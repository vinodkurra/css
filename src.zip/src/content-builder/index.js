import React, { useEffect, useState, Fragment } from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import Toolbar from './components/Header/Toolbar';
import ContentTab from './components/Header/ContentTab';
import FormBar from './components/Header/FormBar';
import {
  updateBreadCrumb,
  setContentId,
  setCursorSelectedStatus,
  updateContentName,
  saveContent,
  deleteContent,
  setContentModifiedFlag,
  saveContentByContentId,
  deleteContentByContentId,
  getAllContents,
  getContentDetailsByContentId,
  setProcessAndModule,
  setRenameModuleFlag,
  deleteStoredWidgetLables,
  deleteContentWidgetLabelsByContentId
} from '../store/content';
import PopupComponent from './components/PopupCompontnet';
import ProcessModule from './components/Header/ProcessModule';
import { PROCESS, MODULE, INPUT_TAB, OUTPUT_TAB, PROPERTIES_TAB } from './components/Constants';
import currentContentObjects from '../content-builder/components/GetCurrentContentObjects';
import MessageComponent from '../features/home/message'

function ContentBuilder(props) {

  const dispatch = useDispatch();

  const styles = useSelector((state) => state.ui.styles);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [popupHeader, setPopupHeader] = useState('');
  const [popupMessage, setPopupMessage] = useState('');
  const [newContentName, setNewContentName] = useState('');
  const [currentContentName, setCurrentContentName] = useState('');
  const [newProcessAndModule, setNewProcessAndModule] = useState('');
  const [isWarningPopupVisible, setIsWarningPopupVisible] = useState(false);

  const {
    contents,
    activeContentId,
    // cursorSelectedStatus,
    breadcrumb,
    renameModuleFlag,
    isContentModified,
    contentWidgetLabels
  } = useSelector(
    state => state.content
  );
  const contentState = useSelector((state) => state.content);
  const modules = contents?.length > 0 ?
    contents.find(
      (content) => content.contentId === activeContentId
    ) != undefined ? contents.find(
      (content) => content.contentId === activeContentId
    ).moduleList : []
    : [];

  let currentContent = contents?.length > 0 && contents.find(content => content.contentId === activeContentId);
  let cursorSelectedStatus = currentContent?.cursorSelectedStatus;
  const processModule =
    contents.length > 0
      ? contents.find((content) => content.contentId === activeContentId) !=
        undefined
        ? contents.find((content) => content.contentId === activeContentId)
          .processModule
        : ''
      : '';
  let widgetDuplicateStatus = currentContent?.widgetDuplicateStatus?.length > 0 ? currentContent.widgetDuplicateStatus : [];
  let content = currentContentObjects(contents, activeContentId);
  let activeFormBarTab = content?.activeFormBarTab;
  let isOutputContentModified = content?.isOutputContentModified;

  useEffect(() => {
    if (!activeContentId) {

      dispatch(getAllContents());
      console.log("breadcrumb", breadcrumb);
      dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
    }
  }, []);

  // useEffect(() => {
  //   setIsWarningPopupVisible(true)
  // }, [widgetDuplicateStatus?.length > 0])

  // useEffect(() => {
  //   // localStorage.setItem('tmp_contentBuilder', JSON.stringify(contentState));
  //   if (contents.length > 0) {
  //     dispatch(setContentId(contents[0].contentId));
  //   }
  // }, []);



  /**
   * adding and removing an event listner while clicking mouse left click .
   */
  useEffect(() => {
    window.addEventListener("click", handleCursor);
    return () => {
      window.removeEventListener("click", handleCursor);
    };
  });

  /**
    * Function for handling cursor deselcting using clicking mouse left click  .
    */
  function handleCursor() {
    if (cursorSelectedStatus) {
      dispatch(setCursorSelectedStatus(false));
    }
  };

  /**
   * Content save functionality
   */

  useEffect(() => {
    if (activeContentId) {
      const contentName = contents?.find(
        (content) => content.contentId === activeContentId
      )?.title;
      setCurrentContentName(contentName);
    }
  }, [activeContentId])

  const handleGetContentName = (e) => {
    if (e) e.preventDefault();
    const { name, value } = e.target;
    setNewContentName(value);
    dispatch(updateContentName(value));
  };

  const warningWithSavePopup = () => {
    return (
      <Fragment>
        <p className="text-align">{popupMessage}</p>
        {!currentContentName ?
          <input
            type="text"
            autoComplete="off"
            className="content-name-input"
            placeholder="Enter Content Name"
            value={newContentName}
            onChange={handleGetContentName}
          />
          : ''
        }
        {
          !processModule ?
            <div className="processModule">
              <div className="processTab">
                <input className={newProcessAndModule == PROCESS ? 'module-process-button active' : 'module-process-button'} type="button"
                  value={PROCESS}
                  title={PROCESS}
                  onClick={() => handleSetModuleProcess(PROCESS)}
                />
                <span>/</span>
                <input className={newProcessAndModule == MODULE ? 'module-process-button active' : 'module-process-button'} type="button"
                  value={MODULE}
                  title={MODULE}
                  onClick={() => handleSetModuleProcess(MODULE)}
                />
              </div>
            </div> : ''
        }
        <div className="align-button">
          <input
            type="button"
            className="close-button ml5"
            value="Save"
            disabled={!newContentName && !currentContentName || (!newProcessAndModule && !processModule)}
            onClick={handleSave}
          />
          <input
            type="button"
            className="close-button ml5"
            value="Close"
            onClick={handleClose}
          />
        </div>
      </Fragment>
    );
  };

  const handleSaveContent = () => {

    const contentName = contents.find(
      (content) => content.contentId === activeContentId
    ).title;
    setNewProcessAndModule('');
    setCurrentContentName(contentName);

    //if (contentName) {
    if (contentName) {
      handleSave();
      return;
    }
    else {
      handleCloseContent();
      return;
    }
  };

  const handleCloseContent = (e) => {
    if (e) e.preventDefault();
    //if (!isContentModified) {
    if (((activeFormBarTab === PROPERTIES_TAB || activeFormBarTab === INPUT_TAB) &&
      !isContentModified) || (activeFormBarTab === OUTPUT_TAB &&
        !isOutputContentModified)) {
      handleClose();
      return;
    }
    setNewContentName('');
    const contentName = contents?.find(
      (content) => content.contentId === activeContentId
    )?.title;
    setCurrentContentName(contentName);
    setPopupHeader('Content');
    const message = (
      <Fragment>
        <span>
          Want to save your {contentName ? 'changes' : 'content'}{' '}
          {contentName ? contentName : ''}?
        </span>
        <br />
        <span>
          If you click "Close" current changes won't be available in this
          content document
        </span>
        <br />
        <span>Do you really want to Close ?</span>
        <br />
      </Fragment>
    );
    setPopupMessage(message);
    setIsPopupVisible(true);
    return;
  };

  const handleSave = (e) => {
    if (e) e.preventDefault();
    if (newProcessAndModule) {
      dispatch(setProcessAndModule(newProcessAndModule));
    }
    dispatch(saveContentByContentId(contents, activeContentId, newContentName));
    dispatch(updateBreadCrumb({ ...breadcrumb, content: newContentName }));
    setIsPopupVisible(false);
    setNewContentName('');
    // dispatch(saveContent(activeContentId));
    // dispatch(updateBreadCrumb({ ...breadcrumb, content: newContentName }));
    // setIsPopupVisible(false);
  };

  const handleClose = (e) => {
    if (e) e.preventDefault();
    let checksumId = JSON.parse(localStorage.getItem("account")).userid;
    dispatch(deleteContentByContentId(activeContentId, checksumId));
    dispatch(deleteContentWidgetLabelsByContentId(activeContentId));
    dispatch(updateBreadCrumb({ ...breadcrumb, content: '', module: '' }));
    setIsPopupVisible(false);
    dispatch(deleteStoredWidgetLables(activeContentId, 0, contentWidgetLabels, true));
    // dispatch(deleteContent());
    // dispatch(updateBreadCrumb({ ...breadcrumb, content: '', module: '' }));
    // setIsPopupVisible(false);
    return;
  };

  const handleSetModuleProcess = (processModule) => {
    setNewProcessAndModule(processModule);
    //dispatch(setProcessAndModule(processModule));
    //dispatch(setContentModifiedFlag(true));
  }

  const warningPopup = () => {
    const message = (
      <Fragment>
        <span>
          Widget Field Label Name already exported
        </span>
      </Fragment>
    );
    //setPopupMessage(message);
    return (
      <Fragment>
        <p className="text-align">{message}</p>
        <div className="align-button">
          <input
            type="button"
            className="close-button ml5"
            value="Close"
            onClick={() => {
              setIsWarningPopupVisible(false);
            }}
          />
        </div>
      </Fragment>
    );
  };


  return (
    <ContentStyles>
      <Toolbar handleSaveContent={handleSaveContent} />
      <ContentTab handleCloseContent={handleCloseContent} />
      <FormBar />
      {/* content save popup call from contentTab and Toolbar */}
      <PopupComponent
        width="500px"
        visible={isPopupVisible}
        styles={styles}
        header={popupHeader}
        children={warningWithSavePopup()}
        close={() => {
          setIsPopupVisible(false);
        }}
      />
      {/* warning popup */}
      <PopupComponent
        width="500px"
        visible={isWarningPopupVisible}
        styles={styles}
        header={popupHeader}
        children={warningWithSavePopup()}
        close={() => {
          setIsWarningPopupVisible(false);
        }}
      />

    </ContentStyles>
  );
}

export default ContentBuilder;

const ContentStyles = Styled.div`
background: #d9d9d9 !important;
font-size:14px;
.text-align{
  text-align:center;
}
.align-button{
  display:flex !important;
  justify-content: space-around;
  margin-bottom: 15px;
  width: 45%;
  margin: 10px auto;
}
.mb15{
  margin-bottom:15px !important;
}
.content-name-input {
  background: white;
  border: 1px solid #666;
  border-radius: 5px;
  outline: 0;
  padding: 5px;
  box-shadow: 0px 0px 2px #999;
  width: 70%;
  height: 35px;
  align-self: center;
}
.module-process-button{
    background: #f2f2f2;
    border-radius: 5px;
    border: none;
    font-size: 14px;
    font-weight: 500;
    padding: 2px 5px;
    margin-right:3px;
    margin-left:3px;
}
.processTab{
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
.module-process-button.active{
  outline: black auto 1px;
}
.close-button:disabled{
    opacity: 0.7;
    cursor: not-allowed;
}

`;