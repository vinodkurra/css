import React from 'react';
import styled from 'styled-components';

export const getIndex = (type, options) => {
  let index;
  options.filter((option, idx) => {
    if(option.value === type) index = idx
    return true;
  })
  return index
}

/**
 * Function will render the jsx fragment with icon.
 * @param {string} imageUrl
 * @param {string} type
 */
export const renderLabel = (imageUrl, type) => {
  return (
    <Div title={type}>
      <img src={imageUrl} draggable="false" alt={type} />
    </Div>
  );
};

const Div = styled.div`
  /* padding: 10px; */
  height: 25px;  
  display: flex;
  align-items: center;
  img {
    padding: 5px;
    width: 38px! important;
    height: 38px! important
  }
`;
