import React from "react";
import styled from "styled-components";
import { useSelector } from "react-redux";

import EditPaneCursor from "../EditPaneCursor";
import ExecutionWidgetList from "../ExecutionwidgetList";

import {
  WARNING_INPUT_WIDGET,
  NARRATIVE_WIDGET,
  CALCULATION_WIDGET,
} from "../Constants";

export default function NestedExecutionFrame(props) {
  const { contents, activeContentId } = useSelector((state) => state.content);
  const styles = useSelector((state) => state.ui.styles);
  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);

  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let nestedBranchCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;

  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;

  let nestedExecutionCursorIndex =
    currentContent?.nestedExecutionFrameCursorId !== undefined
      ? currentContent.nestedExecutionFrameCursorId
      : undefined;
  /**
   * Function to get the class name based on type of the widget.
   *  @return {string} - will return backgroud class
   */
  const getBackgroundClass = () => {
    switch (props.widgetDetails?.widgetType) {
      case WARNING_INPUT_WIDGET:
        return { class: "background_warn", color: "#f1420d" };
      case NARRATIVE_WIDGET:
        return { class: "nara_bg", color: "#ec04e5" };
      case CALCULATION_WIDGET:
        return { class: "calc_bg", color: "#f79032" };
      default:
        return { class: "background", color: "#f2f2f2" };
    }
  };
  return (
    <Styles styles={styles} widgetHeaderColor={getBackgroundClass().color}>
      <div
        className={
          props?.module?.readOnly
            ? "execution-frame pointerEvent"
            : "execution-frame"
        }
        onClick={(e) =>
          props.handleSelectWidget(
            e,
            props.widgetPosition,
            props.widgetDetails,
            props.module,
            props.widgetIndex,
            props.moduleIndex
          )
        }
      >
        <div className={props.class}></div>
        {props.widgetDetails &&
          props.widgetDetails?.branchControlType !== "jump" && (
            <>
              {props.index === branchWidgetCursorIndex &&
                props.innerWidget &&
                branchWidgetCursorIndex === props.widgetIndex &&
                props.moduleIndex === activeCursorModuleId &&
                nestedBranchCursorIndex === props.index &&
                nestedExecutionCursorIndex === -1 && (
                  <EditPaneCursor type="lined" />
                )}

              <ExecutionWidgetList
                class={props.class}
                module={props.module}
                handleSelectWidget={props.handleSelectWidget}
                widgetPosition={props.widgetPosition}
                widgetIndex={props.widgetIndex}
                moduleIndex={props.moduleIndex}
                isFocus={props.isFocus}
                index={props.index}
                widgetList={props.widgetDetails.widgetList}
              />
            </>
          )}
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  width: 500px;
  z-index: -1;
  .widget_header {
    display: flex;
    margin-top: 0px !important;
    border: 2px solid #26a889;
    border-bottom: 0;
  }
  .background {
    background: #f2f2f2;
  }
  .background_warn {
    background: #ff0009;
  }
  .nara_bg {
    background: #ec04e5;
  }
  .calc_bg {
    background: #f79032;
  }

  .widget_icon {
    width: 19%;
    position: relative;
    padding: 5px;
    padding-top: 10px;
    > div > img {
      width: 50px;
      height: auto;
      position: absolute;
    }
    .change-type {
      border: none;
      outline: 0;
      cursor: pointer;
      > div {
        border: none;
        background-color: ${({ widgetHeaderColor }) => widgetHeaderColor};
        outline: 0;
        svg {
          color: white;
        }
        .react-select__indicator-separator {
          display: none;
        }
      }
      .react-select__menu {
        background-color: white !important;
      }
    }
  }
  .widget_arrow_collapse {
    width: 20px !important;
    bottom: 2px;
    right: 2px;
  }
  .widget_header_info {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 85%;
    position: relative;
    .field_label {
      text-align: right;
      color: #000;
      padding-right: 10px;
      font-weight: 500;
    }
    .widget_form_text_input {
      input {
        width: 100%;
        outline: 0;
        border: 1px solid white;
        padding: 3px;
      }
      > span {
        width: 100%;
        outline: 0;
        //border: 1px solid white;
        padding: 3px;
        background: white;
        display: block;
        height: 30px;
        .green,
        .gray {
          background: #4da184;
          padding: 2px;
        }
        .gray {
          background: #7a7a7a;
        }
      }
    }
  }
  .widget_base {
    display: flex;
    border-bottom-left-radius: 15px;
    border: 2px solid #26a889;
    border-top: 0;
  }
  .generic_options {
    width: 25%;
    border-bottom-left-radius: 15px;
    overflow: hidden;
    background: #d6d6d6;
    // background: rgb(235, 235, 234);
    padding: 5px;
    .input_group {
      label {
        margin-bottom: 0;
        padding-left: 5px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
      }
    }
  }
  .all_options {
    background: #d6d6d6;
    // background: rgb(235, 235, 234);
    width: 75%;
    padding: 5px;
    position: relative;
  }

  .add_options {
    position: absolute;
    bottom: 5px;
    font-size: 25px;
    font-weight: bold;
    color: white;
    cursor: pointer;
  }
  .widget_view_mode_icon {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
  }
  .widget_view_mode_icon_compressed {
    position: absolute;
    // bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
    z-index: 1;
  }
  .default_bg {
    background: #d6d6d6 !important;
  }

  .dark_bg,
  .dark_bg .generic_options,
  .dark_bg .all_options {
    //background:#7b7878 !important;
    // background: #acacac !important;
    background: ${(props) =>
      props.styles.ContentHighlight_Colour?.background} !important;
  }
  .dark_bg {
    background: "red";
  }
  .radious-none {
    border-bottom-left-radius: 0;
    border-bottom: 1px solid #7b7b7b;
  }
  .ant-picker {
    padding: 0 !important;
  }
  .ant-picker-suffix {
    margin-right: 4px;
  }
  .ant-picker-input input,
  .react-datepicker__input-container input {
    padding: 13px 5px !important;
    border-radius: 0 !important;
  }
  .calcWidgetTextBox {
    height: 30px;
    position: relative;
  }
  .hideOverflow {
    overflow: hidden;
  }
  .bgLightGrey {
    background: #d6d6d6;
  }
  .widgetBaseContainer {
    background: #d6d6d6;
    width: 100%;
    .fieldSection {
      display: flex;
      justify-content: space-between;
      margin: 8px 0 0 8px;
      .textArrow {
        position: relative;
        overflow: hidden;
        input[type="text"] {
          width: 100%;
          border: none;
          height: 28px;
          padding: 2px;
        }
        img {
          position: absolute;
          right: 2px;
          top: 2px;
          height: 20px;
          width: auto;
        }
      }
      .andClick {
        width: 50px;
        span {
          color: #3ef5f6;
          font-weight: 600;
          cursor: pointer;
        }
      }
      .deleteIcon {
        background: #595959;
        border-radius: 15px 0 0 15px;
        img {
          height: 20px;
          width: auto;
        }
      }
      .equalAndArrow {
        select {
          height: 28px;
        }
      }
    }
    .hideBookmark {
      display: flex;
      margin-top: 8px;
      .checkContainer {
        padding-left: 20px;
        input[type="checkbox"] {
          transform: scale(1.5);
        }
        label {
          padding-left: 6px;
          color: black;
          font-weight: 600;
        }
      }
    }
    .orClick {
      text-align: center;
      margin: 10px 20px;
      position: relative;
      span {
        background: #d6d6d6;
        position: relative;
        padding: 0 8px;
        color: #2bf5f5;
        font-weight: 600;
        font-size: 1.2rem;
        width: 60px;
        display: block;
        margin: 0 auto;
        text-align: center;
      }
      .lineBehid {
        height: 3px;
        position: absolute;
        background: #2bf5f5;
        width: 100%;
        top: 50%;
      }
    }
  }
  .widget_form_text_input.bgLightGrey {
    text-align: right;
    padding: 5px;
  }
  .execution-frame {
    border-top: 4px solid #36ae8f;
    border-left: 4px solid #36ae8f;
    padding-bottom: 30px;
    border-bottom: 4px solid #36ae8f;
    width: 500px;
  }
  .dark_bg .widgetBaseContainer,
  .dark_bg .widgetBaseContainer .orClick span {
    background: #a6a2a2 !important;
  }
  .pointerEvent {
    pointer-events: none;
  }
  .widget_view_mode_icon_compressed {
    right: 2px !important;
  }
`;
