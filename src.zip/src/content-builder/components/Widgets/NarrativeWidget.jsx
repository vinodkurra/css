import React from "react";
import styled from "styled-components";
import { MentionsInput, Mention } from "react-mentions";
export default function NarrativeWidget({
  widget,
  handleCalcAndNarrativeChange,
  mentionWidgets,
}) {
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group narav">
          {/* <textarea
            rows="3"
            resize="false"
            value={widget.value}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
          /> */}
          <MentionsInput
            id="calcWidget"
            markup="@[__display__](__id__)"
            value={widget.defaultText || ""}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
            className="textAreaCalcWidget"
            //onKeyUp={(e) => handleKeyPress(e)}
            //onSelect={handleSelect}
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput>
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .narav .textAreaCalcWidget {
    width: 340px !important;
  }
  .default_values {
    .input_group {
      display: flex;
      align-items: center;
      textarea {
        border: none;
        margin-bottom: 20px;
        margin-right: 20px;
        outline-width: 0;
        padding: 5px;
        resize: none;
        width: 100%;
      }
    }
  }
  .textAreaCalcWidget {
    background-color: white;
    width: 400px;
    height: 80px;
    margin: 22px 0 10px 0;
    .textAreaCalcWidget__suggestions {
      z-index: 2 !important;
    }
  }
`;
