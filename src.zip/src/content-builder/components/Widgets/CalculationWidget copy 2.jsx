
import React, { useState, useRef } from 'react'
import { EditorState, convertToRaw, RichUtils } from 'draft-js'
import Editor from 'draft-js-plugins-editor'
import createMentionPlugin, { defaultSuggestionsFilter } from 'draft-js-mention-plugin'
import 'draft-js/dist/Draft.css'
import 'draft-js-mention-plugin/lib/plugin.css'
import styled from 'styled-components';
// import { MentionsInput, Mention } from "react-mentions";

const mentionPlugin = createMentionPlugin()
const { MentionSuggestions } = mentionPlugin
const plugins = [mentionPlugin];

export default function CalculationWidget({
  widget,
  handleCalcAndNarrativeChange,

}) {
  console.log(widget);
  const mentions = [
    {
      id: 1,
      name: 'Matthew Russell',
      title: 'Senior Software Engineer',
      //avatar: 'widget',
    },
    {
      id: 2,
      name: 'Julian Krispel-Samsel',
      title: 'United Kingdom',
      // avatar: 'tag',
    },
  ];
  const [suggestions, setSuggestions] = useState(mentions);
  const [temp, setTemp] = useState({});
  // Draft-JS editor configuration
  const [editorState, setEditorState] = useState(
    () => EditorState.createEmpty(),
  )
  const editor = useRef(null)

  // Check editor text for mentions
  const onSearchChange = ({ value }) => {
    setSuggestions(defaultSuggestionsFilter(value, mentions))
  }

  const onAddMention = () => {
    
    const contentState = editorState.getCurrentContent();
   // const contentStateSelect = editorState.getSelection();
   // const contentStateInline = editorState.getCurrentInlineStyle();
    editorState.getInlineStyleOverride('color:red')
    // const raw = convertToRaw(contentState);
    // const raw1 = convertToRaw(contentStateSelect);
    // const raw2 = convertToRaw(contentStateInline);
  }

  // Focus on editor window
  const focusEditor = () => {
    editor.current.focus()
  }
  const onChange = (editorState) => {
    console.log('editorState', JSON.stringify(editorState));
    setEditorState(editorState);
    RichUtils.toggleInlineStyle(editorState, 'color:red');
  }

  const renderContentAsRawJs = () => {
    
    const contentState = editorState.getCurrentContent();
    const raw = convertToRaw(contentState);

    setTemp(JSON.stringify(raw, null, 2));
  }

  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <input type="button" value="save" onClick={renderContentAsRawJs} />
          <div className="editor" onClick={() => focusEditor()}>
            <Editor
              ref={editor}
              editorState={editorState}
              plugins={plugins}
              onChange={editorState => onChange(editorState)}
              placeholder={'Type here...'}
            />
            <MentionSuggestions
              onSearchChange={onSearchChange}
              suggestions={suggestions}
              onAddMention={onAddMention}
            />
          </div>
          {/* <textarea
            rows="3"
            resize="false"
            value={widget.defaultText}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
          /> */}
          {/* <MentionsInput
            markup="@[__display__](__id__)"
            value={widget.defaultText}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
            style={{ backgroundColor: 'white', width: '400px', height: '100px' }}
            //onKeyUp={(e) => handleKeyPress(e)}
            onSelect={handleSelect}
          >
            <Mention
              trigger="@"
              data={users}
              style={{
                backgroundColor: widget.widgetColor
              }}
              appendSpaceOnAdd='true'
            />
          </MentionsInput> */}
          {/* <div contenteditable="true" className="textAreaContainer">
            Type formula and insert <span className="greenBg">Fields</span> <span className="greyBg">Tags</span> to create a calculation
          </div> */}
        </div>
      </div>
    </Styles >
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      align-items: center;
      display: flex;
      .editor {
        box-sizing: border-box;
        border: 1px solid #ddd;
        cursor: text;
        padding: 16px;
        border-radius: 2px;
        margin-bottom: 2em;
        box-shadow: inset 0px 1px 8px -3px #ABABAB;
        background: #fefefe;
        width:300px;
        height:100px;
      }
      
      .editor :global(.public-DraftEditor-content) {
        min-height: 140px;
      }
      textarea {
        border: none;
        margin-top: 24px;
        margin-bottom: 20px;
        margin-right: 20px;
        outline-width: 0;
        padding: 5px;
        resize: none;
        width: 100%;
      }
      .textAreaContainer{
        background: #fff;
        height: 60px;
        position: relative;
        right: 32px;
        top: 24px;
        width: 100%;
        margin-bottom: 25px;
        .greenBg{
          background: #4da184;
        }
        .greyBg{
          background: #7a7a7a;
        }
      }
    }
  }
`;
