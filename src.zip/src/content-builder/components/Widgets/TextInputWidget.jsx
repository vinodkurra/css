import React from "react";
import styled from "styled-components";
import { MentionsInput, Mention } from "react-mentions";

export default function TextInputWidget({
  widget,
  handleTextInputWidgetTextchange,
  mentionWidgets,
  icons,
  globalLogoRef,
}) {
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <label>Default </label>
          {/* <input
            type="text"
            defaultValue={widget.defaultText}
            onChange={(e) => handleTextInputWidgetTextchange(e, "defaultText")}
          /> */}
          <MentionsInput
            id="calcWidget"
            markup="@[display](id)"
            value={widget.defaultText || ""}
            onChange={(e) => handleTextInputWidgetTextchange(e, "defaultText")}
            className="textAreaCalc"
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput>
          <div className="numberarraw_img">
            <img
              src={icons?.input_field_stretch}
              style={{ width: "26px", height: "26px" }}
              alt=".."
              onClick={(e) => globalLogoRef(e, widget.id, "defaultText")}
            />
          </div>
          
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    overflow: visible !important;
    .textAreaCalc {
      background-color: white;
      width: 100%;
      height: 26px;
      margin: 5px;
      padding: 0 2px;
      .textAreaCalc__suggestions {
        z-index: 2 !important;
      }
    }
    textarea {
      border: none;
      margin-top: 24px;
      margin-bottom: 20px;
      margin-right: 20px;
      outline-width: 0;
      padding: 5px;
      resize: none;
      width: 100%;
    }
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
