import React from 'react';
import { TimePicker } from 'antd';
import styled from 'styled-components';
import moment from 'moment';
import 'antd/dist/antd.css';

/**
 * TimeInputWidget component, this will appear in content edit pane, when Time type widget is selected.
 */
export default function TimeInputWidget({ widget, handleTimeFieldChange }) {
  /**
   * This func is to check for invalid date
   * @param {object} momenttime - has the moment time object
   * @returns {object} momenttime - if moment object is valid date else return empty string
   */
  function checkValidDate(momenttime) {
    if (momenttime._isValid) return momenttime;
    return '';
  }

  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <label>Min </label>
          <TimePicker
            defaultValue={checkValidDate(moment(widget.minimumValue, 'HH:mm'))}
            value={checkValidDate(moment(widget.minimumValue, 'HH:mm'))}
            format={'HH:mm'}
            onChange={(_, timeString) =>
              handleTimeFieldChange(timeString, 'minimumValue')
            }
          />
        </div>
        <div className="input_group">
          <label>Max</label>
          <TimePicker
            defaultValue={checkValidDate(moment(widget.maximumValue, 'HH:mm'))}
            value={checkValidDate(moment(widget.maximumValue, 'HH:mm'))}
            format={'HH:mm'}
            onChange={(_, timeString) =>
              handleTimeFieldChange(timeString, 'maximumValue')
            }
          />
        </div>
        <div className="input_group">
          <label>Default </label>
          <TimePicker
            defaultValue={checkValidDate(moment(widget.defaultValue, 'HH:mm'))}
            value={checkValidDate(moment(widget.defaultValue, 'HH:mm'))}
            format={'HH:mm'}
            onChange={(_, timeString) =>
              handleTimeFieldChange(timeString, 'defaultValue')
            }
          />
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
