import React from "react";
import styled from "styled-components";
import Icons from "../Header/Icons";
import { useSelector } from "react-redux";
import { MentionsInput, Mention } from "react-mentions";
export default function SingleChoiceWidget({
  widget,
  handleCommonInputWidget,
  mentionWidgets,
  icons,
  globalLogoRef,
}) {
  const styles = useSelector((state) => state.ui.styles);

  return (
    <Styles>
      <div className="default_values">
        {widget?.defaultOptions?.map((each, i) => (
          <div className="input_group" key={i}>
            {i === 0 ? <label>Default</label> : <label></label>}
            <input
              type="radio"
              name={widget.title}
              value={i}
              // checked={widget.selectedDefaultOptionindex === i ? true : false}
              checked={each.defaultStatus}
              placeholder="(Value)"
              onClick={(e) => handleCommonInputWidget(e, "radio", i)}
            />
            <input
              type="text"
              className="width40 mr5"
              value={each.value}
              placeholder="(Value)"
              onChange={(e) => handleCommonInputWidget(e, "value", i)}
            />
            {/* <input type="text" placeholder="Write option" value={each.option} onChange={(e) => handleCommonInputWidget(e, "option", i)} /> */}
            <MentionsInput
              id="singleChoice"
              markup="@[display](id)"
              value={each.option}
              onChange={(e) => handleCommonInputWidget(e, "option", i)}
              className="textAreaCalc"
              placeholder="Write Option"
            >
              <Mention
                trigger="@"
                data={mentionWidgets}
                style={{
                  backgroundColor: "#ddd",
                }}
                appendSpaceOnAdd="true"
              />
            </MentionsInput>
            <div className="arraw_img">
              <img
                src={icons?.input_field_stretch}
                style={{ width: "26px", height: "26px" }}
                alt=".."
                onClick={(e) => globalLogoRef(e, widget.id, "defaultOptions", i)}
              />
            </div>
            <Icons
              src={styles.icons.widget_option_delete_icon}
              title="Delete"
              triggerFunc={(e) =>
                handleCommonInputWidget(e, "delete_Default_option_set", i)
              }
              // isActive={i > -1}
              isActive={widget?.defaultOptions.length > 2}
              widgetOptionDeleteIcon={true}
            />
          </div>
        ))}
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    overflow: visible !important;
    .textAreaCalc {
      background-color: white;
      width: 100%;
      height: 26px;
      margin: 5px;
      padding: 0 2px;
      img {
        width: 26px;
        height: 26px;
        position: absolute;
      }
      .textAreaCalc__suggestions {
        z-index: 2 !important;
      }
    }
    textarea {
      border: none;
      margin-top: 24px;
      margin-bottom: 20px;
      margin-right: 20px;
      outline-width: 0;
      padding: 5px;
      resize: none;
      width: 100%;
    }
    .input_group {
      display: flex;
      padding-bottom: 5px;
      align-items: center;
      label {
        font-size: 14px;
        min-width: 50px;
        padding-top: 4px;
        margin-bottom: 0px !important;
      }
      input[type="text"] {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
      input[type="radio"] {
        margin: 0px 6px 0px 6px;
      }
    }
  }
  .width40 {
    width: 40% !important;
  }
  .mr5 {
    margin-right: 5px;
  }
  .delete_option {
    font-size: 15px;
    margin-left: 10px;
    font-weight: bold;
    color: black;
    cursor: pointer;
    border: solid 1px;
    border-radius: 50px;
  }
`;
