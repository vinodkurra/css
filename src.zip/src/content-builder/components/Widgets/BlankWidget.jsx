import React from "react";
import styled from "styled-components";

export default function BlankWidget({ widget, handleCommonInputWidget }) {
  return (
    <Styles>
      <div className="default_values">
        <p>this is a blank widget</p>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
      height:70px;
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        min-width: 50px;
        padding-top: 4px;
        margin-bottom: 0px !important;
      }
      input[type="text"] {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
      input[type="radio"] {
        margin: 0px 6px 0px 6px;
      }
    }
  }
  .width40 {
    width: 40% !important;
  }
  .mr5 {
    margin-right: 5px;
  }
  .delete_option {
    font-size: 15px;
    margin-left: 10px;
    font-weight: bold;
    color: black;
    cursor: pointer;
    border: solid 1px;
    border-radius: 50px;
  }
`;
