import React, { useState } from "react";
import styled from "styled-components";
import { MentionsInput, Mention } from "react-mentions";

export default function WarningInputWidget({
  mentionWidgets,
  widget,
  handleTextInputWidgetTextchange,
}) {
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          {/* <textarea rows="4" /> */}
          <MentionsInput
            id="calcWidget"
            markup="@[display](id)"
            value={widget.defaultText || ""}
            onChange={(e) => handleTextInputWidgetTextchange(e, "defaultText")}
            className="textAreaCalc"
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput>
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    overflow: visible !important;
    .textAreaCalc {
      background-color: white;
      width: 100%;
      height: 100px;
      margin: 5px;
      padding: 0 2px;
      .textAreaCalc__suggestions {
        z-index: 2 !important;
      }
    }
    textarea {
      border: none;
      margin-top: 24px;
      margin-bottom: 20px;
      margin-right: 20px;
      outline-width: 0;
      padding: 5px;
      resize: none;
      width: 100%;
    }
    .input_group {
      display: flex;
      align-items: center;
      textarea {
        width: 98%;
        outline-width: 0;
        border: none;
        resize: none;
        margin-bottom: 4px;
      }
    }
  }
`;
