import React from "react";
import styled from "styled-components";
import { MentionsInput, Mention } from "react-mentions";
export default function NumberWidget({
  widget,
  handleCommonInputWidget,
  mentionWidgets,
  icons,
  globalLogoRef,
}) {
  console.log("number", widget.minimumValue);
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <label>Min </label>
          <input type="text"
            value={widget.minimumValue}
            onChange={(e) => handleCommonInputWidget(e, 'number_minValue')}
          />
          {/* <MentionsInput
            id="calcWidget"
            markup="@[display](id)"
            value={widget.minimumValue || ""}
            onChange={(e) => handleCommonInputWidget(e, "number_minValue")}
            className="textAreaCalc"
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput> */}
          <div className="numberarraw_img">
            <img
              src={icons?.input_field_stretch}
              style={{ width: "26px", height: "26px" }}
              alt=".."
              onClick={(e) => globalLogoRef(e, widget.id, "minimumValue")}
            />
          </div>
        </div>
        <div className="input_group">
          <label>Max</label>
          <input
            type="text"
            value={widget.maximumValue}
            onChange={(e) => handleCommonInputWidget(e, "number_maxValue")}
          />
          {/* <MentionsInput
            id="numberMin"
            markup="@[display](id)"
            value={widget.maximumValue || ""}
            onChange={(e) => handleCommonInputWidget(e, "number_maxValue")}
            className="textAreaCalc"
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput> */}
          <div className="numberarraw_img">
            <img
              src={icons?.input_field_stretch}
              style={{ width: "26px", height: "26px" }}
              alt=".."
              onClick={(e) => globalLogoRef(e, widget.id, "maximumValue")}
            />
          </div>
        </div>
        <div className="input_group">
          <label>Default </label>
          <input
            type="text"
            value={widget.defaultValue}
            onChange={(e) => handleCommonInputWidget(e, "number_defaultValue")}
          />
          {/* <MentionsInput
            id="numberMin"
            markup="@[display](id)"
            value={widget.defaultValue || ""}
            onChange={(e) => handleCommonInputWidget(e, "number_defaultValue")}
            className="textAreaCalc"
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput> */}
          <div className="numberarraw_img">
            <img
              src={icons?.input_field_stretch}
              style={{ width: "26px", height: "26px" }}
              alt=".."
              onClick={(e) => globalLogoRef(e, widget.id, "defaultValue")}
            />
          </div>
        </div>
        <div className="input_group">
          <label>Decimals </label>
          <input
            type="text"
            value={widget.decimalValue}
            onChange={(e) => handleCommonInputWidget(e, "number_decimalValue")}
          />
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    overflow: visible !important;
    .textAreaCalc {
      background-color: white;
      width: 100%;
      height: 26px;
      padding: 0 2px;
      img {
        width: 26px;
        height: 26px;
        position: absolute;
      }
      .textAreaCalc__suggestions {
        z-index: 2 !important;
      }
    }
    textarea {
      border: none;
      margin-top: 24px;
      margin-bottom: 20px;
      margin-right: 20px;
      outline-width: 0;
      padding: 5px;
      resize: none;
      width: 100%;
    }
    margin-bottom: 10px;
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
