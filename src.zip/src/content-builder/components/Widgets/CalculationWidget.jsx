import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
// import { EditorState, convertToRaw, RichUtils } from 'draft-js'
// import Editor from 'draft-js-plugins-editor'
// import createMentionPlugin, { defaultSuggestionsFilter } from 'draft-js-mention-plugin'
// import 'draft-js/dist/Draft.css'
// import 'draft-js-mention-plugin/lib/plugin.css'
import styled from "styled-components";
import { MentionsInput, Mention } from "react-mentions";
// const mentionPlugin = createMentionPlugin()
// const { MentionSuggestions } = mentionPlugin
// const plugins = [mentionPlugin];

export default function CalculationWidget({
  widget,
  handleCalcAndNarrativeChange,
  mentionWidgets,
}) {
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group calc_wid">
          {/* <input type="button" value="save" onClick={renderContentAsRawJs} />
          <div className="editor" onClick={() => focusEditor()}>
            <Editor
              ref={editor}
              editorState={editorState}
              plugins={plugins}
              onChange={editorState => onChange(editorState)}
              placeholder={'Type here...'}
            />
            <MentionSuggestions
              onSearchChange={onSearchChange}
              suggestions={suggestions}
              onAddMention={onAddMention}
            />
          </div> */}
          {/* <textarea
            rows="3"
            resize="false"
            value={widget.defaultText}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
          /> */}
          <MentionsInput
            id="calcWidget"
            markup="@[__display__](__id__)"
            value={widget?.defaultText || ''}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
            className="textAreaCalcWidget"
            //onKeyUp={(e) => handleKeyPress(e)}
            //onSelect={handleSelect}
          >
            <Mention
              trigger="@"
              data={mentionWidgets}
              style={{
                backgroundColor: "#ddd",
              }}
              appendSpaceOnAdd="true"
            />
          </MentionsInput>
          {/* <div contenteditable="true" className="textAreaContainer">
            Type formula and insert <span className="greenBg">Fields</span> <span className="greyBg">Tags</span> to create a calculation
          </div> */}
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`

.calc_wid .textAreaCalcWidget{
  width:340px !important;
}
  .default_values {
    .input_group {
      align-items: center;
      display: flex;
      .editor {
        box-sizing: border-box;
        border: 1px solid #ddd;
        cursor: text;
        padding: 16px;
        border-radius: 2px;
        margin-bottom: 2em;
        box-shadow: inset 0px 1px 8px -3px #ababab;
        background: #fefefe;
        width: 300px;
        height: 100px;
      }
      .bgs {
        background-color: #ddd;
      }

      .editor :global(.public-DraftEditor-content) {
        min-height: 140px;
      }
      textarea {
        border: none;
        margin-top: 24px;
        margin-bottom: 20px;
        margin-right: 20px;
        outline-width: 0;
        padding: 5px;
        resize: none;
        width: 100%;
      }
      .textAreaContainer {
        background: #fff;
        height: 60px;
        position: relative;
        right: 32px;
        top: 24px;
        width: 100%;
        margin-bottom: 25px;
        .greenBg {
          background: #4da184;
        }
        .greyBg {
          background: #7a7a7a;
        }
      }
    }
  }
  .textAreaCalcWidget {
    background-color: white;
    width: 400px;
    height: 80px;
    margin: 22px 0 10px 0;
    .textAreaCalcWidget__suggestions {
      z-index: 2 !important;
    }
  }
  .textAreaCalcWidget__highlighter {
    top: 0;
    max-width:300px;
    strong {
      position: relative;
      top: 5px;
    }
  }
`;
