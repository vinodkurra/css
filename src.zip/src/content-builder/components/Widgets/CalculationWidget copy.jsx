import React, { createRef, useRef, useState } from 'react';
import styled from 'styled-components';
// import { MentionsInput, Mention } from "react-mentions";
import { EditorState } from 'draft-js';
import Editor from 'draft-js-plugins-editor';
import createMentionPlugin, { defaultSuggestionsFilter } from 'draft-js-mention-plugin';

// Draft-JS-Mentions plugin configuration
const mentionPlugin = createMentionPlugin()
const { MentionSuggestions } = mentionPlugin
const plugins = [mentionPlugin];
export default function CalculationWidget({
  widget,
  handleCalcAndNarrativeChange,

}) {
  console.log(widget);
  const mentions = [
    {
      name: 'Matthew Russell',
      title: 'Senior Software Engineer',
      avatar: 'https://pbs.twimg.com/profile_images/517863945/mattsailing_400x400.jpg',
    },
    {
      name: 'Julian Krispel-Samsel',
      title: 'United Kingdom',
      avatar: 'https://avatars2.githubusercontent.com/u/1188186?v=3&s=400',
    },
  ];
  // const editor = createRef();
  const editor = useRef(null);
  // const mentionPlugin = createMentionPlugin({
  //   mentions,
  //   mentionComponent: (mentionProps) => (
  //     <span
  //       className={mentionProps.className}
  //       // eslint-disable-next-line no-alert
  //       onClick={() => alert('Clicked on the Mention!')}
  //     >
  //       {mentionProps.children}
  //     </span>
  //   ),
  // });
  const [state, setState] = useState({
    editorState: EditorState.createEmpty(),
    suggestions: mentions,
  });
  const onChange = (editorState) => {
    setState({
      editorState: editorState,
    });
  };

  const onSearchChange = ({ value }) => {
    setState({
      suggestions: defaultSuggestionsFilter(value, mentions),
    });
  };

  const focus = () => {
    
    if (editor.current) editor.current.focus();
  };


  const { MentionSuggestions } = mentionPlugin;
  const plugins = [mentionPlugin];
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          {/* <textarea
            rows="3"
            resize="false"
            value={widget.defaultText}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
          /> */}
          <div className="editor" onClick={focus}>
            {/* onClick={this.focus} */}
            <Editor
              editorState={state.editorState}
              onChange={onChange}
              plugins={plugins}
              // ref={(element) => { editor = element; }}
              onFocus={focus}
              ref={(element) => { editor = element; }}
            />
            <MentionSuggestions
              onSearchChange={onSearchChange}
              suggestions={state.suggestions}
            />
          </div>
          {/* <MentionsInput
            markup="@[__display__](__id__)"
            value={widget.defaultText}
            onChange={(e) => handleCalcAndNarrativeChange(e)}
            style={{ backgroundColor: 'white', width: '400px', height: '100px' }}
            //onKeyUp={(e) => handleKeyPress(e)}
            onSelect={handleSelect}
          >
            <Mention
              trigger="@"
              data={users}
              style={{
                backgroundColor: widget.widgetColor
              }}
              appendSpaceOnAdd='true'
            />
          </MentionsInput> */}
          {/* <div contenteditable="true" className="textAreaContainer">
            Type formula and insert <span className="greenBg">Fields</span> <span className="greyBg">Tags</span> to create a calculation
          </div> */}
        </div>
      </div>
    </Styles >
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      align-items: center;
      display: flex;
      .editor {
        box-sizing: border-box;
        border: 1px solid #ddd;
        cursor: text;
        padding: 16px;
        border-radius: 2px;
        margin-bottom: 2em;
        box-shadow: inset 0px 1px 8px -3px #ABABAB;
        background: #fefefe;
        width: 400px;
        height: 100px;
      }
      
      .editor :global(.public-DraftEditor-content) {
        min-height: 140px;
      }
      textarea {
        border: none;
        margin-top: 24px;
        margin-bottom: 20px;
        margin-right: 20px;
        outline-width: 0;
        padding: 5px;
        resize: none;
        width: 100%;
      }
      .textAreaContainer{
        background: #fff;
        height: 60px;
        position: relative;
        right: 32px;
        top: 24px;
        width: 100%;
        margin-bottom: 25px;
        .greenBg{
          background: #4da184;
        }
        .greyBg{
          background: #7a7a7a;
        }
      }
    }
  }
`;
