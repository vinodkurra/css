import React from 'react';
import styled from 'styled-components';
import DateField from 'hypaiq-rc/lib/DateField';

/**
 * DateWidget component, this will appear in content edit pane, when date type widget is selected.  
 */
export default function DateWidget({ widget, handleDateFieldChange }) {

  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <label>Min </label>
          <DateField
            selected={widget.minimumValue}
            onChange={e => handleDateFieldChange(e, 'minimumValue')}          
          />
        </div>
        <div className="input_group">
          <label>Max</label>
          <DateField
            selected={widget.maximumValue}
            onChange={e => handleDateFieldChange(e, 'maximumValue')}
          />
        </div>
        <div className="input_group">
          <label>Default </label>
          <DateField
            selected={widget.defaultValue}
            onChange={e => handleDateFieldChange(e, 'defaultValue')}
          />
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
