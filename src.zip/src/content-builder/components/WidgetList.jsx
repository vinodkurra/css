import React from 'react';
import Widget from './Widget';
import BranchControlWidget from './BranchControlWidget';
import { BRANCH_CONTROL_WIDGET } from './Constants';
import EditPaneCursor from './EditPaneCursor';
import { useSelector} from 'react-redux';

export default function NarrativeWidget(props) {
      const {
    contents,
    activeContentId,
    } = useSelector((state) => state.content);

  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);

      let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined 
    ? currentContent.branchWidgetCursorIndex 
    :undefined;

  return (
      <div>
                 {props.widgetList !== undefined &&
                          Object.values(props.widgetList).length > 0
                          ? props.widgetList.map(
                            (widget, widgetIndex) => (
                              <>
                                <div
                                  className={"temp"}
                                  key={widgetIndex}
                                  style={{
                                    marginTop: '10px',
                                    textAlign: 'left',
                                  }}
                                >
                                  {widget.type === BRANCH_CONTROL_WIDGET ?
                                    <BranchControlWidget
                                      class={props.class}
                                      widgetDetails={widget}
                                      module={props.module}
                                      handleSelectWidget={props.handleSelectWidget}
                                      widgetPosition={props.widgetPosition}
                                      widgetIndex={widgetIndex}
                                      moduleIndex={props.moduleIndex}
                                      isFocus={props.isFocus}
                                      innerWidget={true}
                                    />
                                    :
                                    <Widget
                                     // class={props.class}
                                      widgetDetails={widget}
                                      module={props.module}
                                      handleSelectWidget={props.handleSelectWidget}
                                      widgetPosition={props.widgetPosition}
                                      widgetIndex={widgetIndex}
                                      moduleIndex={props.moduleIndex}
                                      isFocus={props.isFocus}
                                      innerWidget={true}
                                    />
                                  }
                             
                                </div>
                        {(props.widgetIndex === activeCursorWidgetId || activeCursorWidgetId === undefined) && props.innerWidget === undefined &&
                                props.moduleIndex === activeCursorModuleId &&  branchWidgetCursorIndex === widgetIndex &&(
                                <EditPaneCursor type="lined" />
                        )}
                                            
                              </>

                            )
                          )
                          : ''}
                          </div>
   );
}

