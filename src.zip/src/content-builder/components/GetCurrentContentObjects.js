export default function currentContentObjects(contents, activeContentId) {

    let currentContent = contents?.length > 0 && contents?.find(content => content.contentId === activeContentId)
    let activeModuleId = currentContent?.activeModuleId ? currentContent.activeModuleId : 0;
    //let selectedWidgetIds = currentContent?.selectedWidgetIds?.length > 0 ? currentContent.selectedWidgetIds : [];
    let selectedModuleIds = currentContent?.selectedModuleIds?.length > 0 ? currentContent.selectedModuleIds : [];
    let modules = currentContent?.moduleList?.length > 0 ? currentContent?.moduleList : [];
    let selectedOuterWidgetIds = currentContent?.selectedOuterWidgetIds?.length > 0 ? currentContent.selectedOuterWidgetIds : [];

    let advancedViewWidgetIds = currentContent?.advancedViewWidgetIds?.length > 0 ? currentContent.advancedViewWidgetIds : [];
    let compressedViewWidgetIds = currentContent?.compressedViewWidgetIds?.length > 0 ? currentContent.compressedViewWidgetIds : [];
    let standardViewWidgetIds = currentContent?.standardViewWidgetIds?.length > 0 ? currentContent.standardViewWidgetIds : [];

    let combinedModulesandWidgets =
        currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
            ? currentContent.modulesAndOutsideWidgetsPositions
            : [];
    let activeCursorModuleId =
        currentContent?.activeCursorModuleId !== undefined
            ? currentContent.activeCursorModuleId
            : undefined;
    let activeCursorWidgetId = currentContent?.activeCursorWidgetId !== undefined ? currentContent.activeCursorWidgetId : undefined;
    let widgets = currentContent?.widgetList ? currentContent.widgetList : [];
    let widgetDuplicateStatus = currentContent?.widgetDuplicateStatus?.length > 0 ? currentContent.widgetDuplicateStatus : [];
    let contentWidgetLabels = currentContent?.contentWidgetLabels?.length > 0 ? currentContent.contentWidgetLabels : [];
    let globalLogoSelectedWidgets = currentContent?.globalLogoSelectedWidgets?.length > 0 ? currentContent?.globalLogoSelectedWidgets : [];
    let currentOutputEditor = currentContent?.outputEditor;
    let activeFormBarTab = currentContent?.activeFormBarTab;
    let isOutputContentModified = currentContent?.isOutputContentModified;
    let outputCursorPosition = currentContent?.outputCursorPosition;
    let selectedWidgetIds = currentContent?.selectedWidgetsData?.widgetIds?.length > 0 ? currentContent?.selectedWidgetsData?.widgetIds : [];
    
    return {
        currentContent: currentContent || {},
        title: currentContent?.title,
        activeModuleId: activeModuleId,
        selectedWidgetIds: selectedWidgetIds,
        selectedModuleIds: selectedModuleIds,
        moduleList: modules,
        selectedOuterWidgetIds: selectedOuterWidgetIds,
        advancedViewWidgetIds: advancedViewWidgetIds,
        compressedViewWidgetIds: compressedViewWidgetIds,
        standardViewWidgetIds: standardViewWidgetIds,
        combinedModulesandWidgets: combinedModulesandWidgets,
        activeCursorModuleId: activeCursorModuleId,
        activeCursorWidgetId: activeCursorWidgetId,
        widgetList: widgets,
        widgetDuplicateStatus: widgetDuplicateStatus,
        modulesAndOutsideWidgetsPositions: combinedModulesandWidgets,
        activeContentId: activeContentId,
        contentWidgetLabels: contentWidgetLabels,
        globalLogoSelectedWidgets: globalLogoSelectedWidgets,
        currentOutputEditor: currentOutputEditor,
        activeFormBarTab: activeFormBarTab,
        isOutputContentModified: isOutputContentModified,
        outputCursorPosition: outputCursorPosition
    }
}