import React, { useState, useEffect, Fragment } from 'react';
import Styled from 'styled-components';
import { Accordion, Card, Button } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
import {
    setIsEmitRefAttachmentFlag, setContentModifiedFlag, importReference, importPicture,
    setContentModuleProperties, setActiveReferenceId, setActiveAttachmentUrl,
    setSelectedPropertiesModuleId, setSelectedPropertiesProcess
} from '../../store/content';
import { userDetails } from "../../calls/apis";
import paperPin from '../../assets/paperPin.png';
import linkIcon from '../../assets/link.png';
import importIcon from '../../assets/import.png';
import downloadIcon from '../../assets/download.png';
import TextAreaFieldGroup from 'hypaiq-rc/lib/TextAreaFieldGroup';
import TextFieldGroup from 'hypaiq-rc/lib/TextFieldGroup';
import TextField from 'hypaiq-rc/lib/TextField';
import SwitchField from 'hypaiq-rc/lib/SwitchField';
import { validateUrl, numericValidation } from '../../common/validation';

export default function PropertiesTab() {
    const [upDown, setUpDown] = useState(false);
    const [imageUpload, setImageUpload] = useState({});
    const { contents, activeContentId, isEmitRefAttachmentFlag } = useSelector(state => state.content);
    const [selectedModuleId, setSelectedModuleId] = useState(0);
    const [fileUploadValidation, setFileuploadValidation] = useState(false);
    const [importPictureUploadValidation, setImportPictureUploadValidation] = useState(false);
    const [refFocus, setRefFocus] = useState(null);
    const [attachFocus, setAttachFocus] = useState(null);
    const [selectRefAttachIndex, setSelectRefAttachIndex] = useState(null);
    const [refAttachValidation, setRefAttachValidation] = useState(false);
    const [userName, setUserName] = useState(null);
    const [selectedProcess, setSelectedProcess] = useState(false);
    const dispatch = useDispatch();
    const maxReferenceCount = 20;
    const [properties, setProperties] = useState({});

    let currentContent = contents.length > 0 ? contents.find((content) => content.contentId === activeContentId) : '';

    let groupId = localStorage.getItem("groupId")
    let checksumId = JSON.parse(localStorage.getItem("account")).userid;
    let author = currentContent?.authors?.filter(x => x.checkSumId === checksumId);
    let access = true;
    if (author?.length > 0 && !author[0].propertiesPermissions.write) {
        access = false;
    }

    const handleSelectContent = (e) => {
        if (e) e.preventDefault();
        setUpDown(!upDown);
        setSelectedProcess(false);
        setSelectedModuleId(0);
        dispatch(setSelectedPropertiesProcess(false));
        dispatch(setSelectedPropertiesModuleId(""));
        initializePropertyField(currentContent);
    }

    const moduleSelect = (e, module) => {
        if (e) e.preventDefault();
        setSelectedProcess(false);
        setSelectRefAttachIndex(null);
        setImportPictureUploadValidation(false);
        setSelectedModuleId(module.id);
        dispatch(setSelectedPropertiesProcess(false));
        dispatch(setSelectedPropertiesModuleId(module.id));
        setImageUpload({});
        let property = currentContent.moduleList?.filter(x => x.id == module.id)[0];
        initializePropertyField(property);
    }

    const processSelect = (e) => {
        if (e) e.preventDefault();
        setSelectedModuleId(0);
        setSelectedProcess(true);
        dispatch(setSelectedPropertiesModuleId(""));
        dispatch(setSelectedPropertiesProcess(true));
        initializePropertyField(currentContent.processProperties);
    }

    useEffect(() => {
        if (selectedModuleId > 0 && currentContent.moduleList?.filter(x => x.id == selectedModuleId).length > 0) {
            let property = currentContent.moduleList?.filter(x => x.id == selectedModuleId)[0];
            initializePropertyField(property);
        }
        else if (selectedProcess)
            initializePropertyField(currentContent.processProperties);
        else
            initializePropertyField(currentContent);
    }, [currentContent]);

    useEffect(() => {
        // used for accordion up and down arrow based on content and modules.
        setUpDown(false);
    }, [activeContentId]);

    useEffect(() => {
        async function userInfo() {
            let user = await userDetails;
            setUserName(user?.firstname);
        }
        userInfo();
    }, []);

    useEffect(() => {
        // used for import pic and ref attach emit from store content module..
        if (isEmitRefAttachmentFlag && selectedProcess) {
            let property = currentContent?.processProperties;
            setProperties(properties => ({
                ...properties, imageName: property.imageName, refAttachmentList: checkRefAttachments(property)
            }));
            dispatch(setIsEmitRefAttachmentFlag(false));
        }
        else if (isEmitRefAttachmentFlag && selectedModuleId > 0) {
            if (currentContent.moduleList?.filter(x => x.id == selectedModuleId).length > 0) {
                let property = currentContent.moduleList.filter(x => x.id == selectedModuleId)[0];
                setProperties(properties => ({
                    ...properties, imageName: property.imageName, refAttachmentList: checkRefAttachments(property)
                }));
                dispatch(setIsEmitRefAttachmentFlag(false));
            }
        }
        else if (isEmitRefAttachmentFlag) {
            let property = currentContent;
            setProperties(properties => ({
                ...properties, imageName: property.imageName, refAttachmentList: checkRefAttachments(property)
            }));
            dispatch(setIsEmitRefAttachmentFlag(false));
        }
    }, [isEmitRefAttachmentFlag]);

    function initializePropertyField(property) {
        property.locked = property.locked ? true : false;
        property.readOnly = property.readOnly ? true : false;
        property.draft = property.draft ? true : false;

        // property.locked = property.locked == null || property.locked ? true : false;
        // property.readOnly = property.locked ? false : true;
        // property.draft = property.draft == null || property.draft ? true : false;

        property.refLinks = checkRefLinks(property);
        property.refAttachmentList = checkRefAttachments(property);
        setProperties(property);
    }

    function checkRefLinks(property) {
        if (property.refLinks == null || property.refLinks?.length == 0) {
            property.refLinks = []; property.refLinks.push('');
        }
        let referenceLength = property.refLinks?.length + (property.refAttachmentList == undefined ? 0 : property.refAttachmentList?.length);
        if (referenceLength < maxReferenceCount) {
            if (property.refLinks[property.refLinks.length - 1] != "")
                property.refLinks.push('');
        }
        return property.refLinks;
    }

    function checkRefAttachments(property) {
        if (property.refAttachmentList == null || property.refAttachmentList?.length == 0) {
            property.refAttachmentList = []; property.refAttachmentList.push('');
        }
        let referenceLength = property.refLinks?.length + (property.refAttachmentList == undefined ? 0 : property.refAttachmentList?.length);
        if (referenceLength < maxReferenceCount) {
            if (property.refAttachmentList[property.refAttachmentList.length - 1] != "")
                property.refAttachmentList.push('');
        }
        return property.refAttachmentList;
    }

    const onInputChange = (event) => {
        const { name, value } = event.target;
        setProperties(properties => ({ ...properties, [name]: value }));
    };

    const onBlur = () => {
        store();
    }

    const store = (property) => {
        if (fileUploadValidation || importPictureUploadValidation || refAttachValidation)
            return;
        if (selectedModuleId != 0) {
            currentContent.moduleList.map((module) => {
                if (module.id === selectedModuleId) {
                    let mod = property || properties;
                    module.title = mod.title;
                    module.searchTerm = mod.searchTerm;
                    module.description = mod.description;
                    module.useCaseDescription = mod.useCaseDescription;
                    module.refLinks = mod.refLinks;
                    module.refAttachmentList = mod.refAttachmentList;
                    module.locked = mod.locked;
                    module.readOnly = mod.readOnly;
                    module.draft = mod.draft;
                    module.minutesSaved = mod.minutesSaved;
                    module.tripsSaved = mod.tripsSaved;
                    module.moneySaved = mod.moneySaved;
                    module.imageName = mod.imageName;
                    module.snoMedTerms = mod.snoMedTerms;
                }
            });
        }
        else if (selectedProcess) {
            let process = property || properties;
            let proceessProperties = {
                title: "Process",
                searchTerm: process.searchTerm,
                description: process.description,
                useCaseDescription: process.useCaseDescription,
                refLinks: process.refLinks,
                refAttachmentList: process.refAttachmentList,
                locked: process.locked,
                readOnly: process.readOnly,
                draft: process.draft,
                minutesSaved: process.minutesSaved,
                tripsSaved: process.tripsSaved,
                moneySaved: process.moneySaved,
                imageName: process.imageName,
                snoMedTerms: process.snoMedTerms
            };
            currentContent.processProperties = proceessProperties;
        }
        else
            currentContent = property || properties;
        dispatch(setContentModuleProperties(currentContent));
    }

    const _handleImageChange = (e) => {
        let reader = new FileReader();
        let file = e.target.files[0];
        if (e.target.files?.length > 0) {
            let extension = e.target.files[0].name?.substring(e.target.files[0].name?.lastIndexOf('.'))?.toLowerCase();
            if (extension == ".jpg" || extension == ".jpeg" || extension == ".png") {
                reader.onloadend = () => {
                    setImageUpload({ file: file, imagePreviewUrl: reader.result });
                    let cloned = JSON.parse(JSON.stringify(properties));
                    cloned["imageName"] = file;
                    setProperties(properties => ({
                        ...properties, imageName: file
                    }));
                    setImportPictureUploadValidation(false);
                    store(cloned);
                    dispatch(importPicture(activeContentId, selectedModuleId, file, selectedProcess ? "process" : "content"));
                }
                reader.readAsDataURL(file);
            }
            else {
                setImportPictureUploadValidation(true);
                dispatch(setContentModifiedFlag(false));
            }
        }
    }

    const _handleFileChange = (event, index) => {
        event.persist();
        event.preventDefault();
        setSelectRefAttachIndex(index);
        dispatch(setActiveAttachmentUrl(null));
        if (event.target.files?.length > 0) {
            let extension = event.target.files[0].name?.substring(event.target.files[0].name?.lastIndexOf('.'))?.toLowerCase();
            if (extension == ".jpg" || extension == ".jpeg" || extension == ".pdf" || extension == ".png") {
                let attach = properties.refAttachmentList;
                attach[index] = event.target.files[0];
                setProperties(properties => ({ ...properties, refAttachmentList: attach }));
                setFileuploadValidation(false);
                store(properties);
                dispatch(importReference(activeContentId, selectedModuleId, event.target.files[0], selectedProcess ? "process" : "content"));
            }
            else {
                setFileuploadValidation(true);
                dispatch(setContentModifiedFlag(false));
            }
        }
    }

    const onAttachFocus = (event, index) => {
        dispatch(setActiveReferenceId(null));
        if (properties.refAttachmentList[index] != "") {
            setAttachFocus(index);
            let url = `${properties.refAttachmentList[index]}?id=${selectedModuleId != 0 ? selectedModuleId : activeContentId}`;
            dispatch(setActiveAttachmentUrl(url));
        }
        else
            dispatch(setActiveAttachmentUrl(null));
    }

    const onAttachBlur = () => {
        dispatch(setActiveReferenceId(null));
        setAttachFocus(null);
    }

    const onRefFocus = (event, index) => {
        setRefFocus(null);
        dispatch(setActiveAttachmentUrl(null));
        if (event.target.value != "" && validateUrl(event.target.value)) {
            setRefFocus(index); dispatch(setActiveReferenceId(index));
        }
        else
            dispatch(setActiveReferenceId(null));
    }

    const onRefChange = (event, index) => {
        let ref = properties.refLinks;
        ref[index] = event.target.value;
        setProperties(properties => ({ ...properties, refLinks: ref }));
    }

    const onBlurRef = (event) => {
        setRefFocus(null); setRefAttachValidation(false);
        if (event.target.value && !validateUrl(event.target.value)) {
            dispatch(setContentModifiedFlag(false));
            return;
        }
        let data = properties.refLinks.map(x => x != "" && !validateUrl(x));
        if (data?.length > 0 && data.filter(x => x == true).length > 0) {
            dispatch(setContentModifiedFlag(false)); setRefAttachValidation(true);
            return;
        }
        referenceLink();
    }

    const referenceLink = () => {
        let referenceLength = properties.refLinks?.length + properties.refAttachmentList?.length;
        if (referenceLength < maxReferenceCount && properties.refLinks[properties.refLinks.length - 1] != "")
            setProperties(properties => ({
                ...properties, refLinks: [...properties.refLinks, ""]
            }));
        store(properties);
    }

    const onSwitchChange = (event, name) => {
        const value = properties[name];
        if (name == "locked" && !value)
            properties["readOnly"] = false;
        if (name == "readOnly" && !value)
            properties["locked"] = false;

        // if (name == "locked" && value)
        //     properties["readOnly"] = true;
        // else if (name == "locked" && !value)
        //     properties["readOnly"] = false;
        // else if (name == "readOnly" && value)
        //     properties["locked"] = true;

        let cloned = JSON.parse(JSON.stringify(properties));
        cloned[name] = !value;
        setProperties(properties => ({ ...properties, [name]: !value }));
        store(cloned);
    }

    return (
        <Styles>
            {
                currentContent?.title ?
                    <>
                        <div className='propertiesContainer'>
                            <div className="processList">
                                <section>
                                    <h3>Process / Module List</h3>
                                    <div className="accordion-scroll">
                                        < Accordion key={currentContent?.contentId}>
                                            <Card>
                                                <Card.Header className={upDown ? 'up' : 'down'}>
                                                    <Accordion.Toggle
                                                        as={Button}
                                                        variant="link"
                                                        eventKey={currentContent?.contentId}
                                                        onClick={(e) => handleSelectContent(e)}                                        >
                                                        {currentContent?.title}
                                                    </Accordion.Toggle>
                                                </Card.Header>
                                                <Accordion.Collapse eventKey={currentContent?.contentId}>
                                                    <Card.Body>
                                                        {currentContent?.moduleList?.map((module, index) => (
                                                            <div className="insideCard" key={index} onClick={(e) => moduleSelect(e, module)}>
                                                                <label className={module.id == selectedModuleId ? 'highlight' : null} >{module.title}</label>
                                                            </div>
                                                        ))}
                                                        <div className="insideCard" onClick={(e) => processSelect(e)}>
                                                            <label className={selectedProcess ? 'highlight' : ''}>Process</label>
                                                        </div>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </div>
                                </section>
                            </div>
                            <div className={`contentDetails ${!access ? 'pointerEvents' : ''}`}>
                                <div className="main-box">
                                    <div className="content-box">
                                        <h3>Content Detail</h3>
                                        <Fragment>
                                            <TextFieldGroup
                                                labelProps={{ label: 'Title' }}
                                                inputProps={{
                                                    name: 'title',
                                                    value: selectedProcess ? "Process" : properties?.title || "",
                                                    onChange: (e) => onInputChange(e),
                                                    onBlur: onBlur,
                                                    disabled: true
                                                }}
                                            />
                                            <TextFieldGroup
                                                labelProps={{ label: 'Search Terms' }}
                                                inputProps={{
                                                    name: 'searchTerm',
                                                    value: properties?.searchTerm || "",
                                                    onChange: (e) => onInputChange(e),
                                                    onBlur: onBlur
                                                }}
                                            />
                                            <TextFieldGroup
                                                labelProps={{ label: 'SNOMED Terms' }}
                                                inputProps={{
                                                    name: 'snoMedTerms',
                                                    value: properties?.snoMedTerms || "",
                                                    onChange: (e) => onInputChange(e),
                                                    onBlur: onBlur
                                                }}
                                            />
                                            <TextAreaFieldGroup
                                                labelProps={{ label: "Content Description" }}
                                                inputProps={{
                                                    rows: 6, name: 'description', value: properties?.description || "",
                                                    onChange: (e) => onInputChange(e),
                                                    onBlur: onBlur
                                                }} />
                                            <TextAreaFieldGroup
                                                labelProps={{ label: 'Use Case Description' }}
                                                inputProps={{
                                                    rows: 6,
                                                    name: 'useCaseDescription',
                                                    value: properties?.useCaseDescription || "",
                                                    onChange: (e) => onInputChange(e),
                                                    onBlur: onBlur
                                                }} />
                                        </Fragment>
                                    </div>
                                    <div className="content-box pl40">
                                        <h3>Status</h3>
                                        <Fragment>
                                            <div className="disFlex">
                                                <div className="statusOption">
                                                    <div className="disFlex">
                                                        <label>
                                                            <span>Locked</span>
                                                        </label>
                                                        <SwitchField activeColor="#14af14" onChange={(e) => onSwitchChange(e, "locked")} defaultChecked={properties.locked} checked={properties?.locked} />
                                                    </div>
                                                    <div className="disFlex readOnly">
                                                        <label className="subList">
                                                            <span>Read Only</span>
                                                        </label>
                                                        <SwitchField activeColor="#14af14" onChange={(e) => onSwitchChange(e, "readOnly")} defaultChecked={properties?.readOnly} checked={properties?.readOnly} />
                                                        {/* disabled={properties.locked ? true : false}  */}
                                                    </div>
                                                    <div className="disFlex spaceSwitchField">
                                                        <label>
                                                            <span>Final</span>
                                                        </label>
                                                        <SwitchField activeColor="#14af14" onChange={(e) => onSwitchChange(e, "draft")} defaultChecked={properties.draft} checked={properties?.draft} />
                                                    </div>
                                                </div>
                                                <div className="statusSelect">
                                                    <div>
                                                        <TextFieldGroup
                                                            labelProps={{ label: 'Minutes Saved' }}
                                                            inputProps={{
                                                                name: 'minutesSaved',
                                                                list: "minutes",
                                                                value: properties?.minutesSaved || "",
                                                                maxLength: 4,
                                                                onChange: (e) => onInputChange(e),
                                                                onKeyPress: (e) => numericValidation(e),
                                                                onBlur: onBlur
                                                            }}
                                                        />
                                                        <datalist id="minutes">
                                                            <option>0</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                        </datalist>
                                                    </div>
                                                    <div>
                                                        <TextFieldGroup
                                                            labelProps={{ label: 'Trips Saved' }}
                                                            inputProps={{
                                                                name: 'tripsSaved',
                                                                list: "trips",
                                                                maxLength: 4,
                                                                value: properties?.tripsSaved || "",
                                                                onChange: (e) => onInputChange(e),
                                                                onKeyPress: (e) => numericValidation(e),
                                                                onBlur: onBlur
                                                            }}
                                                        />
                                                        <datalist id="trips">
                                                            <option>0</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                        </datalist>
                                                    </div>
                                                    <div>
                                                        <TextFieldGroup
                                                            labelProps={{ label: 'Money Saved' }}
                                                            inputProps={{
                                                                name: 'moneySaved',
                                                                list: "money",
                                                                maxLength: 4,
                                                                value: properties?.moneySaved || "",
                                                                onChange: (e) => onInputChange(e),
                                                                onKeyPress: (e) => numericValidation(e),
                                                                onBlur: onBlur
                                                            }}
                                                        />
                                                        <datalist id="money">
                                                            <option>0</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                        </datalist>
                                                    </div>
                                                </div>
                                            </div>
                                        </Fragment>
                                        <h3>References</h3>
                                        <div className="referenceScroll">
                                            <div className="references">
                                                {properties.refLinks?.map((ref, index) => (
                                                    <div className="posRelative" key={index}>
                                                        <img src={linkIcon} />
                                                        <TextField className={refFocus == index && ref && validateUrl(ref) ? "focusBorder" : ""} name={"reference_" + index} value={ref || ""} onBlur={(e) => onBlurRef(e)} onChange={(e) => onRefChange(e, index)} onFocus={(e) => onRefFocus(e, index)} />
                                                        {
                                                            ref && !validateUrl(ref) ?
                                                                <span className="validation">Ensure valid reference url!</span> : null
                                                        }
                                                    </div>
                                                ))}
                                                {properties.refAttachmentList?.map((attach, index) => (
                                                    <div className="posRelative" key={index}>
                                                        {(attach == '' || attach?.name != undefined) ?
                                                            <>
                                                                <div className="fileUpload">
                                                                    <img src={paperPin} />
                                                                    <input type="file" name={"attachment_" + index} className="hiddenFile" onChange={(e) => _handleFileChange(e, index)} />
                                                                </div>
                                                                <TextField name={"attachment_" + index} value={attach == '' ? '' : attach?.name} />
                                                                {/* className={fileUploadValidation && index === selectRefAttachIndex ? "refAttachValid" : ""} */}
                                                                {fileUploadValidation && index === selectRefAttachIndex ?
                                                                    <span className="validation">Upload files should be jpg, jpeg, png and pdf!</span> : null
                                                                }
                                                            </>
                                                            :
                                                            <>
                                                                <a target="_blank" title="Download" href={attach}>
                                                                    <img className="marginRight5" src={downloadIcon} />
                                                                </a>
                                                                <TextField className={attachFocus == index ? "focusBorder" : ""} onBlur={onAttachBlur} onFocus={(e) => onAttachFocus(e, index)} name={"attachment_" + index} value={attach?.split("/")[attach?.split("/")?.length - 1]} />
                                                            </>
                                                        }
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="importSection">
                                    <div className="uploadBtnContainer">
                                        <div className="aboveUploadBtn">
                                            <img src={importIcon} />
                                            <span> IMPORT PICTURE </span>
                                        </div>

                                        <input className="uploadBtn" type="file" accept="image/*"
                                            onChange={(e) => _handleImageChange(e)} />
                                    </div>
                                    {importPictureUploadValidation ?
                                        <div>
                                            <span className="validation">Upload files should be jpg, jpeg and png!</span>
                                        </div>
                                        : null
                                    }
                                    <div className="imgPreview">
                                        <img src={imageUpload.imagePreviewUrl || properties.imageName} />
                                    </div>
                                </div>
                            </div>
                            <div className="status">
                                <section className="margin9">
                                    <h3>Status</h3>
                                    <ul>
                                        <li>
                                            <span>First Created</span>
                                            <span>{new Date().toLocaleDateString()}</span>
                                        </li>
                                        {/* <li>
                                            <span>Last Published</span>
                                            <span>09/08/2019</span>
                                        </li>
                                        <li>
                                            <span>Version</span>
                                            <span>2.3.11</span>
                                        </li> */}
                                        <li>
                                            <span>Original Author</span>
                                            {/* <span>{userName}</span> */}
                                            {currentContent?.authors?.filter(x => x.authorStatus).sort((a, b) => a - b).reverse()?.map((author) => (
                                                //{
                                                // (author.contentRole !== "ContentOwner")?
                                                //     <>
                                                <span className="paddleft15">{author.userName}</span>
                                                //     </>
                                                // :""
                                                //}
                                            ))}
                                        </li>
                                    </ul>
                                </section>
                            </div>
                        </div>
                    </>
                    : ""
            }
        </Styles >
    )
}

const Styles = Styled.div`
.propertiesContainer{
    background: #f3f3f3;
    display: flex;
    min-height: 400px;
    margin: 0px 10px;
    h3{
        color: #0395a6!important;
      font-size: 20px!important;
      font-weight: 500!important;
      }
    .processList{
      flex: 1.25;
      margin-left: 5px;

      section{
        margin-left: 10px;

    .card-header button{
        width: calc(96% - 20px);
        text-align: left;
        // margin-left: 20px;
        background: #cfcfcf;
        font-size: 14px;
    }
    .insideCard{
        padding-right: 28px;
        margin-bottom: 6px;
        label{
            background: #f3f3f3;
            width: 90%;
            text-align: left;
            padding: 5px;
            color: #707070;
            border: 1px solid #707070;
            border-radius: 3px;
            margin-right: 3px;
            font-weight: normal;
        }
    }
    .insideCard input[type="text"]{
        width: 80%;
    }
    .accordion .card .card-header button:before{
        left:auto !important;
        right: 16px !important;
        top: 16px;
    }
    .collapse, .collapsing{
        text-align: right;
    }
    .card-header{
        background-color: #fff;
        border-bottom: none;
    }
    .btn-link:hover {
        color: #707070;
        text-decoration: none;
    }
    .btn-link {
        color: #707070;
        border: 1px solid #707070;
    }
    .btn.focus, .btn:focus {
        box-shadow: none;
    }
    .card-body{
        display: flex;
        flex-direction: column;
        padding: .75rem 1.25rem;

    }
    .card-body span:hover{
        background: #f3f3f3;
        cursor: pointer !important;
    }
    .card-body .active{
        font-weight: 700;
    }
    .card{
        border: none;
        border-radius: initial;
    }
    .content-box, .card, .card-header{
        // background: #d9d9d9 !important;
        background: #d9d9d900 !important;
    }

    .card-header button:before{
        content: '';
        width: 0px;
        height: 0px;
        border-top: 10px solid transparent;
        border-bottom: 10px solid transparent;
        border-right: 10px solid #727272;
        position:absolute;
        left:16px;
        transition: all 0.75s 0.25s;
        transform: rotate(180deg);
        top: 21px;
        }
        .card-header.up button:before{
            transition: all 0.75s 0.25s;
            transform: rotate(270deg);
        }
        .selected-widget {
            font-weight: 800;
        }
        .accordion-scroll {
            height: 200px;
            overflow-y: scroll;
            direction: ltr;
            margin-right: 5%;
        }
        .accordion-scroll::-webkit-scrollbar {
            width: 8px;
        }

        .accordion-scroll::-webkit-scrollbar-track,
        .settingContainer::-webkit-scrollbar-track {
            background: #b3b3b3;
            border-radius: 10px;
        }

        .accordion-scroll::-webkit-scrollbar-thumb {
            background: #0395a6;
            border-radius: 10px;
        }
      }
    }
    .contentDetails{
      flex: 3;
      background: white;
      border-top: 2px solid #f3f3f3;
      padding-top: 20px;
    }
    .status{
      flex: 0.7;
      ul{
        list-style: none;
        li{
            margin: 5px;
        }
      }
      li span:nth-child(1){
        font-size: 14px;
        font-weight: 500;
      }
      li span:nth-child(2){
        display: block;
        padding-left: 15px;
        font-size: 17px;
      }
    }
    .main-box{
        flex-direction:row;
        display:flex;
        color: #666;
        justify-content: center;
    }

    .content-box {
        min-width:350px;
        max-width:500px;
        padding:0  0 0 2%;

        input{
            margin: 8px 0px 10px 0px;
            border: 1px solid #aeaeae;
	        border-radius: 5px;
            outline: 0;
            padding: 4px 10px;
            box-shadow: 0px 0px 2px #999;
            width: 100% !important;
        }
        textarea{
            width: 100% !important;
            margin: 8px 0px 10px 0px;
            border: 1px solid #aeaeae;
            // height:150px;
            box-shadow: 0px 0px 2px #999;
        }
        select{
            margin: 8px 0px 10px 0px;
            border: 1px solid #aeaeae;
            box-shadow: 0px 0px 2px #999;
        }
        label {
            // display: table;
            position: relative;
            top: 7px;
            left: 8px;
            background: #fff;
            margin-bottom: 0px;
            font-size: 12px;
          }
    }
    .pl40 {
        padding-left:35px !important;
    }

    .width_100 {
        width:100% !important;
    }
    .imgPreview{
        text-align: center;
        margin: 5px 15px;
        height: 300px;
        border: 1px solid #f3f3f3;
        img{
            width: 100%;
            height: 100%;
            background: #2b2b2b;
        }
    }
    .disFlex{
        display: flex;
        div{
            flex:0.5;
        }
        select{
            width: 100%;
            border-radius: 5px;
        }
    }
}
.references {
    margin-top: 7px;
    div
    {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }
}
.statusOption{
    padding-right: 6%;
    .disFlex{
        justify-content: space-between;
        margin: 0% 5% 5% 0%;
    }
    label{
        font-size: 14px !important;
        font-weight: 500;
    }
    .readOnly{
        .subList{
        left: 15px !important;
        }
        label{
        opacity: 0.7;
        }
        .subList:before{
            content: '';
            display: inline-block;
            height: 15px;
            border-left: 1px dashed black;
            position: relative;
            right: 6px;
            bottom: 4px;
        }
        .subList:after{
            content: '';
            width: 5px;
            position: absolute;
            border-bottom: 1px dashed black;
            left: -5px;
            bottom: 8px;
        }
    }
}
.uploadBtn{
    background: #009caa;
}
.uploadBtnContainer{
    position: relative;
    display: inline-block;
    width: 215px;
    overflow: hidden;
    .aboveUploadBtn{
        position: absolute;
        display: flex;
        justify-content: space-around;
        width: 100%;
        span{
            background: #009caa;
            padding: 3px 20px;
            color: #fff;
            font-weight: 500;
            border-radius: 6px;
        }
    }
    .uploadBtn{
        opacity: 0;
    }
}
.importSection{
    // margin: 3% 10% 5% 13%;
    width: 720px;
    margin: 0 auto;
    padding-left: 12px;
}
.switch{
    color:#00ff49;
}
.margin9{
    margin: 9px;
}
.fileUpload{
    //width: 100%;
    position: relative;
    label{
        color: red;
        position: absolute !important;
        right: 0px !important;
        top: -11px !important;
    }
    .hiddenFile{
        opacity: 0;
        position: absolute;
        margin: 0px !important;
        padding: 0px !important;
    }
}
.highlight{
    color: #0095a4 !important;
    border: 3px solid #0095a4 !important;
}
.slider.round:before{
  top: 2px !important;
}
.slider{
    border: 1px solid #14af14 !important;
}
input:checked + .slider {
    background-color: #7df53a;
}
.textAreaDiv{
    position: relative;
    label{
        position: absolute !important;
        top: -4px !important;
        padding: 0px 3px !important;
    }
    textarea{
        padding: 5px;
    }
}
.focusBorder{
    border-color: orange !important;
}
.referenceScroll{
    max-height: 320px;
    overflow-y: auto;
    padding-right: 5px;
}
.referenceDeleteIcon{
    height: 20px;
    width: 20px;
    margin-left: 4px;
    cursor: pointer;
}
.validation{
    color:red;
}
.marginRight5{
    margin-right: 5px;
}
.refAttachValid{
    border: 1px solid red !important;
}
.posRelative{
    position:relative;
    span{
        position: absolute;
    top: -11px;
    right: 0;
    color: red;
    }
}
.spaceSwitchField > div > .switch{
    left: 12px;
}
.pointerEvents{
    pointer-events: none;
}
.paddleft15{
    padding-left: 15px;
    font-size: 17px;
}
`;