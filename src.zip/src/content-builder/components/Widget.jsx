import React, { useRef, useEffect, useState } from "react";
import styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";
import SelectInput from "react-select";
import {
  BinaryInputWidget,
  CalculationWidget,
  TextInputWidget,
  TimeInputWidget,
  WarningInputWidget,
  SingleChoiceWidget,
  DateWidget,
  MultipleChoiceWidget,
  DropdownListWidget,
  NumberWidget,
  NarrativeWidget,
  // BlankWidget,
} from "./Widgets";
import WidgetAdvancedView from "./WidgetAdvancedView";
import BranchControlWidget from "./BranchControlWidget";
import BlankWidget from "./Widgets/BlankWidget";
import {
  COMPRESSED_VIEW,
  STANDARD_VIEW,
  ADVANCED_VIEW,
  BOOKMARK,
  EXPORT,
  REQUIRED,
  HIDE,
  TEXT_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  TIME_INPUT_WIDGET,
  WARNING_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DATE_WIDGET,
  DROPDOWNLIST_WIDGET,
  NUMBER_WIDGET,
  NARRATIVE_WIDGET,
  CALCULATION_WIDGET,
  BLANK_WIDGET,
  BRANCH_CONTROL_WIDGET,
  TEXT_INPUT_WIDGET_TOOLTIP,
  BINARY_INPUT_WIDGET_TOOLTIP,
  TIME_INPUT_WIDGET_TOOLTIP,
  WARNING_INPUT_WIDGET_TOOLTIP,
  SINGLE_CHOICE_WIDGET_TOOLTIP,
  MULTI_CHOICE_WIDGET_TOOLTIP,
  DATE_WIDGET_TOOLTIP,
  DROPDOWNLIST_WIDGET_TOOLTIP,
  NUMBER_WIDGET_TOOLTIP,
  NARRATIVE_WIDGET_TOOLTIP,
  CALCULATION_WIDGET_TOOLTIP,
  BRANCH_CONTROL_WIDGET_TOOLTIP,
} from "./Constants";
import {
  setContentModifiedFlag,
  setAdvancedViewByWidgetIds,
  setCompressedViewByWidgetIds,
  setStandardViewByWidgetIds,
  setCurrentViewMode,
  setWidgetFormTextEnteredStatus,
  setWidgetDefaultNameShowedStatus,
  saveContentDatainBrowser,
  toggleWidget,
  setWidgetDuplicateStatus,
  setGlobalLogoWidget,
  setGlobalLogoSelectedWidgets,
  setIsGlobalLogoPopupVisible,
} from "../../store/content";
import { renderLabel, getIndex } from "./functions";
import currentContentObjects from "./GetCurrentContentObjects";
import {
  findFieldLabelNameExist,
  findExportFieldLabelNameExist,
} from "./WidgetLabelGenerate/FindWidgetLabelExist";
import checkFieldLabelNameExist from "./WidgetLabelGenerate/WidgetLabelByWidgetFormText";
import widgetFieldLabelExist from "./WidgetLabelGenerate/WidgetFieldLabelExist";
import { getExistingWidgets } from "../components/WidgetLabelGenerate/GetExistingExportWidgets";

export default function Widget(props) {
  const inputRef = useRef(null);
  const inputTitleRef = useRef(null);
  const dispatch = useDispatch();
  const [widgetFieldEditIds, setWidgetFieldEditIds] = useState([]);
  const {
    contents,
    activeContentId,
    // selectedWidgetIds,
    // activeModuleId,
    // advancedViewWidgetIds,
    // compressedViewWidgetIds,
    // standardViewWidgetIds,
    //selectedModuleIds
  } = useSelector((state) => state.content);
  const styles = useSelector((state) => state.ui.styles);

  let content = currentContentObjects(contents, activeContentId);

  let currentContent = content?.currentContent;
  let activeModuleId = content?.activeModuleId;
  //let selectedWidgetIds = content?.selectedWidgetIds;
  let activeModuleIds = content?.activeModuleIds;
  let selectedModuleIds = content?.selectedModuleIds;
  let activeCursorModuleId = content?.activeCursorModuleId;
  let activeCursorWidgetId = content?.activeCursorWidgetId;
  let modules = content?.moduleList;
  let widgets = content?.widgetList;
  //let advancedViewWidgetIds = content?.advancedViewWidgetIds;
  let advancedViewWidgetIds = !props.isGlobalLogoPopup
    ? content?.advancedViewWidgetIds
    : [];
  //let compressedViewWidgetIds = content?.compressedViewWidgetIds;
  let compressedViewWidgetIds = !props.isGlobalLogoPopup
    ? content?.compressedViewWidgetIds
    : [];
  let standardViewWidgetIds = content?.standardViewWidgetIds;
  let selectedOuterWidgetIds = content?.selectedOuterWidgetIds;
  //let selectedWidgetsData = currentContent?.selectedWidgetsData?.length > 0 ? currentContent?.selectedWidgetsData : [];
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];
  let globalLogoRefwidget = currentContent.globalRefWidget
    ? currentContent.globalRefWidget
    : {};
  let globalLogoSelectedWidgets = content?.globalLogoSelectedWidgets;
  const allWidgets = getExistingWidgets(currentContent);
  let mentionWidgets = [];
  if (allWidgets?.length > 0) {
    allWidgets.map((widget) => {
      // if (widget.type !== "warning")
      mentionWidgets.push({ id: widget.id, display: widget.title });
    });
  }
  // const mentionWidgets = [
  //   {
  //     id: 1,
  //     display: "Colton Harper",
  //     title: "BA"
  //   },
  //   {
  //     id: 2,
  //     display: "Jackson Juliana",
  //     title: "HR"
  //   },
  //   {
  //     id: 3,
  //     display: "Andrew Anna",
  //     title: "QA"
  //   },
  // ];

  // let currentContent = contents?.length > 0 && contents.find(content => content.contentId === activeContentId)
  // let activeModuleId = currentContent?.activeModuleId ? currentContent.activeModuleId : 0;
  // let selectedWidgetIds = currentContent?.selectedWidgetIds.length > 0 ? currentContent.selectedWidgetIds : [];
  // let selectedModuleIds = currentContent?.selectedModuleIds.length > 0 ? currentContent.selectedModuleIds : [];
  // let modules = currentContent?.moduleList.length > 0 ? currentContent.moduleList : [];
  // let selectedOuterWidgetIds = currentContent?.selectedOuterWidgetIds?.length > 0 ? currentContent.selectedOuterWidgetIds : [];

  // let advancedViewWidgetIds = currentContent?.advancedViewWidgetIds?.length > 0 ? currentContent.advancedViewWidgetIds : [];
  // let compressedViewWidgetIds = currentContent?.compressedViewWidgetIds?.length > 0 ? currentContent.compressedViewWidgetIds : [];
  // let standardViewWidgetIds = currentContent?.standardViewWidgetIds?.length > 0 ? currentContent.standardViewWidgetIds : [];

  // let combinedModulesandWidgets =
  //   currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
  //     ? currentContent.modulesAndOutsideWidgetsPositions
  //     : [];
  // let activeCursorModuleId =
  //   currentContent?.activeCursorModuleId !== undefined
  //     ? currentContent.activeCursorModuleId
  //     : undefined;
  // let activeCursorWidgetId = currentContent?.activeCursorWidgetId !== undefined ? currentContent.activeCursorWidgetId : undefined;
  // let widgets = currentContent?.widgetList ? currentContent.widgetList : [];

  const options = [
    {
      value: TEXT_INPUT_WIDGET,
      label: renderLabel(styles.icons.text_widget, TEXT_INPUT_WIDGET_TOOLTIP),
    },
    {
      value: BINARY_INPUT_WIDGET,
      label: renderLabel(
        styles.icons.binary_choice_widget,
        BINARY_INPUT_WIDGET_TOOLTIP
      ),
    },
    {
      value: MULTI_CHOICE_WIDGET,
      label: renderLabel(
        styles.icons.multi_choice_widget,
        MULTI_CHOICE_WIDGET_TOOLTIP
      ),
    },
    {
      value: SINGLE_CHOICE_WIDGET,
      label: renderLabel(
        styles.icons.single_choice_widget,
        SINGLE_CHOICE_WIDGET_TOOLTIP
      ),
    },
    {
      value: DATE_WIDGET,
      label: renderLabel(styles.icons.date_widget, DATE_WIDGET_TOOLTIP),
    },
    {
      value: NUMBER_WIDGET,
      label: renderLabel(styles.icons.number_widget, NUMBER_WIDGET_TOOLTIP),
    },
    {
      value: DROPDOWNLIST_WIDGET,
      label: renderLabel(
        styles.icons.dropdownlist_widget,
        DROPDOWNLIST_WIDGET_TOOLTIP
      ),
    },
    {
      value: TIME_INPUT_WIDGET,
      label: renderLabel(styles.icons.time_widget, TIME_INPUT_WIDGET_TOOLTIP),
    },
    {
      value: WARNING_INPUT_WIDGET,
      label: renderLabel(
        styles.icons.warning_widget,
        WARNING_INPUT_WIDGET_TOOLTIP
      ),
    },
    {
      value: CALCULATION_WIDGET,
      label: renderLabel(
        styles.icons.calculation_widget,
        CALCULATION_WIDGET_TOOLTIP
      ),
    },
    {
      value: NARRATIVE_WIDGET,
      label: renderLabel(
        styles.icons.narrative_widget,
        NARRATIVE_WIDGET_TOOLTIP
      ),
    },
    {
      value: BRANCH_CONTROL_WIDGET,
      label: renderLabel(
        styles.icons.branch_widget,
        BRANCH_CONTROL_WIDGET_TOOLTIP
      ),
    },
    // {
    //   value: BLANK_WIDGET,
    //   label: renderLabel(
    //     styles.icons.branch_widget,
    //     BRANCH_CONTROL_WIDGET_TOOLTIP
    //   ),
    // },
  ];

  /**
   * focus set to latest created widget
   */
  useEffect(() => {
    if (props.isFocus) {
      if (inputRef.current) inputRef.current.focus();
    }
  }, [props?.widgetDetails]);
  useEffect(() => {
    if (globalLogoSelectedWidgets?.length > 0) {
      let selectedWidgets = globalLogoSelectedWidgets[0];
      dispatch(setGlobalLogoSelectedWidgets([]));
      let mention = ` @[${selectedWidgets.title}](${selectedWidgets.id})`;
      if (props.widgetDetails.id === globalLogoRefwidget.widgetId) {
        if (globalLogoRefwidget.field === "defaultOptions") {
          props.widgetDetails.defaultOptions[
            globalLogoRefwidget.fieldIndex
          ].option = mention;
        } else {
          props.widgetDetails[globalLogoRefwidget.field] = mention;
        }
        dispatch(setContentModifiedFlag(true));
      }
    }
  }, [globalLogoSelectedWidgets]);

  const renderSwitch = () => {
    switch (props.widgetDetails?.type) {
      case TEXT_INPUT_WIDGET:
        return (
          <TextInputWidget
            widget={props.widgetDetails}
            handleTextInputWidgetTextchange={handleTextInputWidgetTextchange}
            mentionWidgets={mentionWidgets}
            icons={styles.icons}
            globalLogoRef={globalLogoRef}
          />
        );
      case BINARY_INPUT_WIDGET:
        return (
          <BinaryInputWidget
            widget={props.widgetDetails}
            handleCommonInputWidget={handleCommonInputWidget}
            mentionWidgets={mentionWidgets}
            icons={styles.icons}
            globalLogoRef={globalLogoRef}
          />
        );
      case TIME_INPUT_WIDGET:
        return (
          <TimeInputWidget
            widget={props.widgetDetails}
            handleTimeFieldChange={handleTimeFieldChange}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case WARNING_INPUT_WIDGET:
        return (
          <WarningInputWidget
            widget={props.widgetDetails}
            handleTextInputWidgetTextchange={handleTextInputWidgetTextchange}
            mentionWidgets={mentionWidgets}
          />
        );
      case SINGLE_CHOICE_WIDGET:
        return (
          <SingleChoiceWidget
            widget={props.widgetDetails}
            handleCommonInputWidget={handleCommonInputWidget}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case MULTI_CHOICE_WIDGET:
        return (
          <MultipleChoiceWidget
            widget={props.widgetDetails}
            handleCommonInputWidget={handleCommonInputWidget}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case DATE_WIDGET:
        return (
          <DateWidget
            widget={props.widgetDetails}
            handleDateFieldChange={handleDateFieldChange}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case DROPDOWNLIST_WIDGET:
        return (
          <DropdownListWidget
            widget={props.widgetDetails}
            handleCommonInputWidget={handleCommonInputWidget}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case NUMBER_WIDGET:
        return (
          <NumberWidget
            widget={props.widgetDetails}
            handleCommonInputWidget={handleCommonInputWidget}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case NARRATIVE_WIDGET:
        return (
          <NarrativeWidget
            widget={props.widgetDetails}
            handleCalcAndNarrativeChange={handleCalcAndNarrativeChange}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case CALCULATION_WIDGET:
        return (
          <CalculationWidget
            widget={props.widgetDetails}
            handleCalcAndNarrativeChange={handleCalcAndNarrativeChange}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case BRANCH_CONTROL_WIDGET:
        return (
          <BranchControlWidget
            widget={props.widgetDetails}
            handleCalcAndNarrativeChange={handleCalcAndNarrativeChange}
            mentionWidgets={mentionWidgets}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
          />
        );
      case BLANK_WIDGET:
        return (
          <BlankWidget
            widget={props.widgetDetails}
            handleCalcAndNarrativeChange={handleCalcAndNarrativeChange}
          />
        );
      default:
        return false;
    }
  };
  /**
   * Ref from global logo
   *
   */
  const globalLogoRef = (e, id, field, index) => {
    let obj = {
      widgetId: id,
      field: field,
      fieldIndex: index,
    };
    dispatch(setGlobalLogoWidget(obj));
    dispatch(setIsGlobalLogoPopupVisible(true));
  };

  /**
   * Function to get the class name based on type of the widget.
   *  @return {string} - will return backgroud class
   */
  const getBackgroundClass = () => {
    let outlineRadius = "";
    if (compressedViewWidgetIds?.indexOf(props.widgetDetails?.id) > -1)
      outlineRadius = "borderBottomLeftRadius";
    if (advancedViewWidgetIds?.indexOf(props.widgetDetails?.id) > -1)
      outlineRadius = "advanceViewBorder";
    switch (props.widgetDetails?.type) {
      case WARNING_INPUT_WIDGET:
        return { class: `background_warn ${outlineRadius}`, color: "#f1420d" };
      case NARRATIVE_WIDGET:
        return { class: `nara_bg ${outlineRadius}`, color: "#ec04e5" };
      case CALCULATION_WIDGET:
        return { class: `calc_bg ${outlineRadius}`, color: "#f79032" };
      default:
        return {
          class: `background ${outlineRadius}`,
          color: "#2479f2 !important",
        };
    }
  };

  const getBackgroundClassWithBookmark = () => {
    // let outlineRadius = "";
    // if (compressedViewWidgetIds?.indexOf(props.widgetDetails?.id) > -1)
    //   outlineRadius = "borderBottomLeftRadius";
    // if (advancedViewWidgetIds?.indexOf(props.widgetDetails?.id) > -1)
    //   outlineRadius = "advanceViewBorder";
    switch (props.widgetDetails?.type) {
      case WARNING_INPUT_WIDGET:
        return { class: `background_warn`, color: "#f1420d" };
      case NARRATIVE_WIDGET:
        return { class: `nara_bg`, color: "#ec04e5" };
      case CALCULATION_WIDGET:
        return { class: `calc_bg`, color: "#f79032" };
      default:
        return {
          class: `background`,
          color: "#2479f2 !important",
        };
    }
  };

  /**
   * swap widget view mode based on existing view mode
   */
  const handleWidgetViewModeChange = (e, widget, viewType) => {
    if (e) e.preventDefault();
    switch (viewType) {
      case STANDARD_VIEW:
        batch(() => {
          dispatch(setAdvancedViewByWidgetIds(widget.id));
          if (standardViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setStandardViewByWidgetIds(widget.id));
          //dispatch(setCurrentViewMode(STANDARD_VIEW));
          props.widgetDetails.widgetCurrentViewMode = STANDARD_VIEW;
        });
        break;
      case ADVANCED_VIEW:
        batch(() => {
          dispatch(setCompressedViewByWidgetIds(widget.id));
          if (advancedViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setAdvancedViewByWidgetIds(widget.id));
          // dispatch(setCurrentViewMode(COMPRESSED_VIEW));
          props.widgetDetails.widgetCurrentViewMode = COMPRESSED_VIEW;
        });
        break;
      case COMPRESSED_VIEW:
        batch(() => {
          dispatch(setStandardViewByWidgetIds(widget.id));
          if (compressedViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setCompressedViewByWidgetIds(widget.id));
          // dispatch(setCurrentViewMode(STANDARD_VIEW));
          props.widgetDetails.widgetCurrentViewMode = STANDARD_VIEW;
        });
        break;
      default:
        return false;
    }
  };

  // Common function to handle call back functions from binary, single choice, multiple choice, drop-down, number widgets.
  const handleCommonInputWidget = (e, type, i) => {
    // if (e) e.stopPropagation();
    //if (e) e.preventDefault();
    const { value } = e.target;
    dispatch(setContentModifiedFlag(true));
    // const numberValidate = /^[0-9]+$/;
    function onlyNumber(value) {
      // return value.replace(/[^0-9\.]+/g, "");
      return value;
    }
    switch (type) {
      case "radio":
        //  props.widgetDetails.selectedDefaultOptionindex = i;
        props.widgetDetails.defaultOptions.map((option, index) => {
          if (index === i) option.defaultStatus = !option.defaultStatus;
          //  option.defaultStatus = true;
          else option.defaultStatus = false;
        });
        // props.widgetDetails.selectedDefaultOptionindex = i;
        break;
      case "value":
        props.widgetDetails.defaultOptions[i].value = value;
        break;
      case "option":
        props.widgetDetails.defaultOptions[i].option = value;
        break;
      case "add_Default_option_set":
        props.widgetDetails.defaultOptions = [
          ...props.widgetDetails.defaultOptions,
          { value: "", option: "", defaultStatus: false },
        ];
        break;
      case "delete_Default_option_set":
        props.widgetDetails.defaultOptions.splice(i, 1);
        props.widgetDetails.defaultOptions = [
          ...props.widgetDetails.defaultOptions,
        ];
        break;

      case "number_minValue":
        // if (
        // numberValidate.test(value)
        //   value.replace(/^[0-9]+$/g, '')
        // || value === ""
        // ) {
        //   props.widgetDetails.minimumValue = value;
        // }
        props.widgetDetails.minimumValue = onlyNumber(value);
        break;
      case "number_maxValue":
        props.widgetDetails.maximumValue = onlyNumber(value);
        break;
      case "number_defaultValue":
        props.widgetDetails.defaultValue = onlyNumber(value);
        break;
      case "number_decimalValue":
        props.widgetDetails.decimalValue = onlyNumber(value);
        break;
      default:
        return false;
    }

    dispatch(saveContentDatainBrowser());
  };

  /**
   * widget default text value assign to state
   */
  const handleTextInputWidgetTextchange = (e, type) => {
    // if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));
    const numberValidate = /^[0-9]+$/;
    switch (type) {
      case "defaultText":
        props.widgetDetails.defaultText = e.target.value;
        break;
      case "maximumchar":
        if (numberValidate.test(e.target.value))
          props.widgetDetails.maximumchar = e.target.value;
        break;
      default:
        return false;
    }

    dispatch(saveContentDatainBrowser());
  };

  /**
   * Func to handle Time field when new time selected
   * @param {string} time - HH:mm format time string
   * @param {string} widgetProp - to select widgetDetails property
   */
  function handleTimeFieldChange(time, widgetProp) {
    dispatch(setContentModifiedFlag(true));
    switch (widgetProp) {
      case "minimumValue":
        props.widgetDetails.minimumValue = time;
        break;
      case "maximumValue":
        props.widgetDetails.maximumValue = time;
        break;
      case "defaultValue":
        props.widgetDetails.defaultValue = time;
        break;
      default:
        return "";
    }
    dispatch(saveContentDatainBrowser());
  }

  /**
   * Func to handle Date field when new date selected.
   * @param {object} date - Select date object
   * @param {string} widgetProp - to select widgetDetails property
   */
  const handleDateFieldChange = (date, widgetProp) => {
    console.log("be date ", date);
    console.log("widgetProp", widgetProp);
    // if(date) date = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
    console.log("af date ", date);
    // return
    dispatch(setContentModifiedFlag(true));
    switch (widgetProp) {
      case "minimumValue":
        props.widgetDetails.minimumValue = date;
        break;
      case "maximumValue":
        props.widgetDetails.maximumValue = date;
        break;
      case "defaultValue":
        props.widgetDetails.defaultValue = date;
        break;
      default:
        return false;
    }

    dispatch(saveContentDatainBrowser());
  };
  /**
   * to get the field type of the mention
   */
  const getFieldType = (e) => {
    let string = e;
    string = string.substring(
      string.lastIndexOf("(") + 1,
      string.lastIndexOf(")")
    );
    let selwidget = allWidgets.filter((sel, idx) => {
      return sel.id === string;
    });
    let type = "";
    if (selwidget) {
      type = selwidget[0]?.type;
    }

    let str = e + "(" + type + ")";
    // e.replace(/\s/g, "");
    const newText = str.split(/\s/).join("");
    console.log("mention", newText);
    return newText;
  };

  /**
   * To handle save function for Narrative and Calculation widget.
   * @params {event} event - getting synthetic event from react active element
   */
  const handleCalcAndNarrativeChange = (e) => {
    // if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));
    let { value } = e.target;
    let pattern = /[()]/;
    value = value.replace(/(@)/g, " @"); //include space before @
    value = value.replace(/  +/g, " ");
    let firstSplit = value.split(" @");
    let finalString = "";
    firstSplit.map((x) => {
      if (x) {
        let first = x;
        let array = first.split(" ");
        array.map((y) => {
          if (y) {
            let withType = "";
            if (y.match(pattern)) {
              let str = getFieldType(y);
              withType = " @" + str + " ";
            } else {
              withType = y + " ";
            }
            finalString = finalString + withType;
            finalString.replace("  ", " ");
          }
        });
      }
    });
    console.log("fieldType", finalString);
    // value = value.replace(/\s+/g, " ");//remove unwanted spaces between the character
    props.widgetDetails.defaultText = value;
    props.widgetDetails.defaultTextFieldType = finalString;
    dispatch(saveContentDatainBrowser());
  };

  // const handleKeyPress = (e) => {

  //   const { value } = e.target;
  // }

  /**
   * widget form text value assign to state
   */
  const handleWidgetFormTextChange = (e) => {
    if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));

    const { value } = e.target;
    const widgetFormTextValidate = /^[a-zA-Z0-9\ ]*$/;
    if (!widgetFormTextValidate.test(value)) return;
    props.widgetDetails.comment = e.target.value;
    dispatch(saveContentDatainBrowser());
  };

  const handleWidgetFormTextBlur = (e) => {
    if (e) e.stopPropagation();

    const value = props.widgetDetails?.comment;
    if (!props.widgetDetails?.isWidgetFormTextEntered) {
      let fieldLabeleName = getFieldLabelName(value);
      if (fieldLabeleName) {
        fieldLabeleName = checkFieldLabelNameExist(
          fieldLabeleName,
          content,
          props.widgetDetails
        );
        //fieldLabeleName = checkFieldLabelNameExist(fieldLabeleName);
        props.widgetDetails.title = fieldLabeleName
          ? fieldLabeleName
          : props.widgetDetails.title;
        props.widgetDetails.widgetDefaultName = props.widgetDetails.title;
        setWidgetFieldEditIds([]);
        //checkWidgetNameDuplicate();
        dispatch(setWidgetFormTextEnteredStatus(props.widgetDetails?.id));
      } else if (!props.widgetDetails?.isWidgetDefaultNameShowed) {
        dispatch(setWidgetDefaultNameShowedStatus(props.widgetDetails?.id));
      }
    }
  };

  function getFieldLabelName(widgetFormText) {
    const maximumFieldLableNameLength = 31;
    let splitWidgetFormText = widgetFormText?.trim()?.split(" ");
    let fieldLableName = "";
    if (splitWidgetFormText?.length >= 2) {
      let firstWord = getFirstWordUpperCase(splitWidgetFormText[0]);
      let secondWord = getFirstWordUpperCase(splitWidgetFormText[1]);
      fieldLableName = firstWord + secondWord;
    } else if (splitWidgetFormText?.length >= 1) {
      fieldLableName = getFirstWordUpperCase(splitWidgetFormText[0]);
    }
    if (fieldLableName) {
      //restrict max length for field label name
      fieldLableName =
        fieldLableName.length > maximumFieldLableNameLength
          ? fieldLableName.substr(0, maximumFieldLableNameLength) + "..."
          : fieldLableName;
    }
    return fieldLableName;
  }

  function getFirstWordUpperCase(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  // function checkFieldLabelNameExist(fieldLabelName) {
  //   let existWidgetNames = [];
  //   const currentModules = contents.find(
  //     (content) => content.contentId === activeContentId
  //   ).moduleList;
  //   const currentContent = contents.find(
  //     (content) => content.contentId === activeContentId
  //   );
  //   let widgetIsExist = -1;
  //   if (currentContent?.widgetList.length > 0) {
  //     widgetIsExist = currentContent.widgetList.findIndex(widget => widget.id === props.widgetDetails?.id);
  //   }

  //   if (widgetIsExist > -1) {
  //     currentContent.widgetList.map((widget, widgetIndex) => {
  //       console.log('widget title ', widget.title)
  //       if (
  //         widget?.title?.includes(fieldLabelName) &&
  //         widget?.title?.length <= fieldLabelName?.length + 3
  //       ) {
  //         existWidgetNames.push(widget.title);
  //       }
  //     });
  //   } else {
  //     currentModules.map((module, index) => {
  //       module.widgetList.map((widget, widgetIndex) => {
  //         console.log('widget title ', widget?.title)
  //         if (
  //           widget?.title?.includes(fieldLabelName) &&
  //           widget?.title?.length <= fieldLabelName?.length + 3
  //         ) {
  //           existWidgetNames.push(widget.title);
  //         }
  //       });
  //     });
  //   }

  //   console.log('existWidgetNames:', existWidgetNames);
  //   //&& isWidgetNameExist
  //   if (existWidgetNames.length > 0) {
  //     let recentWidgetName = existWidgetNames[existWidgetNames.length - 1];
  //     if (recentWidgetName.includes('0')) {
  //       fieldLabelName = getlatestFieldName(recentWidgetName);
  //     } else {
  //       fieldLabelName = fieldLabelName + '001';
  //     }
  //   }
  //   return fieldLabelName;
  // }

  // function getlatestFieldName(recentWidgetName) {
  //   let lastFieldLabelNumber = 1;
  //   lastFieldLabelNumber = parseInt(recentWidgetName.match(/\d+/g)[0].replace(/\b0+/g, ''));
  //   lastFieldLabelNumber++;

  //   let numberOfZeros =
  //     parseInt(lastFieldLabelNumber) <= 9
  //       ? '00'
  //       : parseInt(lastFieldLabelNumber) <= 99
  //         ? '0'
  //         : '000';

  //   let widgetFieldLabelName =
  //     recentWidgetName.match(/[a-zA-Z]+/g)[0] +
  //     numberOfZeros +
  //     lastFieldLabelNumber;

  //   return widgetFieldLabelName;
  // }

  /**
   * getting status from Bookmark,Export,Export,Export to assign states
   */
  const handleCheckboxChange = (e, type) => {
    if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));
    switch (type) {
      case BOOKMARK:
        props.widgetDetails.bookmark = !props.widgetDetails.bookmark;
        break;
      case EXPORT:
        props.widgetDetails.export = !props.widgetDetails.export;
        break;
      case REQUIRED:
        let toggledRequiredBool = !props.widgetDetails.required;
        props.widgetDetails.required = toggledRequiredBool;
        let answerRequired = props.widgetDetails?.answerRequired;
        if (toggledRequiredBool) {
          if (answerRequired === "When") {
          } else {
            answerRequired = "Always";
          }
        } else {
          answerRequired = "Never";
        }
        props.widgetDetails.answerRequired = answerRequired;
        break;
      case HIDE:
        props.widgetDetails.hide = !props.widgetDetails.hide;
        break;
      default:
        return false;
    }

    dispatch(saveContentDatainBrowser());
    if (type === EXPORT) {
      checkWidgetNameDuplicate();
    }
  };

  function checkWidgetNameDuplicate() {
    let isWidgetFieldLabelExist = false;
    if (props.widgetDetails.export) {
      let widgetExists = findFieldLabelNameExist(
        content,
        props.widgetDetails.title,
        props.widgetDetails
      );
      isWidgetFieldLabelExist = widgetExists.length > 0 ? true : false;
    }

    props.widgetDetails.isWidgetFieldLabelExist = isWidgetFieldLabelExist;

    // dispatch(setWidgetDuplicateStatus(props.widgetDetails.id, isWidgetFieldLabelExist));
    if (isWidgetFieldLabelExist) {
      props.widgetDetails.export = false;
      alert("Widget label name already exists!");
    }
  }

  const handleWidgetType = (id, value) => {
    dispatch(toggleWidget({ id, type: value }));
  };

  /**
   * focus set to latest created widget
   */
  useEffect(() => {
    if (inputTitleRef.current) inputTitleRef.current.focus();
  }, [widgetFieldEditIds?.length > 0]);
  const handleWidgetLableEdit = () => {
    setWidgetFieldEditIds(props.widgetDetails.id);
  };

  const handleWidgetTitleChange = (e) => {
    if (e) e.stopPropagation();

    const { value } = e.target;

    const widgetFormTextValidate = /^[a-zA-Z0-9\ ]*$/;
    if (!widgetFormTextValidate.test(value)) return;
    props.widgetDetails.title = value;
    dispatch(setContentModifiedFlag(true));
    dispatch(saveContentDatainBrowser());
  };

  const handleWidgetTitleBlur = (e) => {
    const { name, value } = e.target;
    if (!value) {
      props.widgetDetails.title = props.widgetDetails.widgetDefaultName;
      setWidgetFieldEditIds([]);
      dispatch(setContentModifiedFlag(true));
      dispatch(saveContentDatainBrowser());
      alert("Widget label name should not be empty!");
      return;
    }

    let newFieldLabel = getFieldLabelName(value);
    if (newFieldLabel) {
      props.widgetDetails.isWidgetFieldLabelExist = widgetFieldLabelExist(
        newFieldLabel,
        content,
        props.widgetDetails.id,
        props.widgetDetails
      );

      if (props.widgetDetails.isWidgetFieldLabelExist) {
        alert("Widget label name already exists!");
        dispatch(setContentModifiedFlag(true));
        //props.widgetDetails.title = newFieldLabel;
        props.widgetDetails.title = props.widgetDetails.widgetDefaultName;
        dispatch(saveContentDatainBrowser());
        setWidgetFieldEditIds([]);
      } else {
        props.widgetDetails.title = newFieldLabel;
        props.widgetDetails.widgetDefaultName = newFieldLabel;
        setWidgetFieldEditIds([]);
        dispatch(setContentModifiedFlag(true));
      }
      //dispatch(setWidgetDuplicateStatus(props.widgetDetails.id, props.widgetDetails.isWidgetFieldLabelExist));
    }
  };
  const handleTitleKeyPress = (event) => {
    if (event.key === "Enter") {
      inputTitleRef.current.blur();
    }
  };
  console.log("widgetDetails", props.widgetDetails);
  return (
    <Styles styles={styles} widgetHeaderColor={getBackgroundClass().color}>
      <div className={props.class}>
        <div
          className={"widget_header " + getBackgroundClass().class}
          key={props.widgetDetails?.id}
        >
          <div className="widget_icon">
            <SelectInput
              classNamePrefix="react-select"
              className="change-type"
              options={options}
              isSearchable={false}
              defaultValue={
                options[getIndex(props.widgetDetails?.type, options)]
              }
              onChange={(e) =>
                handleWidgetType(props.widgetDetails?.id, e.value)
              }
              isDisabled={props?.readOnly ? true : false}
            />
          </div>
          <div className="widget_header_info">
            <div className="field_label">
              {inputRef?.current === document.activeElement &&
              !props.widgetDetails?.isWidgetFormTextEntered &&
              !props.widgetDetails?.isWidgetDefaultNameShowed ? (
                <span style={{ visibility: "hidden" }}>test</span>
              ) : widgetFieldEditIds.indexOf(props.widgetDetails?.id) < 0 ? (
                <span onClick={!props?.readOnly && handleWidgetLableEdit}>
                  {props.widgetDetails?.title}
                </span>
              ) : (
                ""
              )}
              {widgetFieldEditIds.indexOf(props.widgetDetails?.id) > -1 &&
              props.widgetDetails?.type !== BLANK_WIDGET ? (
                <input
                  type="text"
                  className="text-color"
                  value={props.widgetDetails?.title}
                  ref={inputTitleRef}
                  onChange={handleWidgetTitleChange}
                  onBlur={handleWidgetTitleBlur}
                  onKeyPress={handleTitleKeyPress}
                />
              ) : (
                ""
              )}
            </div>
            {props.widgetDetails?.type !== NARRATIVE_WIDGET &&
            props.widgetDetails?.type !== CALCULATION_WIDGET &&
            props.widgetDetails?.type !== BLANK_WIDGET &&
            compressedViewWidgetIds.indexOf(props.widgetDetails?.id) < 0 ? (
              <div
                className={
                  props?.readOnly
                    ? "widget_form_text_input pointerEvent"
                    : "widget_form_text_input"
                }
              >
                <input
                  type="text"
                  id={"widget_form_text_input_" + props.widgetDetails?.id}
                  name="widget_form_text_input"
                  autoComplete="off"
                  value={props.widgetDetails?.comment || ""}
                  onChange={handleWidgetFormTextChange}
                  onBlur={handleWidgetFormTextBlur}
                  ref={inputRef}
                />
              </div>
            ) : (
              <div
                className={
                  compressedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1
                    ? "widget_form_text_input calcWidgetTextBox hideOverflow"
                    : "widget_form_text_input calcWidgetTextBox"
                }
              >
                <span
                  className={
                    compressedViewWidgetIds.indexOf(props.widgetDetails?.id) >
                      -1 &&
                    selectedWidgetIds.indexOf(props.widgetDetails?.id) > -1
                      ? props.module.readOnly
                        ? ""
                        : "dark_bg"
                      : props.widgetDetails.type === NARRATIVE_WIDGET ||
                        props.widgetDetails.type === CALCULATION_WIDGET
                      ? selectedWidgetIds.indexOf(props.widgetDetails?.id) > -1
                        ? props.module.readOnly
                          ? ""
                          : "dark_bg"
                        : "default_bg"
                      : "test"
                  }
                  style={
                    props.widgetDetails.type === CALCULATION_WIDGET
                      ? {
                          height: "55px",
                          padding: "4px 6px",
                          fontWeight: "bold",
                          fontSize: "16px",
                          zIndex: "1",
                          position: "absolute",
                        }
                      : {}
                  }
                  onClick={(e) =>
                    props.handleSelectWidget(
                      e,
                      props.widgetPosition,
                      props.widgetDetails,
                      props.module,
                      props.widgetIndex,
                      props.moduleIndex
                    )
                  }
                >
                  {props.widgetDetails.type === CALCULATION_WIDGET ? (
                    <>
                      Type formula and insert{" "}
                      <span className="green">FIELDs</span> &{" "}
                      <span className="gray">TAGs</span> to create a
                      calculation:
                    </>
                  ) : (
                    ""
                  )}
                </span>
              </div>
            )}
            {compressedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1 ? (
              <span
                className="widget_view_mode_icon_compressed"
                onClick={(e) =>
                  handleWidgetViewModeChange(
                    e,
                    props.widgetDetails,
                    COMPRESSED_VIEW
                  )
                }
              ></span>
            ) : (
              ""
            )}
          </div>
          {props.widgetDetails?.bookmark &&
          compressedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1 ? (
            <div
              className={
                "bookMarkRibbon compressedBookmark " +
                getBackgroundClassWithBookmark().class
              }
            >
              <div className="containerSpace">
                <div className="whiteSpace"></div>
              </div>
            </div>
          ) : (
            ""
          )}
        </div>

        {props.widgetDetails?.bookmark &&
        compressedViewWidgetIds.indexOf(props.widgetDetails?.id) < 0 ? (
          <div className={"bookMarkRibbon " + getBackgroundClass().class}>
            <div className="containerSpace">
              <h2 style={{ color: "#ffffff" }}>
                {props.widgetDetails?.outputCount}
              </h2>
              <div className="bookmarklist">
                {props.widgetDetails?.outputList?.map((x) => (
                  <p>{x.title}</p>
                ))}
              </div>
              <div className="whiteSpace"></div>
            </div>
          </div>
        ) : (
          ""
        )}

        {compressedViewWidgetIds.indexOf(props.widgetDetails?.id) < 0 ? (
          <>
            <div
              onClick={(e) =>
                props.handleSelectWidget(
                  e,
                  props.widgetPosition,
                  props.widgetDetails,
                  props.module,
                  props.widgetIndex,
                  props.moduleIndex
                )
              }
              key={props.widgetDetails?.id}
              className={
                selectedWidgetIds.indexOf(props.widgetDetails?.id) > -1
                  ? advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1
                    ? props.readOnly
                      ? "widget_base radious-none"
                      : "widget_base dark_bg radious-none"
                    : props.readOnly
                    ? "widget_base "
                    : "widget_base dark_bg"
                  : "widget_base radious-none"
              }
            >
              <div
                className={
                  props?.readOnly
                    ? "generic_options pointerEvent"
                    : "generic_options"
                }
              >
                <div className="input_group">
                  <input
                    id={"bookmark_" + props.widgetDetails?.id}
                    name={"bookmark_" + props.widgetDetails?.id}
                    type="checkbox"
                    defaultValue={props.widgetDetails?.bookmark}
                    checked={props.widgetDetails?.bookmark}
                    onChange={(e) => handleCheckboxChange(e, BOOKMARK)}
                  />
                  <label
                    style={props?.readOnly ? { pointerEvents: "none" } : {}}
                    htmlFor={"bookmark_" + props.widgetDetails?.id}
                  >
                    Bookmark
                  </label>
                </div>
                {props.widgetDetails?.type !== BLANK_WIDGET ? (
                  <div className="input_group">
                    <input
                      id={"export_" + props.widgetDetails?.id}
                      name={"export_" + props.widgetDetails?.id}
                      type="checkbox"
                      defaultValue={props.widgetDetails?.export}
                      checked={props.widgetDetails?.export}
                      onChange={(e) => handleCheckboxChange(e, EXPORT)}
                    />
                    <label
                      style={props?.readOnly ? { pointerEvents: "none" } : {}}
                      htmlFor={"export_" + props.widgetDetails?.id}
                    >
                      Export
                    </label>
                  </div>
                ) : (
                  <></>
                )}
                {props.widgetDetails?.type !== "warning" ? (
                  <>
                    {props.widgetDetails?.type !== NARRATIVE_WIDGET &&
                    props.widgetDetails?.type !== CALCULATION_WIDGET &&
                    props.widgetDetails?.type !== BLANK_WIDGET ? (
                      <div className="input_group">
                        <input
                          id={"required_" + props.widgetDetails?.id}
                          name={"required_" + props.widgetDetails?.id}
                          type="checkbox"
                          defaultValue={props.widgetDetails?.required}
                          checked={props.widgetDetails?.required}
                          onChange={(e) => handleCheckboxChange(e, REQUIRED)}
                        />
                        <label
                          style={
                            props?.readOnly ? { pointerEvents: "none" } : {}
                          }
                          htmlFor={"required_" + props.widgetDetails?.id}
                        >
                          Required
                        </label>
                      </div>
                    ) : (
                      <></>
                    )}
                    {props.widgetDetails?.type !== BLANK_WIDGET ? (
                      <div className="input_group">
                        <input
                          id={"hide_" + props.widgetDetails?.id}
                          name={"hide_" + props.widgetDetails?.id}
                          type="checkbox"
                          defaultValue={props.widgetDetails?.hide}
                          checked={props.widgetDetails?.hide}
                          onChange={(e) => handleCheckboxChange(e, HIDE)}
                        />
                        <label
                          style={
                            props?.readOnly ? { pointerEvents: "none" } : {}
                          }
                          htmlFor={"hide_" + props.widgetDetails?.id}
                        >
                          Hide
                        </label>
                      </div>
                    ) : (
                      <></>
                    )}
                  </>
                ) : (
                  <></>
                )}
              </div>

              <div className="all_options">
                <div className={props?.readOnly ? "pointerEvent" : "test"}>
                  {renderSwitch()}
                  {props.widgetDetails?.type === MULTI_CHOICE_WIDGET ||
                  props.widgetDetails?.type === SINGLE_CHOICE_WIDGET ||
                  props.widgetDetails?.type === DROPDOWNLIST_WIDGET ? (
                    <span
                      className="add_options"
                      onClick={(e) =>
                        handleCommonInputWidget(e, "add_Default_option_set")
                      }
                    >
                      +
                    </span>
                  ) : (
                    ""
                  )}
                </div>
                <span
                  className="widget_view_mode_icon"
                  onClick={(e) =>
                    handleWidgetViewModeChange(
                      e,
                      props.widgetDetails,
                      advancedViewWidgetIds.indexOf(props.widgetDetails?.id) >
                        -1
                        ? ADVANCED_VIEW
                        : STANDARD_VIEW
                    )
                  }
                ></span>
              </div>
            </div>
          </>
        ) : (
          ""
        )}

        {
          //don't remove this code
          // props.widgetDetails.widgetViewMode === ADVANCED_VIEW ?
          //   <WidgetAdvancedView advancedOptions={props.widgetDetails.advancedOptions} /> : ''
          advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1 ? (
            <div className={props?.readOnly ? "pointerEvent" : "test"}>
              <WidgetAdvancedView
                //advanceProperty={props.widgetDetails.advanceProperty}
                mentionWidgets={mentionWidgets}
                widget={props.widgetDetails}
                module={props.module}
                widgetPosition={props.widgetPosition}
                widgetIndex={props.widgetIndex}
                moduleIndex={props.moduleIndex}
                handleSelectWidget={(e) =>
                  props.handleSelectWidget(
                    e,
                    props.widgetPosition,
                    props.widgetDetails,
                    props.module,
                    props.widgetIndex,
                    props.moduleIndex
                  )
                }
                advancedViewWidgetIds={advancedViewWidgetIds}
              />
            </div>
          ) : (
            ""
          )
        }
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  width: 483px;
  .compressedBookmark {
    height: 60px !important;
    border: 0;
    border-radius: 0;
  }
  .bookMarkRibbon {
    position: absolute;
    height: 100%;
    width: 75px;
    background: #007ced;
    right: -82px;
    top: 0;
    .containerSpace {
      position: relative;
      height: 100%;
      width: 100%;
      h2 {
        position: absolute;
        right: 5px;
        top: 5px;
        font-weight: 700;
      }
      .bookmarklist {
        font-weight: 700;
        transform: rotate(-90deg);
        position: absolute;
        bottom: 43px;
        width: 110px;
        height: 70px;
        right: -13px;
        line-height: 16px;
        font-size: 16px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
      }
      .whiteSpace {
        position: absolute;
        bottom: -1px;
        height: 20px;
        width: 100%;
        background: #fff;
        clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
      }
    }
  }

  .widget_header {
    display: flex;
    border-top-left-radius: 15px;
    border: 2px solid #26a889;
    border-bottom: 0;
  }
  .borderBottomLeftRadius {
    border-bottom-left-radius: 15px;
    border-bottom: 2px solid #26a889;
  }
  .advanceViewBorder {
  }
  .background {
    background: #2479f2;
  }
  .background_warn {
    background: #ff0009;
  }
  .nara_bg {
    background: #ec04e5;
  }
  .calc_bg {
    background: #f79032;
  }

  .widget_icon {
    width: 19%;
    position: relative;
    padding: 5px;
    padding-top: 10px;
    > div > img {
      width: 50px;
      height: auto;
      position: absolute;
    }
    .change-type {
      border: none;
      outline: 0;
      cursor: pointer;
      > div {
        border: none;
        background-color: ${({ widgetHeaderColor }) => widgetHeaderColor};
        outline: 0;
        svg {
          color: white;
        }
        .react-select__indicator-separator {
          display: none;
        }
      }
      .react-select__menu {
        background-color: white !important;
      }
    }
  }
  .widget_arrow_collapse {
    width: 20px !important;
    bottom: 2px;
    right: 2px;
  }
  .widget_header_info {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 85%;
    position: relative;
    .field_label {
      text-align: right;
      color: white;
      padding-right: 10px;
      font-weight: 500;
    }
    .widget_form_text_input {
      input {
        width: 100%;
        outline: 0;
        border: 1px solid white;
        padding: 3px;
      }
      > span {
        width: 100%;
        outline: 0;
        //border: 1px solid white;
        padding: 3px;
        background: white;
        display: block;
        height: 30px;
        .green,
        .gray {
          background: #4da184;
          padding: 2px;
        }
        .gray {
          background: #7a7a7a;
        }
      }
    }
  }
  .widget_base {
    display: flex;
    border-bottom-left-radius: 15px;
    border: 2px solid #26a889;
    border-top: 0;
  }
  .generic_options {
    width: 25%;
    border-bottom-left-radius: 15px;
    overflow: hidden;
    background: #d6d6d6 !important;
    // background: rgb(235, 235, 234) !important;
    padding: 5px;
    .input_group {
      position: relative;
      label {
        margin-bottom: 0;
        padding-left: 5px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        position: initial;
        pointer-events: initial;
      }
    }
  }
  .all_options {
    background: #d6d6d6;
    // background: rgb(235, 235, 234);
    width: 75%;
    padding: 5px;
    position: relative;
  }

  .add_options {
    position: relative;
    font-size: 25px;
    left: 15%;
    font-weight: bold;
    color: white;
    cursor: pointer;
  }
  .widget_view_mode_icon {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
  }
  .widget_view_mode_icon_compressed {
    position: absolute;
    // bottom: 0;
    right: 0px;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
    z-index: 1;
  }
  .borderRed .widget_view_mode_icon_compressed {
    right: 0;
  }
  .default_bg {
    background: #d6d6d6 !important;
  }

  .dark_bg,
  .dark_bg .generic_options,
  .dark_bg .all_options {
    //background:#7b7878 !important;
    // background: #acacac !important;
    background: ${(props) =>
      props.styles.ContentHighlight_Colour?.background} !important;
  }
  .radious-none {
    border-bottom-left-radius: 0;
    border-bottom: 1px solid #7b7b7b;
  }
  .ant-picker {
    padding: 0 !important;
  }
  .ant-picker-suffix {
    margin-right: 4px;
  }
  .ant-picker-input input,
  .react-datepicker__input-container input {
    padding: 13px 5px !important;
    border-radius: 0 !important;
  }
  .calcWidgetTextBox {
    height: 30px;
    position: relative;
  }
  .hideOverflow {
    overflow: hidden;
  }
  .text-color {
    color: black;
    outline-width: 0;
  }
  .pointerEvent {
    pointer-events: none;
  }
`;
