import React, { useState, Fragment, useEffect } from "react";
import PropTypes from "prop-types";
import styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";
import BreadCrumb from "./Breadcrumb";
import Icons from "./Icons";
import duplicate from "../../../assets/duplicate.png";
import paste from "../../../assets/paste.png";
import rename from "../../../assets/edit.png";
import currentContentObjects from "../GetCurrentContentObjects";
import getNewWidgetByType from "../WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import { map, reduce } from "awaity/esm";
import {
  addModule,
  deleteModule,
  abortContent,
  updateBreadCrumb,
  deleteWidget,
  setActiveWidgetId,
  updateContentName,
  deleteContent,
  setContentId,
  deleteReference,
  deleteAttachment,
  deleteOutsideWidget,
  deleteModuleById,
  deleteWidgetById,
  getAllContents,
  copyData,
  pasteData,
  createNewModuleByContentId,
  setActiveExecutionFrameCursorId,
  // createNewModuleByCopyModules,
  // createNewWidgetByCopyOutsideWidget,
  createNewWidgetByCopyModule,
  getContentDetailsByContentId,
  setRenameModuleFlag,
  deletePageBreak,
  deleteStoredWidgetLables,
  addOutsideWidget,
  addWidget,
  setActiveModuleId,
  setActiveCursorWidgetId,
  storeRedis,
  setLoadingSpinner,
  setDefaultOptionsForWidget,
  setContentWidgetLabels,
  setExpandedModuleIds,
  toggleVerticalSpinner,
  setActiveNestedBranchCursorId,
  setActiveBranchCursorId,
  setClearWidgetData,
  addWidgetBranchWidget,
  addWidgetBy_insideBranchWidget,
  addNestedWidgetBy_insideBranchWidget,
  addWidgetBy_insideExecutionFrame,
  addOutsideBranchWidget,
  addNestedWidgetBy_outsideBranchWidget,
  addWidgetBy_outsideBranchWidget,
  addWidgetBy_outsideExecutionFrame,
  duplicateWidget,
  duplicateOutsideWidget,
  setActiveCursorModuleId,
  setActiveNestedWidgetCursorId,
  setActiveNestedExecutionFrameCursorId,
} from "../../../store/content";
/* need to enable this functionality later */
import ProcessModule from "./ProcessModule";
import {
  apiContentUrlWithToken,
  apiUrlWithToken,
  checkSumId,
} from "../../../calls/apis";

import {
  BRANCH_CONTROL_WIDGET,
  INPUT_TAB,
  OUTPUT_TAB,
  PROPERTIES_TAB,
  SUCCESS,
  CREATED_SUCCESS,
  BINARY_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DROPDOWNLIST_WIDGET,
  STANDARD_VIEW,
} from "../Constants";
import { CostExplorer } from "aws-sdk";
import { ge } from '../ConsultationVIew'

function Toolbar({ handleSaveContent }) {
  const styles = useSelector((state) => state.ui.styles);
  const dispatch = useDispatch();
  const {
    contents,
    // activeModuleId,
    activeContentId,
    isContentModified,
    breadcrumb,
    //selectedWidgetIds,
    activeReferenceId,
    activeAttachmentId,
    copiedData,
    activeAttachmentUrl,
    selectedPropertiesModuleId,
  } = useSelector((state) => state.content);
  const viewConsultation = useSelector((state) => state.content.viewConsultation);
  const viewLabel = useSelector((state) => state.content.viewLabel);
  let content = currentContentObjects(contents, activeContentId);

  let currentContent = content?.currentContent;
  let activeModuleId = content?.activeModuleId;
  //let selectedWidgetIds = content?.selectedWidgetIds;
  let activeModuleIds = content?.activeModuleIds;
  let selectedModuleIds = content?.selectedModuleIds;
  let activeCursorModuleId = content?.activeCursorModuleId;
  let activeCursorWidgetId = content?.activeCursorWidgetId;
  let modules = content?.moduleList;
  let widgets = content?.widgetList;
  let selectedOuterWidgetIds = content?.selectedOuterWidgetIds;
  let widgetDuplicateStatus = content?.widgetDuplicateStatus;
  let activeFormBarTab = content?.activeFormBarTab;

  let isOutputContentModified = content?.isOutputContentModified;
  let activeOutputId = currentContent?.activeOutputId;
  // let currentContent = contents?.length > 0 && contents?.find(content => content.contentId === activeContentId);
  let selectedOuterPagebreakIndex =
    currentContent?.selectedOuterPagebreakIndex !== undefined
      ? currentContent.selectedOuterPagebreakIndex
      : undefined;
  let selectedInnerPagebreakIndex =
    currentContent?.selectedInnerPagebreakDetails?.widgetIndex !== undefined
      ? currentContent.selectedInnerPagebreakDetails.widgetIndex
      : undefined;
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedBranchWidgetCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let nestedWidgetId =
    currentContent?.activeNestedWidgetId !== undefined
      ? currentContent.activeNestedWidgetId
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  let nestedExecutionFrameIndex =
    currentContent?.nestedExecutionFrameCursorId !== undefined
      ? currentContent.nestedExecutionFrameCursorId
      : undefined;
  // let activeModuleId = currentContent?.activeModuleId ? currentContent.activeModuleId : 0;
  // let selectedWidgetIds = currentContent?.selectedWidgetIds?.length > 0 ? currentContent.selectedWidgetIds : [];
  // let selectedModuleIds = currentContent?.selectedModuleIds?.length > 0 ? currentContent.selectedModuleIds : [];
  // let selectedOuterWidgetIds = currentContent?.selectedOuterWidgetIds?.length > 0 ? currentContent.selectedOuterWidgetIds : [];
  // let activeCursorModuleId = currentContent?.activeCursorModuleId !== undefined ? currentContent.activeCursorModuleId : undefined;
  // let activeCursorWidgetId = currentContent?.activeCursorWidgetId !== undefined ? currentContent.activeCursorWidgetId : undefined;

  // Used for disable delete using dreadonly and locked scenario.
  let currentModule =
    selectedModuleIds.length > 0
      ? modules?.filter((x) => x.id == selectedModuleIds[0])[0]
      : [];
  let activeModuleUsingWidget = findCurrentModuleUsingWidget();
  let activeByReadOrLockedStatus =
    currentContent?.activeFormBarTab === "Properties"
      ? false
      : modulesStatus()
        ? true
        : activeModuleUsingWidget?.readOnly
          ? true
          : outSideWidgetStatus()
            ? true
            : false;

  const handleAbort = (e) => {
    // dispatch(abortContent(activeContentId));
    // dispatch(getAllContents(true, activeContentId));
    dispatch(getContentDetailsByContentId(activeContentId, false, true));
    dispatch(updateBreadCrumb({ ...breadcrumb, module: "" }));
    // dispatch(setContentId(activeContentId));
    //dispatch(setActiveWidgetId(0));
  };

  const handleDelete = (e) => {
    if (e) e.preventDefault();
    if (activeContentId && selectedModuleIds.length > 0) {
      selectedModuleIds.map((deleteModuleId) => {
        dispatch(deleteModuleById(deleteModuleId));
        dispatch(setActiveExecutionFrameCursorId(undefined));
        dispatch(setActiveNestedBranchCursorId(undefined));
        dispatch(setActiveBranchCursorId(undefined));
        dispatch(
          deleteStoredWidgetLables(
            activeContentId,
            deleteModuleId,
            content?.contentWidgetLabels
          )
        );
        if (selectedModuleIds.indexOf(activeModuleId) > -1)
          dispatch(updateBreadCrumb({ ...breadcrumb, module: "" }));
      });
      // batch(() => {
      //   dispatch(deleteModule());
      //   if (selectedModuleIds.indexOf(activeModuleId) > -1) {
      //     dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
      //     //dispatch(setActiveModuleId(0));
      //   }
      // });
    } else if (activeContentId && selectedWidgetIds.length > 0) {
      selectedWidgetIds.map((deleteWidgetId) => {
        dispatch(deleteWidgetById(deleteWidgetId));
        dispatch(setActiveExecutionFrameCursorId(undefined));
        dispatch(setActiveNestedBranchCursorId(undefined));
        dispatch(setActiveBranchCursorId(undefined));
      });
    }
    // if (activeContentId && selectedOuterWidgetIds.length > 0) {
    //   selectedOuterWidgetIds.map((deleteWidgetId) => {
    //     dispatch(deleteWidgetById(deleteWidgetId, true));
    //   });
    //   // dispatch(deleteOutsideWidget(true));
    // }
    if (
      selectedOuterPagebreakIndex !== undefined ||
      selectedInnerPagebreakIndex !== undefined
    ) {
      dispatch(deletePageBreak());
    } else if (
      activeContentId &&
      activeReferenceId != null &&
      activeReferenceId >= 0
    )
      dispatch(
        deleteReference(
          activeReferenceId,
          selectedPropertiesModuleId,
          currentContent
        )
      );
    else if (
      activeContentId &&
      (activeAttachmentUrl != null || activeAttachmentUrl != "")
    )
      dispatch(deleteAttachment(activeAttachmentUrl));

  };

  const handleCopy = (e) => {
    if (e) e.preventDefault();
    dispatch(copyData());
  };

  const generateAsyncFunc = async (newWidget, widgetCreateData, widgetData) => {
    let response;
    await apiContentUrlWithToken
      .post(`widget/create`, widgetCreateData)
      .then(async (res) => {
        response = res.data;
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.id
        ) {
          if (
            !res.errors ||
            res.status === SUCCESS ||
            (res.data != null && res.data.id)
          ) {
            newWidget.id = res.data.id;
            newWidget.type = res.data.type;
            newWidget.title = newWidget.title || newWidget.widgetName;
            newWidget.branchId = widgetData.branchId;
            newWidget.nestedId = widgetData.nestedId;

            if (widgetData !== undefined) {
              newWidget.widgetType = widgetData.widgetType;
              if (
                newWidget.widgetType === BINARY_INPUT_WIDGET ||
                newWidget.widgetType === SINGLE_CHOICE_WIDGET ||
                newWidget.widgetType === MULTI_CHOICE_WIDGET ||
                newWidget.widgetType === DROPDOWNLIST_WIDGET
              ) {
                newWidget.defaultOptions = setDefaultOptionsForWidget(
                  widgetData.widgetType
                );
              }
              if (newWidget.widgetType === BRANCH_CONTROL_WIDGET) {
                newWidget.branchControlType =
                  widgetData?.branchControlType || "skip";
                newWidget.branchConditions = [
                  {
                    conditions: [
                      {
                        field: "",
                        expression: "",
                        value: "",
                      },
                    ],
                  },
                ];
              }
              newWidget.bookmark = false;
              newWidget.export = false;
              newWidget.hide = false;
              newWidget.required = false;
              newWidget.widgetList = [];
            }

            if (widgetCreateData.moduleId === null)
              currentContent.activeModuleId = 0;
            let newWidgetName = newWidget.widgetName;
            let widgetType = newWidget.type;

            let existingWidgetLabels = currentContent?.contentWidgetLabels || [];

            let contentId =
              currentContent?.activeContentId || currentContent?.contentId;
            let moduleId = currentContent.activeModuleId;
            let isContentExist = -1;
            let widgetInputTypes = [
              "text",
              "binary",
              "time",
              "single_choice",
              "multiple_choice",
              "date",
              "drop_down",
              "number",
            ];
            let widgetOtherTypes = ["warning", "calculation", "narrative"];

            let findWidgetType = widgetInputTypes.includes(widgetType)
              ? "input"
              : widgetType;

            if (existingWidgetLabels?.length > 0) {
              isContentExist = existingWidgetLabels.findIndex(
                (x) =>
                  x.contentId === contentId &&
                  x.moduleId === moduleId &&
                  x.type === findWidgetType
              );
            }

            if (isContentExist > -1) {
              existingWidgetLabels.map((widget, index) => {
                if (
                  contentId === widget.contentId &&
                  widget.moduleId === moduleId &&
                  widget.type === findWidgetType
                ) {
                  widget.widgetDefaultName = newWidgetName;
                }
              });
            } else {
              let widget = {
                contentId: contentId,
                moduleId: moduleId,
                widgetDefaultName: newWidgetName,
                type: findWidgetType,
              };
              existingWidgetLabels.push(widget);
            }

            // updateContentWidgetLabels
            let request = {
              key: contentId,
              data: existingWidgetLabels,
              userid: await checkSumId,
            };
            await apiUrlWithToken
              .post(`/content/save`, request)
              .then((res) => {
                if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
                  if (currentContent.activeCursorWidgetId === undefined) {
                    if (widgetData.branchId) {
                      dispatch(addOutsideBranchWidget(newWidget));
                    } else {
                      if (
                        currentContent.nestedBranchWidgetCursorIndex !==
                        undefined
                      ) {
                        dispatch(
                          addNestedWidgetBy_outsideBranchWidget(newWidget)
                        );
                      } else if (
                        currentContent.executionFrameCursorId !== undefined
                      ) {
                        dispatch(addWidgetBy_outsideExecutionFrame(newWidget));
                      } else if (
                        currentContent.branchWidgetCursorIndex !== undefined
                      ) {
                        dispatch(addWidgetBy_outsideBranchWidget(newWidget));
                      } else {
                        dispatch(addOutsideWidget(newWidget));
                      }
                    }
                  } else {
                    if (widgetData.branchId) {
                      dispatch(addWidgetBranchWidget(newWidget));
                    } else {
                      if (
                        currentContent.nestedBranchWidgetCursorIndex !==
                        undefined
                      ) {
                        dispatch(
                          addNestedWidgetBy_insideBranchWidget(newWidget)
                        );
                      } else if (
                        currentContent.executionFrameCursorId !== undefined
                      ) {
                        dispatch(addWidgetBy_insideExecutionFrame(newWidget));
                      } else if (
                        currentContent.branchWidgetCursorIndex !== undefined
                      ) {
                        dispatch(addWidgetBy_insideBranchWidget(newWidget));
                      } else {
                        dispatch(addWidget(newWidget));
                      }
                    }

                    console.log("currentContent ", currentContent);
                  }
                  dispatch(setContentWidgetLabels(existingWidgetLabels));
                }
              })
              .catch((error) => {
                alert("error storing in redis");
                console.log("content widget label api:", error);
              });
            // return res;
          }
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Create New widget Api: ", error);
        // reject("Create New widget Api: ", error)
      });
    return response;
    // })
  };
  const generateDuplicateAsyncFunc = async (
    newWidget,
    widgetCreateData,
    widgetData
  ) => {
    let response;
    await apiContentUrlWithToken
      .post(`widget/create`, widgetCreateData)
      .then(async (res) => {
        response = res.data;
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.id
        ) {
          if (
            !res.errors ||
            res.status === SUCCESS ||
            (res.data != null && res.data.id)
          ) {
            newWidget.id = res.data.id;
            newWidget.type = res.data.type;
            newWidget.title = newWidget.title || newWidget.widgetName;
            newWidget.branchId = widgetData.branchId;
            newWidget.nestedId = widgetData.nestedId;

            if (widgetData !== undefined) {
              newWidget.widgetType = widgetData.widgetType;
              if (
                newWidget.widgetType === BINARY_INPUT_WIDGET ||
                newWidget.widgetType === SINGLE_CHOICE_WIDGET ||
                newWidget.widgetType === MULTI_CHOICE_WIDGET ||
                newWidget.widgetType === DROPDOWNLIST_WIDGET
              ) {
                newWidget.defaultOptions =
                  widgetData?.defaultOptions.length > 0
                    ? widgetData?.defaultOptions
                    : setDefaultOptionsForWidget(widgetData.widgetType);
              }
              if (newWidget.widgetType === BRANCH_CONTROL_WIDGET) {
                newWidget.branchControlType =
                  widgetData?.branchControlType || "skip";
                newWidget.branchConditions =
                  widgetData?.branchConditions.length > 0
                    ? widgetData?.branchConditions
                    : [
                      {
                        conditions: [
                          {
                            field: "",
                            expression: "",
                            value: "",
                          },
                        ],
                      },
                    ];
              }
              newWidget.bookmark = widgetData?.bookmark || false;
              newWidget.export = widgetData?.export || false;
              newWidget.hide = widgetData?.hide || false;
              newWidget.required = widgetData?.required || false;
              newWidget.widgetList = [];
              newWidget.selectedId = widgetData?.selectedId || "";
            }

            if (widgetCreateData.moduleId === null)
              currentContent.activeModuleId = 0;
            // if (activeCursorWidgetId === undefined) {
            //   dispatch(addOutsideWidget(newWidget));
            // } else {
            //   dispatch(addWidget(newWidget));
            // }

            // storeRedis
            let newWidgetName = newWidget.widgetName;
            let widgetType = newWidget.type;

            let existingWidgetLabels = currentContent?.contentWidgetLabels;

            let contentId =
              currentContent?.activeContentId || currentContent?.contentId;
            let moduleId = currentContent.activeModuleId;
            let isContentExist = -1;
            let widgetInputTypes = [
              "text",
              "binary",
              "time",
              "single_choice",
              "multiple_choice",
              "date",
              "drop_down",
              "number",
            ];
            let widgetOtherTypes = ["warning", "calculation", "narrative"];

            let findWidgetType = widgetInputTypes.includes(widgetType)
              ? "input"
              : widgetType;

            if (existingWidgetLabels?.length > 0) {
              isContentExist = existingWidgetLabels.findIndex(
                (x) =>
                  x.contentId === contentId &&
                  x.moduleId === moduleId &&
                  x.type === findWidgetType
              );
            }

            if (isContentExist > -1) {
              existingWidgetLabels.map((widget, index) => {
                if (
                  contentId === widget.contentId &&
                  widget.moduleId === moduleId &&
                  widget.type === findWidgetType
                ) {
                  widget.widgetDefaultName = newWidgetName;
                }
              });
            } else {
              let widget = {
                contentId: contentId,
                moduleId: moduleId,
                widgetDefaultName: newWidgetName,
                type: findWidgetType,
              };
              existingWidgetLabels.push(widget);
            }

            // updateContentWidgetLabels
            let request = {
              key: contentId,
              data: existingWidgetLabels,
              userid: await checkSumId,
            };
            await apiUrlWithToken
              .post(`/content/save`, request)
              .then((res) => {
                if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
                  dispatch(duplicateWidget(newWidget));

                  dispatch(setContentWidgetLabels(existingWidgetLabels));
                }
              })
              .catch((error) => {
                alert("error storing in redis");
                console.log("content widget label api:", error);
              });
            // return res;
          }
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Create New widget Api: ", error);
        // reject("Create New widget Api: ", error)
      });
    return response;
    // })
  };
  /**
   * this function will create new widget while copy & paste & duplicate actions
   */
  const createNewWidgetByCopyWidget = async (
    currentContent,
    copiedWidgetsData,
    copiedContent
  ) => {
    await reduce(copiedWidgetsData.widgetIds, async (acc, copyId) => {
      let allWidgets = copiedContent.moduleList.reduce(
        (data, obj) => [...data, ...obj.widgetList],
        []
      );
      copiedContent.moduleList.map((x) => {
        if (x.widgetList) {
          x.widgetList.map((y) => {
            if (y.widgetList) {
              y.widgetList.map((z) => {
                allWidgets.push(z);
                if (z.widgetList) {
                  z.widgetList.map((z1) => {
                    allWidgets.push(z1);
                  });
                }
              });
            }
          });
        }
      });
      let allOuterWidgets = copiedContent.widgetList;
      copiedContent.widgetList.map((x) => {
        if (x.widgetList) {
          x.widgetList.map((y) => {
            allOuterWidgets.push(y);
            if (y.widgetList) {
              y.widgetList.map((z) => {
                allOuterWidgets.push(z);
              });
            }
          });
        }
      });
      let innerWidget = allWidgets.findIndex((x) => x.id === copyId);
      let outerWidget = allOuterWidgets.findIndex((x) => x.id === copyId);
      let widget;
      let moduleId = null;
      let activeModuleId = 0;
      if (innerWidget > -1) {
        widget = allWidgets[innerWidget];
        moduleId = currentContent.activeModuleId;
        // moduleId = widget.moduleId;
        // activeModuleId = widget.moduleId;
        activeModuleId = currentContent.activeModuleId;
      } else if (outerWidget > -1) {
        widget = copiedContent.widgetList.find((x) => x.id === copyId);
        moduleId = null;
        activeModuleId = 0;
      }
      if (widget) {
        const newWidget = getNewWidgetByType(currentContent, widget.type);
        let widgetCreateData = {
          contentId: currentContent.contentId,
          moduleId: moduleId,
          type: newWidget.widgetType,
        };
        currentContent.activeModuleId = activeModuleId;
        let activeCursorWidgetId = currentContent.activeCursorWidgetId;
        // createNewWidgetByCopyModule
        let widgetData = widget;
        widgetData.branchId = undefined;
        widgetData.nestedId = undefined;
        if (activeCursorWidgetId === undefined) {
          widgetCreateData.moduleId = null;
        }

        let response = await generateAsyncFunc(
          newWidget,
          widgetCreateData,
          widgetData
        );
      } else {
        alert(
          "Could not find the widget, This is no longer located in original path, Please verify and try again "
        );
      }
    });
  };
  const duplicateWidgetByCopyWidget = async (
    currentContent,
    copiedWidgetsData,
    copiedContent
  ) => {

    await reduce(copiedWidgetsData.widgetIds, async (acc, copyId) => {
      let allWidgets = copiedContent.moduleList.reduce(
        (data, obj) => [...data, ...obj.widgetList],
        []
      );
      let aboveCursorModuleId = activeCursorModuleId;
      let aboveWidgetIndex = activeCursorWidgetId;
      let activeBranchWidgetCursorIndex = branchWidgetCursorIndex;
      let activeNestedBranchCursorId = nestedBranchWidgetCursorIndex;
      let activeExecutionFrameCursorId = executionFrameIndex;
      let aboveNestedWidget = nestedWidgetId;
      let activemodule = activeModuleId;
      copiedContent.moduleList.map((x) => {
        if (x.widgetList) {
          x.widgetList.map((y) => {
            if (y.widgetList) {
              y.widgetList.map((z) => {
                allWidgets.push(z);
                if (z.widgetList) {
                  z.widgetList.map((z1) => {
                    allWidgets.push(z1);
                  });
                }
              });
            }
          });
        }
      });
      let allOuterWidgets = copiedContent.widgetList;
      copiedContent.widgetList.map((x) => {
        if (x.widgetList) {
          x.widgetList.map((y) => {
            allOuterWidgets.push(y);
            if (y.widgetList) {
              y.widgetList.map((z) => {
                allOuterWidgets.push(z);
              });
            }
          });
        }
      });
      let innerWidget = allWidgets.findIndex((x) => x.id === copyId);
      let outerWidget = allOuterWidgets.findIndex((x) => x.id === copyId);
      let widget;
      let moduleId = null;
      let activeModuleId = 0;
      /**
       * placing the cursor for duplicating
       */
      if (innerWidget > -1) {
        widget = allWidgets[innerWidget];
        currentContent.moduleList.map((module, moduleIndex) => {
          module.widgetList.map((wid, widIndex) => {
            if (widget.id === wid.id) {
              aboveWidgetIndex = widIndex;
              activemodule = module.id;
              nestedWidgetId = undefined;
              activeBranchWidgetCursorIndex = undefined;
              activeNestedBranchCursorId = undefined;
              activeExecutionFrameCursorId = undefined;
              aboveCursorModuleId = 0;
              // currentContent.modulesAndOutsideWidgetsPositions.map(
              //   (x, index) => {
              //     if (module.id === x.id) {
              //       aboveCursorModuleId = index;
              //     }
              //   }
              // );
            } else {
              if (wid.widgetList) {
                wid.widgetList.map((branchWid, branchWidId) => {
                  if (branchWid.id === widget.id) {
                    aboveWidgetIndex = widIndex;
                    activemodule = module.id;
                    nestedWidgetId = undefined;
                    activeBranchWidgetCursorIndex = branchWidId;
                    activeNestedBranchCursorId = undefined;
                    activeExecutionFrameCursorId = undefined;
                    currentContent.modulesAndOutsideWidgetsPositions.map(
                      (x, i) => {
                        if (module.id === x.id) {
                          aboveCursorModuleId = i;
                        }
                      }
                    );
                  } else {
                    if (branchWid.widgetList) {
                      branchWid.widgetList.map((nestedWid, nestedWidId) => {
                        if (
                          nestedWid.id === widget.id &&
                          branchWid.type === "execution_frame"
                        ) {
                          aboveWidgetIndex = widIndex;
                          activemodule = module.id;
                          nestedWidgetId = undefined;
                          activeBranchWidgetCursorIndex = branchWidId;
                          activeNestedBranchCursorId = undefined;
                          activeExecutionFrameCursorId = nestedWidId;
                          currentContent.modulesAndOutsideWidgetsPositions.map(
                            (x, i) => {
                              if (module.id === x.id) {
                                aboveCursorModuleId = i;
                              }
                            }
                          );
                        } else if (
                          nestedWid.id === widget.id &&
                          branchWid.type === "branch"
                        ) {
                          aboveWidgetIndex = widIndex;
                          activemodule = module.id;
                          nestedWidgetId = undefined;
                          activeBranchWidgetCursorIndex = branchWidId;
                          activeNestedBranchCursorId = nestedWidId;
                          activeExecutionFrameCursorId = undefined;
                          currentContent.modulesAndOutsideWidgetsPositions.map(
                            (x, i) => {
                              if (module.id === x.id) {
                                aboveCursorModuleId = i;
                              }
                            }
                          );
                        }
                      });
                    }
                  }
                });
              }
            }
          });
        });
      } else if (outerWidget > -1) {
        widget = allOuterWidgets[outerWidget];
        currentContent.widgetList.map((wid, widIndex) => {
          if (widget.id === wid.id) {
            aboveWidgetIndex = undefined;
            activemodule = 0;
            nestedWidgetId = undefined;
            activeBranchWidgetCursorIndex = undefined;
            activeNestedBranchCursorId = undefined;
            activeExecutionFrameCursorId = undefined;
            currentContent.modulesAndOutsideWidgetsPositions.map((x, i) => {
              if (wid.id === x.id) {
                aboveCursorModuleId = i;
              }
            });
          } else {
            if (wid.widgetList) {
              wid.widgetList.map((branchWid, branchWidId) => {
                if (branchWid.id === widget.id) {
                  aboveWidgetIndex = undefined;
                  activemodule = 0;
                  nestedWidgetId = undefined;
                  activeBranchWidgetCursorIndex = branchWidId;
                  activeNestedBranchCursorId = undefined;
                  activeExecutionFrameCursorId = undefined;
                  currentContent.modulesAndOutsideWidgetsPositions.map(
                    (x, i) => {
                      if (wid.id === x.id) {
                        aboveCursorModuleId = i;
                      }
                    }
                  );
                } else {
                  if (branchWid.widgetList) {
                    branchWid.widgetList.map((nestedWid, nestedWidId) => {
                      if (
                        nestedWid.id === widget.id &&
                        branchWid.type === "execution_frame"
                      ) {
                        aboveWidgetIndex = undefined;
                        activemodule = 0;
                        nestedWidgetId = undefined;
                        activeBranchWidgetCursorIndex = branchWidId;
                        activeNestedBranchCursorId = undefined;
                        activeExecutionFrameCursorId = nestedWidId;
                        currentContent.modulesAndOutsideWidgetsPositions.map(
                          (x, i) => {
                            if (wid.id === x.id) {
                              aboveCursorModuleId = i;
                            }
                          }
                        );
                      } else if (
                        nestedWid.id === widget.id &&
                        branchWid.type === "branch"
                      ) {
                        aboveWidgetIndex = undefined;
                        activemodule = 0;
                        nestedWidgetId = undefined;
                        activeBranchWidgetCursorIndex = branchWidId;
                        activeNestedBranchCursorId = nestedWidId;
                        activeExecutionFrameCursorId = undefined;
                        currentContent.modulesAndOutsideWidgetsPositions.map(
                          (x, i) => {
                            if (wid.id === x.id) {
                              aboveCursorModuleId = i;
                            }
                          }
                        );
                      }
                    });
                  }
                }
              });
            }
          }
        });
      }

      if (widget) {
        const newWidget = getNewWidgetByType(currentContent, widget.type);
        let widgetCreateData = {
          contentId: currentContent.contentId,
          moduleId: moduleId,
          type: newWidget.widgetType,
        };
        currentContent.activeModuleId = activeModuleId;
        currentContent.activeCursorWidgetId = aboveWidgetIndex;
        // let activeCursorWidgetId = aboveWidgetIndex;
        // createNewWidgetByCopyModule
        let widgetData = widget;
        widgetData.branchId = undefined;
        widgetData.nestedId = undefined;
        widgetData.selectedId = widget.id;
        if (aboveWidgetIndex === undefined) {
          widgetCreateData.moduleId = null;
        } else {
          widgetCreateData.moduleId = activemodule;
        }
        dispatch(setActiveCursorModuleId(aboveCursorModuleId));
        dispatch(setActiveCursorWidgetId(aboveWidgetIndex));
        dispatch(setActiveBranchCursorId(activeBranchWidgetCursorIndex));
        dispatch(setActiveNestedBranchCursorId(activeNestedBranchCursorId));
        // dispatch(setActiveNestedWidgetCursorId(aboveNestedWidget));
        dispatch(setActiveExecutionFrameCursorId(activeExecutionFrameCursorId));
        dispatch(
          setActiveNestedExecutionFrameCursorId(nestedExecutionFrameIndex)
        );
        dispatch(setActiveModuleId(activeModuleId));
        let response = await generateAsyncFunc(
          newWidget,
          widgetCreateData,
          widgetData
        );
        if (widget.widgetList) {
          await reduce(widget.widgetList, async (id, insideWidget) => {
            const newWidget1 = getNewWidgetByType(
              currentContent,
              insideWidget.type
            );
            let widgetCreateData1 = {
              contentId: currentContent.contentId,
              moduleId: moduleId,
              type: newWidget1.widgetType,
            };
            currentContent.activeModuleId = activeModuleId;
            let activeCursorWidgetId = currentContent.activeCursorWidgetId;
            if (activeCursorWidgetId === undefined) {
              widgetCreateData.moduleId = null;
            }
            // createNewWidgetByCopyModule
            let widgetData1 = insideWidget;
            widgetData1.branchId = response.id;
            if (currentContent.branchWidgetCursorIndex !== undefined) {
              let branchedId;
              if (activeModuleId === 0) {
                branchedId =
                  copiedContent.modulesAndOutsideWidgetsPositions[
                    currentContent.activeCursorModuleId
                  ].id;
              } else {
                branchedId =
                  copiedContent.moduleList[currentContent.activeCursorModuleId]
                    .widgetList[currentContent.activeCursorWidgetId].id;
              }

              widgetData1.branchId = branchedId;
              widgetData1.nestedId = response.id;
              if (insideWidget.type === "branch") {
                return;
              }
              await generateAsyncFunc(
                newWidget1,
                widgetCreateData1,
                widgetData1
              );
              return;
            }

            let responsenested = await generateAsyncFunc(
              newWidget1,
              widgetCreateData1,
              widgetData1
            );
            if (insideWidget.widgetList) {
              await reduce(insideWidget.widgetList, async (i, nested) => {
                const newWidget2 = getNewWidgetByType(
                  currentContent,
                  nested.type
                );
                let widgetCreateData2 = {
                  contentId: currentContent.contentId,
                  moduleId: moduleId,
                  type: newWidget2.widgetType,
                };
                currentContent.activeModuleId = activeModuleId;
                let activeCursorWidgetId = currentContent.activeCursorWidgetId;
                if (activeCursorWidgetId === undefined) {
                  widgetCreateData.moduleId = null;
                }
                let widgetData2 = nested;
                widgetData2.branchId = response.id;
                widgetData2.nestedId = responsenested.id;
                await generateAsyncFunc(
                  newWidget2,
                  widgetCreateData2,
                  widgetData2
                );
              });
            }
          });
        }
      } else {
        alert(
          "Could not find the widget, This is no longer located in original path, Please verify and try again "
        );
      }
    });
  };

  /**
   * this request will create new module and widgets while copy & paste & duplicate actions
   */

  const createNewModuleByCopyModules = async (
    copiedData,
    currentContent,
    copiedContent
  ) => {
    if (
      copiedData.moduleIds.length > 0 &&
      currentContent.activeCursorWidgetId === undefined
    ) {
      let index = 0;

      await reduce(copiedData.moduleIds.reverse(), async (all, item) => {
        await apiContentUrlWithToken
          .post(`module/${currentContent.contentId}/create`, {})
          .then(async (res) => {
            if (
              (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
              res.data != null &&
              res.data.id
            ) {
              const newModuleId = await res.data.id;
              res.data.widgetList = res.data.widgetList || [];
              const newModule = Object.assign({}, res.data, {
                description: [],
                properties: {},
                widgetCurrentviewConsultation: STANDARD_VIEW,
              });
              dispatch(addModule(newModule));
              dispatch(setActiveCursorWidgetId(-1));
              let copiedModule = copiedContent?.moduleList.find(
                (module) => module.id === item
              );
              if (copiedModule?.widgetList.length > 0) {
                let copyWidgets = [];
                let i = 0;
                await reduce(copiedModule.widgetList, async (acc, widget) => {
                  // let newWidget = getDefaultWidgetData(widget, currentContent);
                  let newWidget = getNewWidgetByType(
                    currentContent,
                    widget.type,
                    true,
                    copyWidgets
                  );

                  let widgetCreateData = {
                    contentId: currentContent.contentId,
                    moduleId: newModuleId,
                    type: newWidget.widgetType,
                  };
                  widget.title = newWidget.widgetName;
                  widget.widgetDefaultName = newWidget.widgetName;
                  copyWidgets.push(widget);

                  currentContent.activeModuleId = newModuleId;

                  /**
                   * create new widget within module/outside module also
                   */
                  let widgetData = widget;
                  widget = newWidget;
                  let activeCursorWidgetId = i - 1;
                  // start createNewWidgetByCopyModule

                  if (activeCursorWidgetId === undefined)
                    widgetCreateData.moduleId = null;

                  await apiContentUrlWithToken
                    .post(`widget/create`, widgetCreateData)
                    .then(async (res) => {
                      if (
                        (res.status === SUCCESS ||
                          res.status === CREATED_SUCCESS) &&
                        res.data != null &&
                        res.data.id
                      ) {
                        if (
                          !res.errors ||
                          res.status === SUCCESS ||
                          (res.data != null && res.data.id)
                        ) {
                          widget.id = res.data.id;
                          widget.type = res.data.type;
                          widget.title = widget.title || widget.widgetName;
                          if (widgetData !== undefined) {
                            widget.widgetType = widgetData.widgetType;
                            if (
                              widget.widgetType === BINARY_INPUT_WIDGET ||
                              widget.widgetType === SINGLE_CHOICE_WIDGET ||
                              widget.widgetType === MULTI_CHOICE_WIDGET ||
                              widget.widgetType === DROPDOWNLIST_WIDGET
                            ) {
                              widget.defaultOptions =
                                widgetData?.defaultOptions.length > 0
                                  ? widgetData?.defaultOptions
                                  : setDefaultOptionsForWidget(
                                    widgetData.widgetType
                                  );
                            }
                            if (widget.widgetType === BRANCH_CONTROL_WIDGET) {
                              widget.branchControlType =
                                widgetData?.branchControlType || "skip";
                              widget.branchConditions =
                                widgetData?.branchConditions.length > 0
                                  ? widgetData?.branchConditions
                                  : [
                                    {
                                      conditions: [
                                        {
                                          field: "",
                                          expression: "",
                                          value: "",
                                        },
                                      ],
                                    },
                                  ];
                            }
                            widget.bookmark = widgetData?.bookmark || false;
                            widget.export = widgetData?.export || false;
                            widget.hide = widgetData?.hide || false;
                            widget.required = widgetData?.required || false;
                          }
                          if (widgetCreateData.moduleId === null)
                            currentContent.activeModuleId = 0;
                          if (activeCursorWidgetId === undefined) {
                            dispatch(addOutsideWidget(widget));
                          } else {
                            dispatch(addWidget(widget));
                          }
                          // dispatch(
                          //   storeRedis(
                          //     currentContent,
                          //     widget.widgetName,
                          //     widget.type
                          //   )
                          // );
                          // storeRedis (currentContent, newWidgetName, widgetType)
                          let newWidgetName = widget.widgetName;
                          let existingWidgetLabels =
                            currentContent?.contentWidgetLabels;
                          let widgetType = widget.type;

                          let contentId =
                            currentContent?.activeContentId ||
                            currentContent?.contentId;
                          let moduleId = currentContent.activeModuleId;
                          let isContentExist = -1;
                          let widgetInputTypes = [
                            "text",
                            "binary",
                            "time",
                            "single_choice",
                            "multiple_choice",
                            "date",
                            "drop_down",
                            "number",
                          ];
                          let widgetOtherTypes = [
                            "warning",
                            "calculation",
                            "narrative",
                          ];

                          let findWidgetType = widgetInputTypes.includes(
                            widgetType
                          )
                            ? "input"
                            : widgetType;

                          if (existingWidgetLabels?.length > 0) {
                            isContentExist = existingWidgetLabels.findIndex(
                              (x) =>
                                x.contentId === contentId &&
                                x.moduleId === moduleId &&
                                x.type === findWidgetType
                            );
                          }

                          if (isContentExist > -1) {
                            existingWidgetLabels.map((widget, index) => {
                              if (
                                contentId === widget.contentId &&
                                widget.moduleId === moduleId &&
                                widget.type === findWidgetType
                              ) {
                                widget.widgetDefaultName = newWidgetName;
                              }
                            });
                          } else {
                            let widget = {
                              contentId: contentId,
                              moduleId: moduleId,
                              widgetDefaultName: newWidgetName,
                              type: findWidgetType,
                            };
                            existingWidgetLabels.push(widget);
                          }
                          // dispatch(updateContentWidgetLabels(existingWidgetLabels, contentId));
                          //dispatch(setContentWidgetLabels(existingWidgetLabels));
                          // start setContentWidgetLabels
                          let widgetLabels = existingWidgetLabels;
                          let request = {
                            key: contentId,
                            data: widgetLabels,
                            userid: await checkSumId,
                          };
                          await apiUrlWithToken
                            .post(`/content/save`, request)
                            .then((res) => {
                              if (
                                res.status === SUCCESS ||
                                res.status === CREATED_SUCCESS
                              ) {
                                dispatch(setContentWidgetLabels(widgetLabels));
                                dispatch(toggleVerticalSpinner(false));
                              }
                            })
                            .catch((error) => {
                              console.log("content widget label api:", error);
                              dispatch(toggleVerticalSpinner(false));
                            });
                          // end setContentWidgetLabels
                          // end storeRedis
                          return res;
                        }
                      }
                    })
                    .catch((error) => {
                      dispatch(setLoadingSpinner(false));
                      console.log("Create New widget Api: ", error);
                    });
                  /// end createNewWidgetByCopyModule
                  // );
                  i++;
                });
              }
              dispatch(setExpandedModuleIds(newModuleId));
              if (index === copiedData?.moduleIds?.length - 1) {
                dispatch(setActiveModuleId(newModuleId));
                dispatch(setActiveCursorWidgetId(-1));
              }
            }
          })
          .catch((error) => {
            dispatch(setLoadingSpinner(false));
            console.log("Create New module Api: ", error);
          });
        index++;
      });
    } else {
      alert("Could not copied a module inside a module, please try again");
    }
  };

  const handlePaste = (e) => {
    if (e) e.preventDefault();

    // let activeModuleId = 0;
    // if (currentContent.activeCursorWidgetId != undefined) {
    //   activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
    //     (x, index) =>
    //       index === currentContent?.activeCursorModuleId &&
    //       x.type === 'module'
    //   )?.id;
    // }
    let copiedContent =
      contents?.length > 0 &&
      contents?.find((content) => content.contentId === copiedData.contentId);
    if (copiedData.moduleIds?.length > 0) {
      // dispatch(
      createNewModuleByCopyModules(copiedData, currentContent, copiedContent);
      // );
    } else if (copiedData.widgetsdata?.widgetIds?.length > 0) {
      createNewWidgetByCopyWidget(
        currentContent,
        copiedData.widgetsdata,
        copiedContent
      );
    }
  };

  const handleDuplicate = (e) => {
    if (e) e.preventDefault();

    if (selectedWidgetIds.length > 0) {
      duplicateWidgetByCopyWidget(
        currentContent,
        currentContent.selectedWidgetsData,
        currentContent
      );
    }
  };

  const handleRenameModule = (e) => {
    if (e) e.preventDefault();
    dispatch(setRenameModuleFlag(true));
  };

  function findCurrentModuleUsingWidget() {
    let module;
    if (selectedWidgetIds?.length > 0) {
      currentContent.moduleList.forEach((value) => {
        if (value?.widgetList?.length > 0) {
          let widgetArray = value?.widgetList.filter(
            (s) => s.id == selectedWidgetIds[0]
          );
          if (widgetArray?.length > 0) {
            module = value;
            return false;
          }
        }
      });
    }
    return module;
  }

  function modulesStatus() {
    var result = false;
    selectedModuleIds.forEach((value) => {
      let data = modules.filter((x) => x.id == value);
      if (data?.length > 0) {
        if (data[0].readOnly) {
          result = true;
          return false;
        }
      }
    });
    return result;
  }

  function outSideWidgetStatus() {
    var result = false;
    selectedWidgetIds.forEach((value) => {
      let data = widgets.filter((x) => x.id == value);
      if (data?.length > 0 && currentContent?.processProperties?.readOnly) {
        result = true;
        return false;
      }
    });
    return result;
  }

  const handleClear = () => {
    dispatch(setClearWidgetData());
  };

  return (
    <Style>
      <div className="main-bar">
        <div className="bread-crumb">
          <BreadCrumb />
        </div>
        {/* need to enable this functionality later */}
        {contents?.length > 0 ? (
          <div className="processModule">
            <ProcessModule />
          </div>
        ) : (
            ""
          )}
        <div className="icons-action">
          <Icons
            src={styles.icons.toolbar_clear}
            title="Clear"
            triggerFunc={handleClear}
            isActive={!viewConsultation && selectedWidgetIds?.length > 0}
          />
          <Icons
            src={styles.icons.toolbar_search}
            title="Search"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_select}
            title="Select"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_delete}
            title="Delete"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_update}
            title="Update"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_new}
            title="New"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.toolbar_cancel}
            title="Cancel"
            triggerFunc={handleAbort}
            isActive={
              (!viewConsultation && !activeByReadOrLockedStatus &&
                (activeFormBarTab === PROPERTIES_TAB ||
                  activeFormBarTab === INPUT_TAB) &&
                isContentModified) ||
              (activeOutputId &&
                parseInt(activeOutputId) > 3 &&
                isOutputContentModified)
            }
          />
          <Icons
            src={styles.icons.toolbar_save}
            title="Save"
            triggerFunc={handleSaveContent}
            isActive={
              (!viewConsultation && !activeByReadOrLockedStatus &&
                (activeFormBarTab === PROPERTIES_TAB ||
                  activeFormBarTab === INPUT_TAB) &&
                isContentModified) ||
              (activeOutputId &&
                parseInt(activeOutputId) > 3 &&
                isOutputContentModified)
            }
          />
          <Icons
            src={
              selectedModuleIds.length === 1
                ? rename
                : "https://cdn2.iconfinder.com/data/icons/basic-3/1024/edit-512.png"
            }
            title="Rename"
            triggerFunc={(e) => handleRenameModule(e)}
            isActive={
              !viewConsultation &&
              !activeByReadOrLockedStatus &&
              selectedModuleIds.length === 1 &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={
              selectedModuleIds.length === 0 &&
                (selectedWidgetIds.length > 0 ||
                  selectedOuterWidgetIds.length > 0)
                ? duplicate
                : "https://cdn3.iconfinder.com/data/icons/pixel-perfect-at-16px-volume-3-1/16/2122-512.png"
            }
            title="Duplicate"
            triggerFunc={(e) => handleDuplicate(e)}
            isActive={
              !viewConsultation && !viewLabel &&
              !activeByReadOrLockedStatus &&
              selectedModuleIds.length === 0 &&
              (selectedWidgetIds.length > 0 ||
                selectedOuterWidgetIds.length > 0) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={
              copiedData.moduleIds?.length > 0 ||
                copiedData.widgetsdata?.widgetIds?.length > 0 ||
                copiedData.outerWidgetIds?.length > 0
                ? paste
                : "https://cdn.iconscout.com/icon/premium/png-256-thumb/paste-1502606-1272816.png"
            }
            title="Paste"
            triggerFunc={(e) => handlePaste(e)}
            isActive={
              !viewConsultation && !viewLabel &&
              !activeByReadOrLockedStatus &&
              (copiedData.moduleIds?.length > 0 ||
                copiedData.widgetsdata?.widgetIds?.length > 0 ||
                copiedData.outerWidgetIds?.length > 0) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={styles.icons.toolbar_copy}
            title="Copy"
            triggerFunc={(e) => handleCopy(e)}
            isActive={
              !viewConsultation && !viewLabel && !activeByReadOrLockedStatus &&
              (selectedModuleIds.length > 0 || selectedWidgetIds.length > 0) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={styles.icons.toolbar_suspend}
            title="Suspend"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.toolbar_delete}
            title="Delete"
            triggerFunc={(e) => handleDelete(e)}
            //isActive={activeModuleId}
            // isActive={(selectedModuleIds.length > 0 || selectedWidgetIds.length > 0 || selectedOuterWidgetIds.length > 0 || selectedOuterPagebreakIndex  !== undefined || selectedInnerPagebreakIndex !== undefined || (activeReferenceId != null && activeReferenceId >= 0) || (activeAttachmentUrl != null || activeAttachmentUrl != ""))}
            isActive={
              !viewConsultation && !viewLabel &&
              !activeByReadOrLockedStatus &&
              (selectedModuleIds.length > 0 ||
                selectedWidgetIds.length > 0 ||
                selectedOuterWidgetIds.length > 0 ||
                selectedOuterPagebreakIndex !== undefined ||
                selectedInnerPagebreakIndex !== undefined ||
                (activeReferenceId != null && activeReferenceId >= 0) ||
                (activeAttachmentUrl != null && activeAttachmentUrl != "")) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
        </div>
      </div>
    </Style>
  );
}

Toolbar.defaultProps = {
  accountType: "Private",
  page: "",
};

Toolbar.propTypes = {
  accountType: PropTypes.string.isRequired,
  page: PropTypes.string.isRequired,
  // iconsFragment: PropTypes.node.isRequired,
};

export default Toolbar;

const Style = styled.div`
  position: sticky;
  top: 70px;
  height: 83px;
  background: #fff;
  z-index: 8;
  display: flex;
  justify-content: space-between;
  padding: 10px 0px 2px 5px;
  border-bottom: 2px solid #4395a6;
  // .navMenu {
  //   z-index: 9;
  // }
  .breadcrumb {
    display: flex;
    color: gray;
    font-size: 16px;
    align-items: center;
  }
  .icons-action {
    display: flex;
    align-items: flex-end;
    align-self: flex-end;
    padding-bottom: 6px;
  }
  .icons-action img {
    width: 30px;
  }
  .main-bar {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
  .bread-crumb {
    margin-left: 1rem;
  }
  .align-button {
    display: flex !important;
    justify-content: space-around;
    margin-bottom: 15px;
    width: 45%;
    margin: 10px auto;
  }
  .mb15 {
    margin-bottom: 15px !important;
  }
  label {
    display: table;
    position: relative;
    top: 7px;
    left: 8px;
    background: #fff;
    padding: 0 7px;
  }
  select,
  input[type="text"],
  .input-group input,
  textarea,
  .date,
  .inputSize {
    background: white;
    border: 1px solid #666;
    border-radius: 5px;
    outline: 0;
    padding: 5px;
    box-shadow: 0px 0px 2px #999;
    width: 70%;
    height: 35px;
    align-self: center;
  }
  .process-module {
    background: #d9d9d9;
  }
  .processModule {
    margin-left: 1rem;
    position: absolute;
    top: 48px;
  }
`;
