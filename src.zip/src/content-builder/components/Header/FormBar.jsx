import React, { Fragment, useState, useEffect, component } from "react";
import Styled from "styled-components";
import FormBarLanding from "../FormBarLanding";
import * as A from "../../../store/content";
import { useSelector, useDispatch, batch } from "react-redux";
import AWS from "aws-sdk";

import currentContentObjects from "../GetCurrentContentObjects";
import * as C from "../Constants";
import PopupComponent from "../../components/PopupCompontnet";

AWS.config.update({
  accessKeyId: "AKIA5TI3EZTAIHWI73F4",
  secretAccessKey: "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",
  region: "eu-west-2",
  endpoint: "https://dynamodb.eu-west-2.amazonaws.com",
});
var docClient = new AWS.DynamoDB.DocumentClient({ correctClockSkew: true });
let staticDefaultNames = [
  {
    id: 1,
    name: "note",
  },
  {
    id: 2,
    name: "letter",
  },
  {
    id: 3,
    name: "advice",
  },
  {
    id: 4,
    name: "billing",
  },
  {
    id: 5,
    name: "referral",
  },
];
export default function ModuleBar() {
  const [activeTab, setActiveTab] = useState(C.INPUT_TAB);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [isCustomNameFlag, setCustomNameFlag] = useState(false);
  const [defaultNames] = useState(staticDefaultNames);
  const [customName, setCustomName] = useState("");
  const {
    breadcrumb,
    contents,
    activeContentId,
    activeCommonFormBarTab,
  } = useSelector((state) => state.content);
  const styles = useSelector((state) => state.ui.styles);
  const subtag_add = useSelector((state) => state.ui.styles.icons.subtag_add);
  const dispatch = useDispatch();
  const {
    currentContent: { secondaryTabs: tabs, activeOutputId, outputs },
  } = currentContentObjects(contents, activeContentId);

  let content = currentContentObjects(contents, activeContentId);
  let currentContent = content?.currentContent;
  let checksumId = JSON.parse(localStorage.getItem("account")).userid;
  let author = currentContent?.authors?.filter(
    (x) => x.checkSumId === checksumId
  );
  let access = true;
  if (author?.length > 0 && !author[0].contentPermissions.write) {
    access = false;
  }

  useEffect(() => {
    handleSetActiveKey(undefined, C.INPUT_TAB);
    setActiveTab(C.INPUT_TAB);
    if (activeContentId) {
      dispatch(A.fetchOuputsByContentIdAsync(activeContentId));
    }
  }, [activeContentId]);

  useEffect(() => {
    if (
      activeTab !== C.INPUT_TAB &&
      activeTab !== C.PROPERTIES_TAB &&
      activeTab !== C.AUTHORS_TAB
    ) {
      setActiveTab(C.OUTPUT_TAB);
    }
  }, [activeOutputId]);

  //set route whenever change header from navigation
  const handleSetActiveKey = (e, tabName, outputId = null) => {
    if (
      tabName === C.PROPERTIES_TAB ||
      tabName === C.INPUT_TAB ||
      tabName === C.AUTHORS_TAB
    ) {
      setActiveTab(tabName);
      console.log("tabs", currentContent.contentId);
      

      
      dispatch(A.getContentDetailsByContentId(activeContentId, false, true));
      batch(() => {
        dispatch(
          A.updateBreadCrumb({ ...breadcrumb, inputOutput: "-" + tabName })
        );
        // dispatch(A.setActiveFormBarTab(tabName));
        // dispatch(A.setCommonActiveFormBarTab(tabName));
        dispatch(A.setActiveOutputId(outputId));
      });
    } else {
      setActiveTab(C.OUTPUT_TAB);
      batch(() => {
        dispatch(
          A.updateBreadCrumb({ ...breadcrumb, inputOutput: "-" + tabName })
        );
        // dispatch(A.setActiveFormBarTab(C.OUTPUT_TAB));
        // dispatch(A.setCommonActiveFormBarTab(C.OUTPUT_TAB));
        dispatch(A.setActiveOutputId(outputId));
      });
      if (e.target.className !== "caret") {
        let coordPoints = document.getElementById("dropdown-menu" + outputId);

        coordPoints.style.cssText = "display: none;";
        // let coords = e.target.getBoundingClientRect();
        // coordPoints.style.left = "calc(" + coords.left + "px - 7px)";
        // coordPoints.style.top = "calc(" + coords.bottom + "px + 10px)";
      }
    }
  };

  const addNewTab = (e) => {
    if (e) e.preventDefault();
    if (!activeContentId) return;
    dispatch(A.createNewOuputTab(activeContentId));
  };

  const handleClose = (e) => {
    e.preventDefault();
    setIsPopupVisible(false);
  };

  const onDelete = () => {
    setIsPopupVisible(true);
  };

  const handleDelete = (e) => {
    e.preventDefault();
    setCustomNameFlag(false);
    setIsPopupVisible(true);
    dispatch(A.deleteOutputAsync(activeContentId, activeOutputId));
    setActiveTab(C.INPUT_TAB);
    setIsPopupVisible(false);
  };

  const handleRename = (outputName) => {
    let isNameExist = tabs.some(
      (tab) => tab.label?.toLowerCase() === outputName.toLowerCase()
    );
    if (isNameExist) {
      alert("Name already exist");
    } else {
      outputs.map((output) => {
        if (output.outputId === activeOutputId) {
          const payload = {
            outputId: activeOutputId,
            contentId: activeContentId,
            title: outputName,
            outputData: output.outputData || "",
          };
          dispatch(A.updateOutputAsync(payload));
        }
      });
    }
    setCustomName("");
    setCustomNameFlag(false);
    setIsPopupVisible(false);
  };

  const onCustomClick = (title, outputId) => {
    setIsPopupVisible(true);
    setCustomNameFlag(true);
  };

  const renderTab = (item) => {
    return (
      <li
        onClick={(e) => handleSetActiveKey(e, item.label, item.id)}
        key={item?.id}
        className={
          activeOutputId === item?.id
            ? "active show"
            : item?.isDisabled
            ? "disabled"
            : ""
        }
      >
        <span>{item?.label}</span>
      </li>
    );
  };

  const xyAxis = (e) => {
    let coordPoints = document.getElementById(
      "dropdown-menu" + e.target.id.substr(13)
    );
    coordPoints.style.cssText = "position:fixed; display:block";
    let coords = e.target.getBoundingClientRect();
    coordPoints.style.left = "calc(" + coords.left + "px - 122px)";
    coordPoints.style.top = "calc(" + coords.bottom + "px + 16px)";
  };
  const renderTabWithDropdown = (item) => (
    <li
      className={
        activeOutputId === item.id
          ? "active show"
          : item.isDisabled
          ? "disabled"
          : ""
      }
      key={item.id}
      // onFocus={log(activeOutputId + "active")}
      // onBlur={log(item.id)}
      onClick={(e) => handleSetActiveKey(e, item.label, item.id)}
    >
      <div className="dropdown">
        <button
          className="btn btn-default dropdown-toggle"
          type="button"
          data-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          // onClick={() => handleDropdown(item.id)}
        >
          {item.label}
          <span
            className="caret"
            id={"dropdownMenu2" + item.id}
            onClick={(e) => {
              xyAxis(e);
            }}
          ></span>
        </button>

        <ul
          className="dropdown-menu"
          id={"dropdown-menu" + item.id}
          aria-labelledby={"dropdownMenu2" + item.id}
        >
          {defaultNames.map((ditem) => (
            <li key={ditem.id}>
              <a href="#" onClick={() => handleRename(ditem.name)}>
                {ditem.name}
              </a>
            </li>
          ))}
          <li role="separator" className="divider"></li>
          <li>
            <a href="#" onClick={() => onCustomClick(item.label, item.id)}>
              Custom
            </a>
          </li>
          <li>
            <a href="#" onClick={onDelete}>
              Delete
            </a>
          </li>
        </ul>
      </div>
    </li>
  );

  const renderConfimations = () => {
    {
      return isCustomNameFlag ? (
        <Fragment>
          <p className="text-align">Type your custom name here </p>
          <input
            type="text"
            autoComplete="off"
            className="content-name-input"
            placeholder="Enter Output Name"
            value={customName}
            onChange={(e) => setCustomName(e.target.value)}
          />
          <div className="align-button">
            <input
              type="button"
              className="close-button ml5"
              value="Update"
              disabled={customName.length < 1 ? true : false}
              onClick={() => handleRename(customName)}
            />
            <input
              type="button"
              className="close-button ml5"
              value="Cancel"
              onClick={handleClose}
            />
          </div>
        </Fragment>
      ) : (
        <Fragment>
          <p className="text-align">Do you really want to delete? </p>

          <div className="align-button">
            <input
              type="button"
              className="close-button ml5"
              value="Yes, Delete it"
              onClick={handleDelete}
            />
            <input
              type="button"
              className="close-button ml5"
              value="Cancel"
              onClick={handleClose}
            />
          </div>
        </Fragment>
      );
    }
  };
  console.log("tabs", tabs);
  return (
    <>
      <ModuleBarStyles>
        <div className="moduleBarMenu">
          <ul className="moduleContainer carousel-nav">
            <div className="moduleListContainer">
              {tabs &&
                tabs.map((item, index) => {
                  // console.log("item.id ", item.id);
                  // console.log("item.label ", item.label);
                  return item && item?.isOutput
                    ? renderTabWithDropdown(item)
                    : renderTab(item);
                })}
            </div>
            <li
              className={`add-output ${!access ? "pointerEvents" : ""}`}
              style={{ background: "none" }}
            >
              <img src={subtag_add} onClick={addNewTab} />
            </li>
          </ul>
        </div>
        <FormBarLanding activeMenu={activeTab} />
      </ModuleBarStyles>
      <PopupComponent
        width="500px"
        visible={false || isPopupVisible}
        styles={styles}
        header={"Ouput"}
        children={renderConfimations()}
        close={() => {
          setIsPopupVisible(false);
        }}
      />
    </>
  );
}

const ModuleBarStyles = Styled.div`
.moduleBarMenu{
    z-index: 5; 
    position: sticky;
    top: 200px;
    background: #fff;
    height:55px;
    padding:5px 0;
}
.moduleListContainer{
  display: flex;
  align-items: center;
  color: #fff;
  font-weight: 700;
  max-width: calc(100vw - 100px); //sss
  overflow-x: auto; //sss
  >li.active{
    color: #000;
    padding-top: 14px;
    &::before{background: #fff;}
    span{color: #000;}
    .dropdown{
      button, button:hover{
        color: #000;
      }
    }
  }
  >li:last-child{
    &::before{
    clip-path: polygon(4% 6%,98% 6%,98% 50%,98% 94%,4% 94%,10% 51%);
    }
    &::after{
      clip-path: polygon(0 0,100% 0,100% 50%,100% 100%,0 100%,8% 51%);
      }
  }
  >li:first-child{
    margin-left: -4px;
    &::before{
      clip-path: polygon(0 6%,92% 6%,98% 50%,92% 94%,0 94%,0% 51%);
    }
    &::after{
      height: 50px;
      width: 150px;
      top: 2px;
      clip-path: polygon(0 6%,92% 6%,98% 50%,92% 94%,0 94%,0% 51%);
    }
  }
  >li{
    min-width: 150px;
    text-align: center;
    margin-left: -6px;
    position: relative;
    height: 48px;
    bottom: 4px;
    display: flex;
    justify-content: center;
    align-items: center;
    &::before{
      content: '';
      background: #0095a4;
      height: 46px;
      width: 150px;
      display: block;
      clip-path: polygon(4% 7%,92% 7%,98% 50%,92% 94%,4% 94%,9% 51%);
      top: 4px;
      position: absolute;
      z-index:1;
    }
    &::after{
      content: '';
      height: 46px;
      width: 150px;
      display: block;
      top: 4px;
      position: absolute;
      background: #b7b7b7;
    clip-path: polygon(0 0, 93% 0, 100% 50%, 93% 100%, 0 100%, 7% 51%);
    z-index:0;
    }
    span{
      position: relative;
      z-index: 1;
    }
    .dropdown{
      z-index: 1;
      .dropdown-menu{
        width: 140px !important;
        // top: 42% !important;
        // left: auto;
        // position: fixed;
      }
      button{
        width: 135px;
        height: 25px;
        display: flex;
        align-items: center;
        padding-left: 18px;
        padding-right: 16px;
        span{
          cursor: grab;
          position: absolute;
          right: 12px;
          transform: scale3d(1,3.5,2);
        }
      }
      button, button:hover, button:focus, button:active{
        font-weight: 700;
        color: #fff;
        background: #0000;
        border: none;
        box-shadow: none;
        outline: 0;
        font-size: 14px;
        }
        .dropdown-menu{
          width: 100%;
    font-size: 14px;
    top: 122%;
        }
      }
    }
  }
}
.carousel-nav{
    display: flex;
    padding-left: 1rem;
}

.carousel-nav > li{
    width: 150px;
    height: 44px;
    text-align: center;
    background: #b7b7b7;
    clip-path: polygon(0 0, 93% 0, 100% 50%, 93% 100%, 0 100%, 7% 51%);
    margin-left: -8px;
    font-weight: 500;
    color: #ffffff;
}
  .carousel-nav > li:first-child {
    clip-path: polygon(0 0,93% 0,100% 50%,93% 100%,0 100%,0% 51%);
  }

  .carousel-nav > li:nth-last-child(2){
    clip-path: polygon(0 0,100% 0,100% 50%,100% 100%,0 100%,8% 51%);
  }
  .carousel-nav > li > span,
  .carousel-nav > li > div{
    background: #0095a4;
    height:100%;
    width: 100%;
    display: block;
    clip-path: polygon(3% 7%,92% 7%,98% 50%,92% 94%,3% 94%,9% 51%);
    padding-top: 10px;
  }
  .carousel-nav > li:first-child > span,
  .carousel-nav > li:first-child > span{
    clip-path: polygon(2% 8%,92% 8%,98% 50%,92% 94%,2% 94%,2% 51%);
  }
  .carousel-nav > li:nth-last-child(2) > span,
  .carousel-nav > li:nth-last-child(2) > div{
    clip-path: polygon(3% 7%,98% 7%,98% 50%,98% 94%,3% 94%,10% 51%);
  }
  .carousel-nav > li.active > span,
  .carousel-nav > li.active > div
  {
    background: #ffffff;
    color: #000000;
  }
.logoutImg{
  align-self: center;
  padding-right: 10px;
}
img{
    height:30px;
    width:30px;    
}
.add-output{
    border:none !important;
    width:100px !important;
    padding:6px;
    img {
        cursor: pointer;
    }
}
.pointerEvents{
  pointer-events: none;
}
.disabled {
    pointer-events:none; //This makes it not clickable
    opacity:0.6;         //This grays it out to look disabled
    cursor:no-drop;
}
// ::-webkit-scrollbar{width:2px;height:2px;}
// ::-webkit-scrollbar-button{width:2px;height:2px;}
// .moduleListContainer{
//   position:absolute;
//   display:block;
//   top:0;
//   left:0;
//   width:50px;
//   max-height:calc(100vw - 100px);
//   margin:0;
//   overflow-y:auto;
//   overflow-x:hidden;
//   transform:rotate(-90deg) translateY(-80px);
//   transform-origin:right top;
//   li{
//     width:140px;
//   height:60px;
//   margin:50px 10px;
//   padding:5px;
//   transform:rotate(90deg) translateY(80px);
//   transform-origin: right top;
//   }
// }
`;
