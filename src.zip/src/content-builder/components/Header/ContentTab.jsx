import React, { useState, Fragment, useEffect } from "react";
import Styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";

import {
  addContent,
  setContentId,
  setActiveOutputId,
  setActiveModuleId,
  updateBreadCrumb,
  setContentModifiedFlag,
  getContentDetailsByContentId,
  createNewContent,
  setTabChange,
} from "../../../store/content";
import { apiContentUrlWithToken } from "../../../calls/apis";
import {
  SUCCESS,
  FORBIDDEN,
  INTERNEL_SERVER_ERROR,
  CREATED_SUCCESS,
} from "../Constants";

function ContentTab({ handleCloseContent }) {
  const dispatch = useDispatch();

  const { activeContentId, contents, breadcrumb } = useSelector(
    (state) => state.content
  );

  const styles = useSelector((state) => state.ui.styles);

  const initialState = {
    activeId: activeContentId,
    style: "active",
  };

  const [activeModuleBar, setActiveModuleBar] = useState(initialState);

  function getFlag(currContentId) {
    let currentStoragedContents = JSON.parse(
      localStorage.getItem("tmp_contentBuilder")
    )?.contents;
    let currentStoragedContent = currentStoragedContents?.filter(
      (content) => content.contentId === currContentId
    )[0];
    let currentStoragedContentSerialized = JSON.stringify(
      currentStoragedContent
    );
    let currentContent = contents.filter(
      (content) => content.contentId === currContentId
    )[0];
    let currentContentSerialized = JSON.stringify(currentContent);
    if (
      currentContent &&
      currentStoragedContent &&
      currentContentSerialized !== currentStoragedContentSerialized
    ) {
      return true;
    } else {
      if (currentContent && !currentStoragedContent) {
        let flag = currentContent?.moduleList.length ? true : false;
        // if() return false
        return flag;
      }
      if (!currentStoragedContent) {
        return false;
      }
    }
  }

  useEffect(() => {
    //when there is no activecontentid then set default first tab
    if (contents.length > 0 && !activeContentId) {
      let defaultIndex = 0;
      let defaultContentId = contents[defaultIndex].contentId;
      let defaultContentName = contents[defaultIndex].title;
      dispatch(
        updateBreadCrumb({ ...breadcrumb, content: defaultContentName })
      );

      dispatch(setContentId(defaultContentId, "api"));
      setActiveModuleBar((activeModuleBar) => ({
        ...activeModuleBar,
        activeId: defaultContentId,
      }));
    } else if (contents.length > 0 && activeContentId) {
      let index = contents.findIndex((x) => x.contentId === activeContentId);
      dispatch(
        updateBreadCrumb({
          ...breadcrumb,
          content: index < 0 ? "" : contents[index].title,
        })
      );
      setActiveModuleBar((activeModuleBar) => ({
        ...activeModuleBar,
        activeId: activeContentId,
      }));
    }

    // dispatch(setContentModifiedFlag(getFlag(activeContentId)));
  }, [contents, activeContentId]);

  const handleSetActiveKey = (content) => {
    setActiveModuleBar((activeModuleBar) => ({
      ...activeModuleBar,
      activeId: content.contentId,
    }));

    batch(() => {
      dispatch(setTabChange(true));
      dispatch(setContentId(content.contentId));
      dispatch(getContentDetailsByContentId(content.contentId, false, true));
      // To make input tab active as default
      dispatch(setActiveOutputId(3));
      dispatch(
        updateBreadCrumb({
          ...breadcrumb,
          content: content.title,
          module: "",
        })
      );
    });
  };
  useEffect(() => {
    if (activeContentId) {
      const timer = setTimeout(() => {
        dispatch(setTabChange(false));
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [activeContentId]);

  // useEffect(() => {
  //
  //   if (activeContentId) {
  //     dispatch(getContentDetailsByContentId(activeContentId, false, true));
  //     dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
  //     setActiveModuleBar((activeModuleBar) => ({
  //       ...activeModuleBar,
  //       activeId: activeContentId,
  //     }));
  //   }
  // }, []);

  // useEffect(() => {
  //   if (activeContentId != 0) {
  //     dispatch(getContentDetailsByContentId(activeContentId, false, true));
  //     dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
  //     setActiveModuleBar((activeModuleBar) => ({
  //       ...activeModuleBar,
  //       activeId: activeContentId,
  //     }));
  //   }
  // }, [activeContentId]);

  const handleAddContent = (e) => {
    if (e) e.preventDefault();
    dispatch(createNewContent(true));
    // let generateContentId = 0;
    // if (contents.length > 0) {
    //   generateContentId = contents[contents.length - 1].contentId;
    // }
    // const newContentId = generateContentId + 1;
    // const initialContentstate = {
    //   contentId: newContentId,
    //   contentName: '',
    //   modules: [],
    //   activeModuleId: 0,
    //   activeWidgetId: 0,
    //   activeCursorModuleId: undefined,
    //   activeCursorWidgetId: undefined,
    //   activeModuleIds: [],
    //   advancedViewWidgetIds: [],
    //   selectedModuleId: null,
    //   selectedModuleIds: [],
    //   compressedViewWidgetIds: [],
    //   standardViewWidgetIds: [],
    //   selectedWidgetIds: [],
    //   cursorSelectedStatus: false,
    //   currentViewMode: "STANDARD_VIEW",
    //   activeReferenceId: null,
    //   activeAttachmentId: null,
    //   selectedPropertiesModuleId: 0
    // };

    // batch(() => {
    //   dispatch(setContentId(newContentId));
    //   dispatch(addContent(initialContentstate));
    //    dispatch(setActiveModuleId(0));
    //   dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
    // });
    // setActiveModuleBar((activeModuleBar) => ({
    //   ...activeModuleBar,
    //   activeId: newContentId,
    // }));
  };

  return (
    <Styles>
      <div className="navMenu">
        <ul className="menuContainer">
          <div className="menuContainerList">
            {contents.length > 0 &&
              contents.map((item, index) => (
                <li
                  className={
                    activeModuleBar.activeId === item.contentId
                      ? "active show container-list"
                      : "container-list"
                  }
                  key={index}
                >
                  <div
                    className="module-name"
                    onClick={() => handleSetActiveKey(item)}
                  >
                    {/* {item.title} */}
                    {item?.title?.length > 0 && item?.title?.length >= 12
                      ? item.title.substring(0, 12)
                      : item?.title}
                  </div>
                  <div
                    className="close"
                    onClick={(e) => handleCloseContent(e, item.contentId)}
                  >
                    X
                  </div>
                </li>
              ))}
          </div>
          <li className="add-module">
            <img src={styles.icons.subtag_add} onClick={handleAddContent} />
          </li>
        </ul>
      </div>
      {/* <ModuleBar moduleData={moduleData} /> */}
    </Styles>
  );
}

export default ContentTab;

const Styles = Styled.div`
position: sticky;
top: 153px;
background: #fff;
z-index: 9;
.navMenu {
  width: 100%;
  border-bottom: 2px solid #0f1662;
  display: flex;
  justify-content: space-between;
  padding-top: 5px;
  z-index: 9;
}
.menuContainer {
  display: flex;
  list-style: none;
  position: relative;
  top: 2px;
  margin-bottom: 0;
}
.menuContainerList{
  display: flex;
  max-width: calc(100vw - 100px);
  overflow-x: auto;
}
.menuContainer .menuContainerList li a {
  color: #ffffff;
}

.menuContainer .menuContainerList li.active a {
  color: #4395a6;
}
.menuContainer .menuContainerList li, .menuContainer li {
  min-width: 150px;
  height:40px;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  text-align: center;  
  background: #bfbfbf;
  margin: 0px 5px;
  border-bottom: 2px solid #0f1662;
}
.menuContainer li img{
    margin-top:2px;
  }
.menuContainer .menuContainerList li.active {
  background: #ffffff;
  border: 2px solid #0f1662;
  border-bottom: 2px solid #ffffff;
}
.menuContainer .menuContainerList li:first-child{
    margin-left: 1.2rem;
    }
.logoutImg{
  align-self: center;
  padding-right: 10px;
}
img{
    height:30px;
    width:30px;    
}
.close {
    position: absolute;
    right: 7px;
    top: 8px;
    font-weight: bold;   
    font-size: 1rem;
    cursor:pointer;
} 
  }
  .module-bar-text {
      //display:flex;
  }
  .module-name {    
    cursor:pointer;
    width:100%;
    height:100%;
    color:#0e8a8b;
    padding:7px;
}
.add-module{
    background:none !important;
    text-align: left !important;
    cursor:pointer;
    text-align:center !important;
    width:68px !important;
}
.align-button{
    display:flex !important;
    justify-content: space-around;
    margin-bottom: 15px;
    width: 45%;
    margin: 10px auto;
}
.mb15{
    margin-bottom:15px !important;
}
label {
    display: table;
    position: relative;
    top: 7px;
    left: 8px;
    background: #fff;
    padding: 0 7px;
  }
  select,
input[type="text"],
.input-group input,
textarea,
.date,
.inputSize {
    background: white;
    border: 1px solid #666;
    border-radius: 5px;
    outline: 0;
    padding: 5px;
    box-shadow: 0px 0px 2px #999;
    width: 70%;
    height: 35px;
    align-self: center;
}

  .container-list {
    position:relative;
    padding:0;
  }
`;
