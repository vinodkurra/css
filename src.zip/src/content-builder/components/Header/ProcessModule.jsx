import React, { Fragment, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import styled from 'styled-components';

import { PROCESS, MODULE } from '../Constants';
import { setProcessAndModule, setContentModifiedFlag } from '../../../store/content';

const ProcessModule = () => {
    const dispatch = useDispatch();
    const {
        contents,
        activeContentId
    } = useSelector((state) => state.content);
    const [isMouseInsideProcess, setIsMouseInsideProcess] = useState(false);
    const [isMouseInsideModule, setIsMouseInsideModule] = useState(false);

    const processModule =
        contents.length > 0
            ? contents.find((content) => content.contentId === activeContentId) !=
                undefined
                ? contents.find((content) => content.contentId === activeContentId)
                    .processModule
                : ''
            : '';
    const isProcessAssigned =
        contents.length > 0
            ? contents.find((content) => content.contentId === activeContentId) !=
                undefined
                ? contents.find((content) => content.contentId === activeContentId)
                    .isProcessAssigned
                : false
            : false;

    const handleSetModuleProcess = (processModule) => {
        dispatch(setProcessAndModule(processModule));
        dispatch(setContentModifiedFlag(true));
    }
    const handleMouseEnter = (processModule) => {
        //  
        if (processModule === PROCESS)
            setIsMouseInsideProcess(true);
        else if (!isProcessAssigned)
            setIsMouseInsideModule(true);
    }
    const handleMouseLeave = (processModule) => {
        // 
        if (processModule === PROCESS)
            setIsMouseInsideProcess(false);
        else
            setIsMouseInsideModule(false);
    }

    return (
        <Style>
            <Fragment>
                <div style={{ display: 'flex' }}>
                    <div onMouseEnter={() => handleMouseEnter(PROCESS)} onMouseLeave={() => handleMouseLeave(PROCESS)}>
                        <input className={(processModule === PROCESS || isMouseInsideProcess) ? "active" : "notActive"} type="button"
                            value={PROCESS}
                            title={PROCESS}
                            disabled={(processModule === PROCESS || isMouseInsideProcess) ? false : true}
                            onClick={() => handleSetModuleProcess(PROCESS)}
                        />
                    </div>
                    <span>/</span>
                    <div onMouseEnter={() => handleMouseEnter(MODULE)} onMouseLeave={() => handleMouseLeave(MODULE)}>
                        <input className={(processModule === MODULE || isMouseInsideModule) ? "active" : "notActive"} type="button"
                            value={MODULE}
                            title={MODULE}
                            disabled={((processModule === MODULE || (isMouseInsideModule)) && !isProcessAssigned) ? false : true}
                            onClick={() => handleSetModuleProcess(MODULE)}
                        />
                    </div>
                </div>


            </Fragment>
        </Style>
    )
}

export default ProcessModule;
const Style = styled.div`
// input[type="button"]{
//     background: #f2f2f2;
//     border-radius: 5px;
//     border: none;
//     font-size: 14px;
//     font-weight: 500;
//     padding: 2px 5px;
// }
.active{
    background: #9f9898;
    border-radius: 5px;
    font-size: 14px;
    font-weight: 500;
    padding: 2px 5px;
    border: 1px;
}
.notActive{
    background: #f2f2f2;
    border-radius: 5px;
    font-size: 14px;
    font-weight: 500;
    padding: 2px 5px;
}

`;