import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

function Icons({ isActive, src, triggerFunc, title, big = false, moduleView = false, widgetOptionDeleteIcon = false, requiredAnimation = false }) {

  // let activeClass = isActive ? 
  // (moduleView ? 'moduleview active' : (widgetOptionDeleteIcon ? 'widget_option_delete_icon active' : 'active')) : '';

  let activeClass = isActive ?
    (moduleView ? 'moduleview active' :
      (widgetOptionDeleteIcon ? 'widget_option_delete_icon active' : 'active')) :
    widgetOptionDeleteIcon ? 'widget_option_delete_icon' : ''

  activeClass = requiredAnimation ? 'required-animation active' : activeClass;

  let activeFunc = isActive ? triggerFunc : () => console.log('icon disabled');

  return (
    <Icon onClick={activeFunc} className={activeClass} title={title}>
      <img alt="icon" src={src} draggable={false} />
    </Icon>
  );
}

Icons.defaultProps = {
  alt: '',
  src: 'https://img.icons8.com/fluent/48/000000/file.png',
  isActive: false,
};

Icons.propTypes = {
  triggerFunc: PropTypes.func.isRequired,
  title: PropTypes.string.isRequired,
};

export default Icons;

const Icon = styled.span`
  margin: 0 6px;
  cursor: not-allowed;
  filter: url("data:image/svg+xml;utf8,&lt;svg xmlns='http://www.w3.org/2000/svg'&gt;&lt;filter id='grayscale'&gt;&lt;feColorMatrix type='matrix' values='0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0'/&gt;&lt;/filter&gt;&lt;/svg&gt;#grayscale"); /* Firefox 10+, Firefox on Android */
  filter: gray; /* IE6-9 */
  -webkit-filter: grayscale(100%); /* Chrome 19+, Safari 6+, Safari 6+ iOS */

  &.active {
    cursor: pointer;
    filter: url("data:image/svg+xml;utf8,&lt;svg xmlns='http://www.w3.org/2000/svg'&gt;&lt;filter id='grayscale'&gt;&lt;feColorMatrix type='matrix' values='1 0 0 0 0, 0 1 0 0 0, 0 0 1 0 0, 0 0 0 1 0'/&gt;&lt;/filter&gt;&lt;/svg&gt;#grayscale");
    -webkit-filter: grayscale(0%);
  }
  img {
    width: 18px;
    margin-bottom: 0px;
  }
  &.active.big {
    transform: scale(1.5);
    position: relative;
    bottom: 8px;
    right: 8px;
    margin-top: 13px;
    margin-right: 18px;
  }
  &.moduleview {
    background: #989a99;
  }
  &.widget_option_delete_icon{
    background: #494949;
    margin-right: 0;
    clip-path: ellipse(83% 58% at 103% 51%);
  }
  .gray-color {
    background-color: #ccc;
  }
  &.required-animation {
    animation: iconAnim 1s ease 0s infinite normal forwards;
  }

  @keyframes iconAnim {
    0.0%{
        transform: scale(1);
        opacity: 1;
    }
    100%{
        transform: scale(1);
        opacity: 1;
    }
    32.6%{
        transform: scale(1.5);
        opacity: 0.7;
    }
    84.4%{
        transform: scale(1.3);
        opacity: 0.3;
    }
}
`;
