import React, { useState, Fragment, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { useSelector, useDispatch, batch } from 'react-redux';
import BreadCrumb from './Breadcrumb';
import Icons from './Icons';
import duplicate from '../../../assets/duplicate.png';
import paste from '../../../assets/paste.png';
import rename from '../../../assets/edit.png';
import currentContentObjects from '../GetCurrentContentObjects';
import getNewWidgetByType from '../WidgetLabelGenerate/UniqueWidgetLabelGeneration';
import { map, props } from 'awaity/esm';

import {
  deleteModule,
  abortContent,
  updateBreadCrumb,
  deleteWidget,
  setActiveWidgetId,
  updateContentName,
  deleteContent,
  setContentId,
  deleteReference,
  deleteAttachment,
  deleteOutsideWidget,
  deleteModuleById,
  deleteWidgetById,
  getAllContents,
  copyData,
  pasteData,
  createNewModuleByContentId,
  createNewModuleByCopyModules,
  // createNewWidgetByCopyWidget,
  // createNewWidgetByCopyOutsideWidget,
  createNewWidgetByCopyModule,
  getContentDetailsByContentId,
  setRenameModuleFlag,
  deletePageBreak,
  deleteStoredWidgetLables,
  addOutsideWidget,
  addWidget,
  storeRedis
} from '../../../store/content';
/* need to enable this functionality later */
import ProcessModule from './ProcessModule';
import { apiContentUrlWithToken } from '../../../calls/apis';
import { INPUT_TAB, OUTPUT_TAB, PROPERTIES_TAB } from '../Constants';

function Toolbar({ handleSaveContent }) {
  const styles = useSelector((state) => state.ui.styles);
  const dispatch = useDispatch();
  const {
    contents,
    // activeModuleId,
    activeContentId,
    isContentModified,
    breadcrumb,
    //selectedWidgetIds,
    activeReferenceId,
    activeAttachmentId,
    copiedData,
    activeAttachmentUrl,
    selectedPropertiesModuleId
  } = useSelector(
    (state) => state.content
  );

  let content = currentContentObjects(contents, activeContentId);

  let currentContent = content?.currentContent;
  let activeModuleId = content?.activeModuleId;
  //let selectedWidgetIds = content?.selectedWidgetIds;
  let activeModuleIds = content?.activeModuleIds;
  let selectedModuleIds = content?.selectedModuleIds;
  let activeCursorModuleId = content?.activeCursorModuleId;
  let activeCursorWidgetId = content?.activeCursorWidgetId;
  let modules = content?.moduleList;
  let widgets = content?.widgetList;
  let selectedOuterWidgetIds = content?.selectedOuterWidgetIds;
  let widgetDuplicateStatus = content?.widgetDuplicateStatus;
  let activeFormBarTab = content?.activeFormBarTab;
  let isOutputContentModified = content?.isOutputContentModified;

  // let currentContent = contents?.length > 0 && contents?.find(content => content.contentId === activeContentId);
  let selectedOuterPagebreakIndex = currentContent?.selectedOuterPagebreakIndex !== undefined ? currentContent.selectedOuterPagebreakIndex : undefined;
  let selectedInnerPagebreakIndex = currentContent?.selectedInnerPagebreakDetails?.widgetIndex !== undefined ? currentContent.selectedInnerPagebreakDetails.widgetIndex : undefined;
  let selectedWidgetIds = currentContent?.selectedWidgetsData?.widgetIds?.length > 0 ? currentContent?.selectedWidgetsData?.widgetIds : [];
  // let activeModuleId = currentContent?.activeModuleId ? currentContent.activeModuleId : 0;
  // let selectedWidgetIds = currentContent?.selectedWidgetIds?.length > 0 ? currentContent.selectedWidgetIds : [];
  // let selectedModuleIds = currentContent?.selectedModuleIds?.length > 0 ? currentContent.selectedModuleIds : [];
  // let selectedOuterWidgetIds = currentContent?.selectedOuterWidgetIds?.length > 0 ? currentContent.selectedOuterWidgetIds : [];
  // let activeCursorModuleId = currentContent?.activeCursorModuleId !== undefined ? currentContent.activeCursorModuleId : undefined;
  // let activeCursorWidgetId = currentContent?.activeCursorWidgetId !== undefined ? currentContent.activeCursorWidgetId : undefined;


  // Used for disable delete using dreadonly and locked scenario.
  let currentModule = selectedModuleIds.length > 0 ? modules?.filter(x => x.id == selectedModuleIds[0])[0] : [];
  let activeModuleUsingWidget = findCurrentModuleUsingWidget();
  let activeByReadOrLockedStatus = currentContent?.activeFormBarTab === "Properties" ? false : modulesStatus() ? true : activeModuleUsingWidget?.readOnly ? true : false;

  const handleAbort = (e) => {
    // dispatch(abortContent(activeContentId));
    // dispatch(getAllContents(true, activeContentId));
    dispatch(getContentDetailsByContentId(activeContentId, false, true));
    dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
    // dispatch(setContentId(activeContentId));
    //dispatch(setActiveWidgetId(0));
  }

  const handleDelete = (e) => {
    if (e) e.preventDefault();

    if (activeContentId && selectedModuleIds.length > 0) {
      selectedModuleIds.map((deleteModuleId) => {
        dispatch(deleteModuleById(deleteModuleId));

        dispatch(deleteStoredWidgetLables(activeContentId, deleteModuleId, content?.contentWidgetLabels));
        if (selectedModuleIds.indexOf(activeModuleId) > -1)
          dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
      });
      // batch(() => {
      //   dispatch(deleteModule());
      //   if (selectedModuleIds.indexOf(activeModuleId) > -1) {
      //     dispatch(updateBreadCrumb({ ...breadcrumb, module: '' }));
      //     //dispatch(setActiveModuleId(0));
      //   }
      // });
    }
    else if (activeContentId && selectedWidgetIds.length > 0) {
      selectedWidgetIds.map((deleteWidgetId) => {
        dispatch(deleteWidgetById(deleteWidgetId));
      });
    }
    // if (activeContentId && selectedOuterWidgetIds.length > 0) {
    //   selectedOuterWidgetIds.map((deleteWidgetId) => {
    //     dispatch(deleteWidgetById(deleteWidgetId, true));
    //   });
    //   // dispatch(deleteOutsideWidget(true));
    // }
    if (selectedOuterPagebreakIndex !== undefined || selectedInnerPagebreakIndex !== undefined) {
      dispatch(deletePageBreak());
    }
    else if (activeContentId && (activeReferenceId != null && activeReferenceId >= 0))
      dispatch(deleteReference(activeReferenceId, selectedPropertiesModuleId, currentContent));
    else if (activeContentId && (activeAttachmentUrl != null || activeAttachmentUrl != ""))
      dispatch(deleteAttachment(activeAttachmentUrl));
  };


  const handleCopy = (e) => {
    if (e) e.preventDefault();
    dispatch(copyData());
  };

  const handlePaste = (e) => {
    if (e) e.preventDefault();

    // let activeModuleId = 0;
    // if (currentContent.activeCursorWidgetId != undefined) {
    //   activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
    //     (x, index) =>
    //       index === currentContent?.activeCursorModuleId &&
    //       x.type === 'module'
    //   )?.id;
    // }

    let copiedContent = contents?.length > 0 && contents?.find(content => content.contentId === copiedData.contentId);
    if (copiedData.moduleIds?.length > 0) {
      
      let copiedContent = contents?.length > 0 && contents?.find(content => content.contentId === copiedData.contentId);
      dispatch(createNewModuleByCopyModules(copiedData, currentContent, copiedContent));
    } else if (copiedData.widgetsdata?.widgetIds?.length > 0) {
      createNewWidgetByCopyWidget(currentContent, copiedData.widgetsdata, copiedContent)
    }
    // else if (copiedData.outerWidgetIds?.length > 0) {
    //   dispatch(createNewWidgetByCopyOutsideWidget(currentContent, copiedData.outerWidgetIds, copiedContent))
    // }
  };

  /**
  * this function will create new widget while copy & paste & duplicate actions
  */
  const createNewWidgetByCopyWidget = (
    currentContent,
    copiedWidgetsData,
    copiedContent,
  ) => {
    //  await map(copiedWidgetsData.widgetIds, async (copyId) => {
    //       let  allWidgets = copiedContent.moduleList.reduce(
    //           (data, obj) => [...data, ...obj.widgetList],
    //         [])
    //       let innerWidget = allWidgets.findIndex(x => x.id === copyId);
    //       let outerWidget = copiedContent.widgetList.findIndex(x => x.id === copyId);
    //       let widget;
    //       let moduleId = null;
    //       let activeModuleId = 0;
    //       if(innerWidget > -1){
    //          widget = allWidgets[innerWidget];
    //          moduleId = widget.moduleId;
    //          activeModuleId = widget.moduleId;
    //         }else if(outerWidget > -1){
    //             widget = copiedContent.widgetList.find((x) => x.id === copyId);
    //             moduleId = null
    //             activeModuleId = 0
    //         }
    //         
    //       if (widget) {
    //        const newWidget =  getNewWidgetByType(currentContent, widget.type);
    //         let widgetCreateData = {
    //           contentId: currentContent.contentId,
    //           moduleId: moduleId,
    //           type: newWidget.widgetType,
    //         };

    //         currentContent.activeModuleId = activeModuleId;
    //          if (currentContent.activeCursorWidgetId === undefined) widgetCreateData.moduleId = null;
    //     const res = await apiContentUrlWithToken.post(`widget/create`, widgetCreateData)
    //            if (!res.errors || (res.data != null && res.data.id)) {
    //              widget.id = res.data.id;
    //              widget.title = newWidget.title || newWidget.widgetName;
    //              widget.type = newWidget.widgetType
    //         if (widgetCreateData.moduleId === null)
    //           currentContent.activeModuleId = 0;
    //         if (activeCursorWidgetId === undefined) {
    //           dispatch(addOutsideWidget(widget));
    //         } else {
    //           dispatch(addWidget(widget));
    //         }

    //        dispatch(storeRedis(currentContent, widget.widgetName, widget.type));
    //   } 
    //       }else{
    //           alert("Could not find the widget, This is no longer located in original path, Please verify and try again ");

    //       }

    // });


    copiedWidgetsData.widgetIds.map(async (copyId) => {
      let allWidgets = copiedContent.moduleList.reduce(
        (data, obj) => [...data, ...obj.widgetList],
        [])
      let innerWidget = allWidgets.findIndex(x => x.id === copyId);
      let outerWidget = copiedContent.widgetList.findIndex(x => x.id === copyId);
      let widget;
      let moduleId = null;
      let activeModuleId = 0;
      if (innerWidget > -1) {
        widget = allWidgets[innerWidget];
        moduleId = widget.moduleId;
        activeModuleId = widget.moduleId;
      } else if (outerWidget > -1) {
        widget = copiedContent.widgetList.find((x) => x.id === copyId);
        moduleId = null
        activeModuleId = 0
      }
      if (widget) {
        const newWidget = getNewWidgetByType(currentContent, widget.type);
        let widgetCreateData = {
          contentId: currentContent.contentId,
          moduleId: moduleId,
          type: newWidget.widgetType,
        };
        currentContent.activeModuleId = activeModuleId;
        dispatch(
          createNewWidgetByCopyModule(
            widgetCreateData,
            newWidget,
            currentContent.activeCursorWidgetId,
            currentContent,
            widget
          )
        ).then(() => console.log('++++++++++++++'));
      } else {
        alert("Could not find the widget, This is no longer located in original path, Please verify and try again ");
      }
    });


  };


  const handleDuplicate = (e) => {
    if (e) e.preventDefault();

    if (selectedWidgetIds.length > 0) {
      // let currentModule = currentContent.moduleList[activeCursorModuleId]
      // let widgetId = currentModule.widgetList[activeCursorWidgetId].id
      // let widgetsdata = {
      //   moduleId: currentModule.id,
      //   widgetIds:  
      // }
      createNewWidgetByCopyWidget(currentContent, currentContent.selectedWidgetsData, currentContent)
    }
  };



  const handleRenameModule = (e) => {
    if (e) e.preventDefault();
    dispatch(setRenameModuleFlag(true));
  };

  function findCurrentModuleUsingWidget() {
    let module;
    if (selectedWidgetIds?.length > 0) {
      currentContent.moduleList.forEach((value) => {
        if (value?.widgetList?.length > 0) {
          let widgetArray = value?.widgetList.filter(s => s.id == selectedWidgetIds[0]);
          if (widgetArray?.length > 0) {
            module = value; return false;
          }
        }
      });
    }
    return module;
  }

  function modulesStatus() {
    var result = false;
    selectedModuleIds.forEach((value) => {
      let data = modules.filter(x => x.id == value);
      if (data?.length > 0) {
        if (data[0].readOnly) {
          result = true; return false;
        }
      }
    });
    return result;
  }

  return (
    <Style>
      <div className="main-bar">
        <div className="bread-crumb">
          <BreadCrumb />
        </div>
        {/* need to enable this functionality later */}
        {
          contents?.length > 0 ?
            <div className="processModule">
              <ProcessModule />
            </div> : ''
        }
        <div className="icons-action">
          <Icons
            src={styles.icons.toolbar_search}
            title="Search"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_select}
            title="Select"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_delete}
            title="Delete"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_update}
            title="Update"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.record_new}
            title="New"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.toolbar_cancel}
            title="Cancel"
            triggerFunc={handleAbort}
            isActive={
              !activeByReadOrLockedStatus &&
              (
                (activeFormBarTab === PROPERTIES_TAB || activeFormBarTab === INPUT_TAB) &&
                isContentModified
              ) ||
              (
                activeFormBarTab === OUTPUT_TAB &&
                isOutputContentModified
              )
            }
          />
          <Icons
            src={styles.icons.toolbar_save}
            title="Save"
            triggerFunc={handleSaveContent}
            isActive={
              !activeByReadOrLockedStatus &&
              (
                (activeFormBarTab === PROPERTIES_TAB || activeFormBarTab === INPUT_TAB) &&
                isContentModified
              ) ||
              (
                activeFormBarTab === OUTPUT_TAB &&
                isOutputContentModified
              )
            }
          />
          <Icons
            src={(selectedModuleIds.length === 1) ? rename : "https://cdn2.iconfinder.com/data/icons/basic-3/1024/edit-512.png"}
            title="Rename"
            triggerFunc={(e) => handleRenameModule(e)}
            isActive={
              (
                !activeByReadOrLockedStatus &&
                selectedModuleIds.length === 1 &&
                activeFormBarTab !== OUTPUT_TAB
              )
            }
          />
          <Icons
            src={(selectedModuleIds.length === 0 && (selectedWidgetIds.length > 0 || selectedOuterWidgetIds.length > 0)) ? duplicate : 'https://cdn3.iconfinder.com/data/icons/pixel-perfect-at-16px-volume-3-1/16/2122-512.png'}
            title="Duplicate"
            triggerFunc={(e) => handleDuplicate(e)}
            isActive={
              (
                !activeByReadOrLockedStatus &&
                selectedModuleIds.length === 0 &&
                (
                  selectedWidgetIds.length > 0 ||
                  selectedOuterWidgetIds.length > 0
                ) &&
                activeFormBarTab !== OUTPUT_TAB
              )
            }
          />
          <Icons
            src={(copiedData.moduleIds?.length > 0 || copiedData.widgetsdata?.widgetIds?.length > 0 || copiedData.outerWidgetIds?.length > 0) ? paste : 'https://cdn.iconscout.com/icon/premium/png-256-thumb/paste-1502606-1272816.png'}
            title="Paste"
            triggerFunc={(e) => handlePaste(e)}
            isActive={
              !activeByReadOrLockedStatus &&
              (
                copiedData.moduleIds?.length > 0 ||
                copiedData.widgetsdata?.widgetIds?.length > 0 ||
                copiedData.outerWidgetIds?.length > 0
              ) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={styles.icons.toolbar_copy}
            title="Copy"
            triggerFunc={(e) => handleCopy(e)}
            isActive={
              !activeByReadOrLockedStatus &&
              (
                selectedModuleIds.length > 0 ||
                selectedWidgetIds.length > 0
              ) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
          <Icons
            src={styles.icons.toolbar_suspend}
            title="Suspend"
            triggerFunc={() => { }}
            isActive={false}
          />
          <Icons
            src={styles.icons.toolbar_delete}
            title="Delete"
            triggerFunc={(e) => handleDelete(e)}
            //isActive={activeModuleId}
            // isActive={(selectedModuleIds.length > 0 || selectedWidgetIds.length > 0 || selectedOuterWidgetIds.length > 0 || selectedOuterPagebreakIndex  !== undefined || selectedInnerPagebreakIndex !== undefined || (activeReferenceId != null && activeReferenceId >= 0) || (activeAttachmentUrl != null || activeAttachmentUrl != ""))}
            isActive={
              !activeByReadOrLockedStatus &&
              (
                selectedModuleIds.length > 0 ||
                selectedWidgetIds.length > 0 ||
                selectedOuterWidgetIds.length > 0 ||
                selectedOuterPagebreakIndex !== undefined ||
                selectedInnerPagebreakIndex !== undefined ||
                (
                  activeReferenceId != null &&
                  activeReferenceId >= 0
                ) ||
                (
                  activeAttachmentUrl != null &&
                  activeAttachmentUrl != ""
                )
              ) &&
              activeFormBarTab !== OUTPUT_TAB
            }
          />
        </div>
      </div>
    </Style>
  );
}

Toolbar.defaultProps = {
  accountType: 'Private',
  page: '',
};

Toolbar.propTypes = {
  accountType: PropTypes.string.isRequired,
  page: PropTypes.string.isRequired,
  // iconsFragment: PropTypes.node.isRequired,
};

export default Toolbar;

const Style = styled.div`
  position: sticky;
  top: 70px;
  background: #fff;
  z-index: 8;
  display: flex;
  justify-content: space-between;
  padding: 10px 0px 2px 5px;
  border-bottom: 2px solid #4395a6;
  // .navMenu {   
  //   z-index: 9;
  // }
  .breadcrumb {
    display: flex;
    color: gray;
    font-size: 16px;
    align-items: center;
  }
  .icons-action {
    display: flex;
    align-items: flex-end;
    align-self: flex-end;
    padding-bottom: 6px;
  }
  .main-bar {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
  .bread-crumb {
    margin-left: 1rem;
  }
  .align-button{
    display:flex !important;
    justify-content: space-around;
    margin-bottom: 15px;
    width: 45%;
    margin: 10px auto;
}
.mb15{
    margin-bottom:15px !important;
}
label {
    display: table;
    position: relative;
    top: 7px;
    left: 8px;
    background: #fff;
    padding: 0 7px;
  }
  select,
input[type="text"],
.input-group input,
textarea,
.date,
.inputSize {
    background: white;
    border: 1px solid #666;
    border-radius: 5px;
    outline: 0;
    padding: 5px;
    box-shadow: 0px 0px 2px #999;
    width: 70%;
    height: 35px;
    align-self: center;
}
.process-module{
  background: #d9d9d9;  
}
.processModule{
  margin-left: 1rem;
  position: absolute;
  top: 48px;
}
`;
