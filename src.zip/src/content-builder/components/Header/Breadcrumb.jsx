import React from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';

export default function Breadcrumb() {
  const { accountType, content, module, inputOutput } = useSelector(
    (state) => state.content.breadcrumb
  );
  
  return (
    <Styles>
      {accountType} &#062; {content} &#062; {module ? module : ''} {inputOutput ? inputOutput : ''}
    </Styles>
  );
}

const Styles = styled.div`
  font-size: 150%;
  color: #888;
  text-transform: capitalize;
  @media (max-width: 810px) {
    font-size: 130%;
    margin: 20px 10px;
  }
`;
