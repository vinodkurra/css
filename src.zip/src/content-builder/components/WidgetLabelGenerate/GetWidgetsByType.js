import lodash from 'lodash';
export default function getWidgetsByType(currentContent) {
    //const currentContent = currentContentObjects();
    /**
 * while creating new widet need to find whether is module or outside of the module
 */
    // let modules = JSON.parse(JSON.stringify(currentContent?.moduleList));
    // let contentWidgets = JSON.parse(JSON.stringify(currentContent?.widgetList));
    let modules = lodash.cloneDeep(currentContent?.moduleList)
    let contentWidgets = lodash.cloneDeep(currentContent?.widgetList);
    let widgets = [];
    if (currentContent.activeCursorWidgetId !== undefined) {
        let activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
            (x, index) =>
                index === currentContent?.activeCursorModuleId &&
                x.type === 'module'
        )?.id;
        if (activeModuleId) {
            widgets = modules.find(module => module.id === activeModuleId)?.widgetList;
        }
    }
    else {//outside widget
        widgets = contentWidgets;
    }
    if (widgets?.length > 0)
        widgets.sort((a, b) => a?.id - b?.id)
    return widgets;
}


