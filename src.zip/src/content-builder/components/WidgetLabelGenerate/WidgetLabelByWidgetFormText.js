import { getExistingExportWidgets } from './GetExistingExportWidgets'
import { getNewWidgetName, getExistingWidgetFieldLabels } from './CommonFunctions';

export default function checkFieldLabelNameExist(fieldLabelName, currentContent, currentWidget) {
    let existWidgetNames = [];
    let widgetIsExist = -1;
    let activeModuleId = 0;
    if (currentContent.activeCursorWidgetId != undefined) {
        activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
            (x, index) =>
                index === currentContent?.activeCursorModuleId &&
                x.type === 'module'
        )?.id;
    }

    if (currentContent?.widgetList.length > 0) {
        widgetIsExist = currentContent.widgetList.findIndex(widget => widget.id === currentWidget.id);
    }

    if (widgetIsExist > -1) {
        currentContent.widgetList.map((widget, widgetIndex) => {
            if (
                widget?.title?.toLowerCase().includes(fieldLabelName?.toLowerCase()) &&
                widget?.title?.length <= fieldLabelName?.length + 3
            ) {
                existWidgetNames.push(widget.title);
            }
        });
    } else {
        currentContent.moduleList.map((module, index) => {

            if (module.id === activeModuleId) {

                module.widgetList.map((widget, widgetIndex) => {
                    if (
                        widget?.title?.toLowerCase().includes(fieldLabelName?.toLowerCase()) &&
                        widget?.title?.length <= fieldLabelName?.length + 3
                    ) {
                        existWidgetNames.push(widget.title);
                    }
                });
            }
        });
    }


    console.log('existWidgetNames:', existWidgetNames);
    //&& isWidgetNameExist
    if (existWidgetNames.length > 0) {
        fieldLabelName = getNewWidgetName(existWidgetNames, fieldLabelName);
    }

    //get all exported widgets
    if (currentWidget.export) {
        let exportedWidgets = getExistingExportWidgets(currentContent, currentWidget, true);
        let existingExportedWidgets = getExistingWidgetLabels(exportedWidgets, fieldLabelName);
        if (existingExportedWidgets.length > 0) {
            fieldLabelName = getNewWidgetName(existingExportedWidgets, fieldLabelName);
        }
    }
    return fieldLabelName;
}

function getExistingWidgetLabels(widgets, widgetTitle) {
    let existWidgetNames = [];
    if (widgets.length > 0) {
        widgets.map((widget, widgetIndex) => {
            if (
                widget?.title?.includes(widgetTitle) &&
                // widget?.title === widgetTitle &&
                widget?.title?.length <= widgetTitle?.length + 3
            ) {
                existWidgetNames.push(widget.title);
            }
        });
    }
    return existWidgetNames;
}

function getlatestFieldName(recentWidgetName) {
    let lastFieldLabelNumber = 1;
    lastFieldLabelNumber = parseInt(recentWidgetName.match(/\d+/g)[0].replace(/\b0+/g, ''));
    lastFieldLabelNumber++;

    let numberOfZeros =
        parseInt(lastFieldLabelNumber) <= 9
            ? '00'
            : parseInt(lastFieldLabelNumber) <= 99
                ? '0'
                : '000';

    let widgetFieldLabelName =
        recentWidgetName.match(/[a-zA-Z]+/g)[0] +
        numberOfZeros +
        lastFieldLabelNumber;

    return widgetFieldLabelName;
}