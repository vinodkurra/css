import {
  CALCULATION_WIDGET,
  COMPRESSED_VIEW,
  NARRATIVE_WIDGET,
  STANDARD_VIEW,
  WARNING_INPUT_WIDGET,
  DATE_WIDGET,
  NUMBER_WIDGET,
  DROPDOWNLIST_WIDGET,
  TIME_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  TEXT_INPUT_WIDGET,
  BRANCH_CONTROL_WIDGET,
} from "../Constants";

export default function getWidgetLeadingNameByType(widgetType) {
  switch (widgetType) {
    case BINARY_INPUT_WIDGET:
      return "INP";
    case SINGLE_CHOICE_WIDGET:
      return "INP";
    case MULTI_CHOICE_WIDGET:
      return "INP";
    case DROPDOWNLIST_WIDGET:
      return "INP";
    case NUMBER_WIDGET:
      return "INP";
    case TEXT_INPUT_WIDGET:
      return "INP";
    case DATE_WIDGET:
      return "INP";
    case CALCULATION_WIDGET:
      return "CALC";
    case NARRATIVE_WIDGET:
      return "NARA";
    case TIME_INPUT_WIDGET:
      return "INP";
    case WARNING_INPUT_WIDGET:
      return "WARN";
    case BRANCH_CONTROL_WIDGET:
      return "BRA";
    default:
      return "";
  }
}
