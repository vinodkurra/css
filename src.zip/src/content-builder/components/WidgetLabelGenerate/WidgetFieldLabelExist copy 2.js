import { getExistingExportWidgets } from './GetExistingExportWidgets'
import { getExistingWidgetFieldLabels, removeWidget } from './CommonFunctions';
import lodash from 'lodash';

export default function widgetFieldLabelExist(fieldLabelName, currentContent, widgetId, currentWidget) {
    let isWidgetNameExist = false;
    let existWidgetNames = [];
    let widgetIsExist = -1;

    // let modules = JSON.parse(JSON.stringify(currentContent?.moduleList));
    // let contentWidgets = JSON.parse(JSON.stringify(currentContent?.widgetList));
    let modules = lodash.cloneDeep(currentContent?.moduleList)
    let contentWidgets = lodash.cloneDeep(currentContent?.widgetList);

    if (contentWidgets?.length > 0) {
        widgetIsExist = contentWidgets.findIndex(widget => widget.id === widgetId);
    }

    removeWidget(currentWidget, modules, contentWidgets);


    if (widgetIsExist > -1) {
        contentWidgets.map((widget, widgetIndex) => {
            if (
                // widget?.title?.includes(fieldLabelName) &&
                widget?.title?.toLowerCase() === fieldLabelName?.toLowerCase() &&
                widget?.title?.length <= fieldLabelName?.length + 3
            ) {
                existWidgetNames.push(widget.title);
            }
        });
    } else {
        modules.map((module, index) => {
            if (currentWidget.moduleId === module.id) {

                module.widgetList.map((widget, widgetIndex) => {
                    if (
                        // widget?.title?.includes(fieldLabelName) &&
                        widget?.title?.toLowerCase() === fieldLabelName?.toLowerCase() &&
                        widget?.title?.length <= fieldLabelName?.length + 3
                    ) {
                        existWidgetNames.push(widget.title);
                    }
                });
            }
        });
    }

    console.log('existWidgetNames:', existWidgetNames);
    //&& isWidgetNameExist
    if (existWidgetNames.length > 0) {
        isWidgetNameExist = true;
    }

    if (currentWidget.export) {
        //get all exported widgets
        //let exportedWidgets = getExistingExportWidgetsExceptCurrentWidget(currentContent,currentWidget);
        let exportedWidgets = getExistingExportWidgets(currentContent, currentWidget, true);
        let existingExportedWidgets = getExistingWidgetFieldLabels(exportedWidgets, fieldLabelName);
        if (existingExportedWidgets.length > 0) {
            isWidgetNameExist = true;
        }
    }
    return isWidgetNameExist;
}