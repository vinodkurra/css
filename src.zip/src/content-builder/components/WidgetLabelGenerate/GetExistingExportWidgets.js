import lodash from 'lodash';
function getExistingWidgets(currentContent, currentWidget = {}) {

    // let modules = JSON.parse(JSON.stringify(currentContent?.moduleList));
    // let contentWidgets = JSON.parse(JSON.stringify(currentContent?.widgetList));
    let modules = lodash.cloneDeep(currentContent?.moduleList)
    let contentWidgets = lodash.cloneDeep(currentContent?.widgetList);
    let allWidgets = [];
    /**
     * when click export button that selected widget needs to exclude
     */
    removeWidget(currentWidget, modules, contentWidgets);
    if (modules?.length > 0) {
        allWidgets = modules.reduce(
            (data, obj) => [...data, ...obj.widgetList],
            []
        );
    }
    if (contentWidgets?.length > 0) {
        allWidgets = [...allWidgets, ...contentWidgets]
    }
    return allWidgets;
}

function getExistingExportWidgets(currentContent, currentWidget, isRemoveCurrentWidget = false) {

    // let modules = JSON.parse(JSON.stringify(currentContent?.moduleList));
    // let contentWidgets = JSON.parse(JSON.stringify(currentContent?.widgetList));
    let modules = lodash.cloneDeep(currentContent?.moduleList)
    let contentWidgets = lodash.cloneDeep(currentContent?.widgetList);
    let allWidgets = [];
    if (isRemoveCurrentWidget)
        removeWidget(currentWidget, modules, contentWidgets)
    if (modules?.length > 0) {
        allWidgets = modules.reduce(
            (data, obj) => [...data, ...obj.widgetList.filter(widget => widget.export === true)],
            []
        );
        //allWidgets.sort((a, b) => a?.id - b?.id)
    }
    if (contentWidgets?.length > 0) {
        allWidgets = [...allWidgets, ...contentWidgets.filter(widget => widget.export === true)]
    }

    return allWidgets;
}

function removeWidget(currentWidget, modules, contentWidgets) {
    if (currentWidget != undefined && Object.values(currentWidget).length > 0) {
        if (modules?.length > 0) {
            modules.map((module) => {
                module.widgetList.map((widget, index) => {
                    if (widget.id === currentWidget.id) {
                        module.widgetList.splice(index, 1);
                    }
                })
            })
        }
        if (contentWidgets?.length > 0) {
            contentWidgets.map((widget, index) => {
                if (widget.id === currentWidget.id) {
                    contentWidgets.splice(index, 1);
                }
            })
        }
    }
}

export { getExistingWidgets, getExistingExportWidgets }

