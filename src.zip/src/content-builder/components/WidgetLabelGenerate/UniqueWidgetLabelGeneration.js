import getWidgetLeadingNameByType from "./GetWidgetLeadingName";
import getWidgetsByType from "./GetWidgetsByType";
import { findExportFieldLabelNameExist } from "./FindWidgetLabelExist";

export default function getNewWidgetByType(
  currentContent,
  type
  //   isCopyWidget = false,
  //   copyWidgets = []
) {
  //   let widgets = [];
  //   if (!isCopyWidget) widgets = getWidgetsByType(currentContent);
  //   else widgets = copyWidgets;

  let activeModuleId = 0;
  if (currentContent.activeCursorWidgetId != undefined) {
    activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
      (x, index) =>
        index === currentContent?.activeCursorModuleId && x.type === "module"
    )?.id;
  }
  /**
   * get leading name based on the widget type
   */

  let widgetLeadingName = getWidgetLeadingNameByType(type);
  // if (!isCopyWidget) {

  const contentWidgetLabels = currentContent?.contentWidgetLabels || [];
  if (contentWidgetLabels?.length > 0) {
    let widgetInputTypes = [
      "text",
      "binary",
      "time",
      "single_choice",
      "multiple_choice",
      "date",
      "drop_down",
      "number",
    ];

    let findWidgetType = widgetInputTypes.includes(type) ? "input" : type;

    let widgetOtherTypes = ["warning", "calculation", "narrative"];
    let lastWidgetName = "";
    const activeContentId =
      currentContent?.activeContentId || currentContent?.contentId;
    contentWidgetLabels.map((widget) => {
      if (
        widget.contentId === activeContentId &&
        // (widget.moduleId === activeModuleId || activeModuleId === 0) &&
        widget.moduleId === activeModuleId &&
        widget.type === findWidgetType
      ) {
        lastWidgetName = widget.widgetDefaultName;
        // if (widgetInputTypes.includes(widget.type) && widgetInputTypes.includes(type)) {
        //     lastWidgetName = widget.widgetDefaultName;
        // }
        // else if (widgetOtherTypes.includes(widget.type) && widgetOtherTypes.includes(type)) {
        //     lastWidgetName = widget.widgetDefaultName;
        // }
      }
    });
    if (lastWidgetName) {
      let newWidgetName = getNewWidgetName(lastWidgetName, widgetLeadingName);
      return getNewWidget(newWidgetName, type, currentContent);
    } else {
      return getNewWidget(
        `${widgetLeadingName}001`,
        type,
        currentContent,
        true
      );
    }
  } else
    return getNewWidget(`${widgetLeadingName}001`, type, currentContent, true);
  // }
  // else {
  //     if (widgets.length > 0) {
  //         //        widgets.sort((a, b) => a?.id - b?.id)
  //         let widgetsBasedOnType = widgets.filter((widget) =>
  //             widget.widgetDefaultName?.includes(widgetLeadingName)
  //         );

  //         if (widgetsBasedOnType.length > 0) {
  //             let lastWidgetName =
  //                 widgetsBasedOnType[widgetsBasedOnType.length - 1].widgetDefaultName;
  //             let newWidgetName = getNewWidgetName(lastWidgetName, widgetLeadingName);

  //             return getNewWidget(newWidgetName, type, currentContent);
  //         } else
  //             return getNewWidget(`${widgetLeadingName}001`, type, currentContent);

  //     } else
  //         return getNewWidget(`${widgetLeadingName}001`, type, currentContent, true);
  // }

  // let widgetLeadingName = getWidgetLeadingNameByType(type);
  // if (widgets.length > 0) {
  //     //        widgets.sort((a, b) => a?.id - b?.id)
  //     let widgetsBasedOnType = widgets.filter((widget) =>
  //         widget.widgetDefaultName?.includes(widgetLeadingName)
  //     );

  //     if (widgetsBasedOnType.length > 0) {
  //         let lastWidgetName =
  //             widgetsBasedOnType[widgetsBasedOnType.length - 1].widgetDefaultName;
  //         let newWidgetName = getNewWidgetName(lastWidgetName, widgetLeadingName);

  //         return getNewWidget(newWidgetName, type, currentContent);
  //     } else
  //         return getNewWidget(`${widgetLeadingName}001`, type, currentContent);

  // } else
  //     return getNewWidget(`${widgetLeadingName}001`, type, currentContent, true);
}

function getNewWidgetName(lastWidgetName, widgetLeadingName) {
  let lastWidgetNumber = parseInt(lastWidgetName.slice(-3)) + 1;
  let numberOfZeros =
    parseInt(lastWidgetNumber) <= 9
      ? "00"
      : parseInt(lastWidgetNumber) <= 99
      ? "0"
      : "000";
  let newWidgetName = widgetLeadingName + numberOfZeros + lastWidgetNumber;
  return newWidgetName;
}
function checkNewWidgetName(newWidgetName, lastWidgetName) {
  let newWidgetNumber = parseInt(newWidgetName.slice(-3));
  let lastWidgetNumber = parseInt(lastWidgetName.slice(-3));
  return newWidgetNumber > lastWidgetNumber ? true : false;
}

function getNewWidget(widgetName, type, currentContent, isNew = false) {
  return {
    // id: 1,
    widgetName: widgetName,
    widgetDefaultName: widgetName,
    widgetType: type,
  };
}

/**
 * this needs to be enable in the future don't remove
 */
// function getNewWidget(widgetName, type, currentContent, isNew = false) {

//     // if (!isNew) {
//     let widgetExists = findExportFieldLabelNameExist(currentContent, widgetName);

//     if (widgetExists.length > 0) {
//
//         let newWidgetName = '';
//         let widgetLeadingName = getWidgetLeadingNameByType(type);
//         let uniqueExistingWidget = [...new Set(widgetExists)];

//         if (uniqueExistingWidget.length > 0) {
//             let isFoundName = false;
//
//             for (var i = 0; i < uniqueExistingWidget.length; i++) {
//                 if (uniqueExistingWidget[i]?.includes(widgetName)) {
//                     widgetName = getNewWidgetName(widgetName, widgetLeadingName);
//                     isFoundName = true;
//                 }
//                 else if (isFoundName) {
//                     break;
//                 }
//             }
//         }
//         // else
//         //     newWidgetName = widgetName;

//         // let widgetsBasedOnType = uniqueExistingWidget.filter((widget) =>
//         //     widget?.includes(widgetName)
//         // );

//         // let lastWidgetName = '';
//         // if (widgetsBasedOnType?.length > 0) {
//         //     lastWidgetName =
//         //         widgetsBasedOnType[widgetsBasedOnType.length - 1];
//         //     newWidgetName = getNewWidgetName(lastWidgetName, widgetLeadingName);
//         // }
//         // else
//         //     newWidgetName = widgetName;

//         return {
//             //id: 1,
//             widgetName: widgetName,
//             widgetDefaultName: widgetName,
//             widgetType: type,
//         };
//     }
//     //}

//     return {
//         // id: 1,
//         widgetName: widgetName,
//         widgetDefaultName: widgetName,
//         widgetType: type,
//     };
// }
