
import { getExistingWidgets, getExistingExportWidgets } from './GetExistingExportWidgets';

function findFieldLabelNameExist(currentContent, widgetTitle, currentWidget) {

    let widgets = getExistingWidgets(currentContent, currentWidget);
    
    let existWidgetNames = getExistingWidgetFieldLabels(widgets, widgetTitle)
    return existWidgetNames;
}

function findExportFieldLabelNameExist(currentContent, widgetTitle) {

    // let widgets = getExistingExportWidgets(currentContent);
    // let existWidgetNames = getExistingWidgetFieldLabels(widgets, widgetTitle)
    // return existWidgetNames;
    let widgets = getExistingExportWidgets(currentContent);
    let existWidgetNames = [];
    if (widgets?.length > 0) {

        existWidgetNames = widgets.map(function (widget) { return widget.title; });
        existWidgetNames.sort();
    }
    return existWidgetNames;
}

function getExistingWidgetFieldLabels(widgets, widgetTitle) {
    let existWidgetNames = [];
    if (widgets.length > 0) {
        widgets.map((widget, widgetIndex) => {
            if (
                widget?.title?.toLowerCase() === widgetTitle?.toLowerCase() &&
                widget?.title?.length <= widgetTitle?.length + 3
            ) {
                existWidgetNames.push(widget.title);
            }
            // if (
            //     widget?.title?.includes(widgetTitle) &&
            //     widget?.title?.length <= widgetTitle?.length + 3
            // ) {
            //     existWidgetNames.push(widget.title);
            // }
        });
    }
    return existWidgetNames;
}

export { findFieldLabelNameExist, findExportFieldLabelNameExist }