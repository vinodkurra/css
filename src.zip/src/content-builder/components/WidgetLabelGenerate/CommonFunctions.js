function getNewWidgetName(existWidgetNames, fieldLabelName) {

    let recentWidgetName = existWidgetNames[existWidgetNames.length - 1];
    if (recentWidgetName.includes('0')) {
        fieldLabelName = getlatestFieldName(recentWidgetName);
    } else {
        fieldLabelName = fieldLabelName + '001';
    }
    return fieldLabelName;
}


function getlatestFieldName(recentWidgetName) {
    let lastFieldLabelNumber = 1;
    lastFieldLabelNumber = parseInt(recentWidgetName.match(/\d+/g)[0].replace(/\b0+/g, ''));
    lastFieldLabelNumber++;

    let numberOfZeros =
        parseInt(lastFieldLabelNumber) <= 9
            ? '00'
            : parseInt(lastFieldLabelNumber) <= 99
                ? '0'
                : '000';

    let widgetFieldLabelName =
        recentWidgetName.match(/[a-zA-Z]+/g)[0] +
        numberOfZeros +
        lastFieldLabelNumber;

    return widgetFieldLabelName;
}

function getExistingWidgetFieldLabels(widgets, widgetTitle) {
    let existWidgetNames = [];
    if (widgets.length > 0) {
        widgets.map((widget, widgetIndex) => {
            if (
                // widget?.title?.includes(widgetTitle) &&
                widget?.title?.toLowerCase() === widgetTitle?.toLowerCase() &&
                widget?.title?.length <= widgetTitle?.length + 3
            ) {
                existWidgetNames.push(widget.title);
            }
        });
    }
    return existWidgetNames;
}

function removeWidget(currentWidget, modules, contentWidgets) {

    if (currentWidget != undefined && Object.values(currentWidget).length > 0) {
        if (modules?.length > 0) {
            modules.map((module) => {
                module.widgetList.map((widget, index) => {
                    if (widget.id === currentWidget.id) {
                        module.widgetList.splice(index, 1);
                    }
                    if (currentWidget.type === 'branch' || widget?.widgetList?.length > 0) {
                        widget.widgetList.map((branchWidget, branchWidgetIndex) => {
                            branchWidget.map((childBranch) => {
                                if (
                                    childBranch?.id === currentWidget.id
                                ) {
                                    widget.widgetList.splice(branchWidgetIndex, 1);
                                }
                                childBranch.widgetList.map((chlWidget, chlWidgetIndex) => {
                                    if (
                                        chlWidget?.id === currentWidget.id
                                    ) {
                                        childBranch.widgetList.splice(chlWidgetIndex, 1);
                                    }
                                })
                            });
                        });
                    }
                })
            });

            // if (currentWidget.type === 'branch') {
            //     currentWidget.widgetList.map((branchWidget) => {
            //         branchWidget.map((childBranch, childBranchIndex) => {
            //             if (
            //                 // widget?.title?.includes(fieldLabelName) &&
            //                 childBranch?.id === currentWidget.id
            //             ) {
            //                 currentWidget.widgetList.splice(childBranchIndex, 1);
            //             }
            //             ;
            //             childBranch.widgetList.map((chlWidget, chlWidgetIndex) => {
            //                 if (
            //                     // widget?.title?.includes(fieldLabelName) &&
            //                     chlWidget?.id === currentWidget.id
            //                 ) {
            //                     childBranch.widgetList.splice(chlWidgetIndex, 1);
            //                 }
            //             })
            //         });
            //     });
            // }
        }
        if (contentWidgets?.length > 0) {
            contentWidgets.map((widget, index) => {
                if (widget.id === currentWidget.id) {
                    contentWidgets.splice(index, 1);
                }
                ;
                if (currentWidget.type === 'branch' || widget?.widgetList?.length > 0) {
                    widget.widgetList.map((branchWidget, branchWidgetIndex) => {
                        branchWidget.map((childBranch) => {
                            if (
                                childBranch?.id === currentWidget.id
                            ) {
                                widget.widgetList.splice(branchWidgetIndex, 1);
                            }
                            childBranch.widgetList.map((chlWidget, chlWidgetIndex) => {
                                if (
                                    chlWidget?.id === currentWidget.id
                                ) {
                                    childBranch.widgetList.splice(chlWidgetIndex, 1);
                                }
                            })
                        });
                    });
                }
            })
        }
    }
}
// function removeWidget(currentWidget, modules, contentWidgets) {

//     if (currentWidget != undefined && Object.values(currentWidget).length > 0) {
//         if (modules?.length > 0) {
//             modules.map((module) => {
//                 module.widgetList.map((widget, index) => {
//                     if (widget.id === currentWidget.id) {
//                         module.widgetList.splice(index, 1);
//                     }
//                 })
//             })
//         }
//         if (contentWidgets?.length > 0) {
//             contentWidgets.map((widget, index) => {
//                 if (widget.id === currentWidget.id) {
//                     contentWidgets.splice(index, 1);
//                 }
//             })
//         }
//     }
// }

export { getNewWidgetName, getExistingWidgetFieldLabels, removeWidget };