import React from "react";
import styled from "styled-components";
import { useDispatch } from "react-redux";
import { setCursorSelectedStatus } from "../../store/content";

export default function EditPaneCursor({ type, left }) {
  const dispatch = useDispatch();

  const handleSelectCursor = (e) => {
    if (e) e.preventDefault();
    dispatch(setCursorSelectedStatus(true));
  };

  const handleOnBlur = (e) => {
    if (e) e.preventDefault();
    dispatch(setCursorSelectedStatus(false));
  }

  return (
    <Styles>
      <div style={{ marginTop: "10px", marginLeft: left ? left : "" }}>
        <div
          className={type === "dashed" ? "hoverBar dashed" : "hoverBar"}
          onClick={(e) => handleSelectCursor(e)}
          onBlur={(e) => handleOnBlur(e)}
          tabIndex="0"
        >
          <span></span>
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .hoverBar {
    position: relative;
    padding: 16px 0px;
    left: 10px;
    outline: 0;
  }

  .hoverBar span {
    width: 412px;
    height: 2px;
    border-bottom: 2px solid #7b7b7b;
    display: block;
  }
  .hoverBar.dashed span {
    width: 416px;
    border-bottom: 2px dashed #7b7b7b;
  }
  .hoverBar span:after {
    content: "";
    position: absolute;
    right: 60px;
    top: -3px;
    width: 0;
    height: 0;
    border-top: 20px solid transparent;
    border-bottom: 20px solid transparent;
    border-right: 20px solid #7b7b7b;
    clear: both;
  }
  .hoverBar span:before {
    content: "";
    position: absolute;
    top: -3px;
    left: 0;
    width: 0;
    height: 0;
    border-top: 20px solid transparent;
    border-bottom: 20px solid transparent;
    border-left: 20px solid #7b7b7b;
    clear: both;
  }
`;
