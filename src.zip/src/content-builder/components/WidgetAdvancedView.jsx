import React, { useState } from "react";
import Styled from "styled-components";
import { useDispatch, useSelector } from "react-redux";
import { MentionsInput, Mention } from "react-mentions";
import {
  CALCULATION_WIDGET,
  SHOW_DEFAULT_ANSWER,
  ANSWER_REQUIRED,
  USE_DEFAULT_ANSWER,
  FORMAT_VALIDATION,
  HINT_TEXT,
  LAYOUT,
  FONT_SIZE,
  INDENT,
  NOTE,
  TEXT_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  TIME_INPUT_WIDGET,
  WARNING_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DATE_WIDGET,
  DROPDOWNLIST_WIDGET,
  NARRATIVE_WIDGET,
  NUMBER_WIDGET,
} from "./Constants";
import { setContentModifiedFlag } from "../../store/content";

const WidgetAdvancedView = ({
  widgetPosition,
  widget,
  handleSelectWidget,
  module,
  widgetIndex,
  moduleIndex,
  mentionWidgets,
}) => {
  //advancedOptions,
  // const [activeRequiredTab, setActiveRequiredTab] = useState(widget.answerRequired || widget?.requried ? "Always" : "Never")
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const {
    contents,
    activeContentId,
    // selectedWidgetIds,
    // advancedViewWidgetIds
  } = useSelector((state) => state.content);

  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);
  let advancedViewWidgetIds =
    currentContent?.advancedViewWidgetIds?.length > 0
      ? currentContent.advancedViewWidgetIds
      : [];
  // let selectedWidgetIds =
  //     currentContent?.selectedWidgetIds?.length > 0
  //         ? currentContent.selectedWidgetIds
  //         : [];
  // let selectedOuterWidgetIds = currentContent?.selectedOuterWidgetIds?.length > 0 ? currentContent.selectedOuterWidgetIds : [];
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];

  /**
   * default heading names created instead of hard coding in DOM
   */
  const defaultHeadings = [
    { id: 1, value: "When" },
    { id: 2, value: "Always" },
    { id: 3, value: "Never" },
  ];
  const defaultHintHeadings = [
    { id: 1, value: "As Sub-title" },
    { id: 2, value: "As Call-Out" },
  ];
  const defaultFormValidationHeadings = [
    { id: 1, value: "On" },
    { id: 2, value: "Off" },
  ];
  const defaultLayoutHeadings = [
    { id: 1, value: "Horizontal" },
    { id: 2, value: "Vertical" },
  ];
  widget.showDefaultAnswer = widget.showDefaultAnswer || "Always";
  widget.useDefaultValue = widget.useDefaultValue || "Always";
  widget.hintText = widget.hintText || "As Sub-title";
  // widget.answerRequired =
  //    widget.required ? widget.answerRequired"Always" : "Never";
  if(!widget.answerRequired) {
   widget.answerRequired = 'Never'
  }
  widget.formatValidationStatus = widget.formatValidationStatus || "On";
  widget.layout = widget.layout || "Horizontal";
  widget.size = widget.size || 10;
  widget.indent = widget.indent || 1;

  /**
   *whenever value enter into all the input from advanced view layout corresponding values assigned into their states
   */
  const handleChange = (e, type) => {
    // if (e) e.persist();

    dispatch(setContentModifiedFlag(true));
    switch (type) {
      case SHOW_DEFAULT_ANSWER:
        widget.showDefaultAnswerValue = e.target.value;
        break;
      case ANSWER_REQUIRED:
        widget.answerRequiredValue = e.target.value;
        break;
      case USE_DEFAULT_ANSWER:
        widget.useDefaultAnswerValue = e.target.value;
        break;
      case FORMAT_VALIDATION:
        widget.formatValidationValue = e.target.value;
        break;
      case HINT_TEXT:
        widget.hintTextValue = e.target.value;
        break;
      case FONT_SIZE:
        widget.size = e.target.value;
        break;
      case INDENT:
        widget.indent = e.target.value;
        break;
      case NOTE:
        widget.note = e.target.value;
        break;
    }
  };

  /**
   *whenever headings change  from advanced view layout corresponding values assigned into their states
   */
  const handleTypeChange = (e, newHeader, type) => {
    if (e) e.preventDefault();    
    dispatch(setContentModifiedFlag(true));
    switch (type) {
      case SHOW_DEFAULT_ANSWER:
        widget.showDefaultAnswer = newHeader;
        break;
      case ANSWER_REQUIRED:
        widget.answerRequired = newHeader;
        if (newHeader === "When") {
          widget.required = true;          
        } else if (newHeader === "Always") {
          widget.required = true;
        } else {
          widget.required = false;
        }
        break;
      case USE_DEFAULT_ANSWER:
        widget.useDefaultValue = newHeader;
        break;
      case FORMAT_VALIDATION:
        widget.formatValidationStatus = newHeader;
        break;
      case HINT_TEXT:
        widget.hintText = newHeader;
        break;
      case LAYOUT:
        widget.layout = newHeader;
        break;
    }
  };
  if (
    widget.widgetType === NARRATIVE_WIDGET ||
    widget.widgetType === CALCULATION_WIDGET
  )
    return false;

  return (
    <Styles styles={styles}>
      <div
        className={
          advancedViewWidgetIds.indexOf(widget.id) > -1 &&
          selectedWidgetIds.indexOf(widget.id) > -1
            ? module.readOnly
              ? "advance-widget-container"
              : "advance-widget-container module"
            : "advance-widget-container"
        }
        // className="advance-widget-container"
        onClick={(e) =>
          handleSelectWidget(
            e,
            widgetPosition,
            widget,
            module,
            widgetIndex,
            moduleIndex
          )
        }
      >
        {widget.widgetType !== WARNING_INPUT_WIDGET ? (
          <>
            <div className="advanceWidget">
              <div className="widgetOptions">
                <label>Show Default Answer:</label>
                <div className="widgetOptionType">
                  <div className="optionTypes">
                    {defaultHeadings.map((key, index) => (
                      <span
                        key={index}
                        className={
                          //advancedOptions.showDefaultAnswer.type === key.value ?
                          widget.showDefaultAnswer === key.value
                            ? "active show"
                            : "show"
                        }
                        onClick={(e) =>
                          handleTypeChange(e, key.value, SHOW_DEFAULT_ANSWER)
                        }
                      >
                        {key.value}
                      </span>
                    ))}
                  </div>
                  <div className="widgetInput">
                    {/* <input
                                                type="text"
                                                name="showDefaultAnswer"
                                                autoComplete="off"
                                                placeholder="Inp001 == Option1"
                                                //defaultValue={advancedOptions.showDefaultAnswer.value}
                                                defaultValue={widget.showDefaultAnswerValue}
                                                onChange={(e) => handleChange(e, SHOW_DEFAULT_ANSWER)}
                                            /> */}
                    <MentionsInput
                      disabled={
                        widget.showDefaultAnswer === "When" ? false : true
                      }
                      id="singleChoice"
                      markup="@[display](id)"
                      value={widget.showDefaultAnswerValue || ""}
                      onChange={(e) => handleChange(e, SHOW_DEFAULT_ANSWER)}
                      className="textAreaCalc"
                      placeholder="Inp001 = Option1"
                    >
                      <Mention
                        trigger="@"
                        data={mentionWidgets}
                        style={{
                          backgroundColor: "#ddd",
                        }}
                        appendSpaceOnAdd="true"
                      />
                    </MentionsInput>
                  </div>
                </div>

                <label>Use Default Answer:</label>
                <div className="widgetOptionType">
                  <div className="optionTypes">
                    {defaultHeadings.map((key, index) => (
                      <span
                        key={index}
                        className={
                          //advancedOptions.useDefaultAnswer.type === key.value ?
                          widget.useDefaultValue === key.value
                            ? "active show"
                            : "show"
                        }
                        onClick={(e) =>
                          handleTypeChange(e, key.value, USE_DEFAULT_ANSWER)
                        }
                      >
                        {key.value}
                      </span>
                    ))}
                  </div>
                  <div className="widgetInput">
                    {/* <input
                      type="text"
                      name="useDefaultAnswer"
                      autoComplete="off"
                      placeholder="Inp001 == Option1"
                      // defaultValue={advancedOptions.useDefaultAnswer.value}
                      defaultValue={widget.useDefaultAnswerValue}
                      onChange={(e) => handleChange(e, USE_DEFAULT_ANSWER)}
                    /> */}
                    <MentionsInput
                      disabled={
                        widget.useDefaultValue === "When" ? false : true
                      }
                      id="singleChoice"
                      markup="@[display](id)"
                      value={widget.useDefaultAnswerValue || ""}
                      onChange={(e) => handleChange(e, USE_DEFAULT_ANSWER)}
                      className="textAreaCalc"
                      placeholder="Inp001 = Option1"
                    >
                      <Mention
                        trigger="@"
                        data={mentionWidgets}
                        style={{
                          backgroundColor: "#ddd",
                        }}
                        appendSpaceOnAdd="true"
                      />
                    </MentionsInput>
                  </div>
                </div>

                <label>Hint Text:</label>
                <div className="widgetOptionType">
                  <div className="optionTypes">
                    {defaultHintHeadings.map((key, index) => (
                      <span
                        key={index}
                        className={
                          //advancedOptions.hintText.type === key.value ?
                          widget.hintText === key.value ? "active show" : "show"
                        }
                        onClick={(e) =>
                          handleTypeChange(e, key.value, HINT_TEXT)
                        }
                      >
                        {key.value}
                      </span>
                    ))}
                  </div>
                  <div>
                    <textarea
                      name="hintText"
                      autoComplete="off"
                      placeholder="Atleast one type must be selected"
                      defaultValue={widget.hintTextValue}
                      onChange={(e) => handleChange(e, HINT_TEXT)}
                    />
                  </div>
                </div>
              </div>
              <div className="widgetOptions">
                <label>Answer Required:</label>
                <div className="widgetOptionType">
                  <div className="optionTypes">
                    {defaultHeadings.map((key, index) => (
                      <span
                        key={index}
                        className={
                          //advancedOptions.answerRequired.type === key.value ?
                          widget.answerRequired === key.value
                            ? "active show"
                            : "show"
                        }
                        onClick={(e) =>
                          handleTypeChange(e, key.value, ANSWER_REQUIRED)
                        }
                      >
                        {key.value}
                      </span>
                    ))}
                  </div>
                  <div className="widgetInput">
                    {/* <input
                      type="text"
                      name="answerRequired"
                      autoComplete="off"
                      placeholder="Inp001 == Option1"
                      //defaultValue={advancedOptions.answerRequired.value}
                      defaultValue={widget.answerRequiredValue}
                      onChange={(e) => handleChange(e, ANSWER_REQUIRED)}
                    /> */}
                    <MentionsInput
                      disabled={widget.answerRequired === "When" ? false : true}
                      id="singleChoice"
                      markup="@[display](id)"
                      value={widget.answerRequiredValue || ""}
                      onChange={(e) => handleChange(e, ANSWER_REQUIRED)}
                      className="textAreaCalc"
                      placeholder="Inp001 = Option1"
                    >
                      <Mention
                        trigger="@"
                        data={mentionWidgets}
                        style={{
                          backgroundColor: "#ddd",
                        }}
                        appendSpaceOnAdd="true"
                      />
                    </MentionsInput>
                  </div>
                </div>
                {widget.widgetType !== BINARY_INPUT_WIDGET &&
                widget.widgetType !== SINGLE_CHOICE_WIDGET &&
                widget.widgetType !== MULTI_CHOICE_WIDGET &&
                widget.widgetType !== DROPDOWNLIST_WIDGET ? (
                  <>
                    <label>Format Validation:</label>
                    <div className="widgetOptionType">
                      <div className="optionTypes">
                        {defaultFormValidationHeadings.map((key, index) => (
                          <span
                            key={index}
                            className={
                              //advancedOptions.formValidation.type === key.value ?
                              widget.formatValidationStatus === key.value
                                ? "active show"
                                : "show"
                            }
                            onClick={(e) =>
                              handleTypeChange(e, key.value, FORMAT_VALIDATION)
                            }
                          >
                            {key.value}
                          </span>
                        ))}
                      </div>
                      <div className="widgetInput">
                        <input
                          type="text"
                          name="formValidation"
                          autoComplete="off"
                          placeholder="DD/MM/YY"
                          // defaultValue={advancedOptions.formValidation.value}
                          defaultValue={widget.formatValidationValue}
                          onChange={(e) => handleChange(e, FORMAT_VALIDATION)}
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  ""
                )}

                {widget.widgetType !== DROPDOWNLIST_WIDGET &&
                widget.widgetType !== NUMBER_WIDGET &&
                widget.widgetType !== TEXT_INPUT_WIDGET &&
                widget.widgetType !== DATE_WIDGET &&
                widget.widgetType !== TIME_INPUT_WIDGET ? (
                  <>
                    <label>Layout:</label>
                    <div className="widgetOptionType layout">
                      <div className="optionTypes">
                        {defaultLayoutHeadings.map((key, index) => (
                          <span
                            key={index}
                            className={
                              // advancedOptions.layout.type === key.value ?
                              widget.layout === key.value
                                ? "active show"
                                : "show"
                            }
                            onClick={(e) =>
                              handleTypeChange(e, key.value, LAYOUT)
                            }
                          >
                            {key.value}
                          </span>
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  ""
                )}
                <div className="widgetOptionType layout">
                  <div className="rangeContainer">
                    <label className="sizeLabel">Size:</label>
                    <div className="sizeDiv">
                      <span style={{ fontSize: "10px" }}>A</span>
                      <input
                        type="range"
                        min={10}
                        max={20}
                        id="fontSize"
                        //defaultValue={advancedOptions.fontSize.value}
                        defaultValue={widget.size}
                        onChange={(e) => handleChange(e, FONT_SIZE)}
                      />
                      <span
                        className="constA"
                        style={{ fontSize: widget.size + "px" }}
                      >
                        <div className="rangeFontSize">
                          <span>A</span>
                        </div>
                      </span>
                    </div>
                    <label className="indentLabel">Indent:</label>
                    <div className="indentDiv">
                      <span>0</span>
                      <input
                        type="range"
                        min={0}
                        max={5}
                        id="indent"
                        defaultValue={widget.indent}
                        onChange={(e) => handleChange(e, INDENT)}
                      />
                      <span>{widget.indent}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          ""
        )}
        <div className="widgetNote">
          <label>Note:</label>
          <textarea
            name="note"
            autoComplete="off"
            placeholder="Note to self what a great idea!
                        This must be selected first."
            //defaultValue={advancedOptions.note.value}
            defaultValue={widget.note}
            onChange={(e) => handleChange(e, NOTE)}
          />
        </div>
      </div>
    </Styles>
  );
};

export default WidgetAdvancedView;

const Styles = Styled.div`
font-weight: 500;
background: #ebebea;
border-bottom-left-radius: 15px;
label {
    margin-top: 15px;
}
.advanceWidget{
    display: flex;
    justify-content: space-around;
    margin-bottom:20px;
}
.optionTypes{
    display: flex;
    justify-content: space-around;
    font-size: 15px;
    min-width: 185px;
}
.optionTypes span{
    flex: 1;
    text-align: center;
    border-style: solid;
    border-width: 0 1px 1px 0;
}
.widgetInput input{
    text-align: center;
    padding: 2px;
    border: none;
}
.optionTypes span:last-child{
    border-width: 0 0 1px 0;
}
span.active{
    background: #0dfdff;
}
.widgetOptionType{
    border: 1px solid #000;
    background: #fff;
}
.widgetOptionType.layout{
    border: none;
    background: #ebebea00;
    //height: 113px;
}
.widgetOptionType.layout .optionTypes{
    border-style: solid;
    border-width: 1px 1px 0 1px;
    background: #fff;
}
textarea {
    resize: none;
    border: none;
    width: 100%;
 }
 .widgetNote{
    padding: 3px 10px 10px;
    position: relative;
    padding: 25px 5% 25px 4%;
    width: 97%;
    margin-left: 2.1%;
 }
 .widgetNote label{
    position: absolute;
    left: 28px;
   // bottom: 64px;
    background: #fff;
    padding: 0 0 0 4px;
    top: -3px;
 }
 .widgetNote textarea{
    border: 1px solid #000;
    padding: 8px;
 }
 .rangeContainer{
    position: relative;
    top: 10px;
 }
.sizeLabel{
 }
 .indentLabel{
 }
.sizeDiv{
    display: flex;
    align-items: center;
    span{
        font-weight: 700;
    }
 }
 .indentDiv{
    display: flex;
    align-items: center;
    span{
        font-weight: 700;
    }
 }
 .constA{
    

 }
 input[type="range"] {
    -webkit-appearance: none;
    height: 4px;
    background: #000;
    outline: none;
    opacity: 0.7;
    width: 75%;
    margin: 5px;
    transition: opacity .2s;
  }
  
  input[type="range"]:hover {
    opacity: 1;
  }
  
  input[type="range"]::-webkit-slider-thumb {
    appearance: none;
    width: 8px;
    height: 8px;
    background: #fff;
    border: 1px solid #000;
    border-radius: 50%;
    cursor: pointer;
  }
  .advance-widget-container {
    background: #d6d6d6;
    border-bottom-left-radius: 15px;
  }
  .widgetInput:focus, input[type="text"]:focus, textarea  {
    outline-width: 0;
}
.rangeFontSize{
    height: 25px;
    width: 15px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.dark_bg {
   background:${(props) =>
     props.styles.ContentHighlight_Colour?.background} !important;
  }
`;
