import React from 'react';
import { useSelector } from 'react-redux';
import {
  CALCULATION_WIDGET,
  TEXT_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  TIME_INPUT_WIDGET,
  WARNING_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DATE_WIDGET,
  DROPDOWNLIST_WIDGET,
  NUMBER_WIDGET,
  NARRATIVE_WIDGET,
} from './Constants';

const WidgetTypeIcon = ({ widgetType }) => {
  const styles = useSelector((state) => state.ui.styles);

  const getWidgetTypeIcon = () => {
    
    switch (widgetType) {
      case CALCULATION_WIDGET:
        return (
          <img
            src={styles.icons.calculation_widget}
            draggable="false"
            alt=".."
          />
        );
      case TEXT_INPUT_WIDGET:
        return (
          <img src={styles.icons.text_widget} draggable="false" alt=".." />
        );
      case BINARY_INPUT_WIDGET:
        return (
          <img
            src={styles.icons.binary_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case TIME_INPUT_WIDGET:
        return (
          <img src={styles.icons.time_widget} draggable="false" alt=".." />
        );
      case WARNING_INPUT_WIDGET:
        return (
          <img src={styles.icons.warning_widget} draggable="false" alt=".." />
        );
      case SINGLE_CHOICE_WIDGET:
        return (
          <img
            src={styles.icons.single_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case MULTI_CHOICE_WIDGET:
        return (
          <img
            src={styles.icons.multi_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case DATE_WIDGET:
        return (
          <img src={styles.icons.date_widget} draggable="false" alt=".." />
        );
      case DROPDOWNLIST_WIDGET:
        return (
          <img
            src={styles.icons.dropdownlist_widget}
            draggable="false"
            alt=".."
          />
        );
      case NUMBER_WIDGET:
        return (
          <img src={styles.icons.number_widget} draggable="false" alt=".." />
        );
      case NARRATIVE_WIDGET:
        return (
          <img
            src={styles.icons.narrative_widget}
            draggable="false"
            alt=".."
          />
        );
      default:
        return false;
    }
  };

  return getWidgetTypeIcon();
};

export default WidgetTypeIcon;
