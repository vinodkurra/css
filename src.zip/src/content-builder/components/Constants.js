export const CONSULTATION_VIEW = "Consultation";
export const EDIT_VIEW = "Edit";
export const LABEL_VIEW = "Label";
export const DETAILED_VIEW = "Detailed";

export const COMPRESSED_VIEW = "COMPRESSED_VIEW";
export const STANDARD_VIEW = "STANDARD_VIEW";
export const ADVANCED_VIEW = "ADVANCED_VIEW";

export const BOOKMARK = "BOOKMARK";
export const EXPORT = "EXPORT";
export const REQUIRED = "REQUIRED";
export const HIDE = "HIDE";

export const SHOW_DEFAULT_ANSWER = "SHOW_DEFAULT_ANSWER";
export const ANSWER_REQUIRED = "ANSWERREQUIRED";
export const USE_DEFAULT_ANSWER = "USE_DEFAULT_ANSWER";
export const FORMAT_VALIDATION = "FORMAT_VALIDATION";
export const HINT_TEXT = "HINT_TEXT";
export const LAYOUT = "LAYOUT";
export const FONT_SIZE = "FONT_SIZE";
export const INDENT = "INDENT";
export const NOTE = "NOTE";

export const TEXT_INPUT_WIDGET = "text";
export const BINARY_INPUT_WIDGET = "binary";
export const TIME_INPUT_WIDGET = "time";
export const WARNING_INPUT_WIDGET = "warning";
export const SINGLE_CHOICE_WIDGET = "single_choice";
export const MULTI_CHOICE_WIDGET = "multiple_choice";
export const DATE_WIDGET = "date";
export const DROPDOWNLIST_WIDGET = "drop_down";
export const NUMBER_WIDGET = "number";
export const NARRATIVE_WIDGET = "narrative";
export const CALCULATION_WIDGET = "calculation";
export const BRANCH_CONTROL_WIDGET = "branch";
export const BLANK_WIDGET = "blank";
export const SKIP_WIDGET = "skip";
export const EXECUTE_WIDGET = "execute";
export const SWITCH_WIDGET = "switch";
export const JUMP_WIDGET = "jump";
export const MULTIPLE_EXECUTION="execution_frame";

export const PROCESS = "PROCESS";
export const MODULE = "MODULE";


export const SUCCESS = 200;
export const CREATED_SUCCESS = 201;
export const FORBIDDEN = 403;
export const INTERNEL_SERVER_ERROR = 500;

export const AUTHORS_TAB = "Authors";
export const PROPERTIES_TAB = "Properties";
export const INPUT_TAB = "Input";
export const OUTPUT_TAB = "Output";

//vertical bar and widget type dropdown tooltip
export const TEXT_INPUT_WIDGET_TOOLTIP = "Text";
export const BINARY_INPUT_WIDGET_TOOLTIP = "Binary";
export const TIME_INPUT_WIDGET_TOOLTIP = "Time";
export const WARNING_INPUT_WIDGET_TOOLTIP = "Warning";
export const SINGLE_CHOICE_WIDGET_TOOLTIP = "Single Choice";
export const MULTI_CHOICE_WIDGET_TOOLTIP = "Multiple Choice";
export const DATE_WIDGET_TOOLTIP = "Date";
export const DROPDOWNLIST_WIDGET_TOOLTIP = "Drop-DownList";
export const NUMBER_WIDGET_TOOLTIP = "Number";
export const NARRATIVE_WIDGET_TOOLTIP = "Narrative";
export const CALCULATION_WIDGET_TOOLTIP = "Calculation";
export const BRANCH_CONTROL_WIDGET_TOOLTIP = "Branch";
export const EXECUTION_FRAME_TOOLTIP = "Execution frame";
