import React, { useEffect } from "react";
import Styled from "styled-components";
import ContentList from "./ContentList";
import ContentEdit from "./ContentEdit";
import VerticalBar from "./VerticalBar";
import { useSelector, useDispatch } from "react-redux";
import {
  setActiveCursorModuleId,
  setActiveCursorWidgetId,
  setActiveBranchCursorId,
  setActiveNestedBranchCursorId,
  setActiveNestedWidgetCursorId,
  setActiveExecutionFrameCursorId,
} from "../../store/content";

export default function InputTab() {
  const dispatch = useDispatch();

  const {
    contents,
    activeContentId,
    // cursorSelectedStatus,
  } = useSelector((state) => state.content);
  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);

  let activeModuleId = currentContent?.activeModuleId
    ? currentContent.activeModuleId
    : 0;
  //let selectedWidgetIds = currentContent?.selectedWidgetIds?.length > 0 ? currentContent.selectedWidgetIds : [];
  let activeModuleIds =
    currentContent?.activeModuleIds?.length > 0
      ? currentContent.activeModuleIds
      : [];
  let selectedModuleIds =
    currentContent?.selectedModuleIds?.length > 0
      ? currentContent.selectedModuleIds
      : [];
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let modules =
    currentContent?.moduleList?.length > 0 ? currentContent.moduleList : [];
  let widgets =
    currentContent?.widgetList?.length > 0 ? currentContent.widgetList : [];
  let combinedModulesandWidgets =
    currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
      ? currentContent.modulesAndOutsideWidgetsPositions
      : [];
  let cursorSelectedStatus = currentContent?.cursorSelectedStatus;
  let nestedBranchWidgetCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let nestedWidgetId =
    currentContent?.activeNestedWidgetId !== undefined
      ? currentContent.activeNestedWidgetId
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];

  function handle_up_key() {
    let combined = combinedModulesandWidgets[activeCursorModuleId];
    let aboveCursorModuleId = activeCursorModuleId;
    let aboveWidgetIndex = activeCursorWidgetId;
    let activeBranchWidgetCursorIndex = branchWidgetCursorIndex;
    let activeNestedBranchCursorId = nestedBranchWidgetCursorIndex;
    let activeExecutionFrameCursorId = executionFrameIndex;
    let aboveNestedWidget = nestedWidgetId;

    if (combined?.type === "module" && activeCursorWidgetId !== undefined) {
      if (
        modules[combined.index].widgetList.length > 0 &&
        activeModuleIds.indexOf(combined.id) > -1
      ) {
        if (activeCursorWidgetId > -1) {
          let branchWidget =
            modules[combined.index].widgetList[activeCursorWidgetId];
          if (
            branchWidget &&
            branchWidget.type === "branch" &&
            branchWidget.branchControlType !== "jump"
          ) {
            let executionFrame =
              branchWidget.widgetList[activeBranchWidgetCursorIndex];
            let nestedBranch =
              branchWidget.widgetList[activeBranchWidgetCursorIndex];
            if (
              executionFrame &&
              executionFrame[0].type === "execution_frame"
            ) {
              /**
               * cursor for inside execution frame
               */
              if (activeExecutionFrameCursorId === undefined) {
                activeExecutionFrameCursorId =
                  executionFrame[0].widgetList.length - 1;
              } else if (activeExecutionFrameCursorId === -1) {
                activeExecutionFrameCursorId = undefined;
                activeBranchWidgetCursorIndex =
                  activeBranchWidgetCursorIndex - 1;
              } else {
                activeExecutionFrameCursorId = activeExecutionFrameCursorId - 1;
              }
            } else if (
              /**
               * for cursor inside nesting branches
               */
              nestedBranch &&
              nestedBranch[0].type === "branch" &&
              nestedBranch[0].branchControlType !== "jump"
            ) {
              console.log("nestedbranch", nestedBranch[0]);
              if (activeNestedBranchCursorId === undefined) {
                activeNestedBranchCursorId =
                  nestedBranch[0].widgetList.length - 1;
              } else if (activeNestedBranchCursorId === -1) {
                activeNestedBranchCursorId = undefined;
                activeBranchWidgetCursorIndex =
                  activeBranchWidgetCursorIndex - 1;
                // aboveWidgetIndex = activeCursorWidgetId - 1;
              } else {
                activeNestedBranchCursorId = activeNestedBranchCursorId - 1;
              }
            } else {
              activeNestedBranchCursorId = undefined;
              /**
               * cursor position for module widgets
               */
              if (activeBranchWidgetCursorIndex === undefined) {
                activeBranchWidgetCursorIndex =
                  branchWidget.widgetList.length - 1;
              } else if (activeBranchWidgetCursorIndex === -1) {
                activeBranchWidgetCursorIndex = undefined;
                aboveWidgetIndex = activeCursorWidgetId - 1;
              } else {
                activeBranchWidgetCursorIndex =
                  activeBranchWidgetCursorIndex - 1;
              }
            }
          } else {
            aboveWidgetIndex = activeCursorWidgetId - 1;
            activeBranchWidgetCursorIndex = undefined;
          }
        } else {
          activeBranchWidgetCursorIndex = undefined;
          aboveWidgetIndex = undefined;
          aboveCursorModuleId = activeCursorModuleId - 1;
        }
      } else {
        activeBranchWidgetCursorIndex = undefined;
        aboveWidgetIndex = undefined;
        aboveCursorModuleId = activeCursorModuleId - 1;
      }
    } else if (activeCursorModuleId > -1) {
      let aboveCombined = combinedModulesandWidgets[activeCursorModuleId];

      if (
        aboveCombined?.type === "module" &&
        activeModuleIds.indexOf(aboveCombined.id) > -1
      ) {
        aboveWidgetIndex = modules[aboveCombined?.index].widgetList.length - 1;
        aboveCursorModuleId = activeCursorModuleId;
      } else {
        let branchWidget = widgets[aboveCombined?.index];
        if (
          branchWidget &&
          branchWidget.type === "branch" &&
          branchWidget.branchControlType !== "jump"
        ) {
          let executionFrame =
            branchWidget.widgetList[activeBranchWidgetCursorIndex];
          if (executionFrame && executionFrame[0].type === "execution_frame") {
            if (activeExecutionFrameCursorId === undefined) {
              activeExecutionFrameCursorId =
                executionFrame[0].widgetList.length - 1;
            } else if (activeExecutionFrameCursorId === -1) {
              activeExecutionFrameCursorId = undefined;
              activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex - 1;
            } else {
              activeExecutionFrameCursorId = activeExecutionFrameCursorId - 1;
            }
          } else {
            if (activeBranchWidgetCursorIndex === undefined) {
              activeBranchWidgetCursorIndex =
                branchWidget.widgetList.length - 1;
            } else if (activeBranchWidgetCursorIndex === -1) {
              activeBranchWidgetCursorIndex = undefined;
              aboveWidgetIndex = undefined;
              aboveCursorModuleId = aboveCursorModuleId - 1;
            } else {
              activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex - 1;
            }
          }
        } else {
          activeBranchWidgetCursorIndex = undefined;
          aboveWidgetIndex = undefined;
          aboveCursorModuleId = activeCursorModuleId - 1;
          nestedBranchWidgetCursorIndex = undefined;
        }
      }
    }
    dispatch(setActiveCursorModuleId(aboveCursorModuleId));
    dispatch(setActiveCursorWidgetId(aboveWidgetIndex));
    dispatch(setActiveBranchCursorId(activeBranchWidgetCursorIndex));
    dispatch(setActiveNestedBranchCursorId(activeNestedBranchCursorId));
    dispatch(setActiveNestedWidgetCursorId(aboveNestedWidget));
    dispatch(setActiveExecutionFrameCursorId(activeExecutionFrameCursorId));
  }

  function handle_down_key() {
    let combined = combinedModulesandWidgets[activeCursorModuleId];
    let downCursorModuleId = activeCursorModuleId;
    let downWidgetIndex = activeCursorWidgetId;
    let activeBranchWidgetCursorIndex = branchWidgetCursorIndex;
    let activeExecutionFrameCursorId = executionFrameIndex;
    if (combined?.type === "module" && activeCursorWidgetId !== undefined) {
      if (
        modules[combined?.index].widgetList.length > 0 &&
        activeModuleIds.indexOf(combined.id) > -1
      ) {
        let activeWidget =
          modules[combined?.index]?.widgetList[activeCursorWidgetId];
        if (
          modules[combined?.index]?.widgetList.length - 1 >
          activeCursorWidgetId
        ) {
          //downWidgetIndex = activeCursorWidgetId + 1
          if (
            activeWidget &&
            activeWidget?.type === "branch" &&
            activeBranchWidgetCursorIndex !== undefined &&
            activeWidget.branchControlType !== "jump"
          ) {
            // if(activeBranchWidgetCursorIndex === undefined){
            //     activeBranchWidgetCursorIndex =  -1;
            //     downWidgetIndex = activeCursorWidgetId + 1;
            // }else
            let executionFrame =
              activeWidget.widgetList[activeBranchWidgetCursorIndex];
            if (
              executionFrame &&
              executionFrame[0].type === "execution_frame"
            ) {
              if (activeExecutionFrameCursorId === undefined) {
                activeExecutionFrameCursorId = -1;
                activeBranchWidgetCursorIndex =
                  activeBranchWidgetCursorIndex + 1;
              } else if (
                executionFrame[0].widgetList.length - 1 ===
                activeExecutionFrameCursorId
              ) {
                alert("nestedun");
                activeExecutionFrameCursorId = undefined;
              } else {
                activeExecutionFrameCursorId = activeExecutionFrameCursorId + 1;
              }
            } else {
              if (
                activeWidget.widgetList.length - 1 ===
                activeBranchWidgetCursorIndex
              ) {
                activeBranchWidgetCursorIndex = undefined;
                downWidgetIndex = activeCursorWidgetId;
              } else {
                activeBranchWidgetCursorIndex =
                  activeBranchWidgetCursorIndex + 1;
                downWidgetIndex = activeCursorWidgetId;
              }
            }
          } else {
            let belowBranch =
              modules[combined?.index]?.widgetList[activeCursorWidgetId + 1];
            if (
              belowBranch &&
              belowBranch.type === "branch" &&
              belowBranch.branchControlType !== "jump"
            ) {
              // let executionFrame =
              //   activeWidget.widgetList[activeBranchWidgetCursorIndex];
              // if (
              //   executionFrame &&
              //   executionFrame[0].type === "execution_frame"
              // ) {
              //   if (
              //     executionFrame[0].widgetList.length - 1 ===
              //     activeExecutionFrameCursorId
              //   ) {
              //     activeExecutionFrameCursorId = undefined;
              //   } else {
              //     activeExecutionFrameCursorId =
              //       activeExecutionFrameCursorId + 1;
              //   }
              // } else {
              downWidgetIndex = activeCursorWidgetId + 1;
              activeBranchWidgetCursorIndex = -1;
              // }
            } else {
              downWidgetIndex = activeCursorWidgetId + 1;
              activeBranchWidgetCursorIndex = undefined;
            }
          }
        } else if (
          activeWidget?.widgetList?.length - 1 >
            activeBranchWidgetCursorIndex &&
          activeBranchWidgetCursorIndex !== undefined
        ) {
          let executionFrame =
            activeWidget.widgetList[activeBranchWidgetCursorIndex + 1];
          if (executionFrame && executionFrame[0].type === "execution_frame") {
            console.log("nested", executionFrame[0].widgetList.length - 1);
            if (executionFrameIndex === undefined) {
              activeExecutionFrameCursorId = -1;
              activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
            } else if (
              executionFrame[0].widgetList.length - 1 ===
              activeExecutionFrameCursorId
            ) {
              activeExecutionFrameCursorId = undefined;
              activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
            } else {
              activeExecutionFrameCursorId = activeExecutionFrameCursorId + 1;
            }
          } else if (
            executionFrame &&
            executionFrame[0].type === "branch" &&
            executionFrame[0].branchControlType !== "jump"
          ) {
            if (nestedBranchWidgetCursorIndex === undefined) {
              nestedBranchWidgetCursorIndex = -1;
              // activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
            } else if (
              executionFrame[0].widgetList.length - 1 ===
              nestedBranchWidgetCursorIndex
            ) {
              nestedBranchWidgetCursorIndex = undefined;
              activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
            } else {
              nestedBranchWidgetCursorIndex = nestedBranchWidgetCursorIndex + 1;
            }
          } else {
            downCursorModuleId = activeCursorModuleId;
            downWidgetIndex = activeCursorWidgetId;
            activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
          }
        } else if (activeBranchWidgetCursorIndex !== undefined) {
          downWidgetIndex = activeCursorWidgetId;
          activeBranchWidgetCursorIndex = undefined;
        } else {
          downWidgetIndex = undefined;
          activeBranchWidgetCursorIndex = undefined;
        }
      } else {
        alert("");
        downWidgetIndex = undefined;
        activeBranchWidgetCursorIndex = undefined;
      }
    } else if (combinedModulesandWidgets?.length - 1 > activeCursorModuleId) {
      let downCombined = combinedModulesandWidgets[activeCursorModuleId + 1];
      if (
        downCombined.type === "module" &&
        activeModuleIds.indexOf(downCombined.id) > -1
      ) {
        downWidgetIndex = -1;
        downCursorModuleId = activeCursorModuleId + 1;
      } else {
        let activeWidget = widgets[combined?.index];
        if (
          activeWidget &&
          activeWidget?.type === "branch" &&
          activeBranchWidgetCursorIndex !== undefined &&
          activeWidget?.branchControlType !== "jump"
        ) {
          if (
            activeBranchWidgetCursorIndex ===
            activeWidget?.widgetList?.length - 1
          ) {
            activeBranchWidgetCursorIndex = undefined;
            downWidgetIndex = undefined;
            downCursorModuleId = activeCursorModuleId;
          } else {
            activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
            downWidgetIndex = undefined;
            downCursorModuleId = activeCursorModuleId;
          }
        } else {
          let belowBranch = widgets[downCombined?.index];
          if (
            belowBranch &&
            belowBranch.type === "branch" &&
            belowBranch.branchControlType !== "jump"
          ) {
            downCursorModuleId = activeCursorModuleId + 1;
            activeBranchWidgetCursorIndex = -1;
            downWidgetIndex = undefined;
          } else {
            downCursorModuleId = activeCursorModuleId + 1;
            downWidgetIndex = undefined;
            activeBranchWidgetCursorIndex = undefined;
          }
        }
      }
    } else if (
      activeBranchWidgetCursorIndex !== undefined &&
      widgets[combined?.index]?.widgetList?.length - 1 >
        activeBranchWidgetCursorIndex
    ) {
      let executionFrame =
        widgets[combined?.index]?.widgetList[activeBranchWidgetCursorIndex];
      if (executionFrame && executionFrame[0].type === "execution_frame") {
        if (executionFrameIndex === undefined) {
          activeExecutionFrameCursorId = -1;
        } else if (
          executionFrame[0].widgetList.length - 1 ===
          activeExecutionFrameCursorId
        ) {
          activeExecutionFrameCursorId = undefined;
          activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
        } else {
          activeExecutionFrameCursorId = activeExecutionFrameCursorId + 1;
        }
      } else {
        downCursorModuleId = activeCursorModuleId;
        downWidgetIndex = undefined;
        activeBranchWidgetCursorIndex = activeBranchWidgetCursorIndex + 1;
      }
    } else if (activeBranchWidgetCursorIndex !== undefined) {
      downCursorModuleId = activeCursorModuleId;
      downWidgetIndex = activeCursorWidgetId;
      activeBranchWidgetCursorIndex = undefined;
    }

    dispatch(setActiveCursorModuleId(downCursorModuleId));
    dispatch(setActiveCursorWidgetId(downWidgetIndex));
    dispatch(setActiveBranchCursorId(activeBranchWidgetCursorIndex));
    dispatch(setActiveExecutionFrameCursorId(activeExecutionFrameCursorId));
    dispatch(setActiveNestedBranchCursorId(nestedBranchWidgetCursorIndex));
  }

  /**
   * Function for handling cursor position using UP and DOWN arrow keys from keyboard
   */
  function handling_up_down_keys(e) {
    if (e.keyCode === 38) {
      handle_up_key();
    }

    if (e.keyCode === 40) {
      handle_down_key();
    }
  }

  /**
   * adding and removing an event listner while keydown.
   */
  useEffect(() => {
    window.addEventListener("keydown", handling_up_down_keys);
    return () => {
      window.removeEventListener("keydown", handling_up_down_keys);
    };
  });

  /**
   * adding and removing an event listner while mouse roller.
   */
  useEffect(() => {
    window.addEventListener("wheel", handleCursor_MouseOver);
    return () => {
      window.removeEventListener("wheel", handleCursor_MouseOver);
    };
  });

  // Function for handling cursor position using Mouse roller//
  function handleCursor_MouseOver(e) {
    if (cursorSelectedStatus) {
      if (e.deltaY < 0) {
        handle_up_key();
      } else if (e.deltaY > 0) {
        handle_down_key();
      }
    }
  }

  return (
    <ContentStyles>
      <div className="contentContainer">
        <div className="content-box">
          <div className="main-content-list">
            <ContentList />
          </div>
          <div className="main-vertical-bar">
            <VerticalBar />
          </div>
          <div className="main-content-edit">
            <ContentEdit />
          </div>
          <div className="main-content-message"></div>
        </div>
      </div>
    </ContentStyles>
  );
}

const ContentStyles = Styled.div`
.contentContainer{
  background: #fff;
  padding: 0px 10px 0 10px;	
}
.content-box {
  background: #d9d9d9;
    display:flex;
  }
  .main-content-list {
    flex:2.8;
  }
  .main-vertical-bar {
    background-color: #f1f1f1;
  }
  .main-content-edit {
    flex:5;
    min-width: 650px;
    background: #fff !important;
  }  
  .main-content-message{
    flex:2.5;
  }
`;
