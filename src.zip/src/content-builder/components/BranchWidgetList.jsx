import React from "react";
import NestedBranchControlWidget from "./nestedBranchWidgets";
import {
  BRANCH_CONTROL_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  BINARY_INPUT_WIDGET,
  MULTIPLE_EXECUTION,
  DROPDOWNLIST_WIDGET,
} from "./Constants";
import currentContentObjects from "./GetCurrentContentObjects";
import EditPaneCursor from "./EditPaneCursor";
import { useSelector, useDispatch } from "react-redux";
import BranchWidget from "./BranchWidget";
import ExecutionFrame from "./Widgets/ExecutionFrame";
import getNewWidgetByType from "./WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import {
  setContentModifiedFlag,
  saveContentDatainBrowser,
  storeRedis,
} from "../../store/content";
export default function BranchWidgetList(props) {
  const { contents, activeContentId } = useSelector((state) => state.content);
  const dispatch = useDispatch();
  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);
  let content = currentContentObjects(contents, activeContentId);
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedWidgetCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  const binaryDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const singleDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const multipleDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const handleWidgetChange = (id, value, i, j, x, widget) => {
    console.log("change", id, value, i, j, x, widget, BRANCH_CONTROL_WIDGET);
    if (x.type === "blank") {
      if (currentContent.activeCursorWidgetId === undefined) {
        currentContent.activeModuleId = 0;
      }
      let name = getNewWidgetByType(content, value);
      console.log("widgetBranch", name);
      widget.title = name.widgetName;
      widget.widgetDefaultName = name.widgetDefaultName;
      widget.type = value;
    }

    if (value === BINARY_INPUT_WIDGET) {
      widget.defaultOptions = binaryDefault;
    } else if (value === SINGLE_CHOICE_WIDGET) {
      widget.defaultOptions = singleDefault;
    } else if (value === MULTI_CHOICE_WIDGET || value === DROPDOWNLIST_WIDGET) {
      widget.defaultOptions = multipleDefault;
    }
    if (value === BRANCH_CONTROL_WIDGET) {
      widget.widgetType = value;
      widget.type = value;
      widget.branchControlType = "skip";
      widget.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "",
              value: "",
            },
          ],
        },
      ];
      widget.widgetList = [];
    } else {
      widget.widgetType = value;
    }
    props.widgetList[i] = widget;
    dispatch(setContentModifiedFlag(true));
    dispatch(saveContentDatainBrowser());
    dispatch(storeRedis(content.currentContent, widget.title, widget.type));
  };
  console.log("branch",props.widgetList)
  return (
    <div>
      {props.widgetList !== undefined &&
      Object.values(props.widgetList).length > 0
        ? props.widgetList.map((widget, widgetIndex) => (
            <>
              <div
                className={"temp"}
                key={widgetIndex}
                style={{
                  marginTop: "10px",
                  textAlign: "left",
                }}
              >
                <>
                  {widget.type === BRANCH_CONTROL_WIDGET ? (
                    <NestedBranchControlWidget
                      class={props.class}
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={props.widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      index={widgetIndex}
                      innerWidget={true}
                      handleWidgetType={(id, value) =>
                        handleWidgetChange(
                          id,
                          value,
                          widgetIndex,
                          widgetIndex,
                          widget,
                          widget
                        )
                      }
                    />
                  ) : widget.type === MULTIPLE_EXECUTION ? (
                    <ExecutionFrame
                      class={props.class}
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={props.widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      index={widgetIndex}
                      innerWidget={true}
                    />
                  ) : (
                    <BranchWidget
                      //  class={props.class}
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={props.widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      innerWidget={true}
                      handleWidgetType={(id, value) =>
                        handleWidgetChange(
                          id,
                          value,
                          widgetIndex,
                          widgetIndex,
                          widget,
                          widget
                        )
                      }
                    />
                  )}
                </>
              </div>
              {(props.widgetIndex === activeCursorWidgetId ||
                activeCursorWidgetId === undefined) &&
                props.innerWidget === undefined &&
                nestedWidgetCursorIndex === undefined &&
                executionFrameIndex === undefined &&
                props.moduleIndex === activeCursorModuleId &&
                branchWidgetCursorIndex === widgetIndex && (
                  <EditPaneCursor type="lined" />
                )}
            </>
          ))
        : ""}
    </div>
  );
}
