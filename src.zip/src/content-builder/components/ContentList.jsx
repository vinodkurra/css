import React, { useState } from "react";
import Styled from "styled-components";

import AccordionList from "./AccordionList";
import Icons from "./Header/Icons";
import {
  CONSULTATION_VIEW,
  EDIT_VIEW,
  LABEL_VIEW,
  DETAILED_VIEW,
} from "./Constants";
import { viewConsultation, viewDetails, viewEdit, viewLabel } from "../../store/content";
import { useSelector, useDispatch, batch } from "react-redux";

function ContentList() {
  const dispatch = useDispatch();
  let styles = { icons: "undefined" };
  if (localStorage.getItem("styles") !== "undefined") {
    styles = JSON.parse(localStorage.getItem("styles"));
  }
  const [currentView, setCurrentview] = useState(EDIT_VIEW);

  const handleViewChange = (e, viewName) => {
    if (e) e.preventDefault();
    setCurrentview(viewName);
    if (viewName == "Consultation") {
      dispatch(viewConsultation());
    }
    else if (viewName == "Edit") {
      dispatch(viewDetails());
    }
    else if (viewName == "Label") {
      dispatch(viewLabel());
    }
    else if (viewName == "Detailed") {
      dispatch(viewEdit());
    }
  };

  return (
    <ListStyles>
      <div className="module-view">
        <Icons
          src={styles.icons.consultation_view}
          title="Consultation"
          // triggerFunc={(e) => handleViewChange(e, CONSULTATION_VIEW)}
          triggerFunc={(e) => handleViewChange(e, CONSULTATION_VIEW)}
          isActive={true}
          moduleView={currentView === CONSULTATION_VIEW}
        />
        <Icons
          src={styles.icons.edit_view}
          title="Detailed"
          triggerFunc={(e) => handleViewChange(e, EDIT_VIEW)}
          isActive={true}
          moduleView={currentView === EDIT_VIEW}
        />
        <Icons
          src={styles.icons.label_view}
          title="Label"
          triggerFunc={(e) => handleViewChange(e, LABEL_VIEW)}
          isActive={true}
          moduleView={currentView === LABEL_VIEW}
        />
        <Icons
          src={styles.icons.detailed_view}
          title="Edit"
          triggerFunc={(e) => handleViewChange(e, DETAILED_VIEW)}
          isActive={true}
          moduleView={currentView === DETAILED_VIEW}
        />
      </div>
      <h3>Module/Widget List</h3>
      <AccordionList />
    </ListStyles>
  );
}

export default ContentList;

const ListStyles = Styled.div`
    //background: #d9d9d9 !important;
    position: sticky;
    top: 255px;    
    h3{
        text-align:center;
        padding-top: 10px;
        padding-bottom: 12px;
    }
    .module-view {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        width: 400px;
        margin: 0 auto;
        padding-top: 10px;
        border-bottom: 1px solid #0f1662;
        padding-bottom: 12px;
    }
    .module-view span {
        padding: 10px;
    }
    .module-view span img{
        height: 64px;
        width: 64px;
    }
    // .module-view span:hover, .module-view span.active{
    //     background: #989a99;
    //   }
`;
