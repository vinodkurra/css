import React, { useState, useEffect } from "react";
import Styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";
import Icons from "./Header/Icons";
import {
  addModule,
  updateBreadCrumb,
  addWidget,
  setActiveModuleId,
  setActiveCursorModuleId,
  setActiveCursorWidgetId,
  setExpandedModuleIds,
  setAllWidgetMode,
  setActiveWidgetId,
  setCompressedViewByWidgetIds,
  setStandardViewByWidgetIds,
  setAdvancedViewByWidgetIds,
  addOutsideWidget,
  createNewModuleByContentId,
  createNewWidgetByContentModule,
  addPageBreak,
  createNewNestedBranchWidgetByWidget,
  createNewBranchWidgetByWidget,
  toggleVerticalSpinner,
  viewDetails,
} from "../../store/content";
import {
  CALCULATION_WIDGET,
  COMPRESSED_VIEW,
  NARRATIVE_WIDGET,
  STANDARD_VIEW,
  WARNING_INPUT_WIDGET,
  DATE_WIDGET,
  NUMBER_WIDGET,
  DROPDOWNLIST_WIDGET,
  TIME_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  TEXT_INPUT_WIDGET,
  BRANCH_CONTROL_WIDGET,
  MULTIPLE_EXECUTION,
} from "./Constants";
import getNewWidgetByType from "./WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import currentContentObjects from "./GetCurrentContentObjects";

/**
 * generating widget with their default name
 */
export function getDefaultWidget(type, allWidgets, getWidgetStringName) {
  let widgetName = getWidgetStringName(type);
  if (allWidgets.length > 0) {
    let widgetsBasedOnType = allWidgets.filter((widget) =>
      widget.widgetDefaultName?.includes(widgetName)
    );
    if (widgetsBasedOnType.length > 0) {
      let lastWidgetName =
        widgetsBasedOnType[widgetsBasedOnType.length - 1].widgetDefaultName;
      let lastWidgetNumber = parseInt(lastWidgetName.slice(-3)) + 1;
      let numberOfZeros =
        parseInt(lastWidgetNumber) <= 9
          ? "00"
          : parseInt(lastWidgetNumber) <= 99
            ? "0"
            : "000";
      let newWidgetName = widgetName + numberOfZeros + lastWidgetNumber;

      return {
        id: parseInt(allWidgets[allWidgets.length - 1].id) + 1,
        widgetName: newWidgetName,
        widgetDefaultName: newWidgetName,
        widgetType: type,
      };
    } else
      return {
        id: parseInt(allWidgets[allWidgets.length - 1].id) + 1,
        widgetName: `${widgetName}001`,
        widgetDefaultName: `${widgetName}001`,
        widgetType: type,
      };
  } else
    return {
      id: 1,
      widgetName: `${widgetName}001`,
      widgetDefaultName: `${widgetName}001`,
      widgetType: type,
    };
}

const VerticalBar = () => {
  const dispatch = useDispatch();
  const [isSpecialIconStatus, setIsSpecialIconStatus] = useState(false);
  const {
    contents,
    activeContentId,
    breadcrumb,
    isVerticalSpinner,
    // activeModuleId,
    // activeModuleIds,
    // selectedModuleId,
    currentViewMode,
  } = useSelector((state) => state.content);
  const viewMode = useSelector((state) => state.content.viewDetails)

  let content = currentContentObjects(contents, activeContentId);
  let currentContent = content?.currentContent;
  let activeModuleId = content?.activeModuleId;
  let selectedWidgetIds = content?.selectedWidgetIds;
  let activeModuleIds = content?.activeModuleIds;
  let selectedModuleIds = content?.selectedModuleIds;
  let activeCursorModuleId = content?.activeCursorModuleId;
  let activeCursorWidgetId = content?.activeCursorWidgetId;
  let modules = content?.moduleList;
  let widgets = content?.widgetList;
  let currentModule =
    activeModuleId &&
    currentContent?.moduleList.length > 0 &&
    currentContent?.moduleList?.filter((x) => x?.id === activeModuleId)?.[0];
  let isActive = modulesStatus() ? false : true;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedBranchCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  // let currentContent =
  //   contents.length > 0 &&
  //   contents.find((content) => content.contentId === activeContentId);

  // let activeModuleId = currentContent?.activeModuleId
  //   ? currentContent.activeModuleId
  //   : 0;
  // let selectedWidgetIds = currentContent?.selectedWidgetIds
  //   ? currentContent.selectedWidgetIds
  //   : [];
  // let activeModuleIds = currentContent?.activeModuleIds
  //   ? currentContent.activeModuleIds
  //   : [];
  // let selectedModuleIds = currentContent?.selectedModuleIds
  //   ? currentContent.selectedModuleIds
  //   : [];
  // let activeCursorModuleId =
  //   currentContent?.activeCursorModuleId !== undefined
  //     ? currentContent.activeCursorModuleId
  //     : undefined;
  // let activeCursorWidgetId =
  //   currentContent?.activeCursorWidgetId !== undefined
  //     ? currentContent.activeCursorWidgetId
  //     : undefined;
  // let modules = currentContent?.moduleList ? currentContent.moduleList : [];
  // let widgets = currentContent?.widgetList ? currentContent.widgetList : [];
  let allWidgets = [];
  if (modules?.length > 0 || widgets?.length > 0) {
    allWidgets = modules.reduce(
      (data, obj) => [...data, ...obj?.widgetList],
      []
    );
    allWidgets = [...allWidgets, ...widgets];
    allWidgets.sort((a, b) => a?.id - b?.id);
  }

  const styles = useSelector((state) => state.ui.styles);

  useEffect(() => {
    if (contents?.length > 0 && activeContentId) {
      let content = contents?.find(
        (content) => content.contentId === activeContentId
      );
      let currentModules = contents?.find(
        (content) => content.contentId === activeContentId
      )?.moduleList;
      if (currentModules?.length > 0) {
        currentModules.map((module) => {
          if (module.widgetList.length > 0) setIsSpecialIconStatus(true);
        });
      } else setIsSpecialIconStatus(false);
      if (content?.widgetList?.length > 0) setIsSpecialIconStatus(true);
    } else setIsSpecialIconStatus(false);
  }, [contents, activeContentId]);

  /**
   * Creating new module
   */
  const handleAddModule = (e) => {
    if (e) e.preventDefault();

    dispatch(toggleVerticalSpinner(true));
    dispatch(createNewModuleByContentId(activeContentId));
    dispatch(updateBreadCrumb({ ...breadcrumb, module: module.title }));
    //   const module = getDefaultModule();
    //   const newModule = {
    //     id: module.id,
    //     moduleName: module.moduleName,
    //     description: [],
    //     widgets: [],
    //     properties: {},
    //     widgetCurrentViewMode: STANDARD_VIEW,
    //   };
    //      dispatch(addModule(newModule));
    //     dispatch(setActiveModuleId(module.id));
    //     dispatch(setExpandedModuleIds(module.id));
    //     // dispatch(setActiveCursorModuleId(currentModuleIndex + 1));
    //     dispatch(setActiveCursorWidgetId(-1));

    //     dispatch(updateBreadCrumb({ ...breadcrumb, module: module.moduleName }));
  };

  /**
   * creating new widget
   */
  const handleAddWidget = (e, type) => {
    //closed module should not add widget
    dispatch(toggleVerticalSpinner(true));
    let activeModuleId = 0;
    // alert(currentContent.activeCursorWidgetId)
    if (currentContent.activeCursorWidgetId != undefined) {
      activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
        (x, index) =>
          index === currentContent?.activeCursorModuleId && x.type === "module"
      )?.id;
      content.activeModuleId = activeModuleId;
      currentContent.activeModuleId = activeModuleId;
    }
    if (currentContent.activeCursorWidgetId === undefined) {
      currentContent.activeModuleId = 0;
    }
    let widget = getNewWidgetByType(content, type);
    //  const widget = getDefaultWidget(type, allWidgets, getWidgetStringName);

    let widgetCreateData = {
      contentId: activeContentId,
      moduleId: activeModuleId,
      type: widget.widgetType,
    };
    if (type === BRANCH_CONTROL_WIDGET) {
      widgetCreateData.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "",
              value: "",
            },
          ],
        },
      ];
      widgetCreateData.widgetList = [];
      widget.branchControlType = "skip";
      widgetCreateData.branchControlType = "skip";
    }
    if (selectedModuleIds.indexOf(activeModuleId) === -1) {
      if (
        branchWidgetCursorIndex !== undefined ||
        executionFrameIndex !== undefined ||
        nestedBranchCursorIndex !== undefined
      ) {
        dispatch(
          createNewBranchWidgetByWidget(
            widgetCreateData,
            widget,
            activeCursorWidgetId,
            content
          )
        );
      } else {
        dispatch(
          createNewWidgetByContentModule(
            widgetCreateData,
            widget,
            activeCursorWidgetId,
            content
          )
        );
      }
    } else {
      alert("Could not add widgets inside the selected module");
    }
  };

  /**
   * generating widget with their default name
   */

  function getWidgetStringName(type) {
    switch (type) {
      case BINARY_INPUT_WIDGET:
        return "INP";
      case SINGLE_CHOICE_WIDGET:
        return "INP";
      case MULTI_CHOICE_WIDGET:
        return "INP";
      case DROPDOWNLIST_WIDGET:
        return "INP";
      case NUMBER_WIDGET:
        return "INP";
      case TEXT_INPUT_WIDGET:
        return "INP";
      case DATE_WIDGET:
        return "INP";
      case CALCULATION_WIDGET:
        return "CALC";
      case NARRATIVE_WIDGET:
        return "NARA";
      case TIME_INPUT_WIDGET:
        return "INP";
      case WARNING_INPUT_WIDGET:
        return "WARN";
      case BRANCH_CONTROL_WIDGET:
        return "bra";
      default:
        return "";
    }
  }

  /**
   * generating module with their default name
   */
  function getDefaultModule() {
    let lastModuleName = "";
    let lastModuleNumber = 1;
    if (modules.length > 0) {
      let sortedModules = JSON.parse(JSON.stringify(modules));
      sortedModules.sort((a, b) => a.id - b.id);
      let lastModuleIndex = Object.values(sortedModules).length - 1;
      lastModuleName = sortedModules[lastModuleIndex].title;
      lastModuleNumber = parseInt(
        lastModuleName.replace(/Module/g, "").replace(/\b0+/g, "")
      );
      lastModuleNumber++;
    }

    let numberOfZeros =
      parseInt(lastModuleNumber) <= 9
        ? "00"
        : parseInt(lastModuleNumber) <= 99
          ? "0"
          : "000";

    let newModuleName = "Module" + numberOfZeros + lastModuleNumber;

    return { id: lastModuleNumber, moduleName: newModuleName };
  }

  const handleSpecialViewModeChange = (e) => {
    if (e) e.preventDefault();
    // dispatch(toggleVerticalSpinner(true));
    const viewMode =
      currentViewMode === STANDARD_VIEW ? COMPRESSED_VIEW : STANDARD_VIEW;
    batch(() => {
      dispatch(setAllWidgetMode(viewMode));
    });
  };

  /**
   * This function will handle Adding page break in content pane
   */
  const handleAddPageBreak = (e) => {
    dispatch(toggleVerticalSpinner(true));
    dispatch(addPageBreak(activeCursorModuleId, activeCursorWidgetId));
  };

  function modulesStatus() {
    var result = false;
    selectedModuleIds.forEach((value) => {
      let data = modules.filter((x) => x.id == value);
      if (data?.length > 0) {
        if (data[0].readOnly) {
          result = true;
          return false;
        }
      }
    });
    return result;
  }

  return (
    <VerticalBarStyles>
      {isVerticalSpinner && (
        <div className="spinner">
          <i className="fa fa-spinner" aria-hidden="true"></i>
        </div>
      )}
      <div className="vertical-bar" style={{ pointerEvents: viewMode ? null : "none", opacity: viewMode ? null : 0.5 }}>
        <Icons
          src={styles.icons.spcial_icon_vertical_bar}
          title="Special Icon"
          triggerFunc={handleSpecialViewModeChange}
          isActive={isSpecialIconStatus}
        />
        <Icons
          src={styles.icons.add_module}
          title="Add Module"
          triggerFunc={handleAddModule}
          isActive={activeContentId}
        />
        <Icons
          src={styles.icons.text_widget}
          title="Text"
          triggerFunc={(e) => handleAddWidget(e, TEXT_INPUT_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.binary_choice_widget}
          title="Binary"
          triggerFunc={(e) => handleAddWidget(e, BINARY_INPUT_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.multi_choice_widget}
          title="Multiple Choice"
          triggerFunc={(e) => handleAddWidget(e, MULTI_CHOICE_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.single_choice_widget}
          title="Single Choice"
          triggerFunc={(e) => handleAddWidget(e, SINGLE_CHOICE_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.date_widget}
          title="Date"
          triggerFunc={(e) => handleAddWidget(e, DATE_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.number_widget}
          title="Number"
          triggerFunc={(e) => handleAddWidget(e, NUMBER_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.dropdownlist_widget}
          title="Drop-DownList"
          triggerFunc={(e) => handleAddWidget(e, DROPDOWNLIST_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.time_widget}
          title="Time"
          triggerFunc={(e) => handleAddWidget(e, TIME_INPUT_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.warning_widget}
          title="Warning"
          triggerFunc={(e) => handleAddWidget(e, WARNING_INPUT_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.calculation_widget}
          title="Calculation"
          triggerFunc={(e) => handleAddWidget(e, CALCULATION_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.narrative_widget}
          title="Narrative"
          triggerFunc={(e) => handleAddWidget(e, NARRATIVE_WIDGET)}
          isActive={isActive}
        />
        <Icons
          src={styles.icons.page_breaker}
          title="Page Breaker"
          triggerFunc={(e) => handleAddPageBreak(e)}
          isActive={
            isActive &&
            currentContent.nestedBranchWidgetCursorIndex === undefined &&
            currentContent.executionFrameCursorId === undefined
          }
        />
        <Icons
          src={styles.icons.branch_widget}
          title="Branch"
          triggerFunc={(e) => handleAddWidget(e, BRANCH_CONTROL_WIDGET)}
          isActive={
            isActive &&
            currentContent.nestedBranchWidgetCursorIndex === undefined &&
            currentContent.executionFrameCursorId === undefined
          }
        />
        <Icons
          src={styles.icons.multiple_execution}
          title="Mutiple Execution"
          triggerFunc={(e) => handleAddWidget(e, MULTIPLE_EXECUTION)}
          isActive={
            isActive &&
            currentContent.nestedBranchWidgetCursorIndex === undefined &&
            currentContent.branchWidgetCursorIndex !== undefined &&
            currentContent.executionFrameCursorId === undefined
          }
        />
      </div>
    </VerticalBarStyles>
  );
};

export default VerticalBar;

const VerticalBarStyles = Styled.div`
//without scrolling 
    position: sticky;
    top: 243px;
    // height: calc(100vh - 243px);
    overflow-y: auto;
    .spinner {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      min-height: 100%;
      right: 0;
      bottom: 0;
      background: #ffffff63;
      z-index: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      i {
        font-size: 200%;        
        color: #2479f2;
        -webkit-animation: spin 2s linear infinite; /* Safari */
        animation: spin 2s linear infinite;
        
       
      }
      
    }
    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .vertical-bar {
        width:90px;
        overflow:hidden;
        display:flex;
        flex-direction:column;
        text-align: center;
    }
    img {
        width:50px;
        height:50px;
    }
    .vertical-bar span {
        padding:5px;
    }
    ::-webkit-scrollbar {
      width: 0;
    }
`;
