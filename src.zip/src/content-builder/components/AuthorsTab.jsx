import React, { useState, useEffect, Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import styled from "styled-components";
import AWS from "aws-sdk";
import TextField from "hypaiq-rc/lib/TextField";
import SelectField from "hypaiq-rc/lib/SelectField";
import { apiUrlWithToken } from "../../calls/apis";
import PopupComponent from "./PopupCompontnet";
import UserSearchPopup from '../../features/dashboard/components/TopLineContents/UserSearchPopup';
import { updateAuthor } from '../../store/content';

function AuthorsTab(props) {
    const { contents, activeContentId } = useSelector(state => state.content);
    //const styles = useSelector((state) => state.ui.styles)
    const [contentOwner, setContentOwner] = useState({});
    const [authors, setAuthors] = useState([]);
    const [isPopup, setIsPopup] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [authorId, setAuthorId] = useState(null);
    const dispatch = useDispatch();

    const [isLoading, setIsLoading] = useState(true);
    const [user, setUser] = useState({});
    const [newRole, setNewRole] = useState();
    const [newUser, setNewUser] = useState({});

    let sty = localStorage.getItem("styles");
    let styles = JSON.parse(sty);
    let icons = JSON.parse(sty);
    icons = icons.icons;

    let params = new URLSearchParams(window.location.search);
    let token;
    if (localStorage.getItem("token") !== "undefined") {
        token = localStorage.getItem("token");
    } else {
        token = params.has("token") ? params.get("token") : "";
        localStorage.setItem("token", token);
    }

    let currentContent = contents.length > 0 ? contents.find((content) => content.contentId === activeContentId) : '';
    let authorDetails = currentContent?.authors;
    let groupId = localStorage.getItem("groupId");
    let checksumId = JSON.parse(localStorage.getItem("account")).userid;
    let author = currentContent?.authors?.filter(x => x.contentRole === "ContentOwner" && checksumId === x.checkSumId);
    let access = false;
    if (author?.length > 0) {
        access = true;
    }

    useEffect(() => {
        let contentOwnerData = authorDetails?.filter(x => x.contentRole === "ContentOwner");
        if (contentOwnerData?.length > 0)
            setContentOwner(contentOwnerData[0]);
        setAuthors(authorDetails);
    }, [authorDetails]);

    function setSelectedUser(event) {
        setAuthorId(null);
        if (authorId) {
            if (authors?.length > 0) {
                authors.map((author) => {
                    if (author.authorId === authorId) {
                        author.checkSumId = event.userId;
                        author.userName = event.name;
                    }
                });
                dispatch(updateAuthor(authors));
            }
        }
        else {
            let author = {
                authorId: null,
                authorStatus: false,
                checkSumId: event.userId,
                contentRole: "Contributor",
                commentPermissions: { read: true, write: false },
                contentId: currentContent.contentId,
                contentPermissions: { read: true, write: false },
                propertiesPermissions: { read: true, write: false },
                userName: event.name
            };
            authors.push(author);
            dispatch(updateAuthor(authors));
        }
    }

    function setSelectedUser1(event) {
        let author = {
            authorId: null,
            authorStatus: false,
            checkSumId: event.userId,
            contentRole: "Contributor",
            commentPermissions: { read: true, write: false },
            contentId: currentContent.contentId,
            contentPermissions: { read: true, write: false },
            propertiesPermissions: { read: true, write: false },
            userName: event.name
        };
        authors.push(author);
        dispatch(updateAuthor(authors));
    }

    function permission(access, checkSumId, object) {
        let data = JSON.parse(JSON.stringify(authors));
        if (data?.length > 0) {
            data.map((author) => {
                if (author.checkSumId === checkSumId) {
                    author[object].write = !access;
                }
            });
        }
        setAuthors(data);
        dispatch(updateAuthor(data));
    }

    function authorStatus(access, checkSumId) {
        let data = JSON.parse(JSON.stringify(authors));
        if (data?.length > 0) {
            data.map((author) => {
                if (author.checkSumId === checkSumId) {
                    author.authorStatus = !access;
                }
            });
        }
        setAuthors(data);
        dispatch(updateAuthor(data));
    }

    const getUser = (e) => {
        var code = e.keyCode || e.which;
        if (code === 13) {
            setIsLoading(true);
            let id = e.target.value;
            let req = {
                userid: id,
            };
            apiUrlWithToken
                .post("/groupuser/find", req)
                .then((res) => {
                    console.log("log", res.data);
                    let data = res.data;
                    let user = {
                        id: data.userid,
                        name: data.title + data.firstname + data.lastname,
                    };
                    setNewUser(user);
                })
                .catch((err) => {
                    //setUserNotFoundVisible(true);
                    setNewUser({});
                });
        }
        setIsLoading(false);
    };

    const rowClick = (authorId) => {
        setIsEdit(true);
        setAuthorId(authorId);
    }

    const viewPopup = (index) => {
        setIsPopup(true);
    }

    return (
        <>
            <AuthorsStyle icons={icons} styles={props.styles}>
                {authors ? (
                    <>
                        {!authors ? (
                            <></>
                        ) : (
                                <div className="permission_table">
                                    <div className="permission_table_header">
                                        <div className="tr">
                                            <div
                                                className="th"
                                                style={{ width: "100px", minWidth: "100px !important" }}
                                            >
                                                USER_ID
                                                <p>{contentOwner?.checkSumId}</p>
                                            </div>
                                            <div className="th" style={{ width: "200px" }}>
                                                USER
                                                <p>{contentOwner?.userName} </p>
                                            </div>
                                            <div className="th" style={{ width: "165px" }}>
                                                ROLE
                                                <p> {contentOwner?.contentRole}</p>
                                            </div>
                                            <div className="td">
                                                <span>Content</span>
                                            </div>
                                            <div className="td">
                                                <span>Comment</span>
                                            </div>
                                            <div className="td">
                                                <span>Properties</span>
                                            </div>
                                            <div className="td">
                                                <span>Author</span>
                                            </div>
                                        </div>
                                    </div>
                                    {groupId && access ?
                                        <>
                                            <div className="permission_table_body">
                                                {authors?.length > 0 && access &&
                                                    authors.filter(x => x.contentRole != "ContentOwner").map((author, idx) => (
                                                        <div
                                                            className="tr"
                                                            key={idx + ""}
                                                            onClick={() => rowClick(author.authorId)}
                                                        >
                                                            <div
                                                                className="td"
                                                                style={{ width: "100px", minWidth: "100px" }}
                                                            >
                                                                <div
                                                                    className="td inpt_width"
                                                                    style={{
                                                                        width: "165px",
                                                                        textAlign: "left",
                                                                        paddingLeft: "10px",
                                                                    }}
                                                                >
                                                                    {author.checkSumId}
                                                                </div>
                                                            </div>
                                                            <div
                                                                className="td inpt_width"
                                                                style={{ width: "200px", paddingLeft: "20px" }}
                                                            >
                                                                {isEdit && authorId === author.authorId ? (
                                                                    <div className="input-div">
                                                                        <input
                                                                            value={author.userName ? author.userName : ""}
                                                                            placeholder="Update User"
                                                                        />
                                                                        <img
                                                                            src={icons.input_field_stretch}
                                                                            className="input-icon"
                                                                            alt="..."
                                                                            onClick={() =>
                                                                                viewPopup(idx)
                                                                            }
                                                                        />
                                                                    </div>
                                                                )
                                                                    : (
                                                                        <div
                                                                            className="td inpt_width"
                                                                            style={{
                                                                                width: "165px",
                                                                                textAlign: "left",
                                                                                paddingLeft: "10px",
                                                                            }}
                                                                        >
                                                                            {author.userName}
                                                                        </div>
                                                                    )}
                                                            </div>
                                                            <div
                                                                className="td inpt_width"
                                                                style={{ width: "200px", paddingLeft: "20px" }}
                                                            >
                                                                <div
                                                                    className="td inpt_width"
                                                                    style={{
                                                                        width: "165px",
                                                                        textAlign: "left",
                                                                        paddingLeft: "10px",
                                                                    }}
                                                                >
                                                                    {author.contentRole}
                                                                </div>
                                                            </div>
                                                            <div className="td">
                                                                <span
                                                                    onClick={() => permission(author.contentPermissions.write, author.checkSumId, 'contentPermissions')}
                                                                    className={`permission_icon ${author.contentPermissions.write ? 'write' : 'read'}`}
                                                                    title={`Click for ${author.contentPermissions.write ? 'read' : 'write'} permission`}
                                                                ></span>
                                                            </div>
                                                            <div className="td">
                                                                <span
                                                                    onClick={() => permission(author.commentPermissions.write, author.checkSumId, 'commentPermissions')}
                                                                    className={`permission_icon ${author.commentPermissions.write ? 'write' : 'read'}`}
                                                                    title={`Click for ${author.commentPermissions.write ? 'read' : 'write'} permission`}
                                                                ></span>
                                                            </div>
                                                            <div className="td">
                                                                <span
                                                                    onClick={() => permission(author.propertiesPermissions.write, author.checkSumId, 'propertiesPermissions')}
                                                                    className={`permission_icon ${author.propertiesPermissions.write ? 'write' : 'read'}`}
                                                                    title={`Click for ${author.propertiesPermissions.write ? 'read' : 'write'} permission`}
                                                                ></span>
                                                            </div>
                                                            <div className="td">
                                                                <span
                                                                    onClick={() => authorStatus(author.authorStatus, author.checkSumId)}
                                                                    className={`permission_icon ${author.authorStatus ? 'write' : ''}`}
                                                                    title={`Click for ${author.authorStatus ? 'read' : 'write'} permission`}
                                                                ></span>
                                                            </div>
                                                        </div>
                                                    ))}
                                            </div>

                                            <div className="permission_table_body">
                                                <div className="tr">
                                                    <div
                                                        className="td"
                                                        style={{ width: "100px", minWidth: "100px" }}
                                                    >
                                                        <input
                                                            type="text"
                                                            defaultValue=""
                                                            placeholder="ID_"
                                                            value={newUser.id ? newUser.id : ""}
                                                            onKeyPress={(e) => getUser(e)}
                                                            onChange={(e) => setNewUser({ id: e.target.value })}
                                                        />
                                                    </div>
                                                    <div
                                                        className="td"
                                                        style={{
                                                            width: "200px",
                                                            minWidth: "100px",
                                                            paddingLeft: "20px",
                                                        }}
                                                    >
                                                        <div
                                                            className="input-div"
                                                        >
                                                            <input
                                                                value={newUser.name ? newUser.name : ""}
                                                                placeholder="Add User"
                                                            />
                                                            <img
                                                                src={icons.input_field_stretch}
                                                                className="input-icon"
                                                                alt="..."
                                                                onClick={() => setIsPopup(true)}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div
                                                        className="td inpt_width"
                                                        style={{ paddingLeft: "10px", width: "165px" }}
                                                    >
                                                    </div>
                                                </div>
                                            </div>

                                            <PopupComponent
                                                width="70%"
                                                height="89%"
                                                minWidth="1082px"
                                                visible={isPopup}
                                                styles={styles}
                                                header="User Search"
                                                children={
                                                    <UserSearchPopup
                                                        styles={styles}
                                                        userid={JSON.parse(localStorage.getItem('account')) ? JSON.parse(localStorage.getItem('account')).userid : ''}
                                                        select={(e) => {
                                                            setSelectedUser(e)
                                                            setIsPopup(false)
                                                        }}
                                                    />
                                                }
                                                close={() => setIsPopup(false)}
                                            />
                                        </>
                                        :
                                        <>
                                            { access ?
                                                <>
                                                    <h3
                                                        style={{
                                                            color: "#ccc",
                                                            paddingTop: "5%",
                                                            textAlign: "center",
                                                        }}
                                                    >
                                                        Please switch or create a group
                                                    </h3>
                                                </>
                                                :
                                                <>
                                                    <h3
                                                        style={{
                                                            color: "#ccc",
                                                            paddingTop: "5%",
                                                            textAlign: "center",
                                                        }}
                                                    >
                                                        Only the Content Owner can view or change the collaboration group
                                                    </h3>
                                                </>
                                            }

                                        </>}
                                </div>
                            )}
                    </>
                ) : (
                        <div>
                            <h3
                                style={{
                                    color: "#ccc",
                                    paddingTop: "20%",
                                    textAlign: "center",
                                }}
                            >
                                Loading Permissions
            </h3>
                        </div>
                    )}
            </AuthorsStyle>
        </>
    );
}

export default AuthorsTab;

const AuthorsStyle = styled.div`
    width: 100%;
    margin: auto;
    background: #fff;
    height: calc(100vh - 260px);
    overflow-x: auto;
  input {
    border-radius: 5px;
    outline: 0;
    border: 1px solid #999;
    padding: 5px;
    background: transparent;
    width: 100%;
  }
  .input-div {
    border: 1px solid #999;
    display: flex;
    flex-direction: row;
    background: transparent;
    border-radius: 5px;
    input {
      border-radius: 5px;
      border-width: 0px;
      outline: 0;
      box-shadow: 0px 0px 0px #999 !important;
      padding: 5px;
      background: transparent;
      width: 100%;
    }
  }
  .input-icon {
    padding: 5px;
    width: 30px;
    cursor: pointer;
  }

  .inpt_width {
    min-width: 150px !important;
  }
  .add_role_button {
    display: block;
    background: transparent;
    width: 100%;
    border: 1px solid #999;
    border-radius: 5px;
    padding: 5px;
    margin: 3px 0;
    outline: 0;
  }
  .permission_table {
    margin: 0 auto;
    padding-top: 52px;
    width: 1118px;
  }
  .permission_table_header {
    .tr {
      width: 100%;
      border-bottom: 2px solid #ccc;
      .th {
        position: relative;
        display: inline-block;
        font-weight: bold;
        padding: 0 0 0 20px;
      }
      .td {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 30px;
        top: 48px;
        left: 32px;
        input {
          width: 150px;
        }

        :first-child {
          min-width: 250px;
          &:before {
            display: none;
          }
          span:after {
            display: none;
          }
        }
        &:before {
          content: "";
          position: absolute;
          display: block;
          height: 16px;
          width: 1px;
          background: #ccc;
          top: -15px;
          left: 50%;
          right: 50%;
        }
        span {
          position: absolute;
          white-space: nowrap;
          top: -92px;
          left: -78%;
          min-width: 150px;
          transform: translateY(-50%) rotate(-70deg);
          :after {
            position: absolute;
            content: "";
            width: 40px;
            display: block;
            top: -60px;
            left: 0;
            transform: rotate(-70deg);
            white-space: nowrap;
          }
        }
      }
    }
  }

  .permission_table_body {
    margin-top: 10px;
    padding-right: 5%;
    max-height: 150px;
    overflow-y: auto;
   
    
    ::-webkit-scrollbar-thumb:hover {
      background: #4395a6;
    }
    .tr {
      padding: 2px 0;
      :nth-of-type(2n + 1) {
        background: #eee;
      }
      :last-child {
        .permission_icon {
          padding: 2px 0;
        }
      }
      .td {
        position: relative;
        display: inline-block;
        width: 40px;
        text-align: center;
        :first-child {
          min-width: 150px;
          font-size: 16px;
          text-align: left;
          text-transform: capitalize;
          padding: 0 0 0 20px;
          min-width: 250px;
          position: relative;
          .selectable {
            position: absolute;
            left: 0;
            content: "";
            width: 0;
            height: 0;
            bottom: 0;
            border-bottom: 15px solid #ddd;
            border-right: 15px solid transparent;
            cursor: pointer;
            &.active {
              border-bottom-color: #4395a6;
            }
          }
        }
        .permission_icon {
          cursor: pointer;
        }
      }
    }
  }

  .permission_icon {
    display: inline-block;
    border: 1px solid #ccc;
    width: 25px;
    height: 25px;
    border-radius: 20px;

    &.write {
        background: ${(props) => `url(${props.icons.permission_write})`};
        background-size: cover;
      }
      &.read {
        background: ${(props) => `url(${props.icons.permission_read})`};
        background-size: cover;
      }

  }
  .popup {
    //height: 89% !important;
  }
  .search-box svg {
    font-size: 15px !important;
  }
  .validation{
    color: red;
    text-align: right;
  }
  .search-panel{
    text-align: left;
  } 
`;