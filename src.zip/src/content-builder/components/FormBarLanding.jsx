import React, { useState, Fragment } from "react";
import Styled from "styled-components";
import InputTab from "./InputTab";
import PropertiesTab from "./PropertiesTab";
import OutputTab from "./OutputTab";
import AuthorsTab from "./AuthorsTab";
import {
  AUTHORS_TAB,
  OUTPUT_TAB,
  INPUT_TAB,
  PROPERTIES_TAB
} from './Constants';

export default function FormBarLanding({ activeMenu }) {
  const renderSwitch = () => {
    switch (activeMenu) {
      case AUTHORS_TAB:
        return <AuthorsTab />;
      case INPUT_TAB:
        return <InputTab />;
      case PROPERTIES_TAB:
        return <PropertiesTab />;
      case OUTPUT_TAB:
        return <OutputTab />;
      default:
        return <InputTab />;
    }
  };

  return <div className="">{renderSwitch()}</div>;
}

const ModuleBarStyles = Styled.div`
`;
