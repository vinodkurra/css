import React, { createRef, useState, useEffect, useRef } from "react";
import Styled from "styled-components";
import { useSelector, useDispatch } from "react-redux";
import Icons from "./Header/Icons";
import {
  TEXT_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  TIME_INPUT_WIDGET,
  WARNING_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DATE_WIDGET,
  DROPDOWNLIST_WIDGET,
  NUMBER_WIDGET,
  NARRATIVE_WIDGET,
  CALCULATION_WIDGET,
  BRANCH_CONTROL_WIDGET,
  OUTPUT_TAB,
} from "./Constants";
import {
  setGlobalLogoSelectedWidgets,
  saveOutputEditorValues,
  setContentModifiedFlag,
  setOutputContentModifiedFlag,
  setOutputCursorPosition,
  toggleVerticalSpinner,
  updateModulesAndWidgetPosition,
} from "../../store/content";
import {
  setCursorPosition,
  restoreSelection,
  saveSelection,
} from "./CaretPositioning";
import currentContentObjects from "./GetCurrentContentObjects";
import getNewWidgetByType from "./WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import {
  createNewWidgetByContentModule,
  createNewBranchWidgetByWidget,
  setRecentAddedWidget,
  createNewContentOutput,
} from "../../store/content";
import ContentEditable from "react-contenteditable";

export default function OutputTab() {
  const styles = useSelector((state) => state.ui.styles);
  const dispatch = useDispatch();
  const [widgetTitle, setWidgetTitle] = useState("");

  const {
    contents,
    activeContentId,
    recentAddedWidget,
    activeCommonFormBarTab,
    isVerticalSpinner,
  } = useSelector((state) => state.content);
  const outputEditorRef = useRef("");
  const outputRef = useRef(null);

  let content = currentContentObjects(contents, activeContentId);
  let currentContent = content?.currentContent;
  let activeCursorWidgetId = content?.activeCursorWidgetId;
  let globalLogoSelectedWidgets = content?.globalLogoSelectedWidgets;
  let outputCursorPosition = content?.outputCursorPosition;
  let selectedModuleIds = content?.selectedModuleIds;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedBranchCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  let combinedModulesandWidgets =
    currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
      ? currentContent.modulesAndOutsideWidgetsPositions
      : [];
  let modulesWidgetsPositions =
    currentContent?.modulesWidgetsPositions?.length > 0
      ? currentContent.modulesWidgetsPositions
      : [];
  // let currentOutputEditor = content?.currentOutputEditor;
  // let activeOutputId = "";
  // if (currentContent?.outputs?.length > 0 && !currentContent.activeOutputId) {
  //     activeOutputId = currentContent?.outputs[0].outputId;
  // }
  let outputData = currentContent?.outputs?.filter(
    (x) => x.outputId === currentContent.activeOutputId
  )[0];

  let currentOutputEditor = outputData?.outputData || "";

  let checksumId = JSON.parse(localStorage.getItem("account")).userid;
  let author = currentContent?.authors?.filter(
    (x) => x.checkSumId === checksumId
  );
  let access = true;
  if (author?.length > 0 && !author[0].contentPermissions.write) {
    access = false;
  }
  const [saveCursor, setSaveCursor] = useState(outputCursorPosition);

  useEffect(() => {
    outputEditorRef.current = currentOutputEditor;
    if (saveCursor !== undefined)
      restoreSelection(document.getElementById("editable"), saveCursor);
  }, [currentContent.activeOutputId]);

  useEffect(() => {
    if (globalLogoSelectedWidgets?.length > 0) {
      let selectedWidgets = globalLogoSelectedWidgets[0];
      dispatch(setGlobalLogoSelectedWidgets([]));
      addWidgetAndTags(selectedWidgets, selectedWidgets.title);
      outputEditorRef.current = document.getElementById("editable").innerHTML;
    }
  }, [globalLogoSelectedWidgets]);
  useEffect(() => {
    if (activeContentId)
      dispatch(
        updateModulesAndWidgetPosition(
          activeContentId,
          combinedModulesandWidgets,
          modulesWidgetsPositions
        )
      );
  }, [combinedModulesandWidgets?.length, modulesWidgetsPositions?.length]);
  useEffect(() => {
    if (Object.values(recentAddedWidget).length > 0 && widgetTitle) {
      addWidgetAndTags(recentAddedWidget, recentAddedWidget.title, true);
      dispatch(setRecentAddedWidget());
      outputEditorRef.current = document.getElementById("editable").innerHTML;
    }
  }, [recentAddedWidget]);

  // useEffect(() => {
  //     if (!currentContent.activeOutputId)
  //         dispatch(createNewContentOutput(activeContentId));
  // }, []);

  // useEffect(() => {
  //     if (activeCommonFormBarTab === OUTPUT_TAB && !currentContent.activeOutputId) {
  //         dispatch(createNewContentOutput(activeContentId));
  //     }
  // }, [activeCommonFormBarTab === OUTPUT_TAB && !currentContent.activeOutputId]);

  const handleEditorBlur = () => {
    if (document.getElementById("editable")?.innerHTML) {
      const outputEditor = document.getElementById("editable")?.innerHTML;
      // const outputTitle = content.title + '_' + 'output';
      const payload = {
        contentId: activeContentId,
        outputContent: outputEditor,
        outputId: currentContent.activeOutputId,
        title: outputData?.title || "",
      };
      if (currentContent.isOutputContentModified)
        dispatch(saveOutputEditorValues(payload));
      dispatch(setOutputContentModifiedFlag(false));
    }
  };

  const addWidgetAndTags = (widget, widgetTitle, isDirectwidget = false) => {
    restoreSelection(document.getElementById("editable"), saveCursor);
    dispatch(setContentModifiedFlag(true));
    dispatch(setOutputContentModifiedFlag(true));
    const WidgetTypeImage = getWidgetTypeIcons(widget, isDirectwidget);
    pasteHtmlAtCaret(WidgetTypeImage, widgetTitle);
  };

  const handleChange = (evt) => {
    dispatch(setContentModifiedFlag(true));
    dispatch(setOutputContentModifiedFlag(true));
    outputEditorRef.current = evt.target.value;
    dispatch(setOutputCursorPosition(saveCursor));
  };

  function getWidgetTypeIcons(widget, isDirectwidget) {
    const widgetTypeIcon = getWidgetTypeIconUrl(widget.type);
    let style = renderBackgroundClass(widget.type);

    return `<figure id=${widget.id} 
             class=${
               widget?.bookmark === true || isDirectwidget
                 ? "with-bookmark"
                 : "without-bookmark"
             }
             contenteditable="false" style="background:${style.background}">
                <img  draggable="false"
                    src=${widgetTypeIcon.props.src}
                />
                <div class=${
                  widget?.bookmark === true || isDirectwidget
                    ? "ribbonShow"
                    : "ribbonHide"
                }></div>
              </figure>`;
  }

  function pasteHtmlAtCaret(widgetTypeIcon, widgetTitle) {
    var sel, range;
    if (window.getSelection) {
      // IE9 and non-IE

      sel = window.getSelection();
      if (sel.getRangeAt && sel.rangeCount) {
        range = sel.getRangeAt(0);
        range.deleteContents();

        // Range.createContextualFragment() would be useful here but is
        // non-standard and not supported in all browsers (IE9, for one)
        var el = document.createElement("div");
        el.innerHTML = widgetTypeIcon;
        el.firstChild.title = widgetTitle;
        var frag = document.createDocumentFragment(),
          node,
          lastNode;
        while ((node = el.firstChild)) {
          lastNode = frag.appendChild(node);
        }
        range.insertNode(frag);

        // Preserve the selection
        if (lastNode) {
          range = range.cloneRange();
          range.setStartAfter(lastNode);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
          insertSpace();
          SaveCursor();
        }
      }
    } else if (document.selection && document.selection.type != "Control") {
      // IE < 9
      document.selection.createRange().pasteHTML(widgetTypeIcon);
    }
  }

  const getWidgetTypeIconUrl = (widgetType) => {
    switch (widgetType) {
      case CALCULATION_WIDGET:
        return (
          <img
            src={styles.icons.calculation_widget}
            draggable="false"
            alt=".."
          />
        );
      case TEXT_INPUT_WIDGET:
        return (
          <img src={styles.icons.text_widget} draggable="false" alt=".." />
        );
      case BINARY_INPUT_WIDGET:
        return (
          <img
            src={styles.icons.binary_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case TIME_INPUT_WIDGET:
        return (
          <img src={styles.icons.time_widget} draggable="false" alt=".." />
        );
      case WARNING_INPUT_WIDGET:
        return (
          <img src={styles.icons.warning_widget} draggable="false" alt=".." />
        );
      case SINGLE_CHOICE_WIDGET:
        return (
          <img
            src={styles.icons.single_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case MULTI_CHOICE_WIDGET:
        return (
          <img
            src={styles.icons.multi_choice_widget}
            draggable="false"
            alt=".."
          />
        );
      case DATE_WIDGET:
        return (
          <img src={styles.icons.date_widget} draggable="false" alt=".." />
        );
      case DROPDOWNLIST_WIDGET:
        return (
          <img
            src={styles.icons.dropdownlist_widget}
            draggable="false"
            alt=".."
          />
        );
      case NUMBER_WIDGET:
        return (
          <img src={styles.icons.number_widget} draggable="false" alt=".." />
        );
      case NARRATIVE_WIDGET:
        return (
          <img src={styles.icons.narrative_widget} draggable="false" alt=".." />
        );
      case "Tag":
        return <img src={styles.icons.tag_image} draggable="false" alt=".." />;
      default:
        return false;
    }
  };

  const renderBackgroundClass = (widgetType) => {
    switch (widgetType) {
      case WARNING_INPUT_WIDGET:
        return { background: "#f1420d", width: "40px" };
      case NARRATIVE_WIDGET:
        return { background: "#ec04e5", width: "40px" };
      case CALCULATION_WIDGET:
        return { background: "#f79032", width: "40px" };
      default:
        return { background: "#2479f2", width: "40px" };
    }
  };

  const handleAddWidget = (e, type) => {
    //closed module should not add widget
    dispatch(toggleVerticalSpinner(true));
    let activeModuleId = 0;
    // alert(currentContent.activeCursorWidgetId)
    if (currentContent.activeCursorWidgetId != undefined) {
      activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
        (x, index) =>
          index === currentContent?.activeCursorModuleId && x.type === "module"
      )?.id;
      content.activeModuleId = activeModuleId;
      currentContent.activeModuleId = activeModuleId;
    }

    let widget = getNewWidgetByType(content, type);
    //  const widget = getDefaultWidget(type, allWidgets, getWidgetStringName);

    let widgetCreateData = {
      contentId: activeContentId,
      moduleId: activeModuleId,
      type: widget.widgetType,
    };
    if (type === BRANCH_CONTROL_WIDGET) {
      widgetCreateData.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "",
              value: "",
            },
          ],
        },
      ];
      widgetCreateData.widgetList = [];
      widget.branchControlType = "skip";
      widgetCreateData.branchControlType = "skip";
    }
    if (selectedModuleIds.indexOf(activeModuleId) === -1) {
      if (
        branchWidgetCursorIndex !== undefined ||
        executionFrameIndex !== undefined ||
        nestedBranchCursorIndex !== undefined
      ) {
        dispatch(
          createNewBranchWidgetByWidget(
            widgetCreateData,
            widget,
            activeCursorWidgetId,
            content
          )
        );
      } else {
        dispatch(
          createNewWidgetByContentModule(
            widgetCreateData,
            widget,
            activeCursorWidgetId,
            content,
            true
          )
        );
      }
      setWidgetTitle(widget.widgetName);
    } else {
      alert("Could not add widgets inside the selected module");
    }
  };

  const handleNewLine = (e) => {
    var evt = e || window.event;
    var keyCode = evt.charCode || evt.keyCode;
    if (keyCode == 13) {
      //document.execCommand('insertHTML', false, '<br>');
      SaveCursor(true);
      return false;
    }
    SaveCursor();
  };

  function insertSpace() {
    document.execCommand("insertHTML", false, "&nbsp;");
  }

  function SaveCursor(isNewLine = false) {
    let savedCaretPosition = saveSelection(document.getElementById("editable"));
    setSaveCursor(savedCaretPosition);
    // console.log('oldLine:', savedCaretPosition);
    // if (isNewLine) {
    //     savedCaretPosition.start = savedCaretPosition.start + 1;
    //     savedCaretPosition.end = savedCaretPosition.end + 1;
    //     console.log('newLine:', savedCaretPosition);
    // }
    //  dispatch(setOutputCursorPosition(savedCaretPosition));
    // if (isNewLine) {
    //     var ev2 = new Event('input', { bubbles: true });
    //     input.dispatchEvent(ev2);
    // }
  }

  const handleFocus = () => {
    if (outputRef.current) {
      outputRef.current.focus();
      //restoreSelection(document.getElementById("editable"), saveCursor);
    }
  };

  return (
    <OutputTabStyle>
      <div className={`outputTabContainer ${!access ? "pointerEvents" : ""}`}>
        <div className="optionIcons">
          {isVerticalSpinner && (
            <div className="spinner">
              <i className="fa fa-spinner" aria-hidden="true"></i>
            </div>
          )}
          <Icons
            src={styles.icons.text_widget}
            title="Text"
            triggerFunc={(e) => handleAddWidget(e, TEXT_INPUT_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.binary_choice_widget}
            title="Binary"
            triggerFunc={(e) => handleAddWidget(e, BINARY_INPUT_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.multi_choice_widget}
            title="Multiple Choice"
            triggerFunc={(e) => handleAddWidget(e, MULTI_CHOICE_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.single_choice_widget}
            title="Single Choice"
            triggerFunc={(e) => handleAddWidget(e, SINGLE_CHOICE_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.date_widget}
            title="Date"
            triggerFunc={(e) => handleAddWidget(e, DATE_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.number_widget}
            title="Number"
            triggerFunc={(e) => handleAddWidget(e, NUMBER_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.dropdownlist_widget}
            title="Drop-DownList"
            triggerFunc={(e) => handleAddWidget(e, DROPDOWNLIST_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.time_widget}
            title="Time"
            triggerFunc={(e) => handleAddWidget(e, TIME_INPUT_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.warning_widget}
            title="Warning"
            triggerFunc={(e) => handleAddWidget(e, WARNING_INPUT_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.calculation_widget}
            title="Calculation Widget"
            triggerFunc={(e) => handleAddWidget(e, CALCULATION_WIDGET)}
            isActive={activeContentId}
          />
          <Icons
            src={styles.icons.narrative_widget}
            title="Narrative Widget"
            triggerFunc={(e) => handleAddWidget(e, NARRATIVE_WIDGET)}
            isActive={activeContentId}
          />
        </div>
        <div className="mainSection">
          {/* <div
                        style={{ background: '', width: '' }}
                        id="editable"
                        contentEditable="true"
                        suppressContentEditableWarning="true"
                        onInput={handleChange}
                        innerHTML={editorValues}
                        onBlur={handleEditorBlur}
                        className="output-editor"
                    >
                    </div> */}
          <ContentEditable
            id="editable"
            className="output-editor"
            tagName="article"
            disabled={false}
            innerRef={outputRef}
            onBlur={handleEditorBlur}
            onChange={handleChange}
            html={outputEditorRef?.current}
            onKeyDown={SaveCursor}
            onMouseDown={SaveCursor}
            onMouseUp={SaveCursor}
            onKeyUp={SaveCursor}
            onFocus={handleFocus}
          />
        </div>
      </div>
    </OutputTabStyle>
  );
}

const OutputTabStyle = Styled.div`
background: #fff;
.yellowBg{
    background: #fffe3c;
}
.redBg{
    background: #f1411d;
}
.greenBg{
    background: #32a184;
}
.outputTabContainer{
    display: flex;

    .optionIcons{
        width: 50px;
        text-align: center;
        background: #f2f2f2;
        height: calc(100vh - 240px);
        display: flex;
        flex-direction: column;
        justify-content: center;
        .icon{}
        .seperateIcon{
            margin: 5px;
            margin-top: 20px;
            border-top: 1px solid #e2e2e2;
            padding-top: 20px;
        }
        position: relative;
    .spinner {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      min-height: 100%;
      right: 0;
      bottom: 0;
      background: #ffffff63;
      z-index: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      i {
        font-size: 200%;        
        color: #2479f2;
        -webkit-animation: spin 2s linear infinite; /* Safari */
        animation: spin 2s linear infinite;

      }
      
    }
    }
    .mainSection{
            .greyBg{
                background: #d6d6d6;
            }
            .with-bookmark{
            .ribbonIcon{
                width: 26px;
                height: 35px;
                position: absolute;
                text-align: center;
                img{
                    height: 20px;
                    width: auto;
                    padding-bottom: 2px;
                    outline: black solid 2px;
                }
            }
        }
    }
}
.output-editor{
    height: 340px;
    width: 900px;
    outline-width: 0;
    padding: 5px;
}
.background {
    background: #2479f2;
  }
  .background_warn {
    background: #ff0009;
  }
  .nara_bg {
    background: #ec04e5;
  }
  .calc_bg {
    background: #f79032;
  }
  .with-bookmark{
    position: relative;
    width: 35px;
    height: 46px;
    display: inline-block;
    margin: 5px;
    text-align: center;
    img{
        width: 25px;
        height: auto;
        outline: black solid 2px;
        margin: 4px;
    }    
  }
  .without-bookmark{
      display: inline-block;
      img{
        outline: black solid 2px;
      }
  }
  .ribbonShow{
    height: 10px;
    width: 100%;
    background: #fff;
    position: absolute;
    bottom: -1px;
    clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
  }
  .ribbonHide{
      display: none;
  }
  .pointerEvents{
    pointer-events: none;
}
`;
