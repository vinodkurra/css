import React from "react";
import NestedBranchControlWidget from "./nestedBranchWidgets";
import {
  BRANCH_CONTROL_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  BINARY_INPUT_WIDGET,
  MULTIPLE_EXECUTION,
} from "./Constants";
import currentContentObjects from "./GetCurrentContentObjects";
import EditPaneCursor from "./EditPaneCursor";
import { useSelector, useDispatch } from "react-redux";
import BranchWidget from "./BranchWidget";
import ExecutionFrame from "./Widgets/ExecutionFrame";
import getNewWidgetByType from "./WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import {
  setContentModifiedFlag,
  saveContentDatainBrowser,
} from "../../store/content";
import ExecutionWidget from "./ExecutionWidget";
export default function ExecutionWidgetList(props) {
  const { contents, activeContentId } = useSelector((state) => state.content);
  const dispatch = useDispatch();
  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);
  let content = currentContentObjects(contents, activeContentId);
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedWidgetCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  let nestedExecutionCursorIndex =
    currentContent?.nestedExecutionFrameCursorId !== undefined
      ? currentContent.nestedExecutionFrameCursorId
      : undefined;
  const binaryDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const singleDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const multipleDefault = [
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
    {
      value: "",
      option: "",
      defaultStatus: false,
    },
  ];
  const handleWidgetChange = (id, value, i, j, x, widget) => {
    console.log("change", id, value, i, j, x, widget, BRANCH_CONTROL_WIDGET);
    if (x.type === "blank") {
      let name = getNewWidgetByType(content, value);
      console.log("widgetBranch", name);
      widget.title = name.widgetName;
      widget.widgetDefaultName = name.widgetDefaultName;
      widget.type = value;
    }
    if (value === BINARY_INPUT_WIDGET) {
      widget.defaultOptions = binaryDefault;
    } else if (value === SINGLE_CHOICE_WIDGET) {
      widget.defaultOptions = singleDefault;
    } else if (value === MULTI_CHOICE_WIDGET) {
      widget.defaultOptions = multipleDefault;
    }
    if (value === BRANCH_CONTROL_WIDGET) {
      widget.widgetType = value;
      widget.branchControlType = "skip";
      widget.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "",
              value: "",
            },
          ],
        },
      ];
      widget.widgetList = [];
    } else {
      widget.widgetType = value;
    }
    props.widgetList[i] = widget;
    dispatch(setContentModifiedFlag(true));
    dispatch(saveContentDatainBrowser());
  };

  return (
    <div>
      {props.widgetList !== undefined &&
      Object.values(props.widgetList).length > 0
        ? props.widgetList.map((widget, widgetIndex) => (
            <>
              <div
                className={"temp"}
                key={widgetIndex}
                style={{
                  marginTop: "10px",
                  textAlign: "left",
                }}
              >
                <>
                  {widget.type === BRANCH_CONTROL_WIDGET ? (
                    <NestedBranchControlWidget
                      class={props.class}
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      innerWidget={true}
                    />
                  ) : widget.type === MULTIPLE_EXECUTION ? (
                    <ExecutionFrame
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      innerWidget={true}
                      handleWidgetType={(id, value) =>
                        handleWidgetChange(
                          id,
                          value,
                          widgetIndex,
                          widgetIndex,
                          widget,
                          widget
                        )
                      }
                    />
                  ) : (
                    <ExecutionWidget
                      //  class={props.class}
                      widgetDetails={widget}
                      module={props.module}
                      handleSelectWidget={props.handleSelectWidget}
                      widgetPosition={props.widgetPosition}
                      widgetIndex={props.widgetIndex}
                      moduleIndex={props.moduleIndex}
                      isFocus={props.isFocus}
                      innerWidget={true}
                      handleWidgetType={(id, value) =>
                        handleWidgetChange(
                          id,
                          value,
                          widgetIndex,
                          widgetIndex,
                          widget,
                          widget
                        )
                      }
                    />
                  )}
                </>
              </div>
              {props.index === branchWidgetCursorIndex &&
                props.innerWidget === undefined &&
                nestedWidgetCursorIndex === undefined &&
                executionFrameIndex === widgetIndex &&
                props.moduleIndex === activeCursorModuleId &&
                nestedExecutionCursorIndex === undefined && (
                  <EditPaneCursor type="lined" />
                )}
            </>
          ))
        : ""}
    </div>
  );
}
