import React, { useState, useEffect, useRef } from "react";
import Styled from "styled-components";
import { Accordion, Card, Button } from "react-bootstrap";
import { useSelector, useDispatch, batch } from "react-redux";
import {
  setActiveModuleId,
  updateBreadCrumb,
  setActiveWidgetId,
  setExpandedModuleIds,
  setSelectedModuleIds,
  setActiveCursorModuleId,
  setActiveCursorWidgetId,
  setSelectedOuterWidgetId,
  setNewModuleName,
} from "../../store/content";

export default function AccordionList() {
  const dispatch = useDispatch();
  const inputRef = useRef(null);
  const styles = useSelector((state) => state.ui.styles);
  const {
    contents,
    activeContentId,
    breadcrumb,
    renameModuleFlag,
  } = useSelector((state) => state.content);
  const [newModuleName, setModuleName] = useState(null);

  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);

  let activeModuleId = currentContent?.activeModuleId
    ? currentContent.activeModuleId
    : 0;
  //let selectedWidgetIds = currentContent?.selectedWidgetIds?.length > 0 ? currentContent.selectedWidgetIds : [];
  let activeModuleIds =
    currentContent?.activeModuleIds?.length > 0
      ? currentContent.activeModuleIds
      : [];
  let selectedModuleIds =
    currentContent?.selectedModuleIds?.length > 0
      ? currentContent.selectedModuleIds
      : [];
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let modules =
    currentContent?.moduleList?.length > 0 ? currentContent.moduleList : [];
  let widgets =
    currentContent?.widgetList?.length > 0 ? currentContent.widgetList : [];
  let combinedModulesandWidgets =
    currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
      ? currentContent.modulesAndOutsideWidgetsPositions
      : [];
  let selectedOuterWidgetIds =
    currentContent?.selectedOuterWidgetIds?.length > 0
      ? currentContent.selectedOuterWidgetIds
      : [];
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];

  let viewMode = useSelector((state)=>state.content.viewDetails)
  //let selectedWidgetsData = currentContent?.selectedWidgetsData?.length > 0 ? currentContent?.selectedWidgetsData : [];
  /**
   * when click on the module or Concertina Triangle captured that module id and breadcrumb also updated
   */
  const handleSelectModule = (e, module) => {
    if (e) e.preventDefault();
    if (!renameModuleFlag) {
      let activeModuleIndex = combinedModulesandWidgets?.findIndex(
        (x) => x.id === module.id && x.type === "module"
      );
      dispatch(updateBreadCrumb({ ...breadcrumb, module: module.title }));
      dispatch(setActiveCursorModuleId(activeModuleIndex));
      dispatch(setActiveModuleId(module.id));
      dispatch(setExpandedModuleIds(module.id));
    }
  };

  /**
   * when click on any widget captured that selected widget id and breadcrumb also updated
   */
  const handleSelectWidget = (
    e,
    widgetPosition,
    widget,
    module,
    widgetIndex,
    moduleIndex
  ) => {
    if (e) e.preventDefault();
    let clickType = null;
    if (e.ctrlKey) {
      clickType = "ctrlClick";
    }
    if (e.shiftKey) {
      clickType = "shiftClick";
    }
    if (selectedModuleIds.indexOf(module.id) === -1) {
      if (widgetPosition === "insideModule") {
        dispatch(updateBreadCrumb({ ...breadcrumb, module: module.title }));
        dispatch(setActiveModuleId(module.id));
        dispatch(setActiveCursorModuleId(moduleIndex));
        dispatch(setActiveCursorWidgetId(widgetIndex));
        dispatch(
          setActiveWidgetId(widget.id, clickType, module.id, moduleIndex)
        );
      }
      if (widgetPosition === "outsideModule") {
        dispatch(updateBreadCrumb({ ...breadcrumb, module: widget.title }));
        dispatch(setActiveCursorModuleId(moduleIndex));
        dispatch(setActiveCursorWidgetId(undefined));
        dispatch(setActiveWidgetId(widget.id, clickType, moduleIndex));
      }
    } else {
      alert("Could not select or de-select widgets inside the selected module");
    }
    window.getSelection().removeAllRanges();
  };

  // returns class names based on selected modules
  const getSelected = (id) => {
    let status = activeModuleIds.indexOf(id);
    //let preSelect = selectedModuleIds.indexOf(id);
    if (status > -1) {
      return "up";
    }
    return "down";
  };

  /**
   * when click on the module body stored that corresponding module id
   */
  const handlePreSelectmodule = (e, module, moduleIndex) => {
    // if (e) e.preventDefault();
    e.stopPropagation();
    let clickType = null;
    if (e.ctrlKey) {
      clickType = "ctrlClick";
    }
    if (e.shiftKey) {
      clickType = "shiftClick";
    }
    dispatch(setSelectedModuleIds(module.id, clickType, moduleIndex));
    dispatch(setActiveCursorModuleId(moduleIndex, module.id));
  };

  /**
   * To check for module name exist or not
   * @param {string} name
   */
  const isModuleNameExist = (name) => {
    return modules.some((module) => module.title === name);
  };

  /**
   * when on blur of text input, will call rename module action to set new name for module
   */
  const handleRenameModule = () => {
    // if (newModuleName && newModuleName !== undefined) {
    //   console.log('newModuleName ', newModuleName)
    //   console.log(' newModuleName.length ',  newModuleName?.length)
    //   let newModuleName = newModuleName.trim();
    //   let moduleData = modules.find((x) => x.id === selectedModuleIds[0]);
    //   let nameExist = isModuleNameExist(newModuleName)
    //   if (moduleData) {
    //     let suffix = "002";
    //     let slicedSuffix = parseInt(newModuleName.slice(-3));
    //     if (nameExist) {
    // if (!isNaN(slicedSuffix)) {
    //   let suffixedIncr = slicedSuffix + 1;
    //   if ((suffixedIncr + "").length === 1) {
    //     suffix = "00" + suffixedIncr;
    //   } else if ((suffixedIncr + "").length === 2) {
    //     suffix = "0" + suffixedIncr;
    //   } else if ((suffixedIncr + "").length >= 3) {
    //     suffix = suffixedIncr;
    //   }
    //   moduleData.title =
    //     newModuleName.slice(0, newModuleName.length - 3) + suffix;
    // } else {
    //   moduleData.title = newModuleName + suffix;
    // }
    // console.log( moduleData.title)
    // handleRenameModule( moduleData.title)
    //   alert(newModuleName + ' module name already exist')
    // } else {
    //   moduleData.title = newModuleName;
    //   dispatch(setNewModuleName(moduleData, activeContentId));
    // }
    //   }
    // }
    let moduleData = modules.find((x) => x.id === selectedModuleIds[0]);
    dispatch(setNewModuleName(moduleData, activeContentId));
    setModuleName(null);
  };

  /**
   * when click on rename icon module name can be able to ediatble with focus and selecting existing name
   */
  useEffect(() => {
    let moduleName = modules?.find((x) => x.id === selectedModuleIds[0])?.title;
    if (moduleName) setModuleName(moduleName);
    if (inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [renameModuleFlag]);

  const keypressHandler = (event) => {
    if (event.key === "Enter") {
      let moduleData = modules.find((x) => x.id === selectedModuleIds[0]);
      let nameExist = isModuleNameExist(newModuleName);
      if (nameExist) {
        alert("Name already exist");
        dispatch(setNewModuleName(moduleData, activeContentId));
        setModuleName(moduleData.title);
      } else {
        if (moduleData) {
          moduleData.title = newModuleName?.trim();
        }
        dispatch(setNewModuleName(moduleData, activeContentId));
      }
      // let moduleData = modules.find((x) => x.id === selectedModuleIds[0]);
      // if (moduleData) {
      //   moduleData.title = newModuleName;
      // }
      // dispatch(setNewModuleName(moduleData, activeContentId));
    }
  };

  return (
    <AccordionStyle styles={styles}>
      <div className="accordion-scroll">
        <div style={{ marginTop: "17px", marginBottom: "12px" }}>
          {" "}
          {activeCursorModuleId === -1 && activeCursorWidgetId === undefined && (
            <div className="hoverBarInitial">
              <span></span>
            </div>
          )}
        </div>
        {combinedModulesandWidgets != undefined &&
          Object.values(combinedModulesandWidgets).length > 0
          ? combinedModulesandWidgets.map((item, itemIndex) => (
            <>
              {item.type === "module" && (
                <AccordionToggleStyle
                  locked={modules[item.index]?.locked}
                  readOnly={modules[item.index]?.readOnly}
                >
                  <Accordion key={itemIndex}>
                    <Card>
                      <Card.Header
                        className={
                          !modules[item.index]?.locked &&
                          getSelected(modules[item.index]?.id)
                        }
                      >
                        <div
                          // className={
                          //   selectedModuleIds.indexOf(modules[item.index]?.id) > -1
                          //     ? modules[item.index]?.locked ? "card-header-div lockedBorder" : "card-header-div selected-module"
                          //     : "card-header-div"
                          // }
                          className={
                            modules[item.index]?.locked
                              ? "card-header-div lockedBorder"
                              : selectedModuleIds.indexOf(
                                modules[item.index]?.id
                              ) > -1
                                ? modules[item.index]?.readOnly
                                  ? "card-header-div"
                                  : "card-header-div selected-module"
                                : "card-header-div"
                          }
                        >
                          <span
                            className="card-header-span"
                            onClick={(e) =>
                              !modules[item.index]?.locked &&
                              handlePreSelectmodule(
                                e,
                                modules[item.index],
                                itemIndex
                              )
                            }
                          ></span>
                          <Accordion.Toggle
                            as={Button}
                            variant="link"
                            eventKey={modules[item.index]?.id}
                            onClick={(e) =>
                              handleSelectModule(e, modules[item.index])
                            }
                            disabled={
                              modules[item.index]?.locked ? true : false
                            }
                          >
                            {selectedModuleIds[0] ===
                              modules[item.index]?.id && renameModuleFlag ? (
                                <input
                                  ref={inputRef}
                                  type="text"
                                  style={{ direction: "ltr" }}
                                  onKeyPress={(event) => keypressHandler(event)}
                                  value={
                                    newModuleName === null
                                      ? modules[item.index]?.title
                                      : newModuleName
                                  }
                                  onBlur={(e) => handleRenameModule(e)}
                                  onChange={(e) =>
                                    setModuleName(e.target.value)
                                  }
                                  onFocus={(e) =>
                                    e.target.value
                                      ? setModuleName(e.target.value)
                                      : {}
                                  }
                                />
                              ) : (
                                <> {modules[item.index]?.title} </>
                              )}
                          </Accordion.Toggle>
                        </div>
                      </Card.Header>
                      <Accordion.Collapse
                        eventKey={
                          activeModuleIds.indexOf(modules[item.index]?.id) >
                            -1
                            ? modules[item.index]?.id
                            : 0
                        }
                        className={
                          activeModuleIds.indexOf(modules[item.index]?.id) >
                            -1 && !modules[item.index]?.locked
                            ? "show"
                            : "collapse"
                        }
                      >
                        <Card.Body>
                          <div
                            style={{
                              marginTop: "5px",
                              marginBottom: "5px",
                              zIndex: "1",
                            }}
                          >
                            {" "}
                            {activeCursorModuleId === itemIndex &&
                              activeCursorWidgetId === -1 && (
                                <div className="hoverBar">
                                  <span></span>
                                </div>
                              )}
                          </div>
                          {modules[item.index]?.widgetList.map(
                            (widget, widgetIndex) => (
                              <div
                                className={
                                  selectedWidgetIds.indexOf(widget.id) > -1
                                    ? modules[item.index].readOnly
                                      ? ""
                                      : "selected-widget"
                                    : ""
                                }
                              >
                                <div
                                  key={widgetIndex}
                                  onClick={(e) =>
                                    handleSelectWidget(
                                      e,
                                      "insideModule",
                                      widget,
                                      modules[item.index],
                                      widgetIndex,
                                      itemIndex
                                    )
                                  }
                                >
                                  <div className="dirLtr">{widget.title}</div>
                                </div>
                                <div
                                  style={{
                                    marginTop: "5px",
                                    marginBottom: "5px",
                                    zIndex: "1",
                                  }}
                                >
                                  {" "}
                                  {widgetIndex === activeCursorWidgetId &&
                                    itemIndex === activeCursorModuleId && (
                                      <div className="hoverBar">
                                        <span></span>
                                      </div>
                                    )}
                                </div>
                              </div>
                            )
                          )}
                          {/* style={{ marginTop: "17px", marginBottom: "12px" }} */}
                          <div> </div>
                        </Card.Body>
                      </Accordion.Collapse>
                      <div style={{ marginTop: "5px", marginBottom: "10px" }}>
                        {" "}
                        {activeCursorModuleId === itemIndex &&
                          activeCursorWidgetId === undefined && (
                            <div className="hoverBarInitial">
                              <span></span>
                            </div>
                          )}
                      </div>
                    </Card>
                  </Accordion>
                </AccordionToggleStyle>
              )}
              {item.type === "widget" && (
                <>
                  <div
                    className={
                      selectedWidgetIds.indexOf(widgets[item.index]?.id) > -1
                        ? currentContent?.processProperties?.readOnly ? "outerWidget" : "selected-widget outerWidget"
                        : "outerWidget"
                    }
                  >
                    <div
                      key={itemIndex}
                      onClick={(e) =>
                        handleSelectWidget(
                          e,
                          "outsideModule",
                          widgets[item.index],
                          widgets[item.index],
                          itemIndex,
                          itemIndex
                        )
                      }
                    >
                      <span className="outerWidgetName">
                        {" "}
                        {widgets[item.index]?.title}
                      </span>
                    </div>
                    <div
                      style={{
                        marginTop: "5px",
                        marginBottom: "10px",
                        zIndex: "1",
                      }}
                    >
                      {" "}
                      {itemIndex === activeCursorModuleId &&
                        activeCursorWidgetId === undefined && (
                          <div className="hoverBar">
                            <span></span>
                          </div>
                        )}
                    </div>
                  </div>
                </>
              )}
            </>
          ))
          : ""}
      </div>
    </AccordionStyle>
  );
}

// commented by senthil 09092020(dont remove it)

// const AccordionStyle = Styled.div`
// //background-color:#bfbfbf !important;
// .card-header-div {
//   width: calc(96% - 20px);
//   text-align: left;
//   margin-left: 20px;
//   color: #707070;
//   border: 1px solid #707070;
//   border-radius: 5px;
//   cursor: pointer !important;
//   position: relative;
// }

// .card-header-span{
//   height: 100%;
//   width: 100%;
//   z-index: 0;
//   position: absolute;
//   right: 0;
// }
// // .card-header button{
// //     width: calc(96% - 20px);
// //     text-align: left;
// //     margin-left: 20px;
// // }
// .collapse, .collapsing{
//     text-align: right;
// }
// .card-header{
//     background-color: #fff;
//     border-bottom: none;
// }
// .btn-link:hover {
//     color: #707070;
//     text-decoration: none;
// }
// .btn-link {
//     color: #707070;
//     z-index:2 !important;
//     position: relative;
//     //border: 1px solid #707070;
// }
// .btn.focus, .btn:focus {
//     box-shadow: none;
// }
// .card-body{
//     display: flex;
//     flex-direction: column;
//     text-align: left;
//     padding: 0 0 0 47px !important;
// }
// .card-body span:hover{
//      background: rgb(123, 123, 123);
//     cursor: pointer !important;
// }
// .card-body .active{
//     font-weight: 700;
// }
// .card{
//     border: none;
//     border-radius: initial;
// }
// .content-box, .card, .card-header{
//     background: #d9d9d9 !important;
// }

// .card-header button:before{
//     content: '';
//     width: 0px;
//     height: 0px;
//     border-top: 10px solid transparent;
//     border-bottom: 10px solid transparent;
//     border-right: 10px solid #727272;
//     position:absolute;
//     left:-30px;
//     transition: all 0.75s 0.25s;
//     transform: rotate(180deg);
//     top: 10px;
//     }
//     .card-header.up button:before{
//         transition: all 0.75s 0.25s;
//         transform: rotate(270deg);
//     }
//     .selected-widget {
//         font-weight: 800;
//     }
//     .accordion-scroll {
//       height: calc(100vh - 430px);
//         overflow-y: auto;
//         direction: rtl;
//         min-height:200px;
//         overflow-x:hidden;
//     }
//     .accordion-scroll::-webkit-scrollbar {
//         width: 8px;
//     }

//     .accordion-scroll::-webkit-scrollbar-track,
//     .settingContainer::-webkit-scrollbar-track {
//         background: #b3b3b3;
//         border-radius: 10px;
//     }

//     .accordion-scroll::-webkit-scrollbar-thumb {
//         background: #0395a6;
//         border-radius: 10px;
//     }
//      .hoverBar {
// position: relative;
// right: 24px;
// top: 2px;
// width: 101%;
// }
// .hoverBar span{
// width: 95%;
// height: 2px;
// background: #7b7b7b;
// display: block;
// }
// .hoverBar span:after{
// content: '';
// position: absolute;
// right: -8px;
// top: -9px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-right: 10px solid #7b7b7b;
// clear: both;
// }
// .hoverBar span:before{
// content: '';
// position: absolute;
// top: -9px;
// left: 10px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-left: 10px solid #7b7b7b;
// clear: both;
// }
// // .hoverBarTotal {
// // position: relative;
// // right: 15px;
// // top: 2px;
// // height: 24px;
// // }
// .hoverBarTotal {
//     position: relative;
//     right: 15px;
//     top: 2px;
//     height: 24px;
// width: 97.5%;
// }
// .hoverBarTotal span{
// width: 92%;
// height: 2px;
// background: #7b7b7b;
// display: block;
// }
// .hoverBarTotal span:after{
// content: '';
// position: absolute;
// // right: -10px;
// // top: -19px;
// right: -8px;
// top: -9px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-right: 10px solid #7b7b7b;
// clear: both;
// }
// .hoverBarTotal span:before{
// content: '';
// position: absolute;
// // top: -19px;
// // left: 44px;
// top: -9px;
// left: 32px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-left: 10px solid #7b7b7b;
// clear: both;
// }
// .hoverBarInitial {
// position: relative;
// right: 4%;
// top: 2px;
// width:96.5%;
// }
// .hoverBarInitial span{
// width: 91%;
// height: 2px;
// background: #7b7b7b;
// display: block;
// }
// .hoverBarInitial span:after{
// content: '';
// position: absolute;
// right: -8px;
// top: -9px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-right: 10px solid #7b7b7b;
// clear: both;
// }
// .hoverBarInitial span:before{
// content: '';
// position: absolute;
// top: -9px;
// left: 28px;
// width: 0;
// height: 0;
// border-top: 10px solid transparent;
// border-bottom: 10px solid transparent;
// border-left: 10px solid #7b7b7b;
// clear: both;
// }
// @media only screen and (min-width: 1294px) {
// .hoverBarInitial span, .hoverBarTotal span{
// width: 91%;
// }
// }
// @media only screen and (min-width: 1294px) {
// .hoverBar span{
// width: 96%;
// }
// }

// .outerWidget{
//   width : 89%;
// .outerWidgetName{
//     position: relative;
//     right: 18px;
// }
// }

// .selected-module{
//       background:${props =>
//     props.styles.ContentHighlight_Colour?.background} !important;
//   }
//   .dirLtr{
//     direction: ltr;
//   }
// `;

const AccordionStyle = Styled.div`
.card-header{
  padding: 0 1.25rem;
}
.btn.active.focus, .btn.active:focus, .btn.focus, .btn:active.focus, .btn:active:focus, .btn:focus{
	outline: 0;
}
//background-color:#bfbfbf !important;    
    .selected-widget {
        font-weight: 800;
    }
    .accordion-scroll {
      height: calc(100vh - 430px);
        overflow-y: auto;
        direction: rtl;
        min-height:200px;
        overflow-x:hidden;
    }
    .accordion-scroll::-webkit-scrollbar {
        width: 8px;
    }    
    .accordion-scroll::-webkit-scrollbar-track,
    .settingContainer::-webkit-scrollbar-track {
        background: #b3b3b3;
        border-radius: 10px;
    }    
    .accordion-scroll::-webkit-scrollbar-thumb {
        background: #0395a6;
        border-radius: 10px;
    }
     .hoverBar {
      position: relative;
      right: 20px;
      top: 2px;
      width: 100%;
      margin: 5px 0 10px 0;
    }
    .hoverBar span{
      // width: 95%;
      height: 2px;
      background: #7b7b7b;
      display: block;
    }
    .hoverBar span:after{
      content: '';
      position: absolute;
      right: -4px;
      top: -9px;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-right: 10px solid #7b7b7b;
      clear: both;
    }
    .hoverBar span:before{
      content: '';
      position: absolute;
      top: -9px;
      left: -4px;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-left: 10px solid #7b7b7b;
      clear: both;
    }
    // .hoverBarTotal {
      // position: relative;
      // right: 15px;
      // top: 2px;
      // height: 24px;
    // }
    .hoverBarTotal {
      position: relative;
      right: 15px;
      top: 2px;
      height: 24px;
      width: 97.5%;
      margin: 5px 0 10px 0;
    }
    .hoverBarTotal span{
      width: 92%;
      height: 2px;
      background: #7b7b7b;
      display: block;
    }
    .hoverBarTotal span:after{
      content: '';
      position: absolute;
      // right: -10px;
      // top: -19px;
      right: -8px;
      top: -9px;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-right: 10px solid #7b7b7b;
      clear: both;
    }
    .hoverBarTotal span:before{
      content: '';
      position: absolute;
      // top: -19px;
      // left: 44px;
      top: -9px;
      left: 32px;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-left: 10px solid #7b7b7b;
      clear: both;
    }
    .hoverBarInitial {
      position: relative;
      right: 5.5%;
      top: 2px;
      width: 89.6%;
      margin: 5px 0 10px 0;
    }
    .hoverBarInitial span{
      width: 100%;
      height: 2px;
      background: #7b7b7b;
      display: block;
    }
    .hoverBarInitial span:after{
      content: '';
      position: absolute;
      right: 0;
      top: -9px;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-right: 10px solid #7b7b7b;
      clear: both;
    }
    .hoverBarInitial span:before{
      content: '';
      position: absolute;
      top: -9px;
      left: 0;
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-left: 10px solid #7b7b7b;
      clear: both;
    }
    // @media only screen and (min-width: 1294px) {
    //   .hoverBarInitial span, .hoverBarTotal span{
    //   width: 91%;
    //   }
    // }
    @media only screen and (min-width: 1294px) {
      .hoverBar span{
      // width: 96%;
      }
    }

    .outerWidget{
        width : 89%;
        direction: ltr;
      .outerWidgetName{
          position: relative;
          right: 18px;
      }
    }

.selected-module{
      background:${(props) =>
    props.styles.ContentHighlight_Colour?.background} !important;
  }
  .dirLtr{
    direction: ltr;
    padding-left: 2%;
  }
  .outerWidget {
    margin: -6px 0px;
}
`;

const AccordionToggleStyle = Styled.div`
.card-header-div {
  width: calc(96% - 20px);
  text-align: left;
  margin-left: 20px;
  color: #707070;
  border: 1px solid #707070;
  border-radius: 5px;
  cursor: pointer !important;
  position: relative;
  
}

.card-header-div button{
  font-size:14px;
}
.lockedBorder{
  border: 1px solid black;
}


.card-header-span{
  height: 100%;
  width: 100%;  
  z-index: 0;
  position: absolute;
  right: 0;
}
// .card-header button{
//     width: calc(96% - 20px);
//     text-align: left;
//     margin-left: 20px;
// }
.collapse, .collapsing{
    text-align: right;
}
.card-header{
    background-color: #fff;
    border-bottom: none;
}
.btn-link:hover {
    color: #707070;
    text-decoration: none;
}
.btn-link {
    color: #707070;
    z-index:2 !important;
    position: relative;
    //border: 1px solid #707070;
}
.btn.focus, .btn:focus {
    box-shadow: none;
}
.card-body{
    display: flex;
    flex-direction: column;
    text-align: left;  
    padding: 0 0 0 47px !important;
}
.card-body span:hover{
     background: rgb(123, 123, 123);
    cursor: pointer !important;
}
.card-body .active{
    font-weight: 700;
}
.card{
    border: none;
    border-radius: initial;
}
.content-box, .card, .card-header{
    background: #d9d9d9 !important;
}
.card-header button:before{
  content: '';
  width: 0px;
  height: 0px;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  // border-right: 10px solid #727272;
  border-right: ${(props) =>
    props.locked
      ? "10px solid black"
      : props.readOnly
        ? "10px solid #0395a6"
        : "10px solid red"};
  position:absolute;
  left:-30px;
  transition: all 0.75s 0.25s;
  transform: rotate(180deg);
  top: 2px;
}
.card-header.up button:before{
  transition: all 0.75s 0.25s;
  transform: rotate(270deg);
}
.btn.btn-link{
  color: #212529;
}
`;
