import React from "react";
import { MentionsInput, Mention } from "react-mentions";
import { useDispatch } from "react-redux";
import styled from "styled-components";
import { holdCursor } from "../../../store/content";
export default function SkipWidget(props) {
  const dispatch = useDispatch();

  const handleOnChange = (e, type, i, j) => {
    e.target.blur()
    // dispatch(holdCursor(true));
    props.handleInputWidget(e, type, i, j);
  };

  return (
    <Styles>
      {props.branchConditions &&
        props.branchConditions?.length > 0 &&
        props.branchConditions.map((branch, i) => (
          <>
            {branch.conditions.map((format, j) => (
              <div className="fieldSection">
                <div className="textArrow">
                  {/* <input type="text" onChange={(e) => props.handleInputWidget(e, 'field', i, j)} value={format.field} placeholder="field" /> */}
                  <MentionsInput
                    id="calcWidget"
                    markup="@[__display__](__id__)"
                    value={format.field}
                    onChange={(e) => props.handleInputWidget(e, "field", i, j)}
                    className="textAreaCalcWidget"
                    placeholder="field"
                    //onKeyUp={(e) => handleKeyPress(e)}
                    //onSelect={handleSelect}
                  >
                    <Mention
                      trigger="@"
                      data={props.mentionWidgets}
                      style={{
                        backgroundColor: "#ddd",
                      }}
                      appendSpaceOnAdd="true"
                    />
                  </MentionsInput>
                  <img
                    src={props.icons?.input_field_stretch}
                    style={{ width: "26px", height: "26px" }}
                    alt=".."
                    onClick={(e) =>
                      props.globalLogoRef(
                        e,
                        props.widget.id,
                        "branchField",
                        i,
                        j
                      )
                    }
                  />
                </div>
                <div className="equalAndArrow">
                  <select
                    onChange={(e) => handleOnChange(e, "expression", i, j)}
                    onBlur={() => dispatch(holdCursor(false))}
                    value={format.expression}
                  >
                    <option value=">"> {">"} </option>
                    <option value="<"> {"<"} </option>
                    <option value="="> {"="} </option>
                    <option value="!="> {"!="} </option>
                    <option value="<="> {"<="} </option>
                    <option value="=>"> {"=>"} </option>
                  </select>
                </div>
                <div className="textArrow">
                  {/* <input
                    type="text"
                    onChange={(e) => props.handleInputWidget(e, "value", i, j)}
                    value={format.value}
                    placeholder="value"
                  /> */}
                  <MentionsInput
                    id="switch"
                    markup="@[__display__](__id__)"
                    value={format.value}
                    onChange={(e) => props.handleInputWidget(e, "value", i, j)}
                    className="textAreaCalcWidgetValue"
                    placeholder="value"
                    //onKeyUp={(e) => handleKeyPress(e)}
                    //onSelect={handleSelect}
                  >
                    <Mention
                      trigger="@"
                      data={props.mentionWidgets}
                      style={{
                        backgroundColor: "#ddd",
                      }}
                      appendSpaceOnAdd="true"
                    />
                  </MentionsInput>
                  <img
                    src={props.icons?.input_field_stretch}
                    style={{ width: "26px", height: "26px" }}
                    alt=".."
                    onClick={(e) =>
                      props.globalLogoRef(
                        e,
                        props.widget.id,
                        "branchValue",
                        i,
                        j
                      )
                    }
                  />
                </div>
                {branch.conditions.length - 1 === j ? (
                  <div
                    onClick={(e) => props.handleAddANDgate(e, i)}
                    className="andClick"
                  >
                    <span> AND...</span>
                  </div>
                ) : (
                  <div className="andClick">
                    <span style={{ color: "green" }}> AND </span>
                  </div>
                )}
                <div
                  onClick={(e) => props.handleDeleteCondition(e, i, j)}
                  className="deleteIcon"
                >
                  <img
                    src="https://lh3.googleusercontent.com/-xM32kehAHdU/X1hej6-o0KI/AAAAAAAAAfA/6X5sWRWCU3IG4w-Wm_BgndX4ZtobNay_ACK8BGAsYHg/s0/2020-09-08.png"
                    alt="delete-icon"
                  />
                </div>
              </div>
            ))}
            {props.branchConditions.length - 1 === i ? (
              <div
                onClick={(e) => props.handleAddORgate(e)}
                className="orClick"
              >
                <div className="lineBehid"></div>
                <span>OR...</span>
              </div>
            ) : (
              <div className="orClick">
                <div className="lineBehid"></div>
                <span style={{ color: "green" }}>OR</span>
              </div>
            )}
          </>
        ))}
    </Styles>
  );
}
const Styles = styled.div`
  .textAreaCalcWidget {
    background-color: white;
    width: 80px;
    height: 28px;
    margin: 0;
  }
  .textAreaCalcWidgetValue {
    background-color: white;
    width: 100px;
    height: 28px;
    margin: 0;
  }
  .textArrow {
    overflow: visible !important;
  }
  textarea {
    border: none;
    margin-top: 24px;
    margin-bottom: 20px;
    margin-right: 20px;
    outline-width: 0;
    padding: 5px;
    resize: none;
    width: 100%;
  }
`;
