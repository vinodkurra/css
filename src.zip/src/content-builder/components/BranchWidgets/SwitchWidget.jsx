import React from "react";
import { MentionsInput, Mention } from "react-mentions";
import styled from "styled-components";
export default function SwitchWidget(props) {
  return (
    <Styles>
      {props.branchConditions &&
        props.branchConditions?.length > 0 &&
        props.branchConditions.map((branch, i) => (
          <>
            {branch.conditions.map((format, j) => (
              <div className="fieldSection">
                <div className="textArrow">
                  {/* <input type="text" onChange={(e) => props.handleInputWidget(e, 'field', i, j)} value={format.field} placeholder="field" /> */}
                  <MentionsInput
                    id="switch"
                    markup="@[__display__](__id__)"
                    value={format.field}
                    onChange={(e) => props.handleInputWidget(e, "field", i, j)}
                    className="textAreaCalcWidget"
                    placeholder="field"
                    //onKeyUp={(e) => handleKeyPress(e)}
                    //onSelect={handleSelect}
                  >
                    <Mention
                      trigger="@"
                      data={props.mentionWidgets}
                      style={{
                        backgroundColor: "#ddd",
                      }}
                      appendSpaceOnAdd="true"
                    />
                  </MentionsInput>
                  <img
                    src={props.icons?.input_field_stretch}
                    style={{ width: "26px", height: "26px" }}
                    alt=".."
                    onClick={(e) =>
                      props.globalLogoRef(
                        e,
                        props.widget.id,
                        "branchField",
                        i,
                        j
                      )
                    }
                  />
                </div>
                <div className="equalAndArrow">
                  <select
                    onChange={(e) => {
                      props.handleInputWidget(e, "expression", i, j);
                      e.target.blur();
                    }
                    }
                    value={format.expression}
                  >
                    <option value=">"> {">"} </option>
                    <option value="<"> {"<"} </option>
                    <option value="="> {"="} </option>
                    <option value="!="> {"!="} </option>
                    <option value="<="> {"<="} </option>
                    <option value="=>"> {"=>"} </option>
                  </select>
                </div>
                <div className="textArrow">
                  {/* <input
                    type="text"
                    onChange={(e) => props.handleInputWidget(e, "value", i, j)}
                    value={format.value}
                    placeholder="value"
                  /> */}
                  <MentionsInput
                    id="switch"
                    markup="@[__display__](__id__)"
                    value={format.value}
                    onChange={(e) => props.handleInputWidget(e, "value", i, j)}
                    className="textAreaCalcWidget"
                    placeholder="value"
                    //onKeyUp={(e) => handleKeyPress(e)}
                    //onSelect={handleSelect}
                  >
                    <Mention
                      trigger="@"
                      data={props.mentionWidgets}
                      style={{
                        backgroundColor: "#ddd",
                      }}
                      appendSpaceOnAdd="true"
                    />
                  </MentionsInput>
                  <img
                    src={props.icons?.input_field_stretch}
                    style={{ width: "26px", height: "26px" }}
                    alt=".."
                    onClick={(e) =>
                      props.globalLogoRef(
                        e,
                        props.widget.id,
                        "branchValue",
                        i,
                        j
                      )
                    }
                  />
                </div>

                {props.branchConditions.length - 1 === i ? (
                  <div
                    onClick={(e) => props.handleAddANDgate(e, i)}
                    className="andClick"
                  >
                    <span style={{ fontSize: "20px" }}>::...</span>
                  </div>
                ) : (
                  <div className="andClick">
                    <span style={{ color: "green", fontSize: "20px" }}>::</span>
                  </div>
                )}
                <div
                  onClick={(e) => props.handleDeleteCondition(e, i, j)}
                  className="deleteIcon"
                >
                  <img
                    src="https://lh3.googleusercontent.com/-xM32kehAHdU/X1hej6-o0KI/AAAAAAAAAfA/6X5sWRWCU3IG4w-Wm_BgndX4ZtobNay_ACK8BGAsYHg/s0/2020-09-08.png"
                    alt="delete-icon"
                  />
                </div>
              </div>
            ))}
          </>
        ))}
    </Styles>
  );
}
const Styles = styled.div`
  .textAreaCalcWidget {
    background-color: white;
    width: 120px;
    height: 28px;
    margin: 0;
  }

  .textArrow {
    overflow: visible !important;
  }
  textarea {
    border: none;
    margin-top: 24px;
    margin-bottom: 20px;
    margin-right: 20px;
    outline-width: 0;
    padding: 5px;
    resize: none;
    width: 100%;
  }
`;
