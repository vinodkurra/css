import React, { useEffect } from "react";
import Styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";
import Widget from "./Widget";
import BranchControlWidget from "./BranchControlWidget";
import ExecutionFrame from "./Widgets/ExecutionFrame";
// import BranchControlWidget from './BranchControlWidgets'
import {
  setActiveModuleId,
  updateBreadCrumb,
  setActiveWidgetId,
  setExpandedModuleIds,
  setSelectedModuleIds,
  setActiveCursorModuleId,
  setActiveCursorWidgetId,
  setSelectedOuterWidgetId,
  updateContentWithPositions,
  selectPageBreak,
  updateModulesAndWidgetPosition,
  getContentDetailsByContentId,
} from "../../store/content";
import { BRANCH_CONTROL_WIDGET, MULTIPLE_EXECUTION } from "./Constants";

import EditPaneCursor from "./EditPaneCursor";

function ContentEdit() {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  const {
    contents,
    activeContentId,
    breadcrumb,
    renameModuleFlag,
    isContentTabChange,
  } = useSelector((state) => state.content);

  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);

  let activeModuleId = currentContent?.activeModuleId
    ? currentContent.activeModuleId
    : 0;
  // let selectedWidgetIds =
  //   currentContent?.selectedWidgetIds?.length > 0
  //     ? currentContent.selectedWidgetIds
  //     : [];
  let activeModuleIds =
    currentContent?.activeModuleIds?.length > 0
      ? currentContent.activeModuleIds
      : [];
  let selectedModuleIds =
    currentContent?.selectedModuleIds?.length > 0
      ? currentContent.selectedModuleIds
      : [];
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let modules =
    currentContent?.moduleList?.length > 0 ? currentContent.moduleList : [];
  let widgets =
    currentContent?.widgetList?.length > 0 ? currentContent.widgetList : [];
  let combinedModulesandWidgets =
    currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
      ? currentContent.modulesAndOutsideWidgetsPositions
      : [];
  let modulesWidgetsPositions =
    currentContent?.modulesWidgetsPositions?.length > 0
      ? currentContent.modulesWidgetsPositions
      : [];
  let cursorSelectedStatus = currentContent?.cursorSelectedStatus;
  let pageBreakPosition =
    currentContent?.pageBreakPosition?.length > 0
      ? currentContent.pageBreakPosition
      : [];
  let selectedOuterPagebreakIndex =
    currentContent?.selectedOuterPagebreakIndex !== undefined
      ? currentContent.selectedOuterPagebreakIndex
      : undefined;
  let selectedInnerPagebreakIndex =
    currentContent?.selectedInnerPagebreakDetails?.widgetIndex !== undefined
      ? currentContent.selectedInnerPagebreakDetails.widgetIndex
      : undefined;
  let selectedInnerPagebreakModuleId =
    currentContent?.selectedInnerPagebreakDetails?.moduleId !== undefined
      ? currentContent.selectedInnerPagebreakDetails.moduleId
      : undefined;
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedBranchWidgetCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;

  let checksumId = JSON.parse(localStorage.getItem("account")).userid;
  let author = currentContent?.authors?.filter(
    (x) => x.checkSumId === checksumId
  );
  let access = true;
  if (author?.length > 0 && !author[0].contentPermissions.write) {
    access = false;
  }

  // useEffect(() => {
  //   if (activeContentId)
  //     dispatch(getContentDetailsByContentId(activeContentId, false, true));
  // }, []);
  useEffect(() => {
    if (activeContentId && !isContentTabChange)
      dispatch(
        updateModulesAndWidgetPosition(
          activeContentId,
          combinedModulesandWidgets,
          modulesWidgetsPositions
        )
      );
  }, [combinedModulesandWidgets?.length, modulesWidgetsPositions?.length]);

  var child = document.querySelector("#child");

  const handleSelectWidget = (
    e,
    widgetPosition,
    widget,
    module,
    widgetIndex,
    moduleIndex
  ) => {
    if (e) e.persist();
    let clickType = null;
    if (e.ctrlKey) {
      clickType = "ctrlClick";
    }
    if (e.shiftKey) {
      clickType = "shiftClick";
    }
    if (Array.isArray(widget)) {
      widget = widget[0];
    }
    // console.log("select", widgetPosition,
    //   widget,
    //   module,
    //   widgetIndex,
    //   moduleIndex)
    //this method only execute when click parent element and should not remove/modify belowed class names

    var isWidgetSelection = isValidWidgetSelection(e.target.className);
    console.log(
      "select",
      widgetPosition,
      widget,
      module,
      widgetIndex,
      moduleIndex
    );
    if (isWidgetSelection) {
      if (widgetPosition === "insideModule") {
        dispatch(updateBreadCrumb({ ...breadcrumb, module: module?.title }));
        dispatch(setActiveModuleId(module.id));
        dispatch(setActiveCursorModuleId(moduleIndex));
        dispatch(setActiveCursorWidgetId(widgetIndex));
        dispatch(setActiveWidgetId(widget.id, clickType));
        window.getSelection().removeAllRanges();
      }
      if (widgetPosition === "outsideModule") {
        // console.log("select", module.id);
        dispatch(updateBreadCrumb({ ...breadcrumb, module: widget?.title }));
        dispatch(setActiveModuleId(0));
        dispatch(setActiveCursorModuleId(moduleIndex));
        dispatch(setActiveCursorWidgetId(undefined));
        dispatch(setActiveWidgetId(widget.id, clickType));
        window.getSelection().removeAllRanges();
      }
    }
  };

  const isValidWidgetSelection = (cssClassName) => {
    if (
      cssClassName &&
      (cssClassName === "generic_options" ||
        cssClassName === "input_group" ||
        cssClassName === "all_options" ||
        cssClassName === "test" ||
        cssClassName === "advanceWidget" ||
        cssClassName === "dark_bg" ||
        cssClassName === "widget_form_text_input" ||
        cssClassName === "hideBookmark" ||
        cssClassName === "widgetBaseContainer" ||
        cssClassName === "checkContainer" ||
        cssClassName === "execution-frame")
    )
      return true;
    return false;
  };
  const handleSelectModule = (e, module) => {
    if (e) e.stopPropagation();
    let activeModuleIndex = modules?.findIndex((x) => x.id === module.id);
    if (!renameModuleFlag) {
      dispatch(setActiveCursorModuleId(activeModuleIndex));
      dispatch(updateBreadCrumb({ ...breadcrumb, module: module.title }));
      dispatch(setActiveModuleId(module.id));
      dispatch(setExpandedModuleIds(module.id));
    }
  };

  const handlePreSelectmodule = (e, module, moduleIndex) => {
    e.stopPropagation();
    //let activeModuleIndex = modules?.findIndex(x => x.id === moduleId);
    let clickType = null;
    if (e.ctrlKey) {
      clickType = "ctrlClick";
    }
    if (e.shiftKey) {
      clickType = "shiftClick";
    }
    dispatch(setActiveCursorModuleId(moduleIndex, module.id));
    dispatch(setSelectedModuleIds(module.id, clickType, moduleIndex));
    //  window.getSelection().removeAllRanges();
  };

  const handleSelectPageBreak = (e, itemIndex, widgetIndex, moduleId) => {
    dispatch(selectPageBreak(itemIndex, widgetIndex, moduleId));
  };

  //   useEffect(() => {
  //     if(activeContentId !== undefined && activeContentId !==0 && currentContent?.modulesAndOutsideWidgetsPositions !== undefined)
  //     dispatch(updateContentWithPositions(currentContent?.modulesAndOutsideWidgetsPositions, activeContentId));
  //  }, [currentContent?.modulesAndOutsideWidgetsPositions]);

  return (
    <Styles styles={styles}>
      <div
        className="content-edit"
        style={{
          width: "545px",
          textAlign: "center",
          position: "relative",
          paddingBottom: "180px",
        }}
      >
        {activeCursorWidgetId === undefined && activeCursorModuleId === -1 && (
          <EditPaneCursor type="lined" left="5px" />
        )}
        {pageBreakPosition.includes(-1) && (
          <div
            className={
              selectedOuterPagebreakIndex === -1
                ? "pagebreak pagebreakSelected"
                : "pagebreak"
            }
            onClick={(e) => handleSelectPageBreak(e, -1)}
          >
            <div className="zigzagSection"></div>
          </div>
        )}
        {combinedModulesandWidgets !== undefined &&
        Object.values(combinedModulesandWidgets).length > 0 ? (
          combinedModulesandWidgets.map((item, itemIndex) => (
            <>
              {item !== undefined && item.type === "module" && (
                <div
                  style={{ width: "90%", marginLeft: "5px", marginTop: "30px" }}
                  key={itemIndex}
                >
                  {activeModuleIds.indexOf(modules[item.index]?.id) > -1 &&
                  !modules[item.index]?.locked ? (
                    <>
                      <div className="top_braces_design"></div>
                      <div
                        className={
                          selectedModuleIds.indexOf(modules[item.index]?.id) >
                          -1
                            ? modules[item.index]?.readOnly
                              ? "module_hdr_nm"
                              : "module_hdr_nm module_selected"
                            : "module_hdr_nm"
                        }
                        onClick={(e) =>
                          handlePreSelectmodule(
                            e,
                            modules[item.index],
                            itemIndex
                          )
                        }
                      >
                        <span
                          onClick={(e) =>
                            handleSelectModule(e, modules[item.index])
                          }
                        >
                          {modules[item.index]?.title}
                        </span>
                      </div>
                      {modules[item.index]?.pageBreakPosition?.includes(-1) && (
                        <div
                          className={
                            selectedInnerPagebreakIndex === -1 &&
                            selectedInnerPagebreakModuleId ===
                              modules[item.index]?.id
                              ? "pagebreak pagebreakSelected"
                              : "pagebreak"
                          }
                          onClick={(e) =>
                            handleSelectPageBreak(
                              e,
                              itemIndex,
                              -1,
                              modules[item.index]?.id
                            )
                          }
                        >
                          <div className="zigzagSection"></div>
                        </div>
                      )}

                      {activeCursorWidgetId === -1 &&
                        modules[item.index]?.widgetList.length !== 0 &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="lined" />
                        )}

                      {modules[item.index]?.widgetList !== undefined &&
                      Object.values(modules[item.index]?.widgetList).length > 0
                        ? modules[item.index]?.widgetList.map(
                            (widget, widgetIndex) => (
                              <>
                                <div
                                  className={
                                    !modules[item.index]?.readOnly
                                      ? "temp"
                                      : "temp"
                                  }
                                  key={widgetIndex}
                                  style={{
                                    marginTop: "10px",
                                    textAlign: "left",
                                  }}
                                >
                                  {widget.type === BRANCH_CONTROL_WIDGET ? (
                                    <BranchControlWidget
                                      class={
                                        !modules[item.index]?.readOnly
                                          ? "clickable borderRed"
                                          : "clickable borderBlue"
                                      }
                                      widgetDetails={widget}
                                      module={modules[item.index]}
                                      handleSelectWidget={handleSelectWidget}
                                      widgetPosition="insideModule"
                                      widgetIndex={widgetIndex}
                                      moduleIndex={itemIndex}
                                      isFocus={
                                        access &&
                                        !modules[item.index]?.readOnly &&
                                        activeCursorWidgetId == widgetIndex
                                          ? true
                                          : false
                                      }
                                      readOnly={modules[item.index]?.readOnly}
                                    />
                                  ) : (
                                    <Widget
                                      class={
                                        !modules[item.index]?.readOnly
                                          ? "clickable borderRed topLeft"
                                          : "clickable borderBlue topLeft"
                                      }
                                      widgetDetails={widget}
                                      module={modules[item.index]}
                                      handleSelectWidget={handleSelectWidget}
                                      widgetPosition="insideModule"
                                      widgetIndex={widgetIndex}
                                      moduleIndex={itemIndex}
                                      isFocus={
                                        access &&
                                        !modules[item.index]?.readOnly &&
                                        activeCursorWidgetId == widgetIndex
                                          ? true
                                          : false
                                      }
                                      readOnly={modules[item.index]?.readOnly}
                                    />
                                  )}
                                  {/* <div className="widget_rb" key={index} widgetDetails={widget} >
                            <div className="widget">Letter</div>
                          </div> */}
                                </div>
                                {widgetIndex === activeCursorWidgetId &&
                                  branchWidgetCursorIndex === undefined &&
                                  executionFrameIndex === undefined &&
                                  itemIndex === activeCursorModuleId && (
                                    <EditPaneCursor type="lined" />
                                  )}
                                {modules[
                                  item.index
                                ]?.pageBreakPosition?.includes(widgetIndex) && (
                                  <div
                                    className={
                                      selectedInnerPagebreakIndex ===
                                      widgetIndex
                                        ? "pagebreak pagebreakSelected"
                                        : "pagebreak"
                                    }
                                    onClick={(e) =>
                                      handleSelectPageBreak(
                                        e,
                                        itemIndex,
                                        widgetIndex,
                                        modules[item.index]?.id
                                      )
                                    }
                                  >
                                    <div className="zigzagSection"></div>
                                  </div>
                                )}
                              </>
                            )
                          )
                        : ""}

                      {modules[item.index].widgetList.length === 0 &&
                        activeCursorWidgetId !== undefined &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="dashed" />
                        )}

                      <div
                        className={
                          selectedModuleIds.indexOf(modules[item.index]?.id) >
                          -1
                            ? modules[item.index]?.readOnly
                              ? "module_hdr_nm"
                              : "module_hdr_nm module_selected"
                            : "module_hdr_nm"
                        }
                        style={{ marginTop: "10px" }}
                        onClick={(e) =>
                          handlePreSelectmodule(
                            e,
                            modules[item.index],
                            itemIndex
                          )
                        }
                      >
                        <span
                          onClick={(e) =>
                            handleSelectModule(e, modules[item.index])
                          }
                        >
                          {modules[item.index]?.title}
                        </span>
                      </div>
                      <div className="btm_braces_design"></div>
                      {activeCursorWidgetId === undefined &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="lined" />
                        )}
                    </>
                  ) : (
                    <>
                      {/*<div className="top_braces_design"></div>
                  <div className="module_hdr_nm">{modules[item.index].moduleName}</div>
                  <div className="btm_braces_design"></div>*/}

                      <div
                        className={
                          modules[item.index]?.locked
                            ? "card-header-div lockedBorder"
                            : // activeModuleIds.indexOf(modules[item.index].id) > -1
                            selectedModuleIds.indexOf(modules[item.index]?.id) >
                              -1
                            ? modules[item.index].readOnly
                              ? "card-header-div"
                              : "card-header-div selected-module"
                            : "card-header-div"
                        }
                        //onClick={(e) => handlePreSelectmodule(e, modules[item.index].id)}
                      >
                        <span
                          className="card-header-span"
                          onClick={(e) =>
                            !modules[item.index]?.locked &&
                            handlePreSelectmodule(
                              e,
                              modules[item.index],
                              itemIndex
                            )
                          }
                        ></span>

                        <span
                          className="card-header-btn-span"
                          onClick={(e) =>
                            !modules[item.index]?.locked &&
                            handleSelectModule(e, modules[item.index])
                          }
                        >
                          {modules[item.index]?.title}
                        </span>
                      </div>

                      {modules[item.index]?.widgetList.length === 0 &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="dashed" />
                        )}

                      {/* {modules[item.index].widgetList.length > 0 &&
                        activeCursorWidgetId === -1 &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="lined" />
                        )} */}
                      {activeModuleIds.indexOf(modules[item.index]?.id) ===
                        -1 &&
                        modules[item.index]?.widgetList.length > 0 &&
                        itemIndex === activeCursorModuleId && (
                          <EditPaneCursor type="lined" />
                        )}
                    </>
                  )}
                  {pageBreakPosition.includes(itemIndex) && (
                    <div
                      className={
                        selectedOuterPagebreakIndex === itemIndex
                          ? "pagebreak pagebreakSelected"
                          : "pagebreak"
                      }
                      onClick={(e) => handleSelectPageBreak(e, itemIndex)}
                    >
                      <div className="zigzagSection"></div>
                    </div>
                  )}
                </div>
              )}

              {item !== undefined && item?.type === "widget" && (
                <>
                  <div
                    className="temp outsideWidget"
                    key={itemIndex}
                    style={{ marginTop: "10px", textAlign: "left" }}
                  >
                    {widgets[item.index]?.type === BRANCH_CONTROL_WIDGET ? (
                      <BranchControlWidget
                        class={
                          !currentContent?.processProperties?.readOnly
                            ? "clickable borderRed"
                            : "clickable borderBlue"
                        }
                        widgetDetails={widgets[item.index]}
                        module={widgets[item.index]}
                        handleSelectWidget={handleSelectWidget}
                        widgetPosition="outsideModule"
                        widgetIndex={itemIndex}
                        moduleIndex={itemIndex}
                        className="clickable"
                        isFocus={
                          access &&
                          !currentContent?.processProperties?.readOnly &&
                          activeCursorModuleId == itemIndex
                            ? true
                            : false
                        }
                        readOnly={currentContent?.processProperties?.readOnly}
                        // isFocus={activeCursorModuleId == itemIndex ? true : false}
                      />
                    ) : (
                      <Widget
                        widgetDetails={widgets[item.index]}
                        module={widgets[item.index]}
                        handleSelectWidget={handleSelectWidget}
                        widgetPosition="outsideModule"
                        widgetIndex={itemIndex}
                        moduleIndex={itemIndex}
                        class={
                          !currentContent?.processProperties?.readOnly
                            ? "clickable borderRed topLeft"
                            : "clickable borderBlue topLeft"
                        }
                        isFocus={
                          access &&
                          !currentContent?.processProperties?.readOnly &&
                          activeCursorModuleId == itemIndex
                            ? true
                            : false
                        }
                        readOnly={currentContent?.processProperties?.readOnly}
                        // isFocus={activeCursorModuleId == itemIndex ? true : false}
                      />
                    )}

                    {/* <div className="widget_rb" key={index} widgetDetails={widget} >
                  <div className="widget">Letter</div>
                </div> */}
                  </div>
                  {itemIndex === activeCursorModuleId &&
                    branchWidgetCursorIndex === undefined &&
                    activeCursorWidgetId === undefined &&
                    nestedBranchWidgetCursorIndex === undefined && (
                      <EditPaneCursor type="lined" />
                    )}
                  {pageBreakPosition.includes(itemIndex) && (
                    <div
                      className={
                        selectedOuterPagebreakIndex === itemIndex
                          ? "pagebreak pagebreakSelected"
                          : "pagebreak"
                      }
                      onClick={(e) => handleSelectPageBreak(e, itemIndex)}
                    >
                      <div className="zigzagSection"></div>
                    </div>
                  )}
                </>
              )}
            </>
          ))
        ) : (
          <div className="no_modules">
            Open Existing Content or Insert Modules, Widgets and Page-Breaks
            using the tools above to build the content here{" "}
          </div>
        )}
      </div>
    </Styles>
  );
}

export default ContentEdit;

const Styles = Styled.div`
.temp {
  margin-left: 20px;
  position: relative;
  width:483px;
}
.outsideWidget .widget_header{
  // margin-top:20px;
}
.outsideWidget .bookMarkRibbon{
  right: -82px;
}
.widget{
font-size:20px;
transform:rotate(-90deg);
margin-top:27px;
font-weight:bold;
}
.widget::after{
width: 0px;
height: 0px;
left: -106px;
border-left: 50px solid transparent;
border-right: 49px solid transparent;
border-bottom: 41px solid #fff;
position: absolute;
content: "";
bottom: -6.5px;
transform: rotate(90deg);
}
.dark_bg{
//background:#7b7878;
//background:#acacac !important;
background:${(props) =>
  props.styles.ContentHighlight_Colour?.background} !important;
}
.btm_braces_design{
margin:0 auto;
position:relative;
width:529px;
border-bottom:solid 2px;
border-radius:10px;
height:25px;
margin-left:13px;
 }
.top_braces_design{
margin:0 auto;
position:relative;
width:529px;
border-top:solid 2px;
border-radius:10px;
height:25px;
margin-left:13px;
margin-top:-13px;
}
.module_hdr_nm{
font-weight:bold;
font-size:20px;
transform: translate(6%, 10%);

}
.module_selected{
//background: #a6a2a2;
background:${(props) =>
  props.styles.ContentHighlight_Colour?.background} !important;
}
.no_modules{
font-size: 25px;
  width: 400px;
  color: gray;
  font-weight: bolder;
  padding: 26px;
  background: #f3f0f0;
}
.widget_rb{
width:100px;
height:168px;
background:#2479f2;
position:absolute;
top:63px;
right:0px;
}
.hoverBar {
position: relative;
  padding: 16px 0px;
  left: 13px;
  width:522px;
}
// .hoverBar.dashed{
//   left: 3px;
// }
.hoverBar span{
width: 522px;
height: 2px;
border-bottom: 2px solid #7b7b7b;
display: block;
}
.hoverBar.dashed span{
width: 522px;
border-bottom: 2px dashed #7b7b7b;
}
.hoverBar span:after{
content: '';
  position: absolute;
  right: -8px;
  top: 7px;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  border-right: 10px solid #7b7b7b;
  clear: both;
}
.hoverBar span:before{
content: '';
  position: absolute;
  top: 7px;
  left: -1px;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  border-left: 10px solid #7b7b7b;
  clear: both;
}
.card-header-div {
width: calc(96% - 20px);  
margin-left: 20px;
color: #707070;
border: 1px solid #707070;
border-radius: 5px;
cursor: pointer !important;
position: relative;
height: 40px;
text-align: center;
padding: 7px 0 0 0;
}
.card-header-span{
height: 100%;
width: 100%;  
z-index: 0;
position: absolute;
right: 0;
}
.card-header-btn-span{  
z-index: 1;
position: absolute;  
// left: 0;
// right: 0;
margin: 0 auto;
transform: translate(-50%, -10%);
}
.selected-module{
  background:${(props) =>
    props.styles.ContentHighlight_Colour?.background} !important;
}
.pagebreak{
    margin: 8px 0;
    position: relative;
    left: 26px;
    height:18px;
    padding: 5px 0;
}
.pagebreakSelected{
    background: #a6a2a2;
    }
.borderRed{
  border: 2px solid #f12f42;
}
.borderRed.topLeft{
  border-radius: 18px 0 0 18px;
  // overflow: hidden;
}
.clickable.borderRed{
  width: 483px;
  position: relative;
  background: #d6d6d6;
}
.borderBlue{
  border: 2px solid #0395a6;
}
.borderBlue.topLeft{
  border-radius: 18px 0 0 18px;
  // overflow: hidden;
}
.lockedBorder{
  border: 2px solid black;
}
.zigzagSection{
   height: 8px;
   background-image: url("data:image/svg+xml,%3C%3Fxml version='1.0' encoding='utf-8'%3F%3E%3C!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --%3E%3C!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3E%3Csvg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' width='34.906px' height='7.729px' viewBox='0 0 34.906 7.729' enable-background='new 0 0 34.906 7.729' xml:space='preserve'%3E%3Cg id='Layer_1' display='none'%3E%3Cg display='inline'%3E%3Cg%3E%3Cg%3E%3Cg%3E%3Cg%3E%3Cpath d='M3.287,2.246L2.468,0.669c0,0-1.121,0.573-2.215,1.204C-0.296,2.185-0.838,2.51-1.244,2.765 c-0.41,0.264-0.683,0.439-0.683,0.439l1.004,1.466c0,0,0.249-0.159,0.622-0.399c0.384-0.24,0.906-0.555,1.438-0.855 C2.195,2.805,3.287,2.246,3.287,2.246z'/%3E%3Cpath d='M9.941-0.775L9.286-2.428c0,0-1.173,0.452-2.321,0.964C6.385-1.22,5.813-0.958,5.387-0.758 C4.958-0.561,4.673-0.429,4.673-0.429l0.762,1.605c0,0,0.279-0.128,0.696-0.321C6.549,0.66,7.106,0.404,7.673,0.166 C8.794-0.334,9.941-0.776,9.941-0.775z'/%3E%3Cpath d='M16.859-3.154L16.36-4.859c0-0.001-1.206,0.352-2.4,0.742c-0.595,0.2-1.19,0.401-1.637,0.552 C11.879-3.406,11.584-3.3,11.584-3.3l0.604,1.672c0,0,0.289-0.104,0.722-0.261c0.437-0.146,1.019-0.343,1.601-0.539 C15.679-2.81,16.859-3.154,16.859-3.154z'/%3E%3Cpath d='M23.97-4.873l-0.338-1.745c0,0-0.308,0.061-0.771,0.151c-0.463,0.086-1.079,0.213-1.688,0.363 c-0.612,0.143-1.223,0.285-1.682,0.393c-0.456,0.119-0.759,0.198-0.759,0.198l0.447,1.721c0,0,0.297-0.078,0.743-0.194 c0.449-0.105,1.046-0.244,1.645-0.384c0.597-0.147,1.198-0.271,1.651-0.355C23.669-4.813,23.97-4.873,23.97-4.873z'/%3E%3Cpath d='M31.207-5.931l-0.17-1.77c0,0.001-0.313,0.025-0.781,0.085c-0.468,0.056-1.092,0.13-1.716,0.204 c-0.625,0.065-1.246,0.166-1.71,0.241c-0.466,0.073-0.776,0.123-0.776,0.123l0.284,1.754c0,0,0.303-0.048,0.758-0.12 c0.455-0.073,1.061-0.172,1.672-0.235c0.61-0.072,1.219-0.145,1.677-0.199C30.901-5.906,31.207-5.931,31.207-5.931z'/%3E%3Cpath d='M38.512-6.264l0.002-1.777c0,0-1.257-0.03-2.513,0.037c-0.628,0.022-1.256,0.045-1.727,0.063 c-0.471,0.015-0.784,0.05-0.784,0.05l0.114,1.773c0,0,0.305-0.034,0.766-0.049c0.46-0.017,1.074-0.038,1.687-0.061 C37.284-6.294,38.512-6.264,38.512-6.264z'/%3E%3Cpath d='M45.81-5.89l0.178-1.769c0,0-0.313-0.03-0.782-0.077c-0.469-0.045-1.094-0.12-1.722-0.141 c-1.255-0.066-2.51-0.133-2.51-0.133l-0.06,1.776c0,0,1.226,0.064,2.452,0.13c0.614,0.02,1.223,0.094,1.682,0.138 C45.505-5.92,45.81-5.89,45.81-5.89z'/%3E%3C/g%3E%3C/g%3E%3Cg%3E%3Cg%3E%3Cpath d='M53.04-4.8l0.35-1.742c0,0-0.309-0.062-0.771-0.153c-0.464-0.082-1.075-0.233-1.699-0.315 c-1.244-0.184-2.487-0.368-2.487-0.368l-0.235,1.762c0,0,1.215,0.18,2.429,0.359c0.609,0.079,1.207,0.229,1.66,0.309 C52.739-4.859,53.04-4.8,53.04-4.8z'/%3E%3Cpath d='M60.13-3.014l0.515-1.701c0,0-0.301-0.091-0.751-0.229c-0.451-0.135-1.048-0.333-1.661-0.473 c-1.219-0.306-2.438-0.611-2.438-0.611l-0.405,1.73c0,0,1.191,0.299,2.383,0.598c0.599,0.136,1.183,0.33,1.624,0.462 C59.836-3.103,60.13-3.014,60.13-3.014z'/%3E%3Cpath d='M67.027-0.575l0.668-1.646c0,0-1.15-0.504-2.341-0.908c-1.182-0.427-2.363-0.854-2.363-0.854l-0.567,1.685 c0,0,1.155,0.418,2.311,0.836C65.901-1.068,67.027-0.574,67.027-0.575z'/%3E%3Cpath d='M73.693,2.459l0.808-1.583c0,0-1.131-0.545-2.261-1.09c-0.565-0.271-1.131-0.544-1.555-0.748 c-0.433-0.185-0.722-0.307-0.722-0.307l-0.716,1.626c0,0,0.283,0.12,0.707,0.301c0.416,0.2,0.969,0.467,1.523,0.733 C72.585,1.926,73.693,2.459,73.693,2.459z'/%3E%3Cpolygon points='80.169,5.993 81.021,4.433 76.661,2.043 75.811,3.604 '/%3E%3Cpath d='M86.852,9.335l0.731-1.62c0-0.001-1.134-0.479-2.229-1.045c-1.104-0.547-2.208-1.093-2.208-1.093l-0.814,1.579 c0,0,1.125,0.557,2.249,1.113C85.694,8.846,86.852,9.334,86.852,9.335z'/%3E%3Cpath d='M93.791,12.125l0.586-1.678c0,0-0.295-0.085-0.726-0.251c-0.431-0.166-1.004-0.387-1.578-0.607 c-0.574-0.221-1.147-0.441-1.578-0.606c-0.431-0.164-0.708-0.299-0.708-0.299l-0.687,1.64c0,0,0.283,0.137,0.723,0.305 c0.44,0.169,1.026,0.395,1.612,0.62s1.173,0.451,1.613,0.62C93.488,12.038,93.791,12.126,93.791,12.125z'/%3E%3C/g%3E%3C/g%3E%3Cg%3E%3Cg%3E%3Cpath d='M100.982,14.237l0.411-1.729c0,0-0.299-0.068-0.748-0.171c-0.443-0.122-1.035-0.285-1.627-0.448 s-1.184-0.326-1.627-0.449c-0.438-0.144-0.729-0.239-0.729-0.239l-0.532,1.696c0,0,0.299,0.098,0.747,0.245 c0.455,0.125,1.062,0.293,1.669,0.46s1.214,0.335,1.669,0.46C100.675,14.168,100.982,14.237,100.982,14.237z'/%3E%3Cpath d='M108.375,15.542l0.203-1.766c0,0-0.304-0.034-0.76-0.087c-0.458-0.041-1.063-0.133-1.667-0.242 c-0.604-0.102-1.208-0.203-1.662-0.279c-0.455-0.07-0.753-0.14-0.753-0.14l-0.346,1.743c0,0,0.307,0.071,0.774,0.144 c0.466,0.079,1.088,0.184,1.71,0.288c0.621,0.111,1.244,0.206,1.716,0.249C108.061,15.506,108.375,15.542,108.375,15.542z'/%3E%3Cpath d='M115.884,15.929l-0.034-1.776c0,0-1.223-0.009-2.445-0.018c-0.611,0.006-1.221-0.063-1.68-0.082 c-0.458-0.028-0.763-0.048-0.763-0.048l-0.128,1.773c0,0,0.315,0.02,0.788,0.048c0.473,0.02,1.102,0.09,1.735,0.085 C114.62,15.921,115.884,15.929,115.884,15.929z'/%3E%3Cpath d='M123.385,15.232l-0.296-1.753c0,0.001-1.206,0.19-2.417,0.344c-0.608,0.059-1.216,0.116-1.671,0.16 c-0.456,0.047-0.76,0.064-0.76,0.064l0.118,1.773c0,0,0.315-0.018,0.788-0.066c0.472-0.045,1.102-0.105,1.732-0.166 C122.134,15.431,123.385,15.232,123.385,15.232z'/%3E%3Cpath d='M130.698,13.398l-0.568-1.685c0,0-0.284,0.113-0.724,0.238c-0.438,0.132-1.022,0.308-1.606,0.483 c-0.591,0.149-1.183,0.299-1.626,0.411c-0.443,0.114-0.741,0.178-0.741,0.178l0.385,1.735c0,0,0.31-0.066,0.77-0.185 c0.461-0.116,1.075-0.271,1.689-0.427c0.607-0.184,1.214-0.366,1.669-0.503C130.402,13.515,130.698,13.398,130.698,13.398z'/%3E%3Cpath d='M137.628,10.409l-0.839-1.566c0,0-1.076,0.571-2.181,1.085c-1.102,0.521-2.239,0.961-2.239,0.961l0.658,1.651 c0,0,1.183-0.458,2.33-1.001C136.507,11.005,137.629,10.409,137.628,10.409z'/%3E%3Cpath d='M143.946,6.247l-1.122-1.379c0,0-0.936,0.767-1.937,1.457c-0.991,0.702-2.033,1.332-2.033,1.332l0.928,1.516 c0,0,1.087-0.657,2.126-1.393C142.957,7.058,143.946,6.247,143.946,6.247z'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3Cg display='inline'%3E%3Cg%3E%3Cpath fill='none' stroke='%23000000' stroke-miterlimit='10' d='M351.454-95.813'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3Cg id='Layer_2'%3E%3Cpath fill='none' stroke='%23000000' stroke-miterlimit='10' d='M-1.439,3.813'/%3E%3Cg%3E%3Cg%3E%3Cg%3E%3Cg%3E%3Cpath d='M4.087,2.919L3.415,1.273c0,0-0.885,0.36-1.726,0.817C1.27,2.322,0.856,2.566,0.552,2.768 c-0.157,0.107-0.288,0.197-0.38,0.26c-0.083,0.061-0.13,0.095-0.13,0.095l1.067,1.422c0.01-0.008,0.17-0.128,0.42-0.292 C1.792,4.078,2.16,3.861,2.535,3.654C3.289,3.244,4.087,2.919,4.087,2.919z'/%3E%3Cpath d='M9.036,1.827L8.963,0.051c0,0-0.242-0.014-0.6,0.03c-0.358,0.043-0.835,0.1-1.313,0.156 C6.581,0.335,6.111,0.432,5.759,0.505C5.415,0.604,5.185,0.67,5.185,0.67l0.491,1.709c0,0,0.206-0.061,0.515-0.15 c0.314-0.064,0.732-0.151,1.151-0.237C7.765,1.94,8.188,1.891,8.505,1.853C8.823,1.812,9.036,1.827,9.036,1.827z'/%3E%3Cpath d='M14.008,2.587l0.59-1.676c0,0-0.228-0.076-0.57-0.19c-0.171-0.056-0.371-0.121-0.585-0.191 c-0.221-0.046-0.457-0.095-0.693-0.145c-0.938-0.236-1.904-0.287-1.904-0.287l-0.149,1.771c0,0.001,0.851,0.042,1.677,0.254 c0.208,0.043,0.417,0.085,0.611,0.125c0.189,0.063,0.367,0.121,0.518,0.172C13.806,2.52,14.008,2.587,14.008,2.587z'/%3E%3Cpath d='M18.585,5.042l0.941-1.508c0,0-0.769-0.48-1.538-0.962c-0.408-0.245-0.798-0.52-1.122-0.676 c-0.325-0.154-0.541-0.257-0.541-0.257l-0.779,1.598c0,0,0.193,0.091,0.484,0.228c0.29,0.139,0.643,0.393,1.012,0.613 C17.814,4.56,18.585,5.042,18.585,5.042z'/%3E%3Cpath d='M23.815,7.271l0.389-1.734c0,0-0.209-0.043-0.522-0.107c-0.304-0.102-0.709-0.236-1.115-0.371 C22.15,4.94,21.78,4.75,21.498,4.615c-0.284-0.134-0.473-0.223-0.473-0.223L20.169,5.95c0,0,0.223,0.106,0.556,0.266 c0.333,0.16,0.777,0.381,1.239,0.513c0.458,0.152,0.916,0.304,1.259,0.417C23.579,7.221,23.815,7.271,23.815,7.271z'/%3E%3Cpath d='M29.539,7.446L29.25,5.692c0,0-0.212,0.025-0.53,0.062c-0.319,0.03-0.742,0.109-1.168,0.096 c-0.854,0.05-1.701-0.053-1.701-0.053l-0.165,1.771c0-0.001,0.963,0.113,1.932,0.059c0.485,0.011,0.962-0.072,1.323-0.108 C29.299,7.475,29.539,7.446,29.539,7.446z'/%3E%3Cpath d='M34.914,5.567l-0.857-1.557c0,0-0.756,0.409-1.55,0.745c-0.404,0.146-0.802,0.313-1.11,0.405 c-0.309,0.091-0.515,0.151-0.515,0.151l0.49,1.709c0,0,0.23-0.068,0.576-0.17c0.345-0.105,0.788-0.289,1.239-0.453 C34.07,6.026,34.914,5.567,34.914,5.567z'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A");
    background-repeat-y: no-repeat;
}
`;
