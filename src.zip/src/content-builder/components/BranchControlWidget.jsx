import React, { useRef, useEffect, useState } from "react";
import styled from "styled-components";
import { useSelector, useDispatch, batch } from "react-redux";
import SelectInput from "react-select";
import EditPaneCursor from "./EditPaneCursor";
import BranchWidgetList from "./BranchWidgetList";
import { SkipWidget, SwitchWidget } from "./BranchWidgets";
import { MentionsInput, Mention } from "react-mentions";
import currentContentObjects from "./GetCurrentContentObjects";
import getNewWidgetByType from "./WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import widgetFieldLabelExist from "./WidgetLabelGenerate/WidgetFieldLabelExist";

import {
  COMPRESSED_VIEW,
  STANDARD_VIEW,
  ADVANCED_VIEW,
  BOOKMARK,
  EXPORT,
  REQUIRED,
  HIDE,
  TEXT_INPUT_WIDGET,
  BINARY_INPUT_WIDGET,
  TIME_INPUT_WIDGET,
  WARNING_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DATE_WIDGET,
  DROPDOWNLIST_WIDGET,
  NUMBER_WIDGET,
  NARRATIVE_WIDGET,
  CALCULATION_WIDGET,
  SKIP_WIDGET,
  EXECUTE_WIDGET,
  SWITCH_WIDGET,
  JUMP_WIDGET,
  BRANCH_CONTROL_WIDGET,
  BLANK_WIDGET,
} from "./Constants";
import {
  holdCursor,
  setContentModifiedFlag,
  setAdvancedViewByWidgetIds,
  setCompressedViewByWidgetIds,
  setStandardViewByWidgetIds,
  setCursorSelectedStatus,
  setCurrentViewMode,
  setWidgetFormTextEnteredStatus,
  setWidgetDefaultNameShowedStatus,
  saveContentDatainBrowser,
  toggleWidget,
  setActiveBranchCursorId,
  addWidgetBy_insideBranchWidget,
  addWidgetBy_outsideBranchWidget,
  createNewBranchWidgetByWidget,
  createNewBranchWidgetByWidgetWithoutCondition,
  setActiveModuleId,
  setGlobalLogoWidget,
  setIsGlobalLogoPopupVisible,
  setGlobalLogoSelectedWidgets,
} from "../../store/content";
import { renderLabel, getIndex } from "./functions";
import { getExistingWidgets } from "../components/WidgetLabelGenerate/GetExistingExportWidgets";
import { set } from "lodash";

export default function BranchControlWidget(props) {
  const inputRef = useRef(null);
  const inputTitleRef = useRef(null);
  const [str, setStr] = useState("");
  const [widgetFieldEditIds, setWidgetFieldEditIds] = useState([]);
  const dispatch = useDispatch();
  // const [dummy, setDummy] = usestate(null)
  const {
    contents,
    activeContentId,
    cursorSelectedStatus,
    // selectedWidgetIds,
    // activeModuleId,
    // advancedViewWidgetIds,
    // compressedViewWidgetIds,
    // standardViewWidgetIds,
    //selectedModuleIds
  } = useSelector((state) => state.content);

  const styles = useSelector((state) => state.ui.styles);
  let currentContent =
    contents?.length > 0 &&
    contents.find((content) => content.contentId === activeContentId);
  let content = currentContentObjects(contents, activeContentId);
  let activeModuleId = currentContent?.activeModuleId
    ? currentContent.activeModuleId
    : 0;
  // let selectedWidgetIds =
  //   currentContent?.selectedWidgetIds.length > 0
  //     ? currentContent.selectedWidgetIds
  //     : [];
  let selectedModuleIds =
    currentContent?.selectedModuleIds.length > 0
      ? currentContent.selectedModuleIds
      : [];
  let modules =
    currentContent?.moduleList.length > 0 ? currentContent.moduleList : [];
  let selectedOuterWidgetIds =
    currentContent?.selectedOuterWidgetIds?.length > 0
      ? currentContent.selectedOuterWidgetIds
      : [];

  let advancedViewWidgetIds =
    currentContent?.advancedViewWidgetIds?.length > 0
      ? currentContent.advancedViewWidgetIds
      : [];
  let compressedViewWidgetIds =
    currentContent?.compressedViewWidgetIds?.length > 0
      ? currentContent.compressedViewWidgetIds
      : [];
  let standardViewWidgetIds =
    currentContent?.standardViewWidgetIds?.length > 0
      ? currentContent.standardViewWidgetIds
      : [];

  let combinedModulesandWidgets =
    currentContent?.modulesAndOutsideWidgetsPositions?.length > 0
      ? currentContent.modulesAndOutsideWidgetsPositions
      : [];
  let activeCursorModuleId =
    currentContent?.activeCursorModuleId !== undefined
      ? currentContent.activeCursorModuleId
      : undefined;
  let activeCursorWidgetId =
    currentContent?.activeCursorWidgetId !== undefined
      ? currentContent.activeCursorWidgetId
      : undefined;
  let widgets = currentContent?.widgetList ? currentContent.widgetList : [];
  let branchWidgetCursorIndex =
    currentContent?.branchWidgetCursorIndex !== undefined
      ? currentContent.branchWidgetCursorIndex
      : undefined;
  let nestedBranchCursorIndex =
    currentContent?.nestedBranchWidgetCursorIndex !== undefined
      ? currentContent.nestedBranchWidgetCursorIndex
      : undefined;
  let selectedWidgetIds =
    currentContent?.selectedWidgetsData?.widgetIds?.length > 0
      ? currentContent?.selectedWidgetsData?.widgetIds
      : [];
  let executionFrameIndex =
    currentContent?.executionFrameCursorId !== undefined
      ? currentContent.executionFrameCursorId
      : undefined;
  let globalLogoRefwidget = currentContent.globalRefWidget
    ? currentContent.globalRefWidget
    : {};
  let globalLogoSelectedWidgets = content?.globalLogoSelectedWidgets;
  const options = [
    {
      value: TEXT_INPUT_WIDGET,
      label: renderLabel(styles.icons.text_widget, TEXT_INPUT_WIDGET),
    },
    {
      value: BINARY_INPUT_WIDGET,
      label: renderLabel(
        styles.icons.binary_choice_widget,
        BINARY_INPUT_WIDGET
      ),
    },
    {
      value: MULTI_CHOICE_WIDGET,
      label: renderLabel(styles.icons.multi_choice_widget, MULTI_CHOICE_WIDGET),
    },
    {
      value: SINGLE_CHOICE_WIDGET,
      label: renderLabel(
        styles.icons.single_choice_widget,
        SINGLE_CHOICE_WIDGET
      ),
    },
    {
      value: DATE_WIDGET,
      label: renderLabel(styles.icons.date_widget, DATE_WIDGET),
    },
    {
      value: NUMBER_WIDGET,
      label: renderLabel(styles.icons.number_widget, NUMBER_WIDGET),
    },
    {
      value: DROPDOWNLIST_WIDGET,
      label: renderLabel(styles.icons.dropdownlist_widget, DROPDOWNLIST_WIDGET),
    },
    {
      value: TIME_INPUT_WIDGET,
      label: renderLabel(styles.icons.time_widget, TIME_INPUT_WIDGET),
    },
    {
      value: WARNING_INPUT_WIDGET,
      label: renderLabel(styles.icons.warning_widget, WARNING_INPUT_WIDGET),
    },
    {
      value: CALCULATION_WIDGET,
      label: renderLabel(styles.icons.calculation_widget, CALCULATION_WIDGET),
    },
    {
      value: NARRATIVE_WIDGET,
      label: renderLabel(styles.icons.narrative_widget, NARRATIVE_WIDGET),
    },
    {
      value: BRANCH_CONTROL_WIDGET,
      label: renderLabel(styles.icons.branch_widget, BRANCH_CONTROL_WIDGET),
    },
  ];
  const allWidgets = getExistingWidgets(currentContent);
  let mentionWidgets = [];
  if (allWidgets?.length > 0) {
    allWidgets.map((widget) => {
      if (widget.type !== "warning")
        mentionWidgets.push({ id: widget.id, display: widget.title });
    });
  }
  useEffect(() => {
    if (globalLogoSelectedWidgets?.length > 0) {
      let selectedWidgets = globalLogoSelectedWidgets[0];
      dispatch(setGlobalLogoSelectedWidgets([]));
      let mention = ` @[${selectedWidgets.title}](${selectedWidgets.id})`;
      if (props.widgetDetails.id === globalLogoRefwidget.widgetId) {
        if (globalLogoRefwidget.field === "branchField") {
          handleInputWidget(
            {
              target: {
                value: mention,
                name: "",
              },
            },
            "field",
            globalLogoRefwidget.fieldIndex,
            globalLogoRefwidget.j
          );
        } else if (globalLogoRefwidget.field === "branchValue") {
          handleInputWidget(
            {
              target: {
                value: mention,
                name: "",
              },
            },
            "value",
            globalLogoRefwidget.fieldIndex,
            globalLogoRefwidget.j
          );
        }
      }
    }
  }, [globalLogoSelectedWidgets]);
  const globalLogoRef = (e, id, field, index, j) => {
    let obj = {
      widgetId: id,
      field: field,
      fieldIndex: index,
      j: j,
    };
    dispatch(setGlobalLogoWidget(obj));
    dispatch(setIsGlobalLogoPopupVisible(true));
  };
  const addBranchWidget = (e) => {
    let activeModuleId = 0;
    // alert(currentContent.activeCursorWidgetId)
    if (currentContent.activeCursorWidgetId != undefined) {
      activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
        (x, index) =>
          index === currentContent?.activeCursorModuleId && x.type === "module"
      )?.id;
      content.activeModuleId = activeModuleId;
      currentContent.condition = e;
      currentContent.activeModuleId = activeModuleId;
    }
    console.log("moduleId", activeModuleId);
    if (currentContent.activeCursorWidgetId === undefined) {
      activeModuleId = 0;
      currentContent.moduleId = 0;
    }
    // dispatch(setActiveModuleId(activeModuleId));
    let widget = getNewWidgetByType(content, "blank");
    let widgetCreateData = {
      contentId: activeContentId,
      moduleId: activeModuleId,
      type: widget.widgetType,
    };

    dispatch(
      createNewBranchWidgetByWidget(
        widgetCreateData,
        widget,
        activeCursorWidgetId,
        content
      )
    );
  };
  const addBranchWidgetCondition = (e) => {
    let activeModuleId = 0;
    // alert(currentContent.activeCursorWidgetId)
    if (currentContent.activeCursorWidgetId != undefined) {
      activeModuleId = currentContent?.modulesAndOutsideWidgetsPositions.find(
        (x, index) =>
          index === currentContent?.activeCursorModuleId && x.type === "module"
      )?.id;
      content.activeModuleId = activeModuleId;
      currentContent.condition = e;
      currentContent.activeModuleId = activeModuleId;
    }
    let widget = getNewWidgetByType(content, "blank");
    let widgetCreateData = {
      contentId: activeContentId,
      moduleId: activeModuleId,
      type: widget.widgetType,
    };

    dispatch(
      createNewBranchWidgetByWidgetWithoutCondition(
        widgetCreateData,
        widget,
        activeCursorWidgetId,
        content
      )
    );
  };

  /**
   * focus set to latest created widget
   */

  const renderSwitch = () => {
    switch (props.widgetDetails?.branchControlType) {
      case SKIP_WIDGET:
        return (
          <SkipWidget
            mentionWidgets={mentionWidgets}
            branchConditions={props.widgetDetails.branchConditions}
            handleAddORgate={handleAddORgate}
            handleAddANDgate={handleAddANDgate}
            handleDeleteCondition={handleDeleteCondition}
            handleInputWidget={handleInputWidget}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
            widget={props.widgetDetails}
          />
        );
      case EXECUTE_WIDGET:
        return (
          <SkipWidget
            mentionWidgets={mentionWidgets}
            branchConditions={props.widgetDetails.branchConditions}
            handleAddORgate={handleAddORgate}
            handleAddANDgate={handleAddANDgate}
            handleDeleteCondition={handleDeleteCondition}
            handleInputWidget={handleInputWidget}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
            widget={props.widgetDetails}
          />
        );
      case SWITCH_WIDGET:
        return (
          <SwitchWidget
            mentionWidgets={mentionWidgets}
            branchConditions={props.widgetDetails.branchConditions}
            handleAddORgate={handleAddORgate}
            handleAddANDgate={handleAddANDgate}
            handleDeleteCondition={handleDeleteCondition}
            handleInputWidget={handleInputWidget}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
            widget={props.widgetDetails}
          />
        );
      case JUMP_WIDGET:
        return (
          <SkipWidget
            mentionWidgets={mentionWidgets}
            branchConditions={props.widgetDetails.branchConditions}
            handleAddORgate={handleAddORgate}
            handleAddANDgate={handleAddANDgate}
            handleDeleteCondition={handleDeleteCondition}
            handleInputWidget={handleInputWidget}
            globalLogoRef={globalLogoRef}
            icons={styles.icons}
            widget={props.widgetDetails}
          />
        );
      default:
        return false;
    }
  };
  /**
   * focus set to latest created widget
   */
  useEffect(() => {
    if (inputTitleRef.current) inputTitleRef.current.focus();
  }, [widgetFieldEditIds?.length > 0]);
  const handleWidgetLableEdit = () => {
    setWidgetFieldEditIds(props.widgetDetails.id);
  };
  /**
   * Function to get the class name based on type of the widget.
   *  @return {string} - will return backgroud class
   */
  const getBackgroundClass = () => {
    switch (props.widgetDetails?.widgetType) {
      case WARNING_INPUT_WIDGET:
        return { class: "background_warn", color: "#f1420d" };
      case NARRATIVE_WIDGET:
        return { class: "nara_bg", color: "#ec04e5" };
      case CALCULATION_WIDGET:
        return { class: "calc_bg", color: "#f79032" };
      default:
        return { class: "background", color: "#f2f2f2" };
    }
  };

  /**
   * swap widget view mode based on existing view mode
   */
  const handleWidgetViewModeChange = (e, widget, viewType) => {
    if (e) e.preventDefault();
    switch (viewType) {
      case STANDARD_VIEW:
        batch(() => {
          dispatch(setAdvancedViewByWidgetIds(widget.id));
          if (standardViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setStandardViewByWidgetIds(widget.id));
          //dispatch(setCurrentViewMode(STANDARD_VIEW));
          props.widgetDetails.widgetCurrentViewMode = STANDARD_VIEW;
        });
        break;
      case ADVANCED_VIEW:
        batch(() => {
          dispatch(setCompressedViewByWidgetIds(widget.id));
          if (advancedViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setAdvancedViewByWidgetIds(widget.id));
          // dispatch(setCurrentViewMode(COMPRESSED_VIEW));
          props.widgetDetails.widgetCurrentViewMode = COMPRESSED_VIEW;
        });
        break;
      case COMPRESSED_VIEW:
        batch(() => {
          dispatch(setStandardViewByWidgetIds(widget.id));
          if (compressedViewWidgetIds.indexOf(widget.id) > -1)
            dispatch(setCompressedViewByWidgetIds(widget.id));
          // dispatch(setCurrentViewMode(STANDARD_VIEW));
          props.widgetDetails.widgetCurrentViewMode = STANDARD_VIEW;
        });
        break;
      default:
        return false;
    }
  };

  /**
   * Func to handle Time field when new time selected
   * @param {string} time - HH:mm format time string
   * @param {string} widgetProp - to select widgetDetails property
   */
  function handleTimeFieldChange(time, widgetProp) {
    dispatch(setContentModifiedFlag(true));
    switch (widgetProp) {
      case "time_minValue":
        props.widgetDetails.time_minValue = time;
        break;
      case "time_maxValue":
        props.widgetDetails.time_maxValue = time;
        break;
      case "time_defaultValue":
        props.widgetDetails.time_defaultValue = time;
        break;
      default:
        return "";
    }
    dispatch(saveContentDatainBrowser());
  }

  /**
   * Func to handle Date field when new date selected.
   * @param {object} date - Select date object
   * @param {string} widgetProp - to select widgetDetails property
   */
  const handleDateFieldChange = (date, widgetProp) => {
    console.log("be date ", date);
    console.log("widgetProp", widgetProp);
    // if(date) date = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
    console.log("af date ", date);
    // return
    dispatch(setContentModifiedFlag(true));
    switch (widgetProp) {
      case "date_minValue":
        props.widgetDetails.date_minValue = date;
        break;
      case "date_maxValue":
        props.widgetDetails.date_maxValue = date;
        break;
      case "date_defaultValue":
        props.widgetDetails.date_defaultValue = date;
        break;
      default:
        return false;
    }

    dispatch(saveContentDatainBrowser());
  };

  function getFieldLabelName(widgetFormText) {
    const maximumFieldLableNameLength = 31;
    let splitWidgetFormText = widgetFormText?.trim()?.split(" ");
    let fieldLableName = "";
    if (splitWidgetFormText?.length >= 2) {
      let firstWord = getFirstWordUpperCase(splitWidgetFormText[0]);
      let secondWord = getFirstWordUpperCase(splitWidgetFormText[1]);
      fieldLableName = firstWord + secondWord;
    } else if (splitWidgetFormText?.length >= 1) {
      fieldLableName = getFirstWordUpperCase(splitWidgetFormText[0]);
    }
    if (fieldLableName) {
      //restrict max length for field label name
      fieldLableName =
        fieldLableName.length > maximumFieldLableNameLength
          ? fieldLableName.substr(0, maximumFieldLableNameLength) + "..."
          : fieldLableName;
    }
    return fieldLableName;
  }

  function getFirstWordUpperCase(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  function checkFieldLabelNameExist(fieldLabelName) {
    let existWidgetNames = [];
    const currentModules = contents.find(
      (content) => content.contentId === activeContentId
    ).moduleList;
    const currentContent = contents.find(
      (content) => content.contentId === activeContentId
    );
    let widgetIsExist = -1;
    if (currentContent?.widgetList.length > 0) {
      widgetIsExist = currentContent.widgetList.findIndex(
        (widget) => widget.id === props.widgetDetails?.id
      );
    }

    if (widgetIsExist > -1) {
      currentContent.widgetList.map((widget, widgetIndex) => {
        console.log("widget title ", widget.title);
        if (
          widget?.title?.includes(fieldLabelName) &&
          widget?.title?.length <= fieldLabelName?.length + 3
        ) {
          existWidgetNames.push(widget.title);
        }
      });
    } else {
      currentModules.map((module, index) => {
        module.widgetList.map((widget, widgetIndex) => {
          console.log("widget title ", widget?.title);
          if (
            widget?.title?.includes(fieldLabelName) &&
            widget?.title?.length <= fieldLabelName?.length + 3
          ) {
            existWidgetNames.push(widget.title);
          }
        });
      });
    }

    console.log("existWidgetNames:", existWidgetNames);
    //&& isWidgetNameExist
    if (existWidgetNames.length > 0) {
      let recentWidgetName = existWidgetNames[existWidgetNames.length - 1];
      if (recentWidgetName.includes("0")) {
        fieldLabelName = getlatestFieldName(recentWidgetName);
      } else {
        fieldLabelName = fieldLabelName + "001";
      }
    }
    return fieldLabelName;
  }

  function getlatestFieldName(recentWidgetName) {
    let lastFieldLabelNumber = 1;
    lastFieldLabelNumber = parseInt(
      recentWidgetName.match(/\d+/g)[0].replace(/\b0+/g, "")
    );
    lastFieldLabelNumber++;

    let numberOfZeros =
      parseInt(lastFieldLabelNumber) <= 9
        ? "00"
        : parseInt(lastFieldLabelNumber) <= 99
        ? "0"
        : "000";

    let widgetFieldLabelName =
      recentWidgetName.match(/[a-zA-Z]+/g)[0] +
      numberOfZeros +
      lastFieldLabelNumber;

    return widgetFieldLabelName;
  }

  const handleWidgetType = (id, value) => {
    console.log("error", value);
    if (value === "branch") {
      props.widgetDetails.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "<",
              value: "",
            },
          ],
        },
      ];
      props.widgetDetails.branchControlType = "skip";
      dispatch(saveContentDatainBrowser());
    } else {
      dispatch(toggleWidget({ id, type: value }));
    }
  };

  const handleAddORgate = (e) => {
    if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));
    props.widgetDetails.branchConditions = [
      ...props.widgetDetails.branchConditions,
      { conditions: [{ field: "", expression: "<", value: "" }] },
    ];
    if (props.widgetDetails.branchControlType === "switch") {
      addBranchWidget();
    }
    dispatch(saveContentDatainBrowser());
  };

  const handleAddANDgate = (e, i) => {
    if (e) e.stopPropagation();
    dispatch(setContentModifiedFlag(true));

    if (props.widgetDetails.branchControlType === "switch") {
      addBranchWidget();
    } else {
      props.widgetDetails.branchConditions[i].conditions.push({
        field: "",
        expression: "<",
        value: "",
      });
    }
    dispatch(saveContentDatainBrowser());
  };

  const handleDeleteCondition = (e, i, j) => {
    if (e) e.stopPropagation();
    console.log("delete", e.target.name, i, j);
    console.log("delete", props.widgetDetails.branchConditions);
    dispatch(setContentModifiedFlag(true));

    if (props.widgetDetails.branchControlType === "switch") {
      props.widgetDetails.branchConditions.splice(i, 1);
      if (props.widgetDetails.branchConditions.length === 0) {
        props.widgetDetails.branchConditions = [
          {
            conditions: [
              {
                field: "",
                expression: "<",
                value: "",
              },
            ],
          },
        ];
      }
    } else {
      props.widgetDetails.branchConditions[i].conditions.splice(j, 1);
      if (props.widgetDetails.branchConditions[i].conditions.length === 0) {
        props.widgetDetails.branchConditions.splice(i, 1);
      }
      if (props.widgetDetails.branchConditions.length === 0) {
        props.widgetDetails.branchConditions = [
          {
            conditions: [
              {
                field: "",
                expression: "<",
                value: "",
              },
            ],
          },
        ];
      }
    }
    // }
    if (props.widgetDetails.branchControlType === "switch") {
      if (props.widgetDetails.widgetList.length === 1) {
        props.widgetDetails.widgetList.splice(j, 1);
        props.widgetDetails.branchConditions = [];
        addBranchWidget();
      } else {
        props.widgetDetails.widgetList.splice(j, 1);
      }
    }
    dispatch(saveContentDatainBrowser());
  };

  const handleBranchTypeChange = (e) => {
    if (e) e.stopPropagation();
    // dispatch(setActiveBranchCursorId(-1));
    dispatch(holdCursor(false));
    e.target.blur();
    // dispatch(setCursorSelectedStatus(false))
    dispatch(setContentModifiedFlag(true));
    if (advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1) {
      handleWidgetViewModeChange(
        e,
        props.widgetDetails,
        advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1
          ? ADVANCED_VIEW
          : STANDARD_VIEW
      );
    }

    // dispatch(setActiveCursorModuleId(0));
    // dispatch(setActiveCursorWidgetId(0));

    props.widgetDetails.branchControlType = e.target.value;
    // if (branchWidgetCursorIndex === props.widgetIndex) {
    if (e.target.value === "switch") {
      props.widgetDetails.branchConditions = [];
      props.widgetDetails.widgetList = [];
      addBranchWidget(-1);
    } else {
      props.widgetDetails.branchConditions = [
        {
          conditions: [
            {
              field: "",
              expression: "<",
              value: "",
            },
          ],
        },
      ];
      props.widgetDetails.widgetList = [];
    }

    dispatch(setActiveBranchCursorId(undefined));
    dispatch(saveContentDatainBrowser());
  };
  const getFieldType = (e) => {
    let string = e;
    string = string.substring(
      string.lastIndexOf("(") + 1,
      string.lastIndexOf(")")
    );
    let selwidget = allWidgets.filter((sel, idx) => {
      return sel.id === string;
    });
    let type = "";
    if (selwidget) {
      type = selwidget[0]?.type;
    }

    let str = e + "(" + type + ")";
    // e.replace(/\s/g, "");
    const newText = str.split(/\s/).join("");
    console.log("mention", newText);
    return newText;
  };
  // Common function to handle call back functions from binary, single choice, multiple choice, drop-down, number widgets.
  const handleInputWidget = (e, type, i, j) => {
    // if (e) e.stopPropagation();
    let { value, name } = e.target;
    dispatch(setContentModifiedFlag(true));
    switch (type) {
      case "field":
        let fieldtype = getFieldType(value);

        if (value.includes("@[")) {
          let valuearr = value.split("@");
          if (valuearr.length > 0) {
            value = "@" + valuearr[1];
          }
        }

        value = value.replace(/(@)/g, " @"); //include space before @
        // value = value.replace(/  +/g, "");
        // value = value.replace(/\s+/g, "");
        console.log("raw", value);
        props.widgetDetails.branchConditions[i].conditions[
          j
        ].fieldType = fieldtype;
        let id2 = value.split("(").pop().split(")")[0];

        console.log("id", id2);
        // value = value.replace(/\s+/g, " ");//remove unwanted spaces between the character
        props.widgetDetails.branchConditions[i].conditions[j].fieldId = id2;
        props.widgetDetails.branchConditions[i].conditions[j].field = value;
        break;
      case "value":
        let valuetype = getFieldType(value);
        if (value.includes("@[")) {
          let valuearr = value.split("@");
          if (valuearr.length > 0) {
            value = "@" + valuearr[1];
          }
        }
        value = value.replace(/(@)/g, " @"); //include space before @
        // value = value.replace(/  +/g, "");
        // value = value.replace(/\s+/g, "");
        console.log("raw", value);
        let id1 = value.split("(").pop().split(")")[0];

        props.widgetDetails.branchConditions[i].conditions[
          j
        ].valuetype = valuetype;
        props.widgetDetails.branchConditions[i].conditions[j].value = value;
        props.widgetDetails.branchConditions[i].conditions[j].valueId = id1;
        break;
      case "expression":
        props.widgetDetails.branchConditions[i].conditions[
          j
        ].expression = value;
        break;
      case HIDE:
        props.widgetDetails.hide = !props.widgetDetails.hide;
        break;
      case BOOKMARK:
        props.widgetDetails.bookmark = !props.widgetDetails.bookmark;
        break;
      default:
        return false;
    }
    dispatch(saveContentDatainBrowser());
  };
  const handleWidgetTitleChange = (e) => {
    if (e) e.stopPropagation();

    const { value } = e.target;

    const widgetFormTextValidate = /^[a-zA-Z0-9\ ]*$/;
    if (!widgetFormTextValidate.test(value)) return;
    props.widgetDetails.title = value;
    dispatch(setContentModifiedFlag(true));
    dispatch(saveContentDatainBrowser());
  };
  const handleWidgetTitleBlur = (e) => {
    const { name, value } = e.target;
    if (!value) {
      props.widgetDetails.title = props.widgetDetails.widgetDefaultName;
      setWidgetFieldEditIds([]);
      dispatch(setContentModifiedFlag(true));
      dispatch(saveContentDatainBrowser());
      alert("Widget label name should not be empty!");
      return;
    }

    let newFieldLabel = getFieldLabelName(value);
    if (newFieldLabel) {
      props.widgetDetails.isWidgetFieldLabelExist = widgetFieldLabelExist(
        newFieldLabel,
        content,
        props.widgetDetails.id,
        props.widgetDetails
      );
      if (props.widgetDetails.isWidgetFieldLabelExist) {
        alert("Widget label name already exists!");
        dispatch(setContentModifiedFlag(true));
        //props.widgetDetails.title = newFieldLabel;
        props.widgetDetails.title = props.widgetDetails.widgetDefaultName;
        dispatch(saveContentDatainBrowser());
        setWidgetFieldEditIds([]);
      } else {
        props.widgetDetails.title = newFieldLabel;
        props.widgetDetails.widgetDefaultName = newFieldLabel;
        setWidgetFieldEditIds([]);
        dispatch(setContentModifiedFlag(true));
      }
      //dispatch(setWidgetDuplicateStatus(props.widgetDetails.id, props.widgetDetails.isWidgetFieldLabelExist));
    }
  };
  const handleTitleKeyPress = (event) => {
    if (event.key === "Enter") {
      inputTitleRef.current.blur();
    }
  };
  const getRawCondition = () => {
    let str = "";
    let switchStr = "";
    let conditions = props.widgetDetails?.branchConditions;
    if (props.widgetDetails?.branchControlType === "switch") {
      conditions.map((x) => {
        let con = x.conditions[0];
        switchStr =
          switchStr +
          `(${con.field ? con.field : "NULL"} ${con.expression} ${
            con.value ? con.value : "NULL"
          }) and `;
      });
      str = switchStr.substring(0, switchStr.length - 5);
      str = `(${str})`;
      setStr(str);
      return str;
    } else {
      conditions.map((x) => {
        let con = x.conditions;
        let andStr = "";
        con.map((y) => {
          andStr =
            andStr +
            `(${y.field ? y.field : "NULL"} ${y.expression} ${
              y.value ? y.value : "NULL"
            }) and `;
        });
        andStr = andStr.substring(0, andStr.length - 5);
        let newStr = `(${andStr}) or `;
        str = str + newStr;
      });
      str = str.substring(0, str.length - 4);
      setStr(str);
      return str;
    }
  };
  const convertToObject = () => {
    let conStr = str;
    if (str === "") {
      conStr = "((NULL < NULL))";
    }
    if (props.widgetDetails.branchControlType === "switch") {
      let string = conStr.slice(1, -1);
      let rawArr = string.split("and");
      let arr = [];
      rawArr.map((x) => {
        x = x.trim();
        // const userKeyRegExp = /^[A-Z][]\ [0-9][A-Z]\ [0-9]{2}[A-Z]?$/;
        let y = x.slice(1, -1);
        let rawFieldArr = y.split(" ");
        let obj = {
          field: rawFieldArr[0] === "NULL" ? "" : rawFieldArr[0],
          expression: rawFieldArr[1],
          value: rawFieldArr[2] === "NULL" ? "" : rawFieldArr[2],
        };
        let newObj = {
          conditions: [obj],
        };
        arr.push(newObj);
      });
      let defaultConditions = props.widgetDetails.branchConditions;
      let count = arr.length - defaultConditions.length;
      if (count > 0) {
        for (let step = count; step > 0; step--) {
          addBranchWidgetCondition();
        }
      } else {
        for (let step = count; step < 0; step++) {
          props.widgetDetails.widgetList.pop();
          if (currentContent.branchWidgetCursorIndex !== undefined) {
            currentContent.branchWidgetCursorIndex =
              currentContent.branchWidgetCursorIndex - 1;
          }
        }
      }

      props.widgetDetails.branchConditions = arr;
      dispatch(saveContentDatainBrowser());
    } else {
      let rawArr = conStr.split("or");
      let mainArr = [];
      rawArr.map((x) => {
        x = x.trim();
        let string = x.slice(1, -1);
        let newArr = string.split("and");
        let conArr = [];
        newArr.map((y) => {
          y = y.trim();
          let finalString = y.slice(1, -1);
          let objArr = finalString.split(" ");
          let obj = {
            field: objArr[0] === "NULL" ? "" : objArr[0],
            expression: objArr[1],
            value: objArr[2] === "NULL" ? "" : objArr[2],
          };
          console.log("raw", finalString);
          conArr.push(obj);
        });

        let conObj = {
          conditions: conArr,
        };
        mainArr.push(conObj);
      });
      props.widgetDetails.branchConditions = mainArr;
      dispatch(saveContentDatainBrowser());
    }
  };
  const changeMode = (e) => {
    if (advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1) {
      convertToObject();
      handleWidgetViewModeChange(
        e,
        props.widgetDetails,
        advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1
          ? ADVANCED_VIEW
          : STANDARD_VIEW
      );
    } else {
      handleWidgetViewModeChange(
        e,
        props.widgetDetails,
        advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1
          ? ADVANCED_VIEW
          : STANDARD_VIEW
      );
      getRawCondition();
    }
  };

  return (
    <Styles styles={styles} widgetHeaderColor={getBackgroundClass().color}>
      <div
        className={
          props?.readOnly
            ? "branchWidgetContainer pointerEvent"
            : "branchWidgetContainer"
        }
        style={{
          paddingBottom:
            props.widgetDetails?.branchControlType !== "jump" ? "30px" : "0px",
        }}
      >
        <div
          onClick={(e) =>
            props.handleSelectWidget(
              e,
              props.widgetPosition,
              props.widgetDetails,
              props.module,
              props.widgetIndex,
              props.moduleIndex
            )
          }
          className={props.class}
        >
          <div
            className={"widget_header " + getBackgroundClass().class}
            key={props.widgetDetails?.id}
          >
            <div className="widget_icon">
              <SelectInput
                classNamePrefix="react-select"
                className="change-type"
                options={options}
                isSearchable={false}
                defaultValue={
                  options[getIndex(props.widgetDetails?.widgetType, options)]
                }
                onChange={(e) =>
                  handleWidgetType(props.widgetDetails?.id, e.value)
                }
              />
            </div>
            <div className="widget_header_info">
              <div className="field_label">
                {inputRef?.current === document.activeElement &&
                !props.widgetDetails?.isWidgetFormTextEntered &&
                !props.widgetDetails?.isWidgetDefaultNameShowed ? (
                  <span style={{ visibility: "hidden" }}>test</span>
                ) : widgetFieldEditIds.indexOf(props.widgetDetails?.id) < 0 ? (
                  <span onClick={!props?.readOnly && handleWidgetLableEdit}>
                    {props.widgetDetails?.title}
                  </span>
                ) : (
                  ""
                )}
                {widgetFieldEditIds.indexOf(props.widgetDetails?.id) > -1 &&
                props.widgetDetails?.widgetType !== BLANK_WIDGET ? (
                  <input
                    type="text"
                    className="text-color"
                    value={props.widgetDetails?.title}
                    ref={inputTitleRef}
                    onChange={handleWidgetTitleChange}
                    onBlur={handleWidgetTitleBlur}
                    onKeyPress={handleTitleKeyPress}
                  />
                ) : (
                  ""
                )}
              </div>
              <div
                className={
                  selectedWidgetIds.indexOf(props.widgetDetails?.id) > -1
                    ? "widget_form_text_input bgLightGrey dark_bg"
                    : "widget_form_text_input bgLightGrey"
                }
              >
                <select
                  defaultValue={props.widgetDetails?.branchControlType}
                  value={props.widgetDetails?.branchControlType}
                  onChange={(e) => handleBranchTypeChange(e)}
                  onBlur={() => dispatch(holdCursor(false))}
                >
                  <option value="skip">Skip when</option>
                  <option value="execute">Execute when</option>
                  <option value="switch">Switch when</option>
                  <option value="jump">Jump when</option>
                </select>
              </div>
            </div>
          </div>

          <div
            className={
              selectedWidgetIds.indexOf(props.widgetDetails?.id) > -1
                ? "widget_base dark_bg"
                : "widget_base"
            }
          >
            <div className="widgetBaseContainer">
              {advancedViewWidgetIds.indexOf(props.widgetDetails?.id) > -1 ? (
                <div className="textArrow1">
                  <MentionsInput
                    id="calcWidget"
                    markup="@[display](id)"
                    value={str}
                    onChange={(e) => setStr(e.target.value)}
                    className="textAreaCalc"
                  >
                    <Mention
                      trigger="@"
                      data={mentionWidgets}
                      style={{
                        backgroundColor: "#ddd",
                      }}
                      appendSpaceOnAdd="true"
                    />
                  </MentionsInput>
                </div>
              ) : (
                renderSwitch()
              )}
              <div className="hideBookmark">
                <div className="checkContainer">
                  <input
                    type="checkbox"
                    onChange={(e) => handleInputWidget(e, HIDE)}
                    id={"hideB_" + props.widgetDetails?.id}
                    name={"hideB_" + props.widgetDetails?.id}
                    defaultValue={props.widgetDetails?.hide}
                    checked={props.widgetDetails?.hide}
                  />
                  <label htmlFor={"hideB_" + props.widgetDetails?.id}>
                    Hide
                  </label>
                </div>
                <div className="checkContainer">
                  <input
                    type="checkbox"
                    onChange={(e) => handleInputWidget(e, BOOKMARK)}
                    id={"bookmarkB_" + props.widgetDetails?.id}
                    name={"bookmarkB_" + props.widgetDetails?.id}
                    defaultValue={props.widgetDetails?.bookmark}
                    checked={props.widgetDetails?.bookmark}
                  />
                  <label htmlFor={"bookmarkB_" + props.widgetDetails?.id}>
                    Bookmark
                  </label>
                </div>
              </div>
            </div>
          </div>
          <span
            className="widget_view_mode_icon"
            onClick={(e) => changeMode(e)}
          ></span>
        </div>
        {props.widgetDetails &&
          props.widgetDetails?.branchControlType !== "jump" && (
            <>
              {(props.widgetIndex === activeCursorWidgetId ||
                activeCursorWidgetId === undefined) &&
                props.innerWidget === undefined &&
                nestedBranchCursorIndex === undefined &&
                props.moduleIndex === activeCursorModuleId &&
                executionFrameIndex === undefined &&
                branchWidgetCursorIndex === -1 && (
                  <EditPaneCursor type="lined" />
                )}
              <BranchWidgetList
                class={props.class}
                module={props.module}
                handleSelectWidget={props.handleSelectWidget}
                widgetPosition={props.widgetPosition}
                widgetIndex={props.widgetIndex}
                moduleIndex={props.moduleIndex}
                isFocus={props.isFocus}
                widgetList={props.widgetDetails.widgetList}
              />
            </>
          )}
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  width: 480px;
  .textAreaCalc {
    background-color: white;
    // width: 100%;
    // height: 50px;
    margin: 5px;
  }
  .textArrow1 {
    overflow: visible !important;
  }

  .widgetContainer .bookMarkRibbon {
    right: -80px !important;
  }
  .widget_header {
    display: flex;
    margin-top: 0px !important;
    border: 2px solid #26a889;
    border-bottom: 0;
  }
  .background {
    background: #f2f2f2;
  }
  .background_warn {
    background: #ff0009;
  }
  .nara_bg {
    background: #ec04e5;
  }
  .nara_bg svg,
  .background svg,
  .calc_bg svg {
    color: #000 !important;
  }
  .text-area {
    width: 95%;
    margin: 1% 3%;
    height: 50px;
    padding: 0;
  }
  .calc_bg {
    background: #f79032;
  }

  .widget_icon {
    width: 19%;
    position: relative;
    padding: 5px;
    padding-top: 10px;

    > div > img {
      width: 50px;
      height: auto;
      position: absolute;
    }
    .change-type {
      border: none;
      outline: 0;
      cursor: pointer;
      > div {
        border: none;
        background-color: ${({ widgetHeaderColor }) => widgetHeaderColor};
        outline: 0;
        svg {
          color: white;
        }
        .react-select__indicator-separator {
          display: none;
        }
      }
      .react-select__menu {
        background-color: white !important;
      }
    }
  }
  .widget_arrow_collapse {
    width: 20px !important;
    bottom: 2px;
    right: 2px;
  }
  .widget_header_info {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 85%;
    position: relative;
    .field_label {
      text-align: right;
      color: #000;
      padding-right: 10px;
      font-weight: 500;
    }
    .widget_form_text_input {
      input {
        width: 100%;
        outline: 0;
        border: 1px solid white;
        padding: 3px;
      }
      > span {
        width: 100%;
        outline: 0;
        //border: 1px solid white;
        padding: 3px;
        background: white;
        display: block;
        height: 30px;
        .green,
        .gray {
          background: #4da184;
          padding: 2px;
        }
        .gray {
          background: #7a7a7a;
        }
      }
    }
  }
  .widget_base {
    display: flex;
    border-bottom-left-radius: 15px;
    border: 2px solid #26a889;
    border-top: 0;
  }
  .generic_options {
    width: 25%;
    border-bottom-left-radius: 15px;
    overflow: hidden;
    background: #d6d6d6;
    padding: 5px;
    .input_group {
      label {
        margin-bottom: 0;
        padding-left: 5px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
      }
    }
  }
  .all_options {
    background: #d6d6d6;
    // background: rgb(235, 235, 234);
    width: 75%;
    padding: 5px;
    position: relative;
  }

  .add_options {
    // position: absolute;
    position: relative;
    bottom: 5px;
    font-size: 25px;
    font-weight: bold;
    color: white;
    cursor: pointer;
  }
  .widget_view_mode_icon {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
  }
  .widget_view_mode_icon_compressed {
    position: absolute;
    // bottom: 0;
    right: 0;
    right: 0px;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
    z-index: 1;
  }
  .default_bg {
    background: #d6d6d6 !important;
  }

  .dark_bg,
  .dark_bg .generic_options,
  .dark_bg .all_options {
    //background:#7b7878 !important;
    // background: #acacac !important;
    background: ${(props) =>
      props.styles.ContentHighlight_Colour?.background} !important;
  }
  .dark_bg {
    background: "red";
  }
  .radious-none {
    border-bottom-left-radius: 0;
    border-bottom: 1px solid #7b7b7b;
  }
  .ant-picker {
    padding: 0 !important;
  }
  .ant-picker-suffix {
    margin-right: 4px;
  }
  .ant-picker-input input,
  .react-datepicker__input-container input {
    padding: 13px 5px !important;
    border-radius: 0 !important;
  }
  .calcWidgetTextBox {
    height: 30px;
    position: relative;
  }
  .hideOverflow {
    overflow: hidden;
  }
  .bgLightGrey {
    background: #d6d6d6;
  }
  .widgetBaseContainer {
    background: #d6d6d6;
    width: 100%;
    .fieldSection {
      font-size: 16px;
      display: flex;
      justify-content: space-between;
      margin: 8px 0 0 8px;
      .textArrow {
        position: relative;
        overflow: hidden;
        input[type="text"] {
          width: 100%;
          border: none;
          height: 28px;
          padding: 2px;
        }
        img {
          position: absolute;
          right: 2px;
          top: 2px;
          height: 20px;
          width: auto;
        }
      }
      .andClick {
        width: 50px;
        span {
          color: #3ef5f6;
          font-weight: 600;
          cursor: pointer;
        }
      }
      .deleteIcon {
        background: #595959;
        border-radius: 15px 0 0 15px;
        img {
          height: 20px;
          width: auto;
        }
      }
      .equalAndArrow {
        select {
          height: 28px;
        }
      }
    }
    .hideBookmark {
      display: flex;
      margin-top: 8px;
      .checkContainer {
        padding-left: 20px;
        input[type="checkbox"] {
          transform: scale(1.5);
        }
        label {
          padding-left: 6px;
          color: black;
          font-weight: 600;
        }
      }
    }
    .orClick {
      text-align: center;
      margin: 10px;
      position: relative;
      width: 86%;
      span {
        background: #d6d6d6;
        position: relative;
        padding: 0 8px;
        color: #2bf5f5;
        font-weight: 600;
        font-size: 1.2rem;
        width: 60px;
        display: block;
        margin: 0 auto;
        text-align: center;
      }
      .lineBehid {
        height: 3px;
        position: absolute;
        background: #2bf5f5;
        width: 100%;
        top: 50%;
      }
    }
  }
  .widget_form_text_input.bgLightGrey {
    text-align: right;
    padding: 5px;
  }
  .branchWidgetContainer {
    border-left: 4px solid #36ae8f;
    padding-bottom: 30px;
    border-bottom: 4px solid #36ae8f;
    width: 500px;
    .borderRed {
      border-left: 0;
      width: 496px !important;
    }
  }
  .dark_bg .widgetBaseContainer,
  .dark_bg .widgetBaseContainer .orClick span {
    background: #a6a2a2 !important;
  }
  .pointerEvent {
    pointer-events: none;
  }
  // .widget_view_mode_icon_compressed {
  //   right: -2px !important;
  // }
  .widgetBaseContainer .fieldSection .textArrow input[type="text"] {
    width: 130px;
  }
  .widgetBaseContainer .fieldSection .equalAndArrow select {
    width: 50px;
    border: none;
  }
  .textAreaCalcWidget.textAreaCalcWidget--multiLine {
    width: 180px;
    .textAreaCalcWidget__control {
      textarea {
        border: none;
      }
    }
  }
  .widgetBaseContainer .fieldSection .andClick {
    width: 50px;
  }
`;
