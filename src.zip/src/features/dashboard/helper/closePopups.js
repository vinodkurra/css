
export function closeAllPopups() {
    const childFrameObj = document.getElementById("iframeContent");
    if (childFrameObj) {
        childFrameObj.contentWindow.postMessage("closePopups", "*");
    }
}
