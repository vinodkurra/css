import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import styled, { ThemeProvider } from "styled-components";

import TopMenu from "./components/TopMenu";
import Spinner from "./components/Spinner";
import NotFound from "./components/NotFound";
import ContentBuilder from "../../content-builder";
import GlobalLogoPopup from "./components/GlobalLogoPopup";
import Home from "../home";
import Persona from "../home/components/Submenu/Persona";
import DropdownContent from "../home/components/Submenu/DropdownContent";
import Counts from "../home/components/Submenu/Counts";
import ConsultationProcess from "../../consultation-process";
import ConsultationProcess1 from '../../consultation-process/index';
import * as mytheme from "../../exportables/Colors";
import Message from "../home/message";
import {
  setSelectedUser,
  getAppointments,
} from "../../store/LandingPage/index";
import { checkSumId } from "../../calls/apis";
import { getUserMails } from "../../store/LandingPage";
import {
  mailServiceUrlWithToken,
  apiSearchUrlWithToken,
} from "../../calls/apis";
import JwtDecode from "jwt-decode";
import moment from "moment";

export default function Dashboard({ history, authObj, location }) {

  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(true);
  const [togglenav, setTogglenav] = useState(false);
  const [toggle_leftnav, set_LeftTogglenav] = useState(false);
  const [theme, setTheme] = useState(null);
  const token = localStorage.getItem("token");
  const groupId = localStorage.getItem("groupId");
  const groupName = localStorage.getItem("groupName");
  const orgId = localStorage.getItem("orgId");
  const refreshtoken = localStorage.getItem("refreshtoken");
  const access = localStorage.getItem("accesstoken");
  const path = location.pathname.split("/")[2];
  const { selectedUser } = useSelector((state) => state.landingpage);
  const { isGlobalLogoPopupVisible } = useSelector((state) => state.content);

  let iframeUrl = "";
  const hostUrl = window.location.hostname;
  const clientUrl = "hypaiq.cyb.co.uk";
  const qaUrl = "hypaiqqa.cyb.co.uk";
  const rightnavRef = React.createRef()


  let decoded = JwtDecode(access);

  switch (path) {

    case "patients":
      iframeUrl =
        hostUrl === clientUrl
          ? "https://hypaiq-patient.cyb.co.uk/"
          : hostUrl === qaUrl
            ? "https://hypaiqqa-patient.cyb.co.uk/"
            : "https://hypaiqdev-patient.portcullisindia.in/";
      // : "http://localhost:3002/";
      break;
    case "scheduler":
      iframeUrl =
        hostUrl === clientUrl
          ? "https://hypa-scheduler.cyb.co.uk/"
          : hostUrl === qaUrl
            ? "https://hypaqa-scheduler.cyb.co.uk/"
            : "https://hypadev-scheduler.portcullisindia.in/";
      // :"http://localhost:3003/";
      break;
    case "admin":
      iframeUrl =
        hostUrl === clientUrl
          ? "https://hypaiq-admin.cyb.co.uk/settings"
          : hostUrl === qaUrl
            ? "https://hypaiqqa-admin.cyb.co.uk/settings"
            : "https://hypaiqdev-admin.portcullisindia.in/settings";
      // "http://localhost:3002/settings";
      break;
    default:
      iframeUrl = "";
  }

  React.useEffect(() => {

    const theme_temp = {
      top_menu_dropdown_bg_color: "#4395A6",
      top_menu_dropdown_text_color: "white",
    };
    let styles = localStorage.getItem("styles");
    let sty = JSON.parse(styles);
    setTheme({ ...theme_temp, ...sty });
    setIsLoading(false);



    setTimeout(() => {
      if (localStorage.getItem("account")) {
        let currentUser = {
          userId: JSON.parse(localStorage.getItem("account")).userid,
          name: JSON.parse(localStorage.getItem("account")).firstname,
          isSet: true,
        };
        if (!selectedUser.isSet) {
          dispatch(setSelectedUser(currentUser));
        }
      }
    }, 2000);
  }, []);

  let path1 = window.location.href.split("/")[4];
  path1 = path1?.includes('#') ? path1.split('#')[0] : path1;
  const isConsultationProcess = path1 === "consultation-process" ? true : false;
  const isContent = path1 === "content" ? true : false;
  const [postUrl, setPostUrl] = useState("");




  async function fetchAppoinments() {
    const today = moment().format("DD-MM-YYYY");
    const todate = moment(moment().format("YYYY-MM-DD"))
      .add(7, "days")
      .format("DD-MM-YYYY");
    return await apiSearchUrlWithToken
      .get(`/scheduler/datewise?date=${today}&todate=${todate}`)
      .then(async (result) => {
        const { schedulerList } = await result.data;
        dispatch(getAppointments(schedulerList));
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function togglesidenav(e) {
    console.log('The link right nav was clicked.');
    setTogglenav(!togglenav);

  }

  function toggleLeftsidenav(e) {
    console.log('The left nav was clicked.');
    set_LeftTogglenav(!toggle_leftnav);

  }

  React.useEffect(() => {
    // if (!isConsultationProcess) {

    fetchAppoinments();

    setInterval(() => {
      fetchAppoinments();
    }, 30000);
  }, [path1]);

  if (isLoading) {
    return <Spinner msg="Loading ..." theme={theme} />;
  }

  return (
    <MainNavBar>
      <TopMenu
        className="mainNavBar"
        theme={theme}
        history={history}
        authObj={authObj}
        setIsLoading={setIsLoading}
      />

      {
        iframeUrl && path !== "scheduler" ? (
          <iframe
            id="iframeContent"
            className="iframeContent"
            src={
              iframeUrl +
              `?token=${token}&refreshtoken=${refreshtoken}&accesstoken=${access}${groupId ? "&groupId=" + groupId : ""
              }${groupName ? "&groupName=" + groupName : ""}&${orgId ? "organisationId=" + orgId : ""
              }`
            }
            allow="clipboard-read;"
            width="100%"
            title="microfrontend"
          />
        ) : iframeUrl && path === "scheduler" ? (
          <ThemeProvider theme={mytheme}>
            <div className="col-md-12" style={{ padding: "0" }}>
              <div className="col-md-2 right_nav1">
                <SubMenu>
                  <Persona />
                  <Counts />
                  <DropdownContent />
                </SubMenu>

              </div>
              <div className="col-md-8">
                <iframe
                  id="iframeContent"
                  className="iframeContent"
                  style={{ marginLeft: "20px" }}
                  src={
                    iframeUrl +
                    `?token=${token}&refreshtoken=${refreshtoken}&accesstoken=${access}${groupId ? "&groupId=" + groupId : ""
                    }${groupName ? "&groupName=" + groupName : ""}&${orgId ? "organisationId=" + orgId : ""
                    }`
                  }
                  allow="clipboard-read;"
                  width="63%"
                  title="microfrontend"
                />
              </div>
              <div className="col-md-2 right_nav1 ">
                <Message />
              </div>
            </div>
          </ThemeProvider>
        ) : path === "content" ? (
          <>
            <ContentBuilder />
            {isGlobalLogoPopupVisible ? <GlobalLogoPopup /> : ""}
          </>
        ) : path === "consultation-process" ? (

          <ThemeProvider theme={mytheme}>
            <div className="col-md-12" style={{ padding: "0" }}>

              <div className={togglenav ? "col-md-2 right_nav1" : "col-md-2 right_nav1_2"} ref={rightnavRef} >
                <SubMenu>
                  <Persona />
                  <Counts />
                  <DropdownContent />

                </SubMenu>
                {togglenav == false ? (
                  <button className="togle_rightnav" onClick={() => { togglesidenav(); }}>
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                  </button>

                ) : (
                    <button className="togle_rightnav" onClick={() => { togglesidenav(); }}>
                      <i class="fa fa-angle-left" aria-hidden="true"></i>
                    </button>
                  )}
              </div>
              <div className={
                ((togglenav && toggle_leftnav) ||
                  (!togglenav && toggle_leftnav) ||
                  (togglenav && !toggle_leftnav)) ?
                  "col-md-8 closedform" + (toggle_leftnav && !togglenav ? " lft_align " : " ") : "col-md-12 center_part"
              }>
                <ConsultationProcess1 />
              </div>
              {toggle_leftnav ? (
                <div className="col-md-2 right_nav1 toggle_leftnavpos">
                  <Message />
                  <button className="togle_lefttnav" onClick={() => { toggleLeftsidenav(); }}>
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                  </button>

                </div>

              ) : (
                  <div className="col-md-2 toggle_leftnav1_2">
                    <div>
                      <div style={{ fontSize: "23px", margin: "0 auto", width: "fit-content" }}><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 512 512"><path fill="#738c87" d="M472 96h-88V40h-32v56H160V40h-32v56H40a24.028 24.028 0 0 0-24 24v336a24.028 24.028 0 0 0 24 24h432a24.028 24.028 0 0 0 24-24V120a24.028 24.028 0 0 0-24-24zm-8 352H48V128h80v40h32v-40h192v40h32v-40h80z"></path><path fill="#738c87" d="M112 224h32v32h-32z"></path><path fill="#738c87" d="M200 224h32v32h-32z"></path><path fill="#738c87" d="M280 224h32v32h-32z"></path><path fill="#738c87" d="M368 224h32v32h-32z"></path><path fill="#738c87" d="M112 296h32v32h-32z"></path><path fill="#738c87" d="M200 296h32v32h-32z"></path><path fill="#738c87" d="M280 296h32v32h-32z"></path><path fill="#738c87" d="M368 296h32v32h-32z"></path><path fill="#738c87" d="M112 368h32v32h-32z"></path><path fill="#738c87" d="M200 368h32v32h-32z"></path><path fill="#738c87" d="M280 368h32v32h-32z"></path><path fill="#738c87" d="M368 368h32v32h-32z"></path><rect x="0" y="0" width="512" height="512" fill="rgba(0, 0, 0, 0)"></rect></svg></div>
                    </div>

                    <div>
                      <div style={{ color: "#738c87", fontSize: "23px", margin: "0 auto", width: "fit-content" }}><i className="fa fa-comment"></i></div>
                    </div>
                    <button className="togle_lefttnav" onClick={() => { toggleLeftsidenav(); }}>
                      <i class="fa fa-angle-left" aria-hidden="true"></i>
                    </button>
                  </div>

                )
              }
            </div>
          </ThemeProvider>
          // <Home />
        ) : (
                  <Home />
                ) //<NotFound />
      }
    </MainNavBar>
  );
}

const MainNavBar = styled.div`


  // .toggle_leftnavpos div section{
  //   margin-left:-23px;
  // }
  // .toggle_leftnavpos div div{
  //   margin-left:-24px;
  // }

  .lft_align .widgetSection{
    left:20% !important;
  }
  .mainNavBar {
    position: sticky;
    top: 0px;
  }
  .closedform{
    transition:width 0.5s;
  }
  .right_nav1{
    transition: width 2s;
  }
  .right_nav1_2 ul li{
    display:none;
  }
  .right_nav1_2 div img{
    width: 60px !important;
    height: 60px !important;
  }
  .right_nav1_2 div div:nth-child(1){
    padding:10px 15px;
  }

  .right_nav1_2{
    padding:0px;
    height: 90vh;
    border-right: lightgray solid 1px;
    width:90px;
    transition: width 0.3s;
  }

  .center_part{
    width:89%;
    transition: width .5s;
    padding-left: 10px;
  }

  .center_part .mainConsultationContainer{
    float:left;
    margin-right:10px;
  
  }
  .center_part .infoSec{
    float:left;
    width:225px;
    margin-top: 0px;
  }
  // .center_part .mainConsultationContainer{
  //   float:left;
  //   margin-right:20px;
  //   width:70%;
  // }
  .center_part .consultationContainer{
    width: fit-content;
    position:relative;
  }
  .center_part .consultationContainer .moduleSection{
    width:175px;
    // margin-top: 18px;
  }

  // .center_part .consultationContainer .widgetSection{
  //   position:fixed;
  //   left:19% !important;
  //   width: 38% !important;

  // }
  // .center_part .consultationContainer .actionMenuSection{
  //   position: fixed;
  //   left: 57%;
  // }
  button{
    outline: none;
  }

  .toggle_leftnav1_2{
    padding:0px;
    height: 90vh;
    border-left: lightgray solid 1px;
    width:90px;
    background-color:rgb(232, 235, 233);
    position:absolute;
    right:0px;
    transition:width 0.5s;
  }
  .toggle_leftnavpos{
    position:absolute;
    right:23px;
    transition:width 2s;
  }
  .right_nav1_2 h2, .right_nav1_2 h5{
    display:none;
  }
  
  .right_nav1_2 a div div:nth-child(1) img{
    width:60px;
    height:60px;
  }
  .right_nav1_2 a div div:nth-child(1) {
    width:60%;
    // height:60px;
  }

  .right_nav1_2 .dropdown .dropdown-toggle{
    
    color:#000;
    width: 30px !important;
    contain: content !important;
  }
  .right_nav1_2 .dropdown .dropdown-toggle::after{
    content:"&#9662";
  }

  .right_nav1_2 a div div:nth-child(2) p{
    display:none;

  }

  .togle_rightnav{
    position: absolute;
    bottom: 3vh;
    right: 44px;
  }

  .togle_rightnav{
    border:none;
    background:none;
    font-size:20px;
    color:#aca9a9;
  }

  .togle_lefttnav{
    position: absolute;
    bottom: 3vh;
    left: 44px;
  }

  .togle_lefttnav{
    border:none;
    background:none;
    font-size:20px;
    color:#aca9a9;
  }
  .right_nav1 {
    padding: 0;
    height:90vh;
  }
  .iframeContent {
    border: 0px;
    height: 100vh;
    height: -webkit-fill-available;
    position: fixed;
    top: 71px;
    z-index: 1;
  }
  * {
    scrollbar-color: #0395a6 #b3b3b3;
    scrollbar-width: thin;
  }
  ::-webkit-scrollbar {
    width: 8px;
  }

  ::-webkit-scrollbar-track {
    background: #b3b3b3;
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb {
    background: #0395a6;
    border-radius: 10px;
  }
`;

const SubMenu = styled.div`
  padding: 0px;
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
    props.theme.DashboardContentOneColors.DashboardContentOne
      .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
    props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;
