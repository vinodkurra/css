import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../../exportables/Colors";
import store from "../../../store";

const Modal = () => {
  const style = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <ThemeProvider theme={mytheme}>
          <CollageModal>
            <div className="modal" id="myModalcollage" role="dialog">
              <div className="modal-dialog modal-sm">
                <div className="modal-content">
                  <div className="modal-body">
                    <img
                      src={require("../../../assets/cup.png")}
                      className="img-responsive"
                    />
                    <h1>Title Goes Here</h1>
                    <p>Award sentence goes here</p>
                    <div className="modalinputfield">
                      <form>
                        <div className="group">
                          <input type="text" required />
                          <span className="highlight"></span>
                          <span className="bar"></span>
                          <label>Name</label>
                        </div>
                      </form>
                    </div>
                    <div className="modalbuttontext">
                      <button>Send Invitation</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CollageModal>
        </ThemeProvider>
      }
    </>
  );
};

export default Modal;

const CollageModal = styled.div`
  .modal .modal-dialog {
    transform: translate(0, 220px) !important;
    width: 50%;
  }
  .modal {
    background-color: ${(props) =>
      props.theme.TopMenuColors.CollageModal.modal_backgroundColor};
  }

  .modal-sm {
    max-width: 535px;
  }
  h1 {
    color: ${(props) => props.theme.TopMenuColors.CollageModal.h1_color};
    text-align: center;
  }
  p {
    text-align: center;
    font-size: 19px;
    color: ${(props) => props.theme.TopMenuColors.CollageModal.p_color};
  }
  .modalbuttontext button {
    border: 2px solid
      ${(props) =>
        props.theme.TopMenuColors.CollageModal.modalbuttontext_button_border};
    padding: 5px 20px;
    background-color: transparent;
    font-weight: 500;
    font-size: 16px;
    color: ${(props) =>
      props.theme.TopMenuColors.CollageModal.modalbuttontext_button_color};
    text-align: center;
    border-radius: 40px;
    margin-bottom: 20px;
  }

  .modalbuttontext {
    display: block;
    text-align: center;
  }
  .modal-content {
    border-radius: 20px;
  }
  .modal-header {
    border: none;
  }
  .group,
  .appoinmentmodal .group {
    position: relative;
    margin-bottom: 10px;
  }
  input,
  .appoinmentmodal input {
    font-size: 16px;
    padding: 10px 10px 0px 5px;
    display: block;
    width: 300px;
    border: none;
    border-bottom: 0.5px solid
      ${(props) =>
        props.theme.TopMenuColors.CollageModal
          .appointment_modalinput_border_bottom};
  }
  input:focus {
    outline: none;
  }
  // label {
  //   color: ${(props) => props.theme.TopMenuColors.CollageModal.label};
  //   font-size: 15px;
  //   font-weight: normal;
  //   position: absolute;
  //   pointer-events: none;
  //   left: 5px;
  //   top: 10px;
  //   transition: 0.2s ease all;
  //   -moz-transition: 0.2s ease all;
  //   -webkit-transition: 0.2s ease all;
  // }
  
  input:focus ~ label,
  input:valid ~ label {
    top: -10px;
    font-size: 14px;
    color: ${(props) =>
      props.theme.TopMenuColors.CollageModal.input_focus_valid_label};
  }
  .highlight,
  .appoinmentmodal .highlight {
    position: absolute;
    height: 60%;
    width: 100px;
    top: 25%;
    left: 0;
    pointer-events: none;
    opacity: 0.5;
  }
  input:focus ~ .highlight {
    -webkit-animation: inputHighlighter 0.3s ease;
    -moz-animation: inputHighlighter 0.3s ease;
    animation: inputHighlighter 0.3s ease;
  }
  @-webkit-keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.TopMenuColors.CollageModal.webkit_inputHighlighter
          .from_background};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @-moz-keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.TopMenuColors.CollageModal.moz_inputHighlighter
          .from_background};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.TopMenuColors.CollageModal.keyframes_inputHighlighter
          .from_background};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
`;
