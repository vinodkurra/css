import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";

import styled from "styled-components";

const ProfileMenu = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <li className="dropdown">
          <a className=" dropdown-toggle" type="button" data-toggle="dropdown">
            <img src={require("../../../../assets/default-avatar-profile.jpg")} />
          </a>
          <ProfileImagedrop className="dropdown-menu">
            <UserProfileDrop>
              <img
                src={require("../../../../assets/default-avatar-profile.jpg")}
                className="img-responsive"
              />
              <h2>Name LastName</h2>
              <p>St.Mary's Cardiology Unit</p>
              <h4>email@emai.com</h4>
              <div className="profilemanage">
                <h3>Manage Your Account</h3>
              </div>
            </UserProfileDrop>
            <div className="profileborder">
              <div className="profileaccont">
                <div>
                  <img
                    src={require("../../../../assets/default-avatar-profile.jpg")}
                    className="img-responsive"
                  />
                </div>
                <div>
                  <h3>Name LastName</h3>
                  <p>Account Name</p>
                </div>
              </div>
              <div className="profileanother">
                <a>
                  {" "}
                  <i className="fa fa-user-plus"></i>Add Another Account
                </a>
              </div>
            </div>
            <SignOut>
              <div>
                <a> Sign out of all account</a>
              </div>
            </SignOut>
            <ProfileSetting>
              <ul>
                <li>system setting</li>
                <li>Help & Support</li>
              </ul>
            </ProfileSetting>
          </ProfileImagedrop>
        </li>
      }
    </>
  );
};

export default ProfileMenu;

const ProfileImagedrop = styled.div`
  border-radius: 10px;
  border: none;
  left: -275px;
  top: 95px;
  width: 350px !important;
  .userprofiledrop {
    img {
      width: 75px;
      height: 75px;
      border-radius: 50px;
      text-align: center;
      margin: 0 auto;
      margin-top: 20px;
    }
    h2 {
      text-align: center;
      margin: 0;
      font-size: 24px;
      font-weight: 600;
      margin-top: 10px;
    }
  }
  .profileaccont {
    display: table;
    width: 100%;

    margin-top: 10px;
    margin-bottom: 10px;
    div {
      display: table-cell;
      vertical-align: middle;
      :nth-child(1) {
        width: 30%;
        img {
          width: 50px;
          height: 50px;
          border-radius: 25px;
          text-align: right;
          margin: 0 auto;
        }
      }
      :nth-child(2) {
        width: 70%;
        h3 {
          margin: 0px;
          color: ${(props) =>
            props.theme.TopMenuColors.ProfileImagedrop.nthChild_2_h3_color};
          font-size: 16px;
        }
        p {
          margin: 0px;
          font-size: 14px;
          color: ${(props) =>
            props.theme.TopMenuColors.ProfileImagedrop.nthChild_2_p_color};
          font-weight: 500;
        }
      }
    }
  }
  .profileanother {
    a {
      font-size: 18px;
      font-weight: 500;
      text-align: center;
      display: block;
      i {
        color: ${(props) =>
          props.theme.TopMenuColors.ProfileImagedrop.a_i_color};
        background-color: transparent;
      }
    }
  }
  .profileborder {
    border-bottom: 1px solid
      ${(props) => props.theme.TopMenuColors.ProfileImagedrop.profile_border};
  }
  .profilesignout {
    padding: 10px 45px;
    margin-top: 10px;
    text-align: center;
    border-bottom: 1px solid
      ${(props) =>
        props.theme.TopMenuColors.ProfileImagedrop.profile_border_botton};
  }
`;

const SignOut = styled.div`
  padding: 10px 45px;
  margin-top: 10px;
  text-align: center;
  border-bottom: 1px solid
    ${(props) => props.theme.TopMenuColors.SignOut.border_bottom};
  div {
    margin-bottom: 10px;
  }
  a {
    font-size: 16px;
    color: ${(props) => props.theme.TopMenuColors.SignOut.a_border};
    border: 1px solid ${(props) => props.theme.TopMenuColors.SignOut.a_color};
    border-radius: 30px;
    padding: 10px 20px;
  }
`;

const ProfileSetting = styled.div`
  ul {
    list-style: none;
    text-align: center;
    li {
      display: inline-block;
      font-size: 14px;
      color: ${(props) => props.theme.TopMenuColors.ProfileSetting.li_color};
    }
  }
`;
const UserProfileDrop = styled.div`
  border-bottom: 1px solid
    ${(props) => props.theme.TopMenuColors.UserProfileDrop.border_bottom};
  img {
    width: 75px;
    height: 75px;
    border-radius: 50px;
    text-align: center;
    margin: 0 auto;
    margin-top: 20px;
  }
  h2 {
    text-align: center;
    margin: 0;
    font-size: 24px;
    font-weight: 600;
    margin-top: 10px;
  }
  p {
    text-align: center;
    font-size: 14px;
    font-weight: 600;
    color: ${(props) => props.theme.TopMenuColors.UserProfileDrop.p_color};
    margin: 5px;
  }
  h4 {
    text-align: center;
    color: ${(props) => props.theme.TopMenuColors.UserProfileDrop.h2_color};
    font-size: 14px;
    font-weight: 500;
  }
  .profilemanage {
    padding: 10px 45px;
    h3 {
      text-align: center;
      color: ${(props) =>
        props.theme.TopMenuColors.UserProfileDrop.profilemanage_h3_color};
      border: 1px solid
        ${(props) =>
          props.theme.TopMenuColors.UserProfileDrop
            .profilemanage_h3_backgroundcolor};
      border-radius: 30px;
      padding: 10px 20px;
    }
  }
`;
