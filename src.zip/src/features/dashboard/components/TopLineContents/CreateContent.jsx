import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";

import { closeAllPopups } from "../../helper/closePopups";

const CreateContent = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <li className="dropdown" onClick={closeAllPopups}>
          <a
            className="btn btn-primary dropdown-toggle"
            type="button"
            data-toggle="dropdown"
          >
            + Create
          </a>
          <CreaeTab
            className="dropdown-menu crete_tab"
            theme={styles.landing_page}
          >
            <h2>Create</h2>
            <ul>
              <li>
                <a href="#">
                  <CreateTable
                    data-toggle="modal"
                    data-target="#myModalappoinment"
                  >
                    <div>
                      <img
                        src={require("../..../../../../../assets/default-avatar-profile.jpg")}
                      />
                    </div>
                    <div>
                      <h4>Add New Appointment</h4>
                      <p>Subtext</p>
                    </div>
                  </CreateTable>
                </a>
              </li>
            </ul>
          </CreaeTab>
        </li>
      }
    </>
  );
};

export default CreateContent;

// const CreateContentStyle = styled.div`
//     li {
//       display: inline-block;
//       padding: 10px 15px;
//       :nth-child(1) a {
//         background-color: ${(props) =>
//           props.theme.TopMenuColors.HeeaderProfile.nthChild_1_color};
//         border-radius: 30px;
//         color: ${(props) =>
//           props.theme.TopMenuColors.HeeaderProfile.nthChild_1_backgroundcolor};
//         font-size: 16px;
//         font-weight: 600;
//         padding: 10px 25px;
//       }
//       :nth-child(2) {
//         padding: 10px;
//       }
//       :nth-child(3) {
//         padding: 10px;
//         a {
//           background-color: transparent;
//           border: none;
//         }
//       }
//       img {
//         height: 50px;
//         width: 50px;
//         border-radius: 25px;
//       }
//       a {
//         i {
//           background-color: ${(props) =>
//             props.theme.TopMenuColors.HeeaderProfile.a_i_color};
//           color: ${(props) =>
//             props.theme.TopMenuColors.HeeaderProfile.a_i_backcolor};
//           padding: 10px;
//           border-radius: 20px;
//         }
//       }
//     }
//     .open > .dropdown-toggle.btn-primary {
//       background-color: ${(props) =>
//         props.theme.TopMenuColors.HeeaderProfile
//           .toggle_open_backgroundcolor} !important;
//     }

// `;

const CreaeTab = styled.div`
  border-radius: 10px;
  border: none;
  left: -50px;
  top: 100px;
  .crete_tab:active,
  .crete_tab:focus {
    background: unset !important;
  }
  h2 {
    margin-left: 15px;
    color: ${(props) => props.theme.tl_createpopup_header_font_color};
    font-weight: ${(props) => props.theme.tl_createpopup_header_font_weight};
    margin-top: 10px;
  }
  ul {
    display: grid;
    li {
      background-color: transparent !important;
      margin: 0px;
      width: 335px;
      padding: 10px !important;
      padding-bottom: 10px !important;
      padding-top: 0px !important;
      a {
        background-color: transparent !important;
      }
    }
  }
`;

const CreateTable = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 20%;
      img {
        margin-right: 15px;
      }
      
    }
    :nth-child(2) {
      width: 80%;
      h4 {
        margin-bottom: 0px;
        font-size: ${(props) =>
          props.theme.tl_createpopup_contentsubtext_font_size};
      }
      p {
        font-size: ${(props) =>
          props.theme.tl_createpopup_contentsubtext_font_size};
        color: ${(props) =>
          props.theme.tl_createpopup_contentsubtext_font_color};
        font-weight: ${(props) =>
          props.theme.tl_createpopup_contentsubtext_font_weight};
        margin: 0;
      }
    }
  }
`;
