import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";
import {
  readNotification,
  readAllNotification,
} from "../../../../store/LandingPage/index";
import { closeAllPopups } from "../../helper/closePopups";

const NotificationTab = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const notification = useSelector((state) => state.landingpage.notification);
  const appointments = useSelector((state) => state.landingpage.appointments);

  // const onClickNotification = (data) => dispatch(readNotification(data));
  return (
    <>
      {
        <li className="dropdown" onClick={closeAllPopups}>
          <a type="button" data-toggle="dropdown">
            <i className="fa fa-bell"></i>
            <span className="badge badge-dark lg">
              {notification
                ? notification.length
                : null}
            </span>
          </a>
          <CreateNotification className="dropdown-menu" >
            <h2>
              Notification
              <i className="fa fa-bell-slash-o notification_slash_align"></i>
              {notification.length > 0 ? (
                <i
                  className="fa fa-bell notification_noslash_align"
                  //onClick={() => dispatch(readAllNotification())}
                ></i>
              ) : null}
            </h2>

            <ul>
              {notification.map((data) => (
                <li
                // onClick={onClickNotification.bind(null, data.id)}
                >
                  <a href="#">
                    <CreateTableNotification>
                      {notificationRender(data)}
                      {!data.read ? (
                        <div className="dot_align">
                          <p></p>
                        </div>
                      ) : null}
                    </CreateTableNotification>
                  </a>
                </li>
              ))}
            </ul>
          </CreateNotification>
        </li>
      }
    </>
  );
};

export default NotificationTab;

function notificationRender(param) {
  switch (param.entityTypeId) {
    case "SCHEDULER":
      return (
        <div>
          <p>{param.message.split(':')[0]}
          <b>{param.message.split(':')[1]}</b>
          </p>
          <h6>{param.timeDuration}</h6>
        </div>
      );
    case 'POSTS':
      return (
        <div>
          <p>
           {param.message.split(':')[0]} :{" "}
            <b>{param.message.split(':')[1]}</b>
          </p>
          {/* <h6>{param.timeDuration}</h6> */}
        </div>
      );
    case 3:
      return (
        <div>
          <p>
            {param.body}
            <b> {param.totalmail} mails</b> {param.content.substring(0, 20)}
          </p>
          <h6>{param.entry_time}</h6>
        </div>
      );
  }
}

const NotificationTabStyle = styled.li`
  border-radius: 10px;
  border: none;
  left: -150px;
  top: 95px;
  width: 350px;
  .dot_align {
    position: absolute;
    right: 0px;
  }
  .search input {
    background-color: ${(props) =>
      props.theme.TopMenuColors.SearchNotification
        .search_input_backgroundcolor};
    border-radius: 30px;
    font-size: 16px;
    padding: 10px 40px;
    color: ${(props) =>
      props.theme.TopMenuColors.SearchNotification.search_input_color};
    border: none;
    margin-bottom: 20px;
    margin-top: 20px;
  }
  .searchnotifi .search {
    text-align: center;
    border-bottom: 1px solid
      ${(props) => props.theme.TopMenuColors.SearchNotification.search_bottom};
  }
  .recentsearch {
    border-bottom: 1px solid
      ${(props) =>
        props.theme.TopMenuColors.SearchNotification.recentsearch_bottom};
    ul {
      padding: 10px;
      li {
        display: block;
        line-height: 35px;
        color: ${(props) =>
          props.theme.TopMenuColors.SearchNotification.li_color};
        font-size: 16px;
        padding: 0px 10px;
      }
    }
    h2 {
      margin: 0;
      margin-left: 20px;
      color: ${(props) => props.theme.TopMenuColors.SearchNotification.h2};
    }
  }
`;

const CreateNotification = styled.div`
  border-radius: 10px;
  border: none;
  left: -203px;
  top: 95px;
  width: 350px !important;
  height: 82vh !important;
  overflow-y: auto !important;

  .notification_slash_align {
    position: absolute;
    right: 36px;
  }

  .notification_noslash_align {
    position: absolute;
    right: 10px;
  }
  h2 {
    margin-left: 15px;
    color: ${(props) => props.theme.TopMenuColors.CreateNotification.h2_color};
    font-weight: 700;
    margin-top: 10px;
    padding: 0px 15px;
  }
  ul {
    li {
      padding-bottom: 0px !important;
      padding-top: 0px !important;
      a {
        padding: 0px !important;
      }
    }
  }
`;

const CreateTableNotification = styled.div`
  display: table;
  width: 100%;

  .dot_align {
    position: absolute;
    right: 0px;
  }
  p {
    color: ${(props) =>
      props.theme.TopMenuColors.CreateTableNotification.p_color};
    font-weight: 500 !important;
    font-size: 15px !important;
  }
  div {
    display: table-cell;
    vertical-align: top;
    :nth-child(2) {
      width: 10%;
      p {
        height: 15px;
        width: 15px;
        background-color: ${(props) =>
          props.theme.TopMenuColors.CreateTableNotification
            .nthChild_2_p_backgroundcolor};
        border-radius: 50%;
        display: inline-block;
      }
    }
    :nth-child(1) {
      width: 90%;
      p {
        margin-bottom: 5px;
      }
      h6 {
        color: ${(props) =>
          props.theme.TopMenuColors.CreateTableNotification
            .nthChild_2_p_backgroundcolor};
        font-size: 13px;
        font-weight: 500;
      }
    }
  }
`;
