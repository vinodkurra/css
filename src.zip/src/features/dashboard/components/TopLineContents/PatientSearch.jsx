import React, { Component } from "react";
import styled from "styled-components";
import jwt from "jsonwebtoken";
import { BsSearch, BsFillCaretDownFill } from "react-icons/bs";
import SearchToolBar from "../../../home/SeachToolbar";
import Icons from "../../../home/Icons";
import { device, country } from "../../../../exportables/exportables";
import Spinner from "./../Spinner";
import { connect, useDispatch } from "react-redux";
// import * as action from "./../store/scheduler-action";
import * as setSelectedPatient from "../../../../store/LandingPage/index";
import AWS from "aws-sdk";
import { debounce } from "lodash";
import TextFieldGroup from "hypaiq-rc/lib/TextFieldGroup";
import SelectFieldGroup from "hypaiq-rc/lib/SelectFieldGroup";
import TextAreaFieldGroup from "hypaiq-rc/lib/TextAreaFieldGroup";
import DateFieldGroup from "hypaiq-rc/lib/DateFieldGroup";
import {
  apiSearchUrl,
  patientsWithToken,
  apiSearchUrlWithToken,
} from "../../../../calls/apis";

AWS.config.update({
  accessKeyId: "AKIA5TI3EZTAIHWI73F4",
  secretAccessKey: "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",
  region: "eu-west-2",
  endpoint: "https://dynamodb.eu-west-2.amazonaws.com",
});
var docClient = new AWS.DynamoDB.DocumentClient({ correctClockSkew: true });
let access = localStorage.getItem("accesstoken");
let accessDecoded = jwt.decode(access);
var titleTable = {
  TableName: "master-title",
};
var locationTable = {
  TableName: "master-practicelocation",
};
let emailValidate = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
let nameValidate = /^[a-zA-Z. ]*$/;
let numberValidate = /^[0-9]+$/;
let zipValidate = /^[0-9a-zA-Z]+$/;
let addressValidate = /^[a-zA-Z0-9,.# ]*$/;

class AddPatientModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      titles: [],
      locations: [],
      min: "",
      token: "",
      primaryId: "",
      title: "",
      gender: "",
      firstname: "",
      middlename: "",
      lastname: "",
      dateofbirth: "",
      phonenight: "",
      phoneday: "",
      addressline1: "",
      addressline2: "",
      state: "",
      zipcode: "",
      country: "",
      search: "",
      searchId: "",
      patients: [],
      isLoaded: true,
      patient: {},
      copy: "",
      workgroupid: localStorage.getItem("groupId"),
      userid: "",
      styles: {
        patient: {
          active_button_colour: "rgb(67, 149, 166)",
          passive_button_colour: "#a9a9a9",
          button_text_colour: "#FFFFFF",
          button_text_size: "10px",
          button_border_radius: "5px",
          label_text_colour: "#666",
          label_text_size: "10px",
          error_text_size: "10px",
          error_text_colour: "#ff0000",
          input_border_colour: "#666",
          search_border_colour: "#666",
          count_text_colour: "#009999",
          count_text_size: "10px",
          advanced_border_colour: "#fcba03",
        },
        popup: {},
      },
      value: "",
      Regex: /^[0-9\b]+$/,
      city: "",
      location: "",
      select: false,
      save: false,
      secId1: "",
      secId2: "",
      secId3: "",
      secId4: "",
      registrationdate: "",
      doctor: "",
      note: "",
      email: "",
      totalRecord: 0,
      idError: false,
      firstNameError: false,
      middleNameError: false,
      lastNameError: false,
      dobError: false,
      phoneNightError: false,
      phoneDayError: false,
      address1Error: false,
      stateError: false,
      postCodeError: false,
      countryError: false,
      genderError: false,
      cityError: false,
      doctorError: false,
      locationError: false,
      registerError: false,
      secID1Error: false,
      secID2Error: false,
      secID3Error: false,
      secID4Error: false,
      noteError: false,
      emailError: false,
      emailErrortext: "",
      advancedSearch: false,
      warning: 0,
      primaryIdDisabled: true,
      open: false,
      registerOpen: false,
      buttontext: "save",
      icons: {},
      selectedPatient: {},
      stringObject: {},
    };
    this.newPatient = this.newPatient.bind();
  }
  componentDidMount = async () => {
    this.setState({
      styles: {
        ...this.state.styles,
        ...this.props.styles,
      },
      icons: this.props.styles.icons,
    });
    if (localStorage.getItem("local_patientsearch")) {
      let state = JSON.parse(localStorage.getItem("local_patientsearch"));
      if (state.userId === accessDecoded.userReference) {
        this.setState({
          ...state,
        });
      } else {
        localStorage.removeItem("local_patientsearch");
      }
    }
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const token = urlParams.get("token");
    const accessToken = urlParams.get("accesstoken");
    var decodedAccessToken = jwt.decode(accessToken);

    var decoded = jwt.decode(token);

    if (decoded?.email) {
      this.setState({
        token,
        userid: decodedAccessToken.userReference,
      });
    } else {
      // alert("UnAuthorised, try login again");
    }
    docClient.scan(titleTable, (err, data) => {
      if (err) {
      } else {
        let titles = data.Items.map((item) => {
          return {
            id: item.titleid,
            value: item.titlename,
            label: item.titlename,
          };
        });
        this.setState({ titles: titles });
      }
    });
    docClient.scan(locationTable, (err, data) => {
      if (err) {
      } else {
        let loc = data.Items.map((item) => {
          return {
            id: item.locationid,
            value: item.name,
            label: item.name,
          };
        });
        this.setState({ locations: loc });
      }
    });
    this.setState({ isLoaded: true });
  };
  componentDidUpdate() {
    window.addEventListener("message", this.receiveMessageFromIndex, false);
  }
  setlocal = (e) => {
    let data = this.state;
    data.userId = accessDecoded.userReference;
    if (e) {
      data[e.target.name] = e.target.value;
    }
    var cache = [];
    localStorage.setItem(
      "local_patientsearch",
      JSON.stringify(data, (key, value) => {
        if (typeof value === "object" && value !== null) {
          if (cache.includes(value)) return;
          cache.push(value);
        }
        return value;
      })
    );
    cache = null;
  };
  receiveMessageFromIndex(event) {
    let data = JSON.parse(event.data);
    localStorage.setItem("groupId", data.groupId);
  }
  setCopy = (e) => {
    this.setState({
      copy: e.target.value,
    });
  };
  copyToClipboard = () => {
    let str = this.state.copy;
    var text = document.createElement("textarea");
    text.value = str;
    text.setAttribute("readonly", "");
    text.style.position = "absolute";
    text.style.left = "-9999px";
    document.body.appendChild(text);
    text.select();
    document.execCommand("copy");
    document.body.removeChild(text);
  };
  handleFirstName = (e) => {
    let first = e.target.value;
    if (nameValidate.test(first) || first === "") {
      this.setState({
        firstname: e.target.value,
        copy: e.target.value,
        save: true,
        firstNameError: false,
      });
    }
    this.setlocal(e);
  };
  handleMiddleName = (e) => {
    let middle = e.target.value;
    if (nameValidate.test(middle) || middle === "") {
      this.setState({
        middlename: e.target.value,
        copy: e.target.value,
        save: true,
        middleNameError: false,
      });
    }
    this.setlocal(e);
  };
  handleLastName = (e) => {
    let Last = e.target.value;
    if (nameValidate.test(Last) || Last === "") {
      this.setState({
        lastname: e.target.value,
        copy: e.target.value,
        save: true,
        lastNameError: false,
      });
    }
    this.setlocal(e);
  };
  handleZip = (e) => {
    // var day = JSON.stringify(e.target.value);
    if (e.target.value === "" || zipValidate.test(e.target.value)) {
      // let number = day.replace("e", "");
      // let number1 = JSON.parse(number);
      this.setState({
        zipcode: e.target.value,
        copy: e.target.value,
        save: true,
        postCodeError: false,
      });
    }
    this.setlocal(e);
  };
  handlePhoneDay = (e) => {
    var day = JSON.stringify(e.target.value);
    if (e.target.value === "" || numberValidate.test(e.target.value)) {
      let number = day.replace("e", "");
      let number1 = JSON.parse(number);
      this.setState({
        phoneday: number1,
        copy: number1,
        save: true,
        phoneDayError: false,
      });
    }
    this.setlocal(e);
  };
  handlePhoneNight = (e) => {
    var day = JSON.stringify(e.target.value);
    if (e.target.value === "" || numberValidate.test(e.target.value)) {
      let number = day.replace("e", "");
      let number1 = JSON.parse(number);
      this.setState({
        phonenight: number1,
        copy: number1,
        save: true,
        phoneNightError: false,
      });
    }
    this.setlocal(e);
  };
  handleAddress1 = (e) => {
    let add1 = e.target.value;
    if (addressValidate.test(add1) || add1 === "") {
      this.setState({
        addressline1: add1,
        copy: add1,
        save: true,
        address1Error: false,
      });
    }
    this.setlocal(e);
  };
  handleAddress2 = (e) => {
    let add2 = e.target.value;
    if (addressValidate.test(add2) || add2 === "") {
      this.setState({
        addressline2: add2,
        copy: add2,
        save: true,
        address2Error: false,
      });
    }
    this.setlocal(e);
  };
  handleDoctor = (e) => {
    let doc = e.target.value;
    if (nameValidate.test(doc) || doc === "") {
      this.setState({
        doctor: doc,
        copy: doc,
        save: true,
        doctorError: false,
      });
    }
    this.setlocal(e);
  };
  handleCity = (e) => {
    let city = e.target.value;
    if (nameValidate.test(city) || city === "") {
      this.setState({
        city: city,
        copy: city,
        save: true,
        cityError: false,
      });
    }
    this.setlocal(e);
  };
  handleState = (e) => {
    let state = e.target.value;
    if (nameValidate.test(state) || state === "") {
      this.setState({
        state: state,
        copy: state,
        save: true,
        stateError: false,
      });
    }
    this.setlocal(e);
  };
  handleChange = (date) => {
    this.setState({
      dateofbirth: date,
      save: true,
      dobError: false,
    });
    this.setlocal({ target: { name: "dateofbirth", value: date } });
  };
  handleRegister = (date) => {
    this.setState({
      registrationdate: date,
      save: true,
      registerError: false,
    });
    this.setlocal({ target: { name: "registrationdate", value: date } });
  };
  handleGender = (e) => {
    let gender = e.target.value;
    if (gender === "Male")
      this.setState({
        gender: gender,
        title: "Mr.",
        save: true,
        genderError: false,
      });
    else if (gender === "Female")
      this.setState({
        gender: gender,
        title: "Ms.",
        save: true,
        genderError: false,
      });
    this.setlocal(e);
  };
  onInputChange = (e) => {
    let data = this.state;
    data.userId = accessDecoded.userReference;
    let { name, value } = e.target;
    data[e.target.name] = e.target.value;
    this.setState({
      ...data,
      copy: value,
      save: true,
    });
    if (name === "country") {
      this.setState({
        countryError: false,
      });
      data["countryError"] = false;
    }
    if (name === "location") {
      this.setState({
        locationError: false,
      });
      data["locationError"] = false;
    }
    if (name === "secId1") {
      this.setState({
        secID1Error: false,
      });
      data["secID1Error"] = false;
    }
    if (name === "secId2") {
      this.setState({
        secID2Error: false,
      });
      data["secID2Error"] = false;
    }
    if (name === "secId3") {
      this.setState({
        secID3Error: false,
      });
      data["secID3Error"] = false;
    }
    if (name === "secId4") {
      this.setState({
        secID4Error: false,
      });
      data["secID4Error"] = false;
    }
    if (name === "note") {
      this.setState({
        noteError: false,
      });
      data["noteError"] = false;
    }

    var cache = [];
    localStorage.setItem(
      "local_patientsearch",
      JSON.stringify(data, (key, value) => {
        if (typeof value === "object" && value !== null) {
          if (cache.includes(value)) return;
          cache.push(value);
        }
        return value;
      })
    );
    cache = null;
  };
  selectPatient = (firstname) => {
    this.setState({ select: false, search: firstname });
  };

  changePatient = (value) => {
    var dob = value.dateofbirth;
    var Reg = value.registrationdate;
    this.setState({
      save: false,
      dateofbirth:
        dob === "" || dob === undefined ? "" : new Date(value.dateofbirth),
      primaryId: value.id,
      gender: value.gender,
      title: value.title,
      New: true,
      firstname: value.firstname,
      middlename: value.middlename,
      lastname: value.lastname,
      phonenight: value.phonenight,
      phoneday: value.phoneday,
      addressline1: value.addressline1,
      addressline2: value.addressline2,
      workgroupid: value.workgroupid,
      userid: value.userid,
      state: value.state,
      zipcode: value.zipcode,
      country: value.country,
      selectedPatient: value,
      doctor: value.doctor,
      city: value.city,
      secId1: value.secId1,
      secId2: value.secId2,
      secId3: value.secId3,
      secId4: value.secId4,
      registrationdate:
        Reg === "" || Reg === undefined ? "" : new Date(value.registrationdate),
      note: value.note,
      location: value.location,
      email: value.email,
      select: false,
      search: `${value.firstname ? value.firstname : ""} ${
        value.middlename ? value.middlename : ""
      } ${value.lastname ? value.lastname : ""}`,
    });
  };

  addPatient = (event) => {
    
    let error = false;
    let warning = 0;
    if (this.state.warning === 1) {
      // this.setState({ warning: 2 })
      warning = 1;
    }
    if (
      this.state.firstname &&
      this.state.gender &&
      this.state.middlename &&
      this.state.lastname &&
      this.state.dateofbirth &&
      this.state.phoneday &&
      this.state.phonenight &&
      this.state.addressline1 &&
      this.state.zipcode &&
      this.state.state &&
      this.state.city &&
      this.state.email &&
      this.state.country &&
      this.state.doctor &&
      this.state.registrationdate &&
      this.state.secId1 &&
      this.state.secId2 &&
      this.state.location &&
      this.state.secId3 &&
      this.state.secId4 &&
      this.state.note
    ) {
      warning = 1;
    }
    if (
      this.state.firstname === "" ||
      this.state.gender === "" ||
      this.state.middlename === "" ||
      this.state.lastname === "" ||
      this.state.dateofbirth === "" ||
      this.state.phoneday === "" ||
      this.state.phonenight === "" ||
      this.state.addressline1 === "" ||
      this.state.zipcode === "" ||
      this.state.state === "" ||
      this.state.city === "" ||
      this.state.email === "" ||
      this.state.country === "" ||
      this.state.doctor === "" ||
      this.state.registrationdate === "" ||
      this.state.secId1 === "" ||
      this.state.secId2 === "" ||
      this.state.location === "" ||
      this.state.secId3 === "" ||
      this.state.secId4 === "" ||
      this.state.note === ""
    ) {
      if (this.state.warning === 0) {
        this.setState({ buttontext: "Save/Update Anyway!" });
        if (this.state.gender === "" || this.state.gender === undefined) {
          this.setState({
            genderError: true,
            warning: 1,
          });
        }
        if (this.state.firstname === "" || this.state.firstname === undefined) {
          this.setState({
            firstNameError: true,
            warning: 1,
          });
        }
        if (
          this.state.middlename === "" ||
          this.state.middlename === undefined
        ) {
          this.setState({
            middleNameError: true,
            warning: 1,
          });
        }
        if (this.state.lastname === "" || this.state.lastname === undefined) {
          this.setState({
            lastNameError: true,
            warning: 1,
          });
        }
        if (
          this.state.dateofbirth === "" ||
          this.state.dateofbirth === undefined
        ) {
          this.setState({
            dobError: true,
            warning: 1,
          });
        }
        if (this.state.phoneday === "" || this.state.phoneday === undefined) {
          this.setState({
            phoneDayError: true,
            warning: 1,
          });
        }
        if (
          this.state.phonenight === "" ||
          this.state.phonenight === undefined
        ) {
          this.setState({
            phoneNightError: true,
            warning: 1,
          });
        }
        if (
          this.state.addressline1 === "" ||
          this.state.addressline1 === undefined
        ) {
          this.setState({
            address1Error: true,
            warning: 1,
          });
        }
        if (this.state.state === "" || this.state.state === undefined) {
          this.setState({
            stateError: true,
            warning: 1,
          });
        }
        if (this.state.zipcode === "" || this.state.zipcode === undefined) {
          this.setState({
            postCodeError: true,
            warning: 1,
          });
        }
        if (this.state.country === "" || this.state.country === undefined) {
          this.setState({
            countryError: true,
            warning: 1,
          });
        }
        if (this.state.city === "" || this.state.city === undefined) {
          this.setState({
            cityError: true,
            warning: 1,
          });
        }
        if (this.state.email === "" || this.state.email === undefined) {
          this.setState({
            emailError: true,
            emailErrortext: "!",
            warning: 1,
          });
        }

        if (this.state.doctor === "" || this.state.doctor === undefined) {
          this.setState({
            doctorError: true,
            warning: 1,
          });
        }
        if (this.state.secId1 === "" || this.state.secId1 === undefined) {
          this.setState({
            secID1Error: true,
            warning: 1,
          });
        }

        if (this.state.secId2 === "" || this.state.secId2 === undefined) {
          this.setState({
            secID2Error: true,
            warning: 1,
          });
        }
        if (this.state.secId3 === "" || this.state.secId3 === undefined) {
          this.setState({
            secID3Error: true,
            warning: 1,
          });
        }
        if (this.state.secId4 === "" || this.state.secId4 === undefined) {
          this.setState({
            secID4Error: true,
            warning: 1,
          });
        }
        if (this.state.note === "" || this.state.note === undefined) {
          this.setState({
            noteError: true,
            warning: 1,
          });
        }
        if (!this.state.location) {
          this.setState({
            locationError: true,
            warning: 1,
          });
        }
        if (
          this.state.registrationdate === "" ||
          this.state.registrationdate === undefined
        ) {
          this.setState({
            registerError: true,
            warning: 1,
          });
        }
      }
    } else {
      warning = 1;
    }

    if ((this.state.email != "") & (this.state.email != undefined)) {
      if (emailValidate.test(this.state.email) === false) {
        this.setState({
          emailError: true,
          emailErrortext: "Invalid Email",
        });
        error = true;
      }
    }

    if (error === false && warning === 1) {
      this.setState({
        isLoaded: false,
      });
      let patient = {
        gender: this.state.gender,
        title: this.state.title,
        firstname: this.state.firstname,
        middlename: this.state.middlename,
        lastname: this.state.lastname,
        dateofbirth: this.state.dateofbirth,
        phonenight: this.state.phonenight,
        phoneday: this.state.phoneday,
        addressline1: this.state.addressline1,
        addressline2: this.state.addressline2,
        state: this.state.state,
        zipcode: this.state.zipcode,
        country: this.state.country,
        secId1: this.state.secId1,
        secId2: this.state.secId2,
        secId3: this.state.secId3,
        secId4: this.state.secId4,
        doctor: this.state.doctor,
        registrationdate: this.state.registrationdate,
        note: this.state.note,
        email: this.state.email,
        city: this.state.city,
        location: this.state.location,
        workgroupid: this.state.workgroupid || localStorage.getItem("groupId"),
        userid: this.state.userid || accessDecoded.userReference,
      };

      if (this.state.primaryId === "") {
        patientsWithToken
          .post("/patients", patient)
          .then((res) => {
            this.setState({
              isLoaded: true,
            });
            localStorage.removeItem("local_patientsearch");
          })
          .catch((error) => {
            alert(error.message);
          });
      } else {
        patientsWithToken
          .put("/patients/" + this.state.primaryId, patient)
          .then((res) => {
            this.setState({
              isLoaded: true,
            });
            localStorage.removeItem("local_patientsearch");
          })
          .catch((error) => {
            alert(error.message);
          });
      }
      this.newPatient();
      this.setState({
        success: true,
        message: "success!!",
      });
    }
  };

  newPatient = () => {
    this.setState({
      copy: "",
      search: "",
      dateofbirth: "",
      primaryId: "",
      title: "",
      gender: "",
      firstname: "",
      middlename: "",
      lastname: "",
      dob: "",
      phonenight: "",
      phoneday: "",

      addressline1: "",
      addressline2: "",
      state: "",
      zipcode: "",
      country: "",

      save: false,
      location: false,
      email: "",
      doctor: "",
      secId1: "",
      secId2: "",
      secId3: "",
      secId4: "",
      note: "",
      registrationdate: "",
      city: "",
      patients: [],
      idError: false,
      firstNameError: false,
      middleNameError: false,
      lastNameError: false,
      dobError: false,
      phoneNightError: false,
      phoneDayError: false,
      address1Error: false,
      stateError: false,
      postCodeError: false,
      countryError: false,
      genderError: false,
      cityError: false,
      doctorError: false,
      locationError: false,
      registerError: false,
      secID1Error: false,
      secID2Error: false,
      secID3Error: false,
      secID4Error: false,
      noteError: false,
      emailError: false,
      emailErrortext: "",
      buttontext: "Save/Update",
      warning: 0,
      select: false,
      selectedPatient: {},
      workgroupid: this.state.workgroupid,
      userid: this.state.userid,
    });
    localStorage.removeItem("local_patientsearch");
  };

  deletePatient = () => {
    let id = this.state.primaryId;
    this.setState({
      isLoaded: false,
    });

    patientsWithToken
      .delete("/patients/" + id)
      .then((res) => {
        this.setState({
          message: "deleted !!!",
          isLoaded: true,
          delete: false,
        });
      })
      .catch((err) => {});
    this.newPatient();
  };

  toggleAdvancedSearch = () => {
    this.setState({
      advancedSearch: !this.state.advancedSearch,
      select: !this.state.select,
      primaryIdDisabled: !this.state.primaryIdDisabled,
      patients: [],
      totalRecord: 0,
    });
    this.newPatient();
  };
  setSearchString = (e) => {
    let search = e;

    if (search === "" || undefined) search = "_";
    this.setState({ search: e, select: true });
    this.searchPatient(search);
  };
  searchPatient = debounce((e) => {
    let search = e;
    let groupId = localStorage.getItem("groupId");

    let converted = search.replace("?", "%3F");
    if (search === "") this.newPatient();
    if (search) {
      apiSearchUrlWithToken
        .get(
          "simple/patient/" +
            converted +
            `${groupId ? "?workgroupid=" + groupId : ""}`
        )
        .then((res) => {
          this.setState({
            patients: res.data.patientList,
            save: false,
            totalRecord: res.data.total,
          });
        })
        .catch((err) => {
          this.setState({ patients: [] });
        });
    }

    if (search === "_") this.newPatient();
  }, 500);

  cancel = () => {
    if (this.state.selectedPatient.firstname != undefined) {
      let value = this.state.selectedPatient;
      let dob = value.dateofbirth;
      let Reg = value.registrationdate;
      this.setState({
        search: value.firstname,
        dateofbirth:
          dob === "" || dob === undefined ? "" : new Date(value.dateofbirth),
        primaryId: value.id,
        gender: value.gender,
        firstname: value.firstname,
        middlename: value.middlename,
        lastname: value.lastname,
        phonenight: value.phonenight,
        phoneday: value.phoneday,
        addressline1: value.addressline1,
        addressline2: value.addressline2,
        state: value.state,
        zipcode: value.zip,
        country: value.country,
        selectedPatient: value,
        doctor: value.doctor,
        city: value.city,
        secId1: value.secId1,
        secId2: value.secId2,
        secId3: value.secId3,
        secId4: value.secId4,
        registrationdate:
          Reg === "" || Reg === undefined
            ? ""
            : new Date(value.registrationdate),
        note: value.note,
        location: value.location,
        email: value.email,
        copy: "",
      });
    } else {
      this.newPatient();
    }
  };
  duplicateRecord = () => {
    this.setState({
      primaryId: "",
      save: true,
      search: "",
    });
  };
  highlightQuery = (name, query) => {
    let str = query;
    if (
      query === "*" ||
      query === "?" ||
      query.charAt(0) === "*" ||
      query.charAt(0) === "?"
    ) {
      str = str.slice(1);
    }
    if (query === "*?" || query === "?*") {
      str = str.slice(2);
    }
    var string = str.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "");

    var regex = new RegExp("(" + string + ")", "gi");
    return name.replace(regex, "<strong>$1</strong>");
  };
  setAdvancedString = (e) => {
    let object = this.state.stringObject;
    let groupId = localStorage.getItem("groupId");
    if (groupId) {
      object["workgroupid"] = groupId;
    } else {
      delete object["workgroupid"];
    }
    this.setState({
      [e.target.name]: e.target.value,
    });
    object[e.target.name] = e.target.value;
    this.setState({
      stringObject: object,
    });
    if (e.target.value === "") {
      delete object[e.target.name];
    }

    let advancedString = "";
    const keyvalue = (e) =>
      Object.entries(e).forEach(([key, value]) => {
        advancedString += key + "=" + value + "&";
      });
    keyvalue(object);

    advancedString = advancedString.substring(0, advancedString.length - 1);
    this.advancedSearch(advancedString);
  };
  advancedSearch = (e) => {
    apiSearchUrlWithToken
      .get("advance/patient?" + e)
      .then((res) => {
        this.setState({
          patients: res.data.patientList,
          totalRecord: res.data.total,
        });
      })
      .catch((err) => {
        this.setState({
          patients: [],
          totalRecord: 0,
        });
      });
  };
  handletitle = (e) => {
    let title = e.target.value;
    if (title === "Mr.") {
      this.setState({
        title: title,
        gender: "Male",
        save: true,
      });
    }
    if (title === "Ms.") {
      this.setState({
        title: title,
        gender: "Female",
        save: true,
      });
    }
    if (title === "Dr.") {
      this.setState({
        title: title,
        save: true,
      });
    }
    this.setlocal(e);
  };
  render() {
    if (!this.state.isLoaded) {
      let msg = !this.state.isLoaded ? "Loading ..." : "";
      return <Spinner msg={msg} styles={this.state.styles} />;
    }
    const {
      isPatienVisible,
      togglePatient,
      setPatient,
      styles,
      toggleDelete,
    } = this.props;

    const closePopup = () => {
      togglePatient();
      // localStorage.removeItem("local_patientsearch");
    };
    const selectPopup = () => {
      let patient = {
        name: `${this.state.title ? this.state.title : ""} ${
          this.state.firstname ? this.state.firstname : ""
        }  ${this.state.lastname ? this.state.lastname : ""}`,
        id: this.state.primaryId,
      };
      //  this.props.saveSchedulerProps({ name: "patient", value: patient });
      this.props.setSelectedPatient(patient);
      setPatient(patient);
      togglePatient();
      this.setlocal();
    };
    const deletePatient = () => {
      toggleDelete(this.state.primaryId);
      this.newPatient();
    };

    let input_colour = "";
    if (this.state.advancedSearch === false) {
      input_colour = this.state.styles.patient.input_border_colour;
    } else {
      input_colour = this.state.styles.patient.advanced_border_colour;
    }

    let title = this.state.title;
    if (this.state.gender === "Male") {
      title = "Mr.";
    } else if (this.state.gender === "Female") {
      title = "Ms.";
    }
    if (title === "Dr.") {
      title = "Dr.";
    }
    if (title === "") {
      title = "";
    }
    const Button = styled.button({
      width: "80%",
      height: "25px",
      borderRadius: this.state.styles.patient.button_border_radius,
      backgroundColor: this.state.styles.patient.active_button_colour,
      borderWidth: 0,
      margin: "10px 0px",
      color: this.state.styles.patient.button_text_colour,
      fontSize: this.state.styles.patient.button_text_size,
      fontWeight: "bold",
      cursor: "pointer",
    });
    const Radio = styled.input`
      width: 20px;
      height: 20px;
    `;
    const Label = styled.label`
      display: flex;
      color: ${this.state.styles.patient.label_text_colour};
      font-size: ${this.state.styles.patient.label_text_size};
    `;
    const Errortext = styled.p({
      color: this.state.styles.patient.error_text_colour,
      margin: 0,
      fontSize: this.state.styles.patient.error_text_size,
    });
    const length = this.state.patients.length;
    const width = window.innerWidth;
    let New = false;
    if (this.state.selectedPatient.firstname != undefined || this.state.save) {
      New = true;
    }
    let Patients = [];
    Patients = this.state.patients.slice(0, 10);
    return (
      <Styles
        theme={this.state.styles.patient}
        themes={styles}
        inputColor={input_colour}
        width={width}
      >
        <div className="popup" style={{ zIndex: "1", marginTop: "100px" }}>
          <div className="popup-header">
            <h3 style={{ color: "#fff" }}>Patients</h3>
            <span
              className="close"
              style={{ color: "#fff" }}
              onClick={closePopup}
            >
              X
            </span>
          </div>
          <div className="popup-body">
            <div className="main-box">
              <div className="content-box1">
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p style={{ color: "#000" }} className="header">
                    Patient Selections -
                  </p>
                </div>
                <Label>Patient </Label>
                <div style={{ position: "relative" }}>
                  <div className="search-box">
                    <input
                      disabled={
                        true ? this.state.advancedSearch === true : false
                      }
                      onFocus={() => null}
                      value={this.state.search}
                      onChange={(e) => this.setSearchString(e.target.value)}
                      className="search"
                    />
                    {this.state.advancedSearch ? (
                      <BsFillCaretDownFill
                        style={{
                          cursor: "pointer",
                          color: "#ccc",
                          fontSize: 20,
                        }}
                      />
                    ) : this.state.styles.icons?.patient_search ? (
                      <img
                        src={this.state.styles.icons.patient_search}
                        style={{ width: 20 }}
                        alt=".."
                      />
                    ) : (
                      <BsSearch
                        style={{
                          cursor: "pointer",
                          color: "#ccc",
                          fontSize: 20,
                        }}
                      />
                    )}
                  </div>
                  {this.state.select || this.state.advancedSearch ? (
                    <div className="search-panel">
                      <div className="count">
                        {Patients.length || 0} of {this.state.totalRecord}{" "}
                        values
                      </div>
                      {length > 0 &&
                        Patients.map((patient) => (
                          <div
                            className="dropdown-item"
                            key={patient.primaryId + ""}
                            onClick={(e) => this.changePatient(patient)}
                            // onMouseEnter={() => this.changePatient(patient)}
                          >
                            <span
                              id="search-display"
                              dangerouslySetInnerHTML={{
                                __html: this.highlightQuery(
                                  patient.firstname +
                                    " " +
                                    patient.middlename +
                                    " " +
                                    patient.lastname,
                                  this.state.search
                                ),
                              }}
                            ></span>

                            {", "}
                            {patient.title}
                          </div>
                        ))}
                    </div>
                  ) : null}
                </div>
                <div className="space"></div>
              </div>
              <div className="toolbar">
                <div
                  className="row"
                  style={{
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "0px 20px",
                    marginBottom: "10px",
                  }}
                >
                  <p style={{ color: "#000" }} className="header">
                    Patient Details -
                  </p>
                  <SearchToolBar
                    src={
                      this.state.advancedSearch
                        ? this.state.icons.patient_filter_active
                        : this.state.icons.patient_filter
                    }
                    toggleAdvanced={() => this.toggleAdvancedSearch()}
                    iconsFragment={
                      <>
                        <Icons
                          src={this.state.icons.record_select}
                          title="Select"
                          triggerFunc={() => selectPopup()}
                          isActive={this.state.primaryId != ""}
                        />
                        <Icons
                          src={this.state.icons.record_delete}
                          title="Delete Record"
                          triggerFunc={() => deletePatient()}
                          isActive={this.state.primaryId != ""}
                        />
                        <Icons
                          src={this.state.icons.record_update}
                          title="Duplicate Record"
                          triggerFunc={() => this.duplicateRecord()}
                          isActive={this.state.primaryId != ""}
                        />
                        <Icons
                          src={this.state.icons.record_new}
                          title="Copy Record"
                          triggerFunc={() => null}
                          isActive={false}
                        />
                        <Icons
                          src={this.state.icons.toolbar_cancel}
                          title="Cancel Record"
                          triggerFunc={() => this.cancel()}
                          isActive={this.state.save}
                        />
                        <Icons
                          src={this.state.icons.toolbar_save}
                          title="Save Record"
                          triggerFunc={() => this.addPatient()}
                          isActive={this.state.save}
                        />
                        <Icons
                          src={this.state.icons.toolbar_copy}
                          title="Copy Field"
                          triggerFunc={() => this.copyToClipboard()}
                          isActive={this.state.copy != ""}
                        />
                        <Icons
                          src={this.state.icons.scheduler_add}
                          title="New Record"
                          triggerFunc={() => this.newPatient()}
                          isActive={this.state.save || this.state.primaryId}
                        />
                      </>
                    }
                  ></SearchToolBar>
                </div>
                <div className="content">
                  <div className="content-box">
                    <div className="row">
                      <div className="sub-content">
                        <h3 className="heading">Patient Details</h3>
                        <TextFieldGroup
                          className="input"
                          value={this.state.primaryId}
                          labelProps={{
                            label: "Primary id",
                          }}
                          inputProps={{
                            disabled: this.state.primaryIdDisabled,
                            value: this.state.primaryId,
                            name: "primaryId",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.setState({
                                    primaryId: e.target.value,
                                    save: true,
                                    idError: false,
                                  }),
                          }}
                        />
                        <div
                          className="label-error"
                          style={{ marginBottom: "0px" }}
                        >
                          <Label>Gender Biological</Label>
                          {this.state.genderError ? (
                            <Errortext>!</Errortext>
                          ) : null}
                        </div>
                        <div
                          onChange={(e) =>
                            this.state.advancedSearch
                              ? this.setAdvancedString(e)
                              : this.handleGender(e)
                          }
                          className="genderContainer"
                        >
                          <div className="row">
                            <label htmlFor="male">Male</label>
                            <Radio
                              id="male"
                              type="radio"
                              value="Male"
                              name="gender"
                              className="radio"
                              checked={this.state.gender === "Male"}
                              onChange={(e) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(e)
                                  : this.handleGender(e)
                              }
                            />
                          </div>
                          <div className="row">
                            <label htmlFor="female">Female</label>
                            <Radio
                              id="female"
                              type="radio"
                              name="gender"
                              value="Female"
                              className="radio"
                              checked={this.state.gender === "Female"}
                              onChange={(e) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(e)
                                  : this.handleGender(e)
                              }
                            />
                          </div>
                        </div>
                        <SelectFieldGroup
                          className="input"
                          labelProps={{
                            label: "Title",
                          }}
                          inputProps={{
                            value: this.state.title,
                            type: "select",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handletitle(e),
                            options: this.state.titles,
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "First Name",
                            error: this.state.firstNameError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.firstname,
                            name: "firstname",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleFirstName(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Middle Name",
                            error: this.state.middleNameError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.middlename,
                            name: "middlename",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleMiddleName(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Last Name",
                            error: this.state.lastNameError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.lastname,
                            name: "lastname",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleLastName(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />

                        <DateFieldGroup
                          className="date-input"
                          labelProps={{
                            label: "Date Of Birth",
                            error: this.state.dobError ? "!" : false,
                          }}
                          inputProps={{
                            title: "Date Of Birth",
                            name: "dateofbirth",
                            selected: this.state.dateofbirth,
                            onChange: (date) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString({
                                    target: {
                                      name: "dateofbirth",
                                      value: date ? date.toISOString() : "",
                                    },
                                  })
                                : this.handleChange(date),
                            maxDate: new Date(),
                          }}
                        />
                      </div>
                      <div className="sub-content">
                        <h3 className="heading">Contact Details</h3>
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Phone Day",
                            error: this.state.phoneDayError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.phoneday,
                            name: "phoneday",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handlePhoneDay(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Phone Night",
                            error: this.state.phoneNightError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.phonenight,
                            name: "phonenight",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handlePhoneNight(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          style={{ marginBottom: "0px" }}
                          className="input"
                          labelProps={{
                            label: "Address",
                            error: this.state.address1Error ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.addressline1,
                            name: "addressline1",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleAddress1(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <input
                          style={{ marginBottom: "20px" }}
                          value={this.state.addressline2}
                          type="numeric"
                          name="addressline2"
                          className="address input"
                          onChange={(e) =>
                            this.state.advancedSearch
                              ? this.setAdvancedString(e)
                              : this.handleAddress2(e)
                          }
                          onFocus={(e) => this.setCopy(e)}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "City",
                            error: this.state.cityError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.city,
                            name: "city",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleCity(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "State / Country / Province",
                            error: this.state.stateError ? "!" : "",
                          }}
                          inputProps={{
                            name: "state",
                            value: this.state.state,
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleState(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Zip / Post Code",
                            error: this.state.postCodeError ? "!" : "",
                          }}
                          inputProps={{
                            name: "zipcode",
                            value: this.state.zipcode,
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleZip(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <SelectFieldGroup
                          className="input"
                          labelProps={{
                            label: "Country",
                            error: this.state.countryError ? "!" : "",
                          }}
                          inputProps={{
                            name: "country",
                            value: this.state.country,
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            options: country,
                          }}
                        />
                      </div>
                    </div>
                    <TextFieldGroup
                      className="email"
                      labelProps={{
                        label: "Email",
                        error: this.state.emailError
                          ? this.state.emailErrortext
                          : "",
                      }}
                      inputProps={{
                        value: this.state.email,
                        name: "email",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e)
                            : this.setState({
                                email: e.target.value,
                                copy: e.target.value,
                                save: true,
                                emailError: false,
                              }),
                        onFocus: (e) => this.setCopy(e),
                      }}
                    />
                  </div>
                  <div className="content-box">
                    <div
                      style={{
                        flexDirection: "row",
                        display: "flex",
                      }}
                    >
                      <div className="sub-content">
                        <h3 className="heading">Clinical</h3>
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Doctor",
                            error: this.state.doctorError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.doctor,
                            name: "doctor",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.handleDoctor(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <SelectFieldGroup
                          className="input"
                          labelProps={{
                            label: "Practice Location",
                            error: this.state.locationError ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.location,
                            name: "location",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            options: this.state.locations,
                          }}
                        />

                        <DateFieldGroup
                          className="date-input inputdate_Align"
                          labelProps={{
                            label: "Registration Date",
                            error: this.state.registerError ? "!" : false,
                          }}
                          inputProps={{
                            title: "Registration Date",
                            name: "registrationdate",
                            selected: this.state.registrationdate,
                            onChange: (date) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString({
                                    target: {
                                      name: "registrationdate",
                                      value: date ? date.toISOString() : "",
                                    },
                                  })
                                : this.handleRegister(date),
                            minDate: this.state.advancedSearch
                              ? ""
                              : new Date(),
                          }}
                        />
                      </div>
                      <div className="sub-content">
                        <div style={{ height: "15px" }}></div>
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Secondary ID - 1",
                            error: this.state.secID1Error ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.secId1,
                            name: "secId1",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Secondary ID - 2",
                            error: this.state.secID2Error ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.secId2,
                            name: "secId2",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />

                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Secondary ID - 3",
                            error: this.state.secID3Error ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.secId3,
                            name: "secId3",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                        <TextFieldGroup
                          className="input"
                          labelProps={{
                            label: "Secondary ID - 4",
                            error: this.state.secID4Error ? "!" : "",
                          }}
                          inputProps={{
                            value: this.state.secId4,
                            name: "secId4",
                            onChange: (e) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(e)
                                : this.onInputChange(e),
                            onFocus: (e) => this.setCopy(e),
                          }}
                        />
                      </div>
                    </div>
                    <TextAreaFieldGroup
                      className="text-area"
                      labelProps={{
                        label: "Note",
                        error: this.state.noteError ? "!" : "",
                      }}
                      inputProps={{
                        rows: 12,
                        name: "note",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e)
                            : this.onInputChange(e),
                        onFocus: (e) => this.setCopy(e),
                        value: this.state.note,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Styles>
    );
  }
}
const mapActionToProp = () => ({
  ...setSelectedPatient,
});

export default connect(null, mapActionToProp())(AddPatientModal);

const Styles = styled.div`
  height: calc(100vh - 30px);
  width: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  color: #666;
  right: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
  font-size: calc(0.9vh + 6px);
  background: rgb(0, 0, 0, 0.5);

  label span span {
    font-weight: 400 !important;
  }

  label {
    font-weight: 400 !important;
    font-size: 12px;
  }

  // input{
  //   padding:0px !important;
  // }

  .icons-action {
    padding-bottom: 5px;
  }

  .popup {
    height: 89%;
    overflow-y: auto;
    overflow-x: hidden;
    min-width: 1082px;
    width: 70%;
    .popup-body {
      .main-box {
        .toolbar {
          margin: 0 auto;
          width: 100%;
          .content {
            height: calc(68vh - 35px);
            overflow-y: auto;
          }
        }
      }
    }

    button {
      border: 0;
    }

    .popup-header {
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: ${(props) => props.themes.panels.base_colour};
      color: ${(props) =>
        props.themes.popup.active_in_focus_banner_text_colour};
      padding: 5px 10px;
      border-radius: 5px 5px 0 0;
      border: ${(props) => props.themes.panels.border_thickness} solid
        ${(props) => props.themes.panels.border_colour};

      h3 {
        margin: 0;
        font-weight: 500;
        padding: 0;
        font-size: calc(80% + 5px);
      }
      .close {
        font-weight: bold;
        cursor: pointer;
        font-size: 12px;
      }
    }
    .popup-body {
      position: relative;
      border: 1.5px solid
        ${(props) => props.themes.popup.active_in_focus_border_colour};
      border-radius: 0 0
        ${(props) => props.themes.popup.active_in_focus_corner_radius};
      ${(props) => props.themes.popup.active_in_focus_corner_radius};
      padding: 0px 5px;
      background: white;
      .row {
        flex-direction: row;
        display: flex;
      }

      .sub-content > div {
        margin-bottom: 20px;
      }

      .main-box {
        flex-direction: row;
        display: flex;
        padding: 2px 0 5px 0;
      }
      .space {
        height: 180px;
      }
      .content {
        flex-direction: row;
        display: flex;
        padding: 0 20px;
      }
      .email {
        width: 94%;
        padding: 0px;
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
      }
      .input {
        padding: 0px;
        width: 90%;
      }
      .date-input {
        width: 90%;
      }
      .search-box {
        height: 27px;
        display: flex;
        flex-direction: row;
        border: 1px solid ${(props) => props.theme.search_border_colour};
        border-radius: 5px;
        align-items: center;
        box-shadow: 0px 0px 2px #999;
        svg {
          font-size: 15px !important;
        }
      }
      .search-panel {
        position: absolute;
        background-color: #ffffff;
        padding: 0px 5px;
        width: 100%;
        border: 1px solid ${(props) => props.theme.search_border_colour};
        min-height: 100px;
      }
      .count {
        color: rgb(67, 149, 166);
        padding: 1%;
        font-size: 10px;
      }
      .filter {
        color: ${(props) => props.inputColor};
        font-size: 20px;
        z-index: 99;
      }
      .search {
        width: 90%;
        border-radius: 5px;
        height: 20px;
        border: 0;
        padding: 2%;
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        box-shadow: 0px 0px 0px #999;
      }
      .search:disabled {
        background-color: #ffffff;
      }
      .label-error {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin-top: 5px;
        align-items: center;
        height: 10px;
        padding-right: 10%;
      }
      > div > input,
      > div > select {
        width: 90%;
        border-radius: 5px;
        border: 1px solid ${(props) => props.inputColor};
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
        box-shadow: 0px 0px 2px #999;
      }
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }
      select {
        border-radius: 5px;
        border: 1px solid ${(props) => props.inputColor};
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
        background-color: #ffffff;
        box-shadow: 0px 0px 2px #999;
      }
      input {
        border: 1px solid ${(props) => props.inputColor};
      }
      textarea {
        border: 1px solid ${(props) => props.inputColor};
      }
      .header {
        font-size: calc(0.9vh + 8px);
        margin: 0;
        font-weight: bolder;
        margin-top: 10px;
      }
      .heading {
        font-size: calc(0.9vh + 8px);
        margin: 0;
        font-weight: bolder;
        color: #4395a6;
        margin-bottom: 20px;
      }
      .address {
        width: 90%;
        border-radius: 5px;
        height: 27px;
        border: 1px solid ${(props) => props.inputColor};
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 12px;
        box-shadow: 0px 0px 2px #999;
      }
      .row {
        flex-direction: row;
        display: flex;
      }
      .dropdown-item {
        font-size: 10px;
      }
      .dropdown-item:hover {
        background-color: #ccc;
      }
      .content-box1 {
        border-right: 1px solid #ccc;
        padding: 0 10px;
        margin-right: 5px;
        min-width: 25%;
      }
      .content-box {
        padding: 0 0 5px 5px;
        margin: 0 auto;
        width: 100%;
        .sub-content {
          width: 48%;
          margin-right: 5px;
          .radio {
            width: 12px;
            height: 12px;
            box-shadow: 0px 0px 0px #999;
          }
        }
        .sub-content1 {
          width: 50%;
          .radio {
            margin-left: 2px;
            width: 20px;
            height: 10px;
            box-shadow: 0px 0px 0px #999;
          }
        }
      }
    }
  }

  @media ${device.tablet} {
    right: 2.5%;
    .popup {
      margin-top: 50%;
      max-width: 350px;
      margin-right: 0;
      .popup-body {
        .main-box {
          flex-direction: column;
          display: flex;
          max-width: 350px;
        }
        .content {
          flex-direction: column;
          display: flex;
        }
        .space {
          height: 30px;
        }
        .content-box1 {
          max-width: 350px;
        }
        .content-box {
          min-width: 350px;
          max-width: 350px;
        }
      }
    }
  }

  .genderContainer {
    display: flex;
    justify-content: center;
    align-items: center;
    color: #666;

    input {
      margin-top: -1px;
    }
    .row {
      width: 50%;
      display: flex;
      padding: 5px;
      height: 30px;
      align-items: center;
      label {
        padding-right: 4px;
        font-weight: 400 !important;
      }
    }
  }
`;
