import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";

const HubLogo = ({ history }) => {
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <img
          src={styles.icons.hub_logo ? styles.icons.hub_logo : null}
          alt=".."
        />
      }
    </>
  );
};

export default HubLogo;
