import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";

const ButtonLink = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <LinkStyle theme={styles.landing_page}>
          <i className="fa fa-trophy"></i>Find Colleagues
        </LinkStyle>
      }
    </>
  );
};

export default ButtonLink;

const LinkStyle = styled.li`
  display: inline-block;
  padding: 10px 30px;
  font-size: 14px;
  img {
    width: 50px;
    height: 50px;
    border-radius: 25px;
  }
  :nth-child(2) {
    color: ${(props) =>
      props.theme.tl_findclgbtn_font_colorr};
    border: 2px solid #80d7d8;
    padding: 10px 20px;
    border-radius: 30px;
    background-color: transparent !important;
    font-weight: 600 !important;
  }
  :nth-child(2):hover {
    cursor: pointer;
  }
  i {
    margin-right: 5px;
  }
`;
