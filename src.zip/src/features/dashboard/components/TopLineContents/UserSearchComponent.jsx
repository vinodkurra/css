import React, { Component } from "react";
import styled from "styled-components";
import { BsSearch, BsFillCaretDownFill } from "react-icons/bs";

export default class SearchComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      search: "",
      select: false,
      styles: {
        popup: {},
        panels: {},
      },
    };
  }
  clear = () => {
    this.setState({
      search: "",
    });
  };
  highlightQuery = (name, query) => {
    let str = query;
    if (
      query === "*" ||
      query === "?" ||
      query.charAt(0) === "*" ||
      query.charAt(0) === "?"
    ) {
      str = str.slice(1);
    }
    if (query === "*?" || query === "?*") {
      str = str.slice(2);
    }
    var string = str.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "");

    var regex = new RegExp("(" + string + ")", "gi");
    return name.replace(regex, "<strong>$1</strong>");
  };
  render() {
    const {
      totalRecords,
      onInputChange,
      advancedSearch,
      datas,
      onMouseOver,
      onSelect,
    } = this.props;
    const select = (data) => {
      this.setState({
        select: false,
        search:
          `${data.firstname ? data.firstname : ""}` +
          " " +
          `${data.lastname ? data.lastname : ""}`,
      });
      onSelect(data);
    };
    const handlechange = (e) => {
      this.setState({
        search: e,
        select: true,
      });
      if (!e) {
        this.setState({
          search: "",
          select: false,
        });
      }
      onInputChange(e);
    };
    let Dropdown = this.state.select;
    if (advancedSearch === true) {
      Dropdown = true;
    }

    const length = datas.length;
    return (
      <Search>
        <div className="search-box">
          <input
            disabled={advancedSearch}
            onFocus={() => this.setState({ select: true })}
            value={this.state.search}
            onChange={(e) => handlechange(e.target.value)}
            className="search"
          />
          {advancedSearch ? (
            <BsFillCaretDownFill
              style={{
                cursor: "pointer",
                color: "#ccc",
                fontSize: 15,
              }}
            />
          ) : this.state.styles.icons?.patient_search ? (
            <img
              src={this.state.styles.icons.patient_search}
              style={{ width: 15 }}
              alt=".."
            />
          ) : (
            <BsSearch
              style={{
                cursor: "pointer",
                color: "#ccc",
                fontSize: 15,
              }}
            />
          )}
          {Dropdown ? (
            <div className="search-panel">
              <div className="count">
                {length || 0} of {totalRecords || 0} values
              </div>
              {length > 0 &&
                datas.map((data) => (
                  <div
                    className="dropdown-item"
                    onClick={() => select(data)}
                    onMouseEnter={() => onMouseOver(data)}
                  >
                    <span
                      id="search-display"
                      dangerouslySetInnerHTML={{
                        __html: this.highlightQuery(
                          `${data.firstname ? data.firstname : ""}` +
                            " " +
                            `${data.lastname ? data.lastname : ""}`,
                          this.state.search
                        ),
                      }}
                    ></span>
                  </div>
                ))}
            </div>
          ) : null}
        </div>
      </Search>
    );
  }
}
const Search = styled.div`
  position: relative;
  margin-top: 2px;
  .search-box {
    display: flex;
    flex-direction: row;
    border: 1px solid ${(props) => props.theme.search_border_colour};
    border-radius: 5px;
    align-items: center;
    box-shadow: 0px 0px 2px #999;
    width: 100%;
    .search-panel {
      position: absolute;
      background-color: #ffffff;
      width: 100%;
      min-height: 200px;
      border: 1px solid ${(props) => props.theme.search_border_colour};
      top: 100%;
      right: 0.2%;
    }
    .count {
      color: rgb(67, 149, 166);
      padding: 2%;
    }
    .search {
      width: 90%;
      border-radius: 5px;
      border: 0;
      padding: 0 2%;
      outline: 0px;
      box-sizing: border-box;
      box-shadow: 0px 0px 0px rgba(0, 0, 0, 0);
    }
    .search:disabled {
      background-color: #ffffff;
    }
    .dropdown-item {
      padding: 2%;
    }
    .dropdown-item:hover {
      padding: 2%;
      background-color: #ccc;
    }
  }
`;
