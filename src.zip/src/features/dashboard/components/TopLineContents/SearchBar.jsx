import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import logo from "../../../../assets/logo.png";
import {
  addSearchItem,
  setSelectedPatient,
} from "../../../../store/LandingPage/index";
import styled from "styled-components";
import PatientSearch from "./PatientSearch";
import { closeAllPopups } from '../../helper/closePopups'

import axios from "axios";

const SearchBar = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const searchItems = useSelector((state) => state.landingpage.searchItems);
  const [show, setShow] = useState(false);

  const [searchparam, setParam] = useState("");
  const checkSumId = JSON.parse(localStorage.getItem("account")) ? JSON.parse(localStorage.getItem("account")).userid : '';

  const searchPatient = (text) => {
    console.log(text);
    const options = {
      headers: {
        Authorization: "Bearer" + " " + localStorage.getItem("token"),
        checksumid: checkSumId,
      },
    };
    axios
      .get(
        `https://searchservice-dev.cyb.co.uk:8085/search/simple/patient/${text}`,
        options
      )
      .then((res) => {
        dispatch(addSearchItem(res.data.patientList));
      })
      .catch((err) => console.log(err));
  };

  return (
    <>
      {
        <li className="dropdown" onClick={closeAllPopups}>
          <a type="button" data-toggle="dropdown">
            <i className="fa fa-search"></i>
          </a>
          {/* <SearchNotificationStyle className="dropdown-menu">
            <div className="search">
              <input
                placeholder="search"
                value={searchparam}
                onChange={(e) => {
                  setParam(e.target.value);
                  searchPatient(e.target.value);
                }}
              />
            </div>

            {searchItems.length === 0 ? (
              <div className="recentsearch" style={{cursor:"pointer"}}>
                <h2>Recent Searches</h2>
                <ul>
                  <li>Recent Search</li>
                  <li>Recent Search</li>
                  <li>Recent Search</li>
                  <li>Recent Search</li>
                </ul>
              </div>
            ) : (
              <div className="recentsearch" style={{cursor:"pointer"}}>
                <ul>
                  {searchItems.map((data) => (
                    <li onClick={()=> dispatch(setSelectedPatient(data))}>{data.firstname} {data.lastname}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="searchsignout">
              <a>Go to Help Center</a>
            </div>
          </SearchNotificationStyle> */}
          {/* {show ? 
            <PatientSearch
              isPopupVisible={show}
              togglePatient={() => setShow(false)}
              styles={styles}
              setPatient={(e) => null}
              toggleDelete={(e) => null}
            />
           : null} */}
        </li>
      }
    </>
  );
};

export default SearchBar;

const SearchNotificationStyle = styled.div`
  border-radius: 10px;
  border: none;
  left: -150px;
  top: 95px;
  width: 350px;
  .search input {
    background-color: ${(props) =>
      props.theme.TopMenuColors.SearchNotification
        .search_input_backgroundcolor};
    border-radius: 30px;
    font-size: 20px;
    padding: 10px 40px;
    color: "black";
    border: none;
    margin-bottom: 20px;
    margin-top: 20px;
  }
  .searchnotifi .search {
    text-align: center;
    border-bottom: 1px solid
      ${(props) => props.theme.TopMenuColors.SearchNotification.search_bottom};
  }
  .recentsearch {
    border-bottom: 1px solid
      ${(props) =>
        props.theme.TopMenuColors.SearchNotification.recentsearch_bottom};
    ul {
      padding: 10px;
      li {
        display: block;
        line-height: 35px;
        color: ${(props) =>
          props.theme.TopMenuColors.SearchNotification.li_color};
        font-size: 16px;
        padding: 0px 10px;
      }
    }
    h2 {
      margin: 0;
      margin-left: 20px;
      color: ${(props) => props.theme.TopMenuColors.SearchNotification.h2};
    }
  }
`;
