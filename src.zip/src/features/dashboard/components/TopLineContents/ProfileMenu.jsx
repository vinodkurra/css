import React, { useState, useEffect } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import jwtDecode from "jwt-decode";
import { letter } from "../../helper/profileLetter";
import styled from "styled-components";
import { apiUrlWithToken, notificationUrl } from "../../../../calls/apis";
import { closeAllPopups } from "../../helper/closePopups";
import { updateBreadCrumb } from '../../../../store/content';
import {
  switchGroupAccount,
  startConsutationClearTimer,
  selectedAppointments,
  editTimerAppointment,
  setSelectedUser,
} from "../../../../store/LandingPage/index";
import Countdown from "react-countdown";
import moment from "moment";
import updateModal from "./AppointmentPopup";
import defaultLogo from '../../../../assets/default-avatar-profile.jpg'
const ProfileMenu = ({ history, authObj }) => {
  const [logo, setLogo] = useState("");
  const [groups, setGroups] = useState([]);
  const [persona, setPersona] = useState(null);
  const [loading, setloading] = useState(false);
  const [showDiv, setShowDiv] = useState(false);
  const [stayDiv, setstayDiv] = useState(false);
  const [isConStarted, setConStart] = useState(false);
  const dispatch = useDispatch();
  const [type, setType] = useState(
    localStorage.getItem("groupName") || "private"
  );
  const styles = useSelector((state) => state.ui.styles);
  let timerAppointmentData = useSelector(
    (state) => state.landingpage.timerAppointment
  );
  if (timerAppointmentData === undefined) timerAppointmentData = [];

  const { breadcrumb } = useSelector(state => state.content);

  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  const handleLogout = () => {
    apiUrlWithToken.post("/auth/logout").then((res) => {
      authObj.authenticate(false);
      localStorage.removeItem("email");
      localStorage.removeItem("token");
      localStorage.removeItem("isAuthenticated");
      localStorage.removeItem("groupId");
      localStorage.removeItem("groupName");
      localStorage.removeItem("orgId");
      localStorage.removeItem("accesstoken");
      localStorage.removeItem("refreshtoken");
      localStorage.removeItem("firebasetoken");
      localStorage.removeItem("appointments");
      window.location.replace("/");
      // history.push("/");
    });
    // .catch((err) => {
    //   if (err.response) {
    // 		console.log(err.response);
    //
    //   } else if (err.request) {
    // 		console.log(err.request);
    //
    //   } else {
    // 		console.log(err)
    //
    //   }
    // });
  };
  const getValueIfExists = (value) => {
    return value ? value : "";
  };
  let accessDecode = jwtDecode(localStorage.getItem("accesstoken"));

  useEffect(() => {
    window.addEventListener(
      "message",
      function (event) {
        var { name } = event.data;
        setPersona({ ...persona, name });
      },
      false
    );

    window.localStorage.removeItem("group");
    window.addEventListener("message", function (event) {
      getData(accessDecode);
    });
    getData(accessDecode);
  }, []);

  /*
  corrections on style-api
  main_menu.highlight_colour = #4395A6;
*/

  const setGroup = (e) => {
    setIsDropdownVisible(false);
    let groupObj = {
      groupId: e.workgroup_id,
      groupName: e.workgroup_name,
      orgId: e.organisation_id,
    };
    dispatch(switchGroupAccount([groupObj]));
    dispatch(updateBreadCrumb({ ...breadcrumb, accountType: e.workgroup_name }));
    localStorage.setItem("groupId", e.workgroup_id);
    localStorage.setItem("groupName", e.workgroup_name);
    localStorage.setItem("orgId", e.organisation_id);
    setType(e.workgroup_name);
    let group = {
      groupId: e.workgroup_id,
      groupName: e.workgroup_name,
      orgId: e.organisation_id,
    };
    const childFrameObj = document.getElementById("iframeContent");
    if (childFrameObj) {
      childFrameObj.contentWindow.postMessage(JSON.stringify(group), "*");
    }
  };
  const setPrivate = (e) => {
    setIsDropdownVisible(false);
    dispatch(switchGroupAccount([]));
    setType("Private");
    dispatch(updateBreadCrumb({ ...breadcrumb, accountType: "Private" }));
    let group = {
      groupId: "",
      groupName: "",
      orgId: "",
    };
    const childFrameObj = document.getElementById("iframeContent");
    if (childFrameObj) {
      childFrameObj.contentWindow.postMessage(JSON.stringify(group), "*");
    }
    localStorage.removeItem("groupId");
    localStorage.removeItem("groupName");
    localStorage.removeItem("orgId");
  };

  function getData(accessDecode) {
    setGroups([]);
    setloading(true);
    apiUrlWithToken
      .get(`/auth/find/${accessDecode.userReference}`)
      .then(({ data }) => {
        const profile = data.account[0];

        const { email } = profile;
        const { title, firstname, lastname } = profile;
        let name = `${getValueIfExists(title)} ${getValueIfExists(
          firstname
        )} ${getValueIfExists(lastname)}`;

        setPersona({ name, email });
        setLogo(data.account[0].profilepic);

        apiUrlWithToken
          .get(`/groupuser/workgrouplist/${accessDecode.userReference}`)
          .then((res) => {
            setGroups(res.data.groups);
            setloading(false);
          });
      });
  }

  // useEffect(() => {
  //   window.$(".bd-example-modal-sm").modal("show");
  // }, []);
  // Random component
  const Completionist = () => <span>You are good to go!</span>;

  // Renderer callback with condition
  const renderer = ({ minutes, seconds, completed }) => {
    if (completed) {
      return (
        <span className="fnt_wgt">
          {`${minutes}`}
          <br />
          <span className="minu_sec_fnt fnt_wgt">MINUTES</span>
        </span>
      );
    } else if (minutes === 0) {
      if (timerAppointmentData[0].seconds >= 0) {
        return (
          <span className="fnt_wgt">
            {`${seconds}`}
            <br />
            <span className="minu_sec_fnt fnt_wgt">SECONDS</span>
          </span>
        );
      } else {
        return (
          <span className="fnt_wgt">
            {"-" + `${minutes}`}
            <br />
            <span className="minu_sec_fnt fnt_wgt">MINUTES</span>
          </span>
        );
      }
    } else {
      if (timerAppointmentData[0].seconds >= 0) {
        return (
          <span className="fnt_wgt">
            {`${minutes}`}
            <br />
            <span className="minu_sec_fnt fnt_wgt">MINUTES</span>
          </span>
        );
      } else {
        return (
          <span className="fnt_wgt">
            {"-" + `${minutes}`}
            <br />
            <span className="minu_sec_fnt fnt_wgt">MINUTES</span>
          </span>
        );
      }
    }
  };
  return (
    <>
      {
        <li className="dropdown" onClick={closeAllPopups}>
          <a className=" dropdown-toggle" type="button" data-toggle="dropdown">
            <img
              src={logo !== "" ? logo : defaultLogo}
            />
          </a>

          {timerAppointmentData.length > 0 ? (
            <button
              type="button"
              className="btn btn-primary btn_tmealign"
              data-toggle="modal"
              data-target=".bd-example-modal-sm"
              style={{
                backgroundColor:
                  timerAppointmentData[0].seconds >= 0
                    ? "007bffe6"
                    : "007bffe6",
                color: "white",
              }}
              onClick={() => {
                setShowDiv(true);
                setstayDiv(true);
              }}
              onMouseEnter={() => setShowDiv(true)}

            // onMouseEnter={() => {
            //   setShowDiv(true);
            //   window.$(".bd-example-modal-sm").modal("show")
            // }}
            >
              <i className="fa fa-bell notifyicon"></i>
              <Countdown
                date={
                  timerAppointmentData[0].seconds > 0
                    ? Date.now() + timerAppointmentData[0].seconds
                    : Date.now() + Math.abs(timerAppointmentData[0].seconds)
                }
                renderer={renderer}
              />
            </button>
          ) : null}
          {timerAppointmentData &&
            timerAppointmentData.length > 0 &&
            showDiv ? (
              <div
                onMouseLeave={() => {
                  if (stayDiv == true) {
                  } else {
                    setShowDiv(false);
                  }
                }}
              >
                <div className="appontmnttime">
                  <div className="modal-header">
                    <h5 className="modal-title" id="exampleModalLongTitle">
                      Appointment in{" "}
                      {Math.floor(timerAppointmentData[0].seconds / 60000)}{" "}
                    minutes
                  </h5>
                    <button
                      type="button"
                      className="close"
                      onClick={() => {
                        setShowDiv(false);
                        setstayDiv(false);
                      }}
                    >
                      <i className="fa fa-clock-o"></i>
                      {/* &times; */}
                    </button>
                  </div>
                  <div className="modal-body">
                    <p
                      data-toggle="modal"
                      data-target="#updateAppointmentModal"
                      onClick={() => {
                        dispatch(selectedAppointments(timerAppointmentData[0]));
                        dispatch(editTimerAppointment());
                        setShowDiv(false);
                        dispatch(
                          setSelectedUser({
                            userId: timerAppointmentData[0].userchecksum_id,
                            name: timerAppointmentData[0].user_name,
                          })
                        );
                      }}
                      style={{ cursor: "pointer" }}
                    >
                      <div className="apmt_icons">
                        <svg
                          aria-hidden="true"
                          focusable="false"
                          width="1.3em"
                          height="1.3em"
                          preserveAspectRatio="xMidYMid meet"
                          viewBox="0 0 24 24"
                        >
                          <path
                            d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2m0 16H5V10h14v10M5 8V6h14v2H5m2 4h10v2H7v-2m0 4h7v2H7v-2z"
                            fill="#738c87"
                          />
                        </svg>
                      </div>
                      {timerAppointmentData[0].patient_firstname !== null
                        ? timerAppointmentData[0].patient_firstname
                        : `PRIVATE`}
                      <br />
                    </p>
                    <p
                      data-toggle="modal"
                      data-target="#updateAppointmentModal"
                      onClick={() => {
                        dispatch(selectedAppointments(timerAppointmentData[0]));
                        dispatch(editTimerAppointment());
                        setShowDiv(false);
                        dispatch(
                          setSelectedUser({
                            userId: timerAppointmentData[0].userchecksum_id,
                            name: timerAppointmentData[0].user_name,
                          })
                        );
                      }}
                      style={{ cursor: "pointer" }}
                    >
                      <div className="apmt_icons">
                        <svg
                          aria-hidden="true"
                          focusable="false"
                          width="1.3em"
                          height="1.3em"
                          preserveAspectRatio="xMidYMid meet"
                          viewBox="0 0 36 36"
                        >
                          <path
                            d="M31.47 3.84a5.78 5.78 0 0 0-7.37-.63a16.08 16.08 0 0 1 8.2 7.65a5.73 5.73 0 0 0-.83-7.02z"
                            className="clr-i-outline clr-i-outline-path-1"
                            fill="#738c87"
                          />
                          <path
                            d="M11.42 3.43a5.77 5.77 0 0 0-7.64.41a5.72 5.72 0 0 0-.38 7.64a16.08 16.08 0 0 1 8.02-8.05z"
                            className="clr-i-outline clr-i-outline-path-2"
                            fill="#738c87"
                          />
                          <path
                            d="M16.4 4.09a14 14 0 0 0-8.29 23.79l-2.55 2.55A1 1 0 1 0 7 31.84l2.66-2.66a13.9 13.9 0 0 0 16.88-.08l2.74 2.74a1 1 0 0 0 1.41-1.41L28 27.78A14 14 0 0 0 16.4 4.09zm3.18 25.81a12 12 0 1 1 10.34-10.34A12 12 0 0 1 19.58 29.9z"
                            className="clr-i-outline clr-i-outline-path-3"
                            fill="#738c87"
                          />
                          <path
                            d="M24.92 20.34l-6.06-3V9.5a.9.9 0 0 0-1.8 0v9l7.06 3.5a.9.9 0 1 0 .79-1.62z"
                            className="clr-i-outline clr-i-outline-path-4"
                            fill="#738c87"
                          />
                        </svg>
                      </div>
                    Today {timerAppointmentData[0].scheduler_time} {"-"}
                      {moment(
                        timerAppointmentData[0].scheduler_time.split(":")[0] +
                        ":" +
                        timerAppointmentData[0].scheduler_time.split(":")[1],
                        "HH:mm"
                      )
                        .add(timerAppointmentData[0].scheduler_duration, "m")
                        .format("HH:mm")}
                      <br />
                    </p>
                    <p
                      data-toggle="modal"
                      data-target="#updateAppointmentModal"
                      onClick={() => {
                        dispatch(selectedAppointments(timerAppointmentData[0]));
                        dispatch(editTimerAppointment());
                        setShowDiv(false);
                        dispatch(
                          setSelectedUser({
                            userId: timerAppointmentData[0].userchecksum_id,
                            name: timerAppointmentData[0].user_name,
                          })
                        );
                      }}
                      style={{ cursor: "pointer" }}
                    >
                      <div className="apmt_icons">
                        <svg
                          aria-hidden="true"
                          focusable="false"
                          width="1.3em"
                          height="1.3em"
                          preserveAspectRatio="xMidYMid meet"
                          viewBox="0 0 32 32"
                        >
                          <path
                            d="M16 18a5 5 0 1 1 5-5a5.006 5.006 0 0 1-5 5zm0-8a3 3 0 1 0 3 3a3.003 3.003 0 0 0-3-3z"
                            fill="#738c87"
                          />
                          <path
                            d="M16 30l-8.436-9.949a35.076 35.076 0 0 1-.348-.451A10.889 10.889 0 0 1 5 13a11 11 0 0 1 22 0a10.884 10.884 0 0 1-2.215 6.597l-.001.003s-.3.394-.345.447zM8.812 18.395c.002 0 .234.308.287.374L16 26.908l6.91-8.15c.044-.055.278-.365.279-.366A8.901 8.901 0 0 0 25 13a9 9 0 1 0-18 0a8.905 8.905 0 0 0 1.813 5.395z"
                            fill="#738c87"
                          />
                        </svg>
                      </div>
                      {timerAppointmentData[0].location}
                      <br />
                    </p>
                    <p
                      data-toggle="modal"
                      data-target="#updateAppointmentModal"
                      onClick={() => {
                        dispatch(selectedAppointments(timerAppointmentData[0]));
                        dispatch(editTimerAppointment());
                        setShowDiv(false);
                        dispatch(
                          setSelectedUser({
                            userId: timerAppointmentData[0].userchecksum_id,
                            name: timerAppointmentData[0].user_name,
                          })
                        );
                      }}
                      style={{ cursor: "pointer" }}
                    >
                      <div className="apmt_icons">
                        <svg
                          aria-hidden="true"
                          focusable="false"
                          width="1.3em"
                          height="1.3em"
                          preserveAspectRatio="xMidYMid meet"
                          viewBox="0 0 32 32"
                        >
                          <path
                            d="M4 6v20h24V6zm2 2h5v4H6zm7 0h13v4H13zm-7 6h5v4H6zm7 0h13v4H13zm-7 6h5v4H6zm7 0h13v4H13z"
                            fill="#738c87"
                          />
                        </svg>
                      </div>
                      {timerAppointmentData[0].process}
                      <br />
                    </p>
                  </div>
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn"
                      data-dismiss="modal"
                      onClick={() => dispatch(startConsutationClearTimer())}
                    >
                      <i className="fa fa-edit" aria-hidden="true"></i> Start
                    Consultation
                  </button>
                  </div>
                </div>
                {/* <div style={{display:"none"}}
              className="modal bd-example-modal-sm"
              tabindex="-1"
              role="dialog"
              data-backdrop="false"
              aria-labelledby="mySmallModalLabel"
              aria-hidden="true"
              data-dismiss="modal"
              style={{ marginLeft: "320px" }}
            >
              <div className="modal-dialog">
                <div className="modal-dialog" role="document">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLongTitle">
                        Appointment in{" "}
                        {Math.floor(timerAppointmentData[0].seconds / 60000)}{" "}
                        minutes
                      </h5>
                      <button type="button" className="close" data-dismiss="modal">
                        &times;
                      </button>
                    </div>
                    <div className="modal-body">
                      <p
                        data-dismiss="modal"
                        data-toggle="modal"
                        data-target="#myModalappoinment"
                        onClick={() => {
                          dispatch(
                            selectedAppointments(timerAppointmentData[0])
                          );
                          dispatch(editTimerAppointment())
                          dispatch(setSelectedUser({ userId: timerAppointmentData[0].userchecksum_id, name: timerAppointmentData[0].user_name }))
                        }}
                      >
                        {timerAppointmentData[0].patient_firstname !== null
                          ? timerAppointmentData[0].patient_firstname
                          : `PRIVATE`}
                      </p>
                      <p>
                        Today {timerAppointmentData[0].scheduler_time} {"-"}
                        {moment(
                          timerAppointmentData[0].scheduler_time.split(":")[0] +
                            ":" +
                            timerAppointmentData[0].scheduler_time.split(
                              ":"
                            )[1],
                          "HH:mm"
                        )
                          .add(timerAppointmentData[0].scheduler_duration, "m")
                          .format("HH:mm")}
                      </p>
                      <p>{timerAppointmentData[0].location}</p>
                      <p>{timerAppointmentData[0].process}</p>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-primary"
                        data-dismiss="modal"
                        onClick={() => dispatch(startConsutationClearTimer())}
                      >
                        Start Consultation
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div> */}
              </div>
            ) : null}
          <ProfileImagedrop className="dropdown-menu">
            <UserProfileDrop theme={styles.landing_page}>
              <img

                src={
                  require("../../../../assets/circleimage.png")
                }
                alt

                className="img-responsive"
              />
              <h2>
                <span title={persona ? persona.name : ""} id="persona-name">
                  {persona?.name?.length > 2 ? persona.name : "Welcome !"}
                </span>
              </h2>
              <p>
                <span id="persona-email">
                  {persona?.name?.length > 2 ? (
                    type
                  ) : localStorage.getItem("email") ? (
                    <span title={localStorage.getItem("email")}>
                      {localStorage.getItem("email")}
                    </span>
                  ) : (
                        ""
                      )}
                  {/* {persona?.name?.length > 2 ? (
                'Private'
              ) : localStorage.getItem('email') ? (
                <span title={localStorage.getItem('email')}>
                  {localStorage.getItem('email').length > 20
                    ? localStorage.getItem('email').substr(0, 20) + '...'
                    : localStorage.getItem('email')}
                </span>
              ) : (
                ''
              )} */}
                </span>
              </p>
              <h4>{localStorage.getItem("email")}</h4>
              <div className="profilemanage">
                <h3>Manage Your Account</h3>
              </div>
            </UserProfileDrop>
            <div className="profileborder">
              <div className="profileaccont">
                {/* <div>
                  <img
                    src={require("../../../../assets/default-avatar-profile.jpg")}
                    className="img-responsive"
                  />
                </div>
                <div>
                  <h3>Name LastName</h3>
                  <p>Account Name</p>
                </div> */}
                <ul className="groupNameList">
                  <li className="persona-item" onClick={() => setPrivate()}>
                    <span className="persona-item-image">
                      <img src={logo || null} alt="..." />
                    </span>
                    <p className="persona-item-text">Private</p>
                  </li>
                  {groups.map((group) => (
                    <li
                      key={group.workgroup_id}
                      className="persona-item"
                      style={{
                        cursor: group.deleted ? "not-allowed" : "pointer",
                      }}
                      onClick={() => (group.deleted ? null : setGroup(group))}
                    >
                      <span className="persona-item-image">
                        <p className="acronym">
                          {letter(group.workgroup_name)}
                        </p>
                      </span>
                      <p className="persona-item-text">
                        {group.workgroup_name}
                      </p>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="profileanother">
                <a>
                  {" "}
                  <i className="fa fa-user-plus"></i>Add Another Account
                </a>
              </div>
            </div>
            <SignOut>
              <div>
                <a onClick={() => handleLogout()}> Sign out of all account</a>
              </div>
            </SignOut>
            <ProfileSetting>
              <ul>
                <li>system setting</li>
                <li>Help & Support</li>
              </ul>
            </ProfileSetting>
          </ProfileImagedrop>
        </li>
      }
    </>
  );
};

export default ProfileMenu;

const ProfileImagedrop = styled.div`
  .groupNameList {
    display: flex;
    flex-direction: column;
    max-height: 20vh;
    overflow: auto;
    .persona-item {
      cursor: pointer;
      display: flex;
      align-items: center;
      .persona-item-image {
        height: 45px;
        width: 45px;
        border: 1px solid #e5e5e5;
        border-radius: 50%;
        position: relative;
        .acronym {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          font-size: 16px;
          font-weight: 600;
        }
      }
      .persona-item-text {
        font-size: 16px;
        font-weight: 600;
        padding: 10px 0 0 10px;
      }
    }
  }
  border-radius: 10px;
  border: none;
  left: -275px;
  top: 95px;
  width: 350px !important;
  .userprofiledrop {
    img {
      width: 75px;
      height: 75px;
      border-radius: 50px;
      text-align: center;
      margin: 0 auto;
      margin-top: 20px;
    }
    h2 {
      text-align: center;
      margin: 0;
      font-size: 24px;
      font-weight: 600;
      margin-top: 10px;
    }
  }
  .profileaccont {
    display: table;
    width: 100%;

    margin-top: 10px;
    margin-bottom: 10px;
    div {
      display: table-cell;
      vertical-align: middle;
      :nth-child(1) {
        width: 30%;
        img {
          width: 50px;
          height: 50px;
          border-radius: 25px;
          text-align: right;
          margin: 0 auto;
        }
      }
      :nth-child(2) {
        width: 70%;
        h3 {
          margin: 0px;
          color: ${(props) =>
    props.theme.TopMenuColors.ProfileImagedrop.nthChild_2_h3_color};
          font-size: 16px;
        }
        p {
          margin: 0px;
          font-size: 14px;
          color: ${(props) =>
    props.theme.TopMenuColors.ProfileImagedrop.nthChild_2_p_color};
          font-weight: 500;
        }
      }
    }
  }
  .profileanother {
    a {
      font-size: 18px;
      font-weight: 500;
      text-align: center;
      display: block;
      i {
        color: ${(props) =>
    props.theme.tl_profiledropdown_addaccountbtn_font_color};
        background-color: transparent;
      }
    }
  }
  .profileborder {
    border-bottom: 1px solid #dae7e4;
  }
  .profilesignout {
    padding: 10px 45px;
    margin-top: 10px;
    text-align: center;
    border-bottom: 1px solid #dae7e4;
  }
`;

const SignOut = styled.div`
  padding: 10px 45px;
  margin-top: 10px;
  text-align: center;
  border-bottom: 1px solid #dae7e4;
  div {
    margin-bottom: 10px;
  }
  a {
    font-size: 16px;
    color: ${(props) => props.theme.tl_profiledropdown_signoutbtn_font_color};
    border: 1px solid #e5e5e5;
    border-radius: 30px;
    padding: 10px 20px;
  }
`;

const ProfileSetting = styled.div`
  ul {
    list-style: none;
    text-align: center;
    li {
      display: inline-block;
      font-size: 14px;
      color: #738c87;
    }
  }
`;
const UserProfileDrop = styled.div`
  border-bottom: 1px solid #dae7e4;
  img {
    width: 75px;
    height: 75px;
    border-radius: 50px;
    text-align: center;
    margin: 0 auto;
    margin-top: 20px;
  }
  h2 {
    text-align: center;
    margin: 0;
    font-size: 24px;
    font-weight: 600;
    margin-top: 10px;
    color: ${(props) => props.theme.tl_profiledropdown_username_font_color};
  }
  p {
    text-align: center;
    font-size: 14px;
    font-weight: 600;
    color: ${(props) =>
    props.theme.tl_profiledropdown_selaccountname_font_color};
    margin: 5px;
  }
  h4 {
    text-align: center;
    color: ${(props) => props.theme.tl_profiledropdown_mailid_font_color};
    font-size: 14px;
    font-weight: 500;
  }
  .profilemanage {
    padding: 10px 45px;
    h3 {
      text-align: center;
      color: ${(props) => props.theme.tl_profiledropdown_mngacbtn_font_color};
      border: 1px solid
        ${(props) => props.theme.tl_profiledropdown_mngacbtn_font_color};
      border-radius: 30px;
      padding: 10px 20px;
    }
  }
`;
