import React, { Component, useEffect, useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import {} from "react-redux";
import * as mytheme from "../../../../exportables/Colors";

import moment from "moment";
import {
  selectedAppointments,
  saveAppointments,
  manageslicerScheduler,
  setSelectedPatient,
  viewUserSearch,
  setSelectedUser,
  editTimerAppointment,
  getAppointments,
} from "../../../../store/LandingPage/index";
import axios from "axios";
import PatientSearch from "./PatientSearch";

import { useSelector, useDispatch } from "react-redux";
import {
  apiSearchUrlWithToken,
  appointmentUrlWithToken,
} from "../../../../calls/apis";

function Message() {
  // var userDetails = JSON.parse(localStorage.getItem("account"));
  const styles = useSelector((state) => state.ui.styles);

  const [show, setShow] = useState(false);
  const [datetime, setDateTime] = useState("");
  const [dayandmonth, setDayMonth] = useState("");
  const [startandendtime, setStartEnd] = useState("");
  const [process, setProcess] = useState("");
  const [location, setLocation] = useState("");
  const [comments, setComment] = useState("");
  const [duration, setDuration] = useState("");
  const [showPatiensearch, setshowPatiensearch] = useState(false);
  const [offsettime, setOffset] = useState("");
  const [offsettimeError, showOffsetError] = useState(false);
  const [offsettimeErrorText, setOffsetErrorText] = useState("");
  const [nameError, showUsernameError] = useState(false);
  const [durationError, showDurationError] = useState(false);
  const [durationErrorText, setDurationErrorText] = useState("");
  const checksumid = useSelector(
    (state) => state.landingpage.selectedUser.userId
  );
  // const [name, setName] = useState(
  //   userDetails ? userDetails.firstname : localStorage.getItem("email")
  // );
  const name = useSelector((state) => state.landingpage.selectedUser.name);
  const [addAndupdateDiffer, setaddAndupdateDiffer] = useState(1);
  const [scheduleid, setSelectedschedulerID] = useState("");
  const [discardEnable, setDiscardEnable] = useState(false);
  const editTimerData = useSelector((state) => state.landingpage.editTimerData);

  const [savebtnDisable, setSavebtnDisable] = useState(false);

  const dispatch = useDispatch();
  const selUser = useSelector((state) => {
    if (state.landingpage.selectedUser.name == "") {
      dispatch(
        setSelectedUser({
          userId: state.landingpage.selectedUser.userId,
          name: localStorage.getItem("email").split("@")[0] + "@",
        })
      );
    }
    return state.landingpage.selectedUser;
  });

  const scheduleSlicer = useSelector(
    (state) => state.landingpage.schedulerSlicer
  );
  let cur_dd = new Date().getDate();
  let cur_mm = new Date().getMonth() + 1;
  if ((cur_mm + "").length === 1) cur_mm = "0" + cur_mm;
  if ((cur_dd + "").length === 1) cur_dd = "0" + cur_dd;
  let cur_yy = new Date().getFullYear();
  let cur_date = `${cur_yy}-${cur_mm}-${cur_dd}`;

  const appointmentData = useSelector((state) => {
    let a = state.landingpage.appointments;
    return a;
  });
  const selectedData = useSelector(
    (state) => state.landingpage.selectedAppointment
  );
  const selPatient = useSelector((state) => state.landingpage.selectedPatient);

  const path = window.location.href.split("/")[4];

  useEffect(() => {
    if (editTimerData) {
      setaddAndupdateDiffer(2);
      var recreate_date =
        selectedData.scheduler_date.split("-")[2] +
        "-" +
        selectedData.scheduler_date.split("-")[1] +
        "-" +
        selectedData.scheduler_date.split("-")[0] +
        "T" +
        selectedData.scheduler_time;
      document.getElementById("myDate").defaultValue = recreate_date;

      let alt_d =
        moment(recreate_date).format("dddd") +
        ", " +
        moment(recreate_date).date() +
        " " +
        moment(recreate_date).format("MMM") +
        " " +
        moment(recreate_date).format("hh:mm");

      setDateTime(alt_d);
      setProcess(selectedData.process);
      setLocation(selectedData.location);
      setDuration(selectedData.scheduler_duration);
      setComment(selectedData.scheduler_comment);
      setOffset(recreate_date);
      setSelectedschedulerID(selectedData.scheduler_id);
      dispatch(
        setSelectedPatient({
          id: selectedData.patient_id,
          name: selectedData.patient_name,
        })
      );
    }
  }, [selectedData]);

  const updateAppointment = async (e) => {
    e.preventDefault();
    let dd = new Date(offsettime).getDate();
    let mm = new Date(offsettime).getMonth() + 1;
    if ((mm + "").length === 1) mm = "0" + mm;
    if ((dd + "").length === 1) dd = "0" + dd;
    let yy = new Date(offsettime).getFullYear();
    let selected_date = `${yy}-${mm}-${dd}`;

    if (moment(selected_date).isBefore(cur_date, "day") == true) {
      setOffsetErrorText("* past dates are not allowed");
      showOffsetError(true);
      setSavebtnDisable(false);
    } else {
      if (offsettime == "") {
        setOffsetErrorText("* please choose Date/Time");
        showOffsetError(true);
        setSavebtnDisable(false);
      }
      if (duration == "") {
        setDurationErrorText("* please mention duration time");
        showDurationError(true);
        setSavebtnDisable(false);
      }
      if (offsettime != "" && duration != "") {
        let obj = {
          location: location,
          offsetDateTime: offsettime + ":00+05:30",
          patient_id:
            selPatient !== "{}" ? (selPatient.id == "" ? 0 : selPatient.id) : 0,
          patient_name:
            selPatient !== "{}"
              ? selPatient.name == ""
                ? ""
                : selPatient.name
              : "",
          process: process,
          scheduler_comment: comments,
          scheduler_date: (
            moment(new Date(offsettime)).date() +
            "-" +
            (moment(new Date(offsettime)).month() + 1) +
            "-" +
            moment(new Date(offsettime)).year()
          ).toString(),
          scheduler_duration: duration,
          scheduler_id: scheduleid,
          scheduler_time:
            offsettime.split("T")[1].split(":")[0] +
            ":" +
            offsettime.split("T")[1].split(":")[1],
          user_name: name,
          userchecksum_id: selUser.userId,
          workgroup_id: "null",
          //processId:"6700003044777590784"
        };
        let currentUser = {
          userId: JSON.parse(localStorage.getItem("account")).userid,
          name: JSON.parse(localStorage.getItem("account")).firstname,
        };
        await appointmentUrlWithToken
          .put(`/scheduler/${obj.scheduler_id}`, obj)
          .then(async (res) => {
            if (res.status === 200) {
              window.$(".modal").modal("hide");
              alert("Appointment updated successfully");
              obj["scheduler_id"] = res.data.scheduler_id;
              let ex_appointmnet_data = appointmentData;
              let d = new Date(offsettime).getDate();
              let m = new Date(offsettime).getMonth() + 1;
              if ((m + "").length === 1) m = "0" + m;
              if ((d + "").length === 1) d = "0" + d;
              let y = new Date(offsettime).getFullYear();
              let date = `${d}-${m}-${y}`;
              obj["scheduler_date"] = date;
              var foundIndex = ex_appointmnet_data.findIndex(
                (x) => x.scheduler_id == obj.scheduler_id
              );
              ex_appointmnet_data[foundIndex] = obj;
              dispatch(saveAppointments(ex_appointmnet_data));
              dispatch(getAppointments(ex_appointmnet_data));
              dispatch(setSelectedPatient({ id: "", name: "" }));
              setSavebtnDisable(false);
              if (editTimerData === true) {
                dispatch(editTimerAppointment());
              }
            } else {
            }
          })
          .catch((err) => {
            alert(err.response.data.message)
            setSavebtnDisable(false)
          });
        dispatch(setSelectedUser(currentUser));
        setaddAndupdateDiffer(1);

        // .catch((err) => {
        //   console.log(err)
        // });
        discard();
      }
    }
  };

  const discard = () => {
    document.getElementById("myDate").defaultValue = "";
    dispatch(setSelectedUser({ userId: "", name: "" }));
    setDateTime("");
    setComment("");
    setLocation("");
    setProcess("");
    setOffset("");
    setDuration("");
    setDiscardEnable(false);
    showDurationError(false);
    showOffsetError(false);
    showUsernameError(false);
    localStorage.removeItem("local_patientsearch");
  };
  let discardBtnColour = discardEnable ? "#738c87" : "#e5e5e5";
  let discordTextColour = discardEnable ? "#fff" : "#738c87";
  return (
    <ThemeProvider theme={mytheme}>
      <div className="updatemodaltimer">
        <GlobalStyle
          discardBtnColour={discardBtnColour}
          discordTextColour={discordTextColour}
        >
          <div className="container">
            <MyScheduuleOne >
              {/* modal start */}
              <AppointmentModal>
                <div
                  class="modal "
                  id="updateAppointmentModal"
                  role="dialog"
                  data-backdrop="false"
                  style={{ zIndex: 0 }}
                >
                  <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Edit Appoinment</h4>
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                          onClick={() => {
                            discard();
                            if (editTimerData === true) {
                              dispatch(editTimerAppointment());
                            }
                          }}
                        >
                          &times;
                        </button>
                      </div>
                      <div class="modal-body">
                        <p className="datetxt">{datetime}</p>
                        <div className="appoinementmodalform">
                          <form>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  id="myDate"
                                  style={{ cursor: "pointer" }}
                                  type="datetime-local"
                                  value={offsettime}
                                  pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}"
                                  onChange={(e) => {
                                    showOffsetError(false);
                                    let d = e.target.value;

                                    let alt_d =
                                      moment(d).format("dddd") +
                                      ", " +
                                      moment(d).date() +
                                      " " +
                                      moment(d).format("MMM") +
                                      " " +
                                      moment(d).format("LT");

                                    setDateTime(alt_d);
                                    setOffset(d);
                                    setDiscardEnable(true);
                                  }}
                                />
                              </div>
                              {offsettimeError ? (
                                <span style={{ color: "red" }}>
                                  {" "}
                                  {offsettimeErrorText}
                                </span>
                              ) : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  className="mr-auto p-2"
                                  value={selUser ? selUser.name : null}
                                  placeholder="Name"
                                  // onChange={(e) => setName(e.target.value)}
                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    onClick={() => {
                                      showUsernameError(false);
                                      dispatch(viewUserSearch(true));
                                    }}
                                  ></i>
                                </span>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Name</label> */}
                              </div>
                              {nameError ? (
                                <span style={{ color: "red" }}>
                                  {" "}
                                  * please choose user
                                </span>
                              ) : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  className="mr-auto p-2"
                                  type="text"
                                  placeholder="Patient"
                                  value={
                                    selPatient !== {} ? selPatient.name : null
                                  }
                                  // onChange={(e) => setPatient(e.target.value)}
                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    onClick={() => {
                                      // dispatch(viewUserSearch(true));
                                      setshowPatiensearch(true);
                                    }}
                                  ></i>
                                </span>

                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Patient</label> */}
                              </div>
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={process}
                                  placeholder="Process"
                                  onChange={(e) => {
                                    setProcess(e.target.value);
                                    setDiscardEnable(true);
                                  }}
                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    // onClick={() => {
                                    //   dispatch(viewUserSearch(true));
                                    // }}
                                  ></i>
                                </span>

                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Process</label> */}
                              </div>
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={duration}
                                  placeholder="Duration"
                                  onChange={(e) => {
                                    if (
                                      e.target.value.toString().length === 0
                                    ) {
                                      setDurationErrorText(
                                        "* please mention duration time"
                                      );
                                      showDurationError(true);
                                    } else {
                                      showDurationError(false);
                                    }

                                    setDuration(e.target.value);
                                    setDiscardEnable(true);
                                  }}
                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Duration</label> */}
                              </div>
                              {durationError ? (
                                <span style={{ color: "red" }}>
                                  {" "}
                                  {durationErrorText}{" "}
                                </span>
                              ) : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={location}
                                  placeholder="Location"
                                  onChange={(e) => setLocation(e.target.value)}
                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                              </div>
                              {/* <label>Location</label> */}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={comments}
                                  placeholder="Comment"
                                  onChange={(e) => {
                                    setComment(e.target.value);
                                    setDiscardEnable(true);
                                  }}
                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                              </div>
                              {/* <label>Comment</label> */}
                            </div>
                            <div className="appoinmentbutton">
                              <ul>
                                <li>
                                  <button
                                    style={{ cursor: "pointer" }}
                                    // data-toggle="modal"
                                    // data-target="#myModalappoinment"
                                    type="button"
                                    onClick={() => {
                                      discard();
                                    }}
                                    // className="discradBtn"
                                    className="savedBtn"
                                    // disabled={!discardEnable}
                                  >
                                    Discard
                                  </button>
                                </li>
                                <li>
                                  <button
                                    className="savedBtn"
                                    type="submit"
                                    disabled={savebtnDisable}
                                    //data-toggle="modal"
                                    // data-target="#myModalappoinment"
                                    onClick={(e) => {
                                      setSavebtnDisable(true);

                                      updateAppointment(e);
                                    }}
                                    // disabled={
                                    //   offsettime && name && duration
                                    //     ? false
                                    //     : true
                                    // }
                                  >
                                    Update
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {showPatiensearch ? (
                  <div style={{ zIndex: 1 }}>
                    <PatientSearch
                      //isPopupVisible={showPatiensearch}
                      togglePatient={() => setshowPatiensearch(false)}
                      styles={styles}
                      setPatient={(e) => setDiscardEnable(true)}
                      toggleDelete={(e) => null}
                    />
                  </div>
                ) : null}
              </AppointmentModal>
              {/* modal end */}

              {/* modal start */}
            </MyScheduuleOne>
          </div>
        </GlobalStyle>
        <br />
      </div>
    </ThemeProvider>
  );
}
export default Message;

const GlobalStyle = styled.section`
  padding: 10px 15px;
  margin-top: 30px;
  font-size: 14px;
  h3 {
    font-size: 16px;
  }

  #myDate {
    text-transform: uppercase;
  }

  .appoinmentdetailsheader li {
    margin-left: 17px;
  }

  #appoinmentdetails .modal-body {
    padding: 0px;
  }

  .discradBtn:focus,
  .savedBtn:focus {
    outline: 0;
  }
  .savedBtn {
    background: #738c87;
    color: #fff;
  }

  .discradBtn {
    border: solid 1px #e5e5e5;
    background: ${(props) => props.discardBtnColour};
    color: ${(props) => props.discordTextColour};
  }
  .discradBtn:focus,
  .savedBtn:focus {
    outline: 0;
  }
  .savedBtn {
    border: solid 1px #e5e5e5;
    background: #738c87;
    color: #fff;
  }
  .add_appmnt_popup {
    color: #738c87;
    padding: 10px;
    li i {
      margin-right: 10px;
    }
  }

  .startconsulation {
    border-top: solid 1px #eeeeee;
  }
  .startconsulation a:hover {
    text-decoration: none;
    cursor: pointer;
  }

  .add_appmnt_popup li {
    line-height: 2.3;
  }
`;

const Schedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      li {
        display: inline-block;
        padding: 0px 10px;
        :nth-child(2) {
          padding: 0px 10px;
        }
      }
    }
  }
`;

const DaySchedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) p {
      font-size: 14px;
    }
    :nth-child(2) ul {
      list-style: none;
      li {
        display: inline-block;
        padding: 5px;
        margin-left: -3px;
        font-size: 21px;
        margin-top: -14px;
        cursor: pointer;
      }
    }
  }
`;

const MySchedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) {
      width: 30%;
    }
    :nth-child(2) {
      width: 60%;
    }
    :nth-child(3) {
      width: 10%;
      p {
        background-color: transparent;
        border: none;
        font-size: 15px;
        margin-left: 8px;
        i {
          color: ${(props) =>
            props.theme.DashboardContentFourColors.MySchedule
              .nthChild_3_p_i_color} !important;
          cursor: pointer;
        }
      }
    }
  }
`;

const MyScheduuleOne = styled.div`

  margin-right: -15px;
  margin-left: -15px;

`;

const OpenSchedule = styled.div`
  display: table;
  margin-top: 5px;
  width: 100%;
  .icon_allignment {
    position: absolute;
    right: 38px;
  }
  div {
    display: table-cell;
    :nth-child(1) p {
      cursor: pointer;
    }
    :nth-child(2) p {
      text-align: center;
    }
  }
`;

const AppointmentModal = styled.div`
  .group {
    position: relative;
    margin-bottom: 10px;
  }

  .d-flex {
    border-bottom: 0.5px solid
      ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .input_border_bottom};
  }
  input {
    // font-size: 16px;
    padding: 5px 10px 5px 5px;
    display: block;
    width: 100%;
    border: none;
  }
  input:focus {
    outline: none;
  }
  #myModalappoinment {
    z-index: 1 !important;
    .datetxt {
      text-transform: uppercase;
    }
  }
  #myModalappoinment .appoinementmodalform span {
    color: lightgray;
  }
  #myModalappoinment label {
    color: ${(props) =>
      props.theme.DashboardContentFourColors.AppointmentModal.label};
    font-size: 15px;
    font-weight: normal;
    position: absolute;
    pointer-events: none;
    left: 5px;
    top: 10px;
    transition: 0.2s ease all;
    -moz-transition: 0.2s ease all;
    -webkit-transition: 0.2s ease all;
  }
  input:focus ~ label,
  input:valid ~ label {
    top: -10px;
    font-size: 14px;
    color: ${(props) =>
      props.theme.DashboardContentFourColors.AppointmentModal
        .webkit_inputHighlighter_from_backgroundcolor};
  }

  .highlight {
    position: absolute;
    height: 60%;
    width: 100px;
    top: 25%;
    left: 0;
    pointer-events: none;
    opacity: 0.5;
  }
  input:focus ~ .highlight {
    -webkit-animation: inputHighlighter 0.3s ease;
    -moz-animation: inputHighlighter 0.3s ease;
    animation: inputHighlighter 0.3s ease;
  }
  @-webkit-keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .webkit_inputHighlighter_from_backgroundcolor};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @-moz-keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .moz_inputHighlighter_from_backgroundcolor};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @keyframes inputHighlighter {
    from {
      background: ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .keyframes_inputHighlighter};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  .modal .modal-dialog {
    float: right;
    left: -100px;
    top: 150px;
    margin: 0;
  }
  .modal-content {
    width: 350px !important;
    border-radius: 10px;
    border: none;
  }
  .modal-header {
    background-color: ${(props) =>
      props.theme.DashboardContentFourColors.AppointmentModal
        .modal_header_backgroundcolor};
    border-radius: 10px 10px 0px 0px;
    h4 {
      color: ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .h4_color} !important;
      font-size: 20px;
    }
    button {
      font-size: 30px;
      color: ${(props) =>
        props.theme.DashboardContentFourColors.AppointmentModal
          .button_color} !important;
      opacity: 1;
      font-weight: 400;
      padding: 5px;
    }
  }
  .modal-body p {
    font-weight: 500;
    margin-top: 10px;
    font-size: 16px;
  }
  .appoinmentbutton ul li {
    display: inline-block;
    padding: 20px;
    button {
      padding: 5px 30px;
      border-radius: 20px;
      :nth-child(1) button {
        border: 1.5px solid
          ${(props) =>
            props.theme.DashboardContentFourColors.AppointmentModal
              .appoinmentbutton_nthChild_1_button_border};
        background-color: transparent;
        color: ${(props) =>
          props.theme.DashboardContentFourColors.AppointmentModal
            .appoinmentbutton_nthChild_1_button_color};
      }
      :nth-child(2) button {
        background-color: ${(props) =>
          props.theme.DashboardContentFourColors.AppointmentModal
            .appoinmentbutton_nthChild_2_button_backgroundcolor};
        color: ${(props) =>
          props.theme.DashboardContentFourColors.AppointmentModal
            .appoinmentbutton_nthChild_2_button_color};
        border: none;
      }
    }
  }
`;

const AppoinmentDetailsContnet = styled.div`
  .modal-content {
    width: 340px !important;
    border-radius: 10px;
    border: none;
  }
  .modal .modal-dialog {
    float: right;
    left: -90px;
    top: 150px;
    margin: 0;
  }
  .modal-header {
    background-color: ${(props) =>
      props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
        .modal_header_backgroundcolor};
    border-radius: 10px 10px 0px 0px;
  }
  .appoinmentdetailsheader {
    display: flex;
    flex-direction: row;
    width: 100%;
    div {
      display: flex;
      flex-direction: column;
      :nth-child(1) {
        flex: 66%;
        h4 {
          color: ${(props) =>
            props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
              .appoinmentdetailsheader_nthChild_1_h4_color};
          font-size: 20px;
        }
        p {
          color: ${(props) =>
            props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
              .appoinmentdetailsheader_nthChild_1_p_color};
        }
      }
      :nth-child(2) {
        flex: 1 1 auto;
        color: ${(props) =>
          props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
            .appoinmentdetailsheader_nthChild_2_button_color} !important;
        button {
          font-size: 30px;
          color: ${(props) =>
            props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
              .appoinmentdetailsheader_nthChild_2_button_color} !important;
          opacity: 1;
          font-weight: 400;
          padding: 5px;
        }
      }
      .modal-body {
        padding: 0;
        p {
          font-weight: 500;
          margin-top: 10px;
          font-size: 16px;
          padding: 0px 10px;
        }
        ul {
          list-style: none;
          border-bottom: 1px solid
            ${(props) =>
              props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
                .modalbody_ul_bordercolor};
          li {
            line-height: 35px;
            font-size: 14px;
            color: ${(props) =>
              props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
                .modalbody_li_color};
            padding: 0px 10px;
            margin-left: 30px;
            :nth-child(1)::before {
              content: "\f00c";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(2)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(3)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(5)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(6) {
              margin-bottom: 10px;
            }
            ::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
          }
        }
      }
    }
  }
  .startconsulation a {
    color: ${(props) =>
      props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
        .startconsulation_a_color};
    text-align: right !important;
    display: block;
    padding: 10px 10px 10px 0px;
    font-size: 16px;
    font-weight: 600;
    i {
      margin-right: 10px;
    }
  }
`;

const MessageChat = styled.div`
  background-color: ${(props) =>
    props.theme.DashboardContentFourColors.MessageChat.backgroundcolor};
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  margin-top: -25px;
  position: absolute;
  font-size: 14px;
  right: 24px;
  width: 85%;
  button {
    width: 100%;
  }
  input {
    border: none;
    box-shadow: none;
  }
  .inbox_txt {
    position: sticky;
    margin-top: 27px;
    margin-left: -75px;
  }
  .user_online {
    width: 10px;
    height: 10px;
    position: absolute;
    background-color: #00c72c;
    border-radius: 30px;
    right: 11px;
    top: 23px;
  }
  .d-flex1 {
    height: 55px;
    background-color: ${(props) =>
      props.theme.DashboardContentFourColors.MessageChat
        .d_flex_backgroundcolor};
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
`;

const MessageIcon = styled.div`
  display: table;
  width: 100%;
  div {
    h6 {
      font-weight: bold;
      font-size: medium;
    }
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      margin-right: 10px;
      li {
        display: inline-block;
        padding: 10px;
      }
    }
  }
`;

const CreateMessage = styled.div`
  margin-top: 20px;
  button {
    background-color: ${(props) =>
      props.theme.DashboardContentFourColors.CreateMessage
        .d_flex_backgroundcolor};
    border: 2px solid
      ${(props) =>
        props.theme.DashboardContentFourColors.CreateMessage
          .button_border_color};
    color: ${(props) =>
      props.theme.DashboardContentFourColors.CreateMessage.button_border_color};
    border-radius: 30px;
    padding: 10px 40px;
    font-weight: 500;
  }
`;
