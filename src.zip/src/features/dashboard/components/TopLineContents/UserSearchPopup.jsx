import React, { Component } from "react";
import styled from "styled-components";
import jwt from "jsonwebtoken";
import AWS from "aws-sdk";
import TextFieldGroup from "hypaiq-rc/lib/TextFieldGroup";
import TextAreaFieldGroup from "hypaiq-rc/lib/TextAreaFieldGroup";
import SwitchFieldGroup from "hypaiq-rc/lib/SwitchFieldGroup";
import SelectFieldGroup from "hypaiq-rc/lib/SelectFieldGroup";
import SelectField from "hypaiq-rc/lib/SelectField";
import Button from "hypaiq-rc/lib/Button";
import { debounce } from "lodash";

import { country } from "../../../../exportables/exportables";
import Spinner from "../../components/Spinner";
import Icons from "../../../home/Icons";
import SearchToolbar from "../../../home/SeachToolbar";
import UserSearchComponent from "../../components/TopLineContents/UserSearchComponent";
import RadioComponent from "../../components/TopLineContents/RadioComponent";
import {
  apiUrlWithToken,
  patientsWithToken,
  apiSearchUrlWithToken,
  accountApiUrlWithToken,

} from "../../../../calls/apis";

AWS.config.update({
  accessKeyId: "AKIA5TI3EZTAIHWI73F4",
  secretAccessKey: "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",
  region: "eu-west-2",
  endpoint: "https://dynamodb.eu-west-2.amazonaws.com",
});
var docClient = new AWS.DynamoDB.DocumentClient({ correctClockSkew: true });
var titleTable = {
  TableName: "master-title",
};
var jobTitleTable = {
  TableName: "master-jobtitle",
};
var groupTable = {
  TableName: "master-grouptype",
};
var quaTable = {
  TableName: "master-qualifications",
};
var SpecTable = {
  TableName: "master-specialisation",
};
let initialForm = {
  workgroupid: "",
  createdby: "",
  email: "",
  personaldetails: {
    firstname: "",
    lastname: "",
    title: "",
    jobtitle: "",
    description: "",
    grouptype: "",
    specialisation: "",
    showdescription: false,
  },
  contactdetails: {
    contactname: "",
    website: "",
    contactemail: "",
    contactphone: "",
    addressline1: "",
    addressline2: "",
    city: "",
    state: "",
    country: "",
    zip: "",
  },
  qualifications: {
    qualification1: "",
    qualification2: "",
    qualification3: "",
    qualification4: "",
    qualification5: "",
  },
  organisations: {
    organisations1: {
      name: "",
      year: "",
    },
    organisations2: {
      name: "",
      year: "",
    },
    organisations3: {
      name: "",
      year: "",
    },
    organisations4: {
      name: "",
      year: "",
    },
    organisations5: {
      name: "",
      year: "",
    },
  },
};
let params = new URLSearchParams(window.location.search);

let access = localStorage.getItem('accesstoken');
let accesstoken = jwt.decode(access);

class UserSearch extends Component {
  constructor(props) {
    super(props);
    this.child = React.createRef();
    this.state = {
      formData: {
        workgroupid: "",
        createdby: "",
        email: "",
        personaldetails: {
          firstname: "",
          lastname: "",
          title: "",
          jobtitle: "",
          description: "",
          grouptype: "",
          specialisation: "",
          showdescription: false,
        },
        contactdetails: {
          contactname: "",
          website: "",
          contactemail: "",
          contactphone: "",
          addressline1: "",
          addressline2: "",
          city: "",
          state: "",
          country: "",
          zip: "",
        },
        qualifications: {
          qualification1: "",
          qualification2: "",
          qualification3: "",
          qualification4: "",
          qualification5: "",
        },
        organisations: {
          organisations1: {
            name: "",
            year: "",
          },
          organisations2: {
            name: "",
            year: "",
          },
          organisations3: {
            name: "",
            year: "",
          },
          organisations4: {
            name: "",
            year: "",
          },
          organisations5: {
            name: "",
            year: "",
          },
        },
      },
      advancedSearch: false,
      email: "",
      isTokenValid: false,
      isLoaded: false,
      styles: {
        label_text: {},
        patient: {
          input_border_colour: "#666",
          advanced_border_colour: "#fcba03",
        },
      },
      users: [],
      cancelData: {},
      newData: {},
      stringObject: {},
      error: false,
      save: false,
      userid: "",
      filter: "",
      organisationId: "",
    };
  }

  componentDidMount() {
    if (localStorage.getItem("local_schedulerusersearch")) {
      let state = JSON.parse(localStorage.getItem("local_schedulerusersearch"));
      if ((state.userId = accesstoken.userReference)) {
        this.setState({
          ...state,
        });
      } else {
        localStorage.removeItem("local_schedulerusersearch");
      }
    }
    this.setState({
      styles: { ...this.state.styles, ...this.props.styles },
      icons: this.props.styles.icons,
      isLoaded: true,
    });
    let token = localStorage.getItem("token");
    var decoded = jwt.decode(token);

    const resOrg = accountApiUrlWithToken
      .get(`/authentication/${accesstoken.userReference}`)
      .then((res) => {
        this.setState({
          organisationId: res.data.organisationId,
          accesstoken: accesstoken,
        });
      });
    /**
     * Select options
     */
    const year = Array.from(new Array(50).keys()).map((idx) => ({
      id: 1 + idx,
      label: 1970 + idx,
      value: 1970 + idx,
    }));
    this.setState({ yearOptions: year });
    let self = this;
    docClient.scan(titleTable, function (err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        let titles = data.Items.map((item) => {
          return {
            id: item.titleid,
            value: item.titlename,
            label: item.titlename,
          };
        });
        self.setState({ titleOptions: titles });
      }
    });
    docClient.scan(jobTitleTable, function (err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        let jobTitles = data.Items.map((item) => {
          return {
            id: item.jobtitleid,
            value: item.jobtitlename,
            label: item.jobtitlename,
          };
        });
        self.setState({ jobTitleOptions: jobTitles });
      }
    });
    docClient.scan(groupTable, function (err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        let groupType = data.Items.map((item) => {
          return {
            id: item.grouptypeid,
            value: item.grouptypename,
            label: item.grouptypename,
          };
        });
        self.setState({ groupTypeOptions: groupType });
      }
    });
    docClient.scan(quaTable, function (err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        let qua = data.Items.map((item) => {
          return {
            id: item.qualificationId,
            value: item.qualificationname,
            label: item.qualificationname,
          };
        });
        self.setState({ qualificationsOptions: qua });
      }
    });
    docClient.scan(SpecTable, function (err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        let spec = data.Items.map((item) => {
          return {
            id: item.specialisationid,
            value: item.specialisationname,
            label: item.specialisationname,
          };
        });
        self.setState({ specialisationOptions: spec });
      }
    });
    /* Select options end */

    // if (decoded?.email) {
    // this.setState({ email: decoded.email, isTokenValid: true });
    // } else {
    // alert("UnAuthorised, try login again");
    // }
    // const config = {
    // headers: {
    // Authorization: `Bearer ${token}`,
    // },
    // };
    // Axios.get(
    // `https://hypaiqauthapi.cyb.co.uk/v1/auth/find/${decoded.email}`,
    // config
    // )
    // .then((res) => {
    // this.setState({
    // formData: { ...this.state.formData, ...res.data.account[0] },
    // cancelData: { ...this.state.formData, ...res.data.account[0] },
    // });
    // })
    // .catch((err) => {
    // console.log("error ", err.response);
    // });
    let styles = localStorage.getItem("styles");
    let sty = JSON.parse(styles);
    this.setState({
      style: { ...sty },
      isLoaded: true,
    });
  }
  componentDidUpdate() {
    window.addEventListener("message", this.receiveMessageFromIndex, false);
  }
  setlocal = (e) => {
    let data = e;
    data.userId = accesstoken.userReference;

    var cache = [];
    localStorage.setItem(
      "local_schedulerusersearch",
      JSON.stringify(data, (key, value) => {
        if (typeof value === "object" && value !== null) {
          if (cache.includes(value)) return;
          cache.push(value);
        }
        return value;
      })
    );
    cache = null;
  };
  receiveMessageFromIndex(event) {
    let data = JSON.parse(event.data);

    localStorage.setItem("groupId", data.groupId);
    localStorage.setItem("organisationId", data.orgId);
  }

  validateEmail = (mail) => {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
      return true;
    }
    return false;
  };

  validatePhone = (phoneno) => {
    var pattern = /^[0-9]+$/;
    if (phoneno.match(pattern)) {
      return true;
    } else {
      return false;
    }
  };
  validateName = (name) => {
    let numberValidate = /^[a-zA-Z]+$/;
    if (numberValidate.test(name)) {
      return true;
    } else {
      return false;
    }
  };
  validateUrl = (url) => {
    let regexp = /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
    if (regexp.test(url)) {
      return true;
    } else {
      return false;
    }
  };

  onInputChange = (event, property, subproperty = null) => {
    const { name, value } = event.target;

    const predefinedPropArrays = [
      "personaldetails",
      "contactdetails",
      "qualifications",
      "organisations",
    ];
    // this.setState({
    //   save: true,
    // });
    if (predefinedPropArrays.includes(property)) {
      if (subproperty && property === "organisations") {
        this.setState({
          ...this.state,
          save: true,
          formData: {
            ...this.state.formData,
            [property]: {
              ...this.state.formData[property],
              [subproperty]: {
                ...this.state.formData[property][subproperty],
                [name]: value,
              },
            },
          },
        });
        this.setlocal({
          ...this.state,
          save: true,
          formData: {
            ...this.state.formData,
            [property]: {
              ...this.state.formData[property],
              [subproperty]: {
                ...this.state.formData[property][subproperty],
                [name]: value,
              },
            },
          },
        });
        return;
      }
      this.setState({
        ...this.state,
        save: true,
        formData: {
          ...this.state.formData,
          [property]: { ...this.state.formData[property], [name]: value },
        },
      });
      this.setlocal({
        ...this.state,
        save: true,
        formData: {
          ...this.state.formData,
          [property]: { ...this.state.formData[property], [name]: value },
        },
      });
      return;
    }
    this.setState({
      ...this.state,
      save: true,
      formData: {
        ...this.state.formData,
        [name]: value,
      },
    });
    this.setlocal({
      ...this.state,
      save: true,
      formData: {
        ...this.state.formData,
        [name]: value,
      },
    });
  };

  handleShowDescriptionBinary = (value) => {
    let checked = !value;
    this.setState({
      ...this.state,
      save: true,
      formData: {
        ...this.state.formData,
        personaldetails: {
          ...this.state.formData.personaldetails,
          showdescription: checked,
        },
      },
    });
    this.setlocal({
      ...this.state,
      isCancelActive: true,
      isSaveActive: true,
      formData: {
        ...this.state.formData,
        personaldetails: {
          ...this.state.formData.personaldetails,
          showdescription: !checked,
        },
      },
    });
  };

  handleSubmit = (event) => {
    let groupId = localStorage.getItem("groupId");
    let error = false;
    let isWebsiteValid = this.validateUrl(
      this.state.formData.contactdetails?.website
    );
    if (!isWebsiteValid && this.state.formData.contactdetails.website) {
      this.setState({ websiteErr: "Invalid Url" });
      error = true;
    } else {
      this.setState({ websiteErr: "" });
    }

    let email = this.state.formData.contactdetails.contactemail;
    let isemailValid = this.validateEmail(email);
    if (!isemailValid && email) {
      this.setState({ emailErr: "Invalid email" });
      error = true;
    } else {
      this.setState({ emailErr: "" });
    }
    if (email === "" || email === undefined) {
      this.setState({ emailErr: "Email required" });
      error = true;
    }
    let phone = this.state.formData.contactdetails.contactphone;
    let isPhoneValid = this.validatePhone(phone);

    if (!isPhoneValid && phone) {
      this.setState({ phoneErr: "Invalid phone" });
      error = true;
    } else {
      this.setState({ phoneErr: "" });
    }
    let firstname = this.state.formData.personaldetails.firstname;

    let isFirstNameValid = this.validateName(firstname);

    if (!isFirstNameValid && firstname) {
      this.setState({ firstnameerror: "Invalid Name" });
      error = true;
    } else {
      this.setState({ firstnameerror: "" });
    }
    if (firstname === "" || firstname === undefined) {
      this.setState({ firstnameerror: "Name required" });
      error = true;
    }
    let zip = this.state.formData.contactdetails.zip;
    let isZipValid = this.validatePhone(zip);
    if (!isZipValid && zip) {
      this.setState({ ziperror: "Invalid Zip" });
      error = true;
    } else {
      this.setState({ zipnameerror: "" });
    }
    let lastname = this.state.formData.personaldetails.lastname;
    let isLastNameValid = this.validateName(lastname);
    if (!isLastNameValid && lastname) {
      this.setState({ lastnameerror: "Invalid Name" });
      error = true;
    } else {
      this.setState({ lastnameerror: "" });
    }
    if (error) return;

    this.setState({ isLoaded: false });
    const token = this.props.token;
    const data = this.state.formData;
    const actionby = this.props.userid;

    data.actionby = actionby;
    data.workgroupid = groupId;
    data.createdby = actionby;
    data.email = data.contactdetails.contactemail;
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    apiUrlWithToken
      .post("/groupuser/add", data)
      .then((res) => {
        let details = data.personaldetails;
        let name = details.title + details.firstname + details.lastname;
        let user = {
          userId: res.data.userid,
          name: name ? name : data.email.split("@")[0] + "@",
        };
        this.props.select(user);
        this.setState({
          isLoaded: true,
        });
        this.props.close();
        localStorage.removeItem("local_schedulerusersearch");
      })
      .catch((err) => {
        this.setState({
          isLoaded: true,
        });
        //alert(err?.response?.data?.message);
        console.log(err?.response?.data?.message);
      });
  };

  cancel = () => {
    this.setState(
      {
        formData: this.state.cancelData,
      },
      () => console.log(this.state.formData)
    );
    console.log(this.state.formData);
  };
  new = () => {
    this.setState({
      formData: initialForm,
      userid: "",
      total: 0,
    });
    localStorage.removeItem("local_schedulerusersearch");
    this.child.current.clear();
  };

  setAdvancedString = (e, property, subproperty) => {
    const { name, value } = e.target;
    console.log("advacnedstrgin", value);
    let orgId = localStorage.getItem("organisationId");
    let groupId = localStorage.getItem("groupId");
    let object = this.state.stringObject;
    let filter = this.state.filter;
    if (filter === "one" && orgId) {
      object["organisationid"] = orgId;
    }
    if (filter === "two" && groupId) {
      object["workgroupid"] = orgId;
    }
    if (filter === "one") {
      delete object["workgroupid"];
    }
    if (filter === "two") {
      delete object["organisationid"];
    }
    if (filter === "three") {
      delete object["workgroupid"];
      delete object["organisationid"];
    }
    if (
      name === "organisationsname1" ||
      name === "organisationsname2" ||
      name === "organisationsname3" ||
      name === "organisationsname4" ||
      name === "organisationsname5"
    ) {
      this.onInputChange(
        { target: { name: "name", value: value } },
        property,
        subproperty
      );
    } else if (
      name === "organisationsyear1" ||
      name === "organisationsyear2" ||
      name === "organisationsyear3" ||
      name === "organisationsyear4" ||
      name === "organisationsyear5"
    ) {
      this.onInputChange(
        { target: { name: "year", value: value } },
        property,
        subproperty
      );
    } else {
      this.onInputChange(e, property, subproperty);
    }

    object[name] = value;
    this.setState({
      stringObject: object,
    });
    if (value === "") {
      delete object[name];
    }

    let advancedString = "";
    const keyvalue = (e) =>
      Object.entries(e).forEach(([key, value]) => {
        advancedString += key + "=" + value + "&";
      });
    keyvalue(object);

    advancedString = advancedString.substring(0, advancedString.length - 1);
    this.advancedSearch(advancedString);
  };

  advancedSearch = (e) => {
    apiSearchUrlWithToken
      .get("common/user?" + e)
      .then((res) => {
        this.setState({
          users: res.data.userSearchDetail,
          total: res.data.total,
        });
      })
      .catch((err) => {
        this.setState({
          users: [],
          total: 0,
        });
      });
  };
  changeUser = (e) => {
    console.log(e);
    let data = {
      personaldetails: {
        firstname: e.firstname,
        lastname: e.lastname,
        jobtitle: e.jobtitle,
        showdescription: e.showdescription,
        specialisation: e.specialisation,
        title: e.title,
        description: e.description,
        grouptype: e.grouptype,
      },
      contactdetails: e.contactdetails,
      organisations: e.organisations,
      qualifications: e.qualifications,
    };
    this.setState({
      formData: data,
      userid: e.userid,
      save: false,
    });
  };
  selectUser = (e) => {
    this.setState({
      advancedSearch: false,
      save: false,
    });
  };
  setSearchstring = (e) => {
    if (!e) {
      this.new();
    } else {
      this.searchUser(e);
    }
  };
  searchUser = debounce((e) => {
    let search = e;
    let organisationId = localStorage.getItem("organisationId");
    let orgId = this.state.organisationId;
    let groupId = localStorage.getItem("groupId");
    let condition = "";
    let filter = this.state.filter;
    if (filter === "one" && (organisationId || orgId)) {
      condition = `?organisationid=${organisationId || orgId}`;
    }
    if (filter === "two" && groupId) {
      condition = `?workgroupid=${groupId}`;
    }
    let converted = search.replace("?", "%3F");

    apiSearchUrlWithToken
      .get("simple/user/" + converted + condition)
      .then((res) => {
        this.setState({
          users: res.data.userSearchDetail,
          total: res.data.total,
        });
      })
      .catch((err) => {
        this.setState({ users: [], total: 0 });
      });
  }, 500);
  renderErrorMesssage = (name) => {
    return "";
  };
  toggleAdvanced = () => {
    this.setState({
      advancedSearch: !this.state.advancedSearch,
      formData: initialForm,
      total: 0,
    });
    localStorage.removeItem("local_schedulerusersearch");
  };
  render() {
    const { isTokenValid, isLoaded } = this.state;
    let formData = this.state.formData;
    if (!isLoaded) {
      let msg = !isLoaded
        ? "Loading ..."
        : !isTokenValid
          ? "Unauthorised error"
          : "";
      return <Spinner msg={msg} />;
    }

    var {
      personaldetails,
      contactdetails,
      qualifications,
      organisations,
    } = this.state.formData;

    const token = localStorage.getItem("token");

    let input_colour = "";
    if (this.state.advancedSearch === false) {
      input_colour = this.state.styles.patient?.input_border_colour;
    } else {
      input_colour = this.state.styles.patient?.advanced_border_colour;
    }
    const invite = () => {
      this.props.close();
      this.props.invite();
    };
    const selectUser = () => {
      let data = {
        name:
          personaldetails.title +
          personaldetails.firstname +
          personaldetails.lastname,
        userId: this.state.userid,
      };
      this.props.select(data);
      localStorage.removeItem("local_schedulerusersearch");
    };
    return (
      <>
        <PrivateProfileStyles
          styles={this.state.styles}
          inputColor={input_colour}
        >
          <form onSubmit={this.handleSubmit}>
            <div className="form-fields">
              <div className="search_section">
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <h3>User Selection -</h3>
                  <RadioComponent
                    setFilter={(e) =>
                      this.setState({
                        filter: e,
                      })
                    }
                    className="font_align"
                  />
                </div>
                <p className="label font_align">User</p>
                <UserSearchComponent
                  ref={this.child}
                  advancedSearch={this.state.advancedSearch}
                  datas={this.state.users}
                  onMouseOver={(e) => this.changeUser(e)}
                  onSelect={(e) => this.selectUser(e)}
                  totalRecords={this.state.total}
                  onInputChange={(e) => this.setSearchstring(e)}
                />
                <Button
                  disabled
                  onClick={() => { }}
                  value="Invite User"
                  style={{ marginTop: 20, width: "60%", marginLeft: "40%" }}
                />
              </div>
              <div
                className="detailsContainer"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  width: "75%",
                }}
              >
                <div className="utilitiesUnderline">
                  <p className="main-header">User Details -</p>
                  <SearchToolbar
                    src={
                      this.state.advancedSearch
                        ? this.state.icons.patient_filter_active
                        : this.state.icons.patient_filter
                    }
                    toggleAdvanced={() => this.toggleAdvanced()}
                    iconsFragment={
                      <>
                        <Icons
                          src={this.state.icons.record_select}
                          title="Select"
                          triggerFunc={() => selectUser()}
                          isActive={this.state.userid}
                        />
                        <Icons
                          src={this.state.icons.record_delete}
                          title="Delete"
                          triggerFunc={() => { }}
                          isActive={false}
                        />
                        <Icons
                          src={this.state.icons.record_update}
                          title="Update"
                          triggerFunc={() => { }}
                          isActive={false}
                        />

                        <Icons
                          src={this.state.icons.record_new}
                          title="Copy Record"
                          triggerFunc={() => null}
                          isActive={false}
                        />
                        <Icons
                          src={this.state.icons.toolbar_cancel}
                          title="Cancel"
                          triggerFunc={() => this.cancel()}
                          isActive={false}
                        />
                        <Icons
                          src={this.state.icons.toolbar_save}
                          title="Save"
                          triggerFunc={() => this.handleSubmit()}
                          isActive={this.state.save}
                        />
                        <Icons
                          src={this.state.icons.toolbar_copy}
                          title="Copy"
                          triggerFunc={() => { }}
                          isActive={this.state.copy}
                        />
                        <Icons
                          src={this.state.icons.scheduler_add}
                          title="New"
                          triggerFunc={() => this.new()}
                          isActive={this.state.save || this.state.userid}
                        />
                      </>
                    }
                  ></SearchToolbar>
                </div>
                <div className="form">
                  <div className="personal_details_section">
                    <h3>Personal Details</h3>
                    <TextFieldGroup
                      style={{ marginTop: 20, fontWeight: "400" }}
                      labelProps={{
                        label: "First Name",
                        error: this.state.firstnameerror
                          ? this.state.firstnameerror
                          : false,
                      }}
                      inputProps={{
                        name: "firstname",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "personaldetails")
                            : this.onInputChange(e, "personaldetails"),
                        value: personaldetails?.firstname || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{ label: "Last Name" }}
                      inputProps={{
                        name: "lastname",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "personaldetails")
                            : this.onInputChange(e, "personaldetails"),
                        value: personaldetails?.lastname || "",
                      }}
                    />
                    <SelectFieldGroup
                      labelProps={{ label: "Title" }}
                      inputProps={{
                        name: "title",
                        options: this.state?.titleOptions || [],
                        onChange: (event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "personaldetails")
                            : this.onInputChange(event, "personaldetails"),
                        value: personaldetails?.title || "",
                      }}
                    />
                    <SelectFieldGroup
                      labelProps={{ label: "Job Title" }}
                      inputProps={{
                        name: "jobtitle",
                        options: this.state?.jobTitleOptions || [],
                        onChange: (event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "personaldetails")
                            : this.onInputChange(event, "personaldetails"),
                        value: personaldetails?.jobtitle || "",
                      }}
                    />
                    <TextAreaFieldGroup
                      labelProps={{ label: "Description" }}
                      inputProps={{
                        name: "description",
                        onChange: (event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "personaldetails")
                            : this.onInputChange(event, "personaldetails"),
                        value: personaldetails?.description || "",
                      }}
                    />
                    <SelectFieldGroup
                      labelProps={{ label: "Group Type" }}
                      inputProps={{
                        name: "grouptype",
                        options: this.state?.groupTypeOptions || [],
                        onChange: (event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "personaldetails")
                            : this.onInputChange(event, "personaldetails"),
                        value: personaldetails?.grouptype || "",
                      }}
                    />

                    <SelectFieldGroup
                      labelProps={{ label: "Specialisation" }}
                      inputProps={{
                        name: "specialisation",
                        options: this.state?.specialisationOptions || [],
                        onChange: (event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "personaldetails")
                            : this.onInputChange(event, "personaldetails"),
                        value: personaldetails?.specialisation || "",
                      }}
                    />

                    <SwitchFieldGroup
                      labelProps={{
                        label: "Show description in Public Category",
                      }}
                      inputProps={{
                        name: "showdescription",
                        checked: personaldetails?.showdescription,
                        onChange: () =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(
                              {
                                name: "showdescription",
                                value: personaldetails?.showdescription,
                              },
                              "personaldetails"
                            )
                            : this.handleShowDescriptionBinary(
                              personaldetails?.showdescription || ""
                            ),
                      }}
                    />
                  </div>

                  <div className="contact_details_section">
                    <h3>Contact Details</h3>
                    <TextFieldGroup
                      style={{ marginTop: 20 }}
                      labelProps={{ label: "Contact Name" }}
                      inputProps={{
                        name: "contactname",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.contactname || "",
                      }}
                    />

                    <TextFieldGroup
                      labelProps={{
                        label: "Website",
                        error: this.state.websiteErr
                          ? this.state.websiteErr
                          : false,
                      }}
                      inputProps={{
                        name: "website",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.website || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "Contact Email",
                        error: this.state.emailErr
                          ? this.state.emailErr
                          : false,
                      }}
                      inputProps={{
                        name: "contactemail",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.contactemail || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "Contact Phone",
                        error: this.state.phoneErr
                          ? this.state.phoneErr
                          : false,
                      }}
                      inputProps={{
                        name: "contactphone",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.contactphone || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "Address Line 1",
                      }}
                      inputProps={{
                        name: "addressline1",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.addressline1 || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "Address Line 2",
                      }}
                      inputProps={{
                        name: "addressline2",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.addressline2 || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "City / Town",
                      }}
                      inputProps={{
                        name: "city",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.city || "",
                      }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "State / County",
                      }}
                      inputProps={{
                        name: "state",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.state || "",
                      }}
                    />
                    <SelectFieldGroup
                      inputProps={{
                        name: "country",
                        value: contactdetails?.country || "",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        options: country,
                      }}
                      labelProps={{ label: "Country" }}
                    />
                    <TextFieldGroup
                      labelProps={{
                        label: "ZIP / Area code",
                      }}
                      inputProps={{
                        name: "zip",
                        onChange: (e) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(e, "contactdetails")
                            : this.onInputChange(e, "contactdetails"),
                        value: contactdetails?.zip || "",
                      }}
                    />
                  </div>

                  <div className="qualifications_organisations_section">
                    <div className="qualifications_sections">
                      <h3>Qualifications</h3>
                      <SelectField
                        style={{ marginTop: 20 }}
                        name="qualification1"
                        value={qualifications?.qualification1 || ""}
                        onChange={(event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "qualifications")
                            : this.onInputChange(event, "qualifications")
                        }
                        options={this.state?.qualificationsOptions || []}
                      />
                      <SelectField
                        name="qualification2"
                        value={qualifications?.qualification2 || ""}
                        onChange={(event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "qualifications")
                            : this.onInputChange(event, "qualifications")
                        }
                        options={this.state?.qualificationsOptions || []}
                      />
                      <SelectField
                        name="qualification3"
                        value={qualifications?.qualification3 || ""}
                        onChange={(event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "qualifications")
                            : this.onInputChange(event, "qualifications")
                        }
                        options={this.state?.qualificationsOptions || []}
                      />
                      <SelectField
                        name="qualification4"
                        value={qualifications?.qualification4 || ""}
                        onChange={(event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "qualifications")
                            : this.onInputChange(event, "qualifications")
                        }
                        options={this.state?.qualificationsOptions || []}
                      />
                      <SelectField
                        name="qualification5"
                        value={qualifications?.qualification5 || ""}
                        onChange={(event) =>
                          this.state.advancedSearch
                            ? this.setAdvancedString(event, "qualifications")
                            : this.onInputChange(event, "qualifications")
                        }
                        options={this.state?.qualificationsOptions || []}
                      />
                    </div>

                    <div
                      className="organisations_section"
                      style={{ marginTop: "10px" }}
                    >
                      <h3>Organisations</h3>
                      <div
                        className="input_group_horizontal"
                        style={{ marginTop: "20px" }}
                      >
                        <div className="organizationTextbox">
                          <TextFieldGroup
                            labelProps={{
                              label: "Organisation Name",
                            }}
                            inputProps={{
                              name: "name",
                              value: organisations?.organisations1?.name || "",
                              onChange: (event) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(
                                    {
                                      target: {
                                        name: "organisationsname1",
                                        value: event.target.value,
                                      },
                                    },
                                    "organisations",
                                    "organisations1"
                                  )
                                  : this.onInputChange(
                                    event,
                                    "organisations",
                                    "organisations1"
                                  ),
                            }}
                          />
                        </div>
                        <SelectFieldGroup
                          labelProps={{
                            label: "Start Year",
                          }}
                          inputProps={{
                            name: "year",
                            disabled: organisations?.organisations1?.name
                              ? false
                              : true,
                            value: organisations?.organisations1?.year || "",
                            onChange: (event) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(
                                  {
                                    target: {
                                      name: "organisationsyear1",
                                      value: event.target.value,
                                    },
                                  },
                                  "organisations",
                                  "organisations1"
                                )
                                : this.onInputChange(
                                  event,
                                  "organisations",
                                  "organisations1"
                                ),
                            options: this.state.yearOptions,
                          }}
                          className="orginput_fld"
                        />
                      </div>
                      <div className="input_group_horizontal">
                        <div className="organizationTextbox">
                          <TextFieldGroup
                            labelProps={{
                              label: "Organisation Name",
                            }}
                            inputProps={{
                              name: "name",
                              value: organisations?.organisations2?.name || "",
                              onChange: (event) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(
                                    {
                                      target: {
                                        name: "organisationsname2",
                                        value: event.target.value,
                                      },
                                    },
                                    "organisations",
                                    "organisations2"
                                  )
                                  : this.onInputChange(
                                    event,
                                    "organisations",
                                    "organisations2"
                                  ),
                            }}
                          />
                        </div>
                        <SelectFieldGroup
                          labelProps={{
                            label: "Start Year",
                          }}
                          inputProps={{
                            name: "year",
                            disabled: organisations?.organisations2?.name
                              ? false
                              : true,
                            value: organisations?.organisations2?.year || "",
                            onChange: (event) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(
                                  {
                                    target: {
                                      name: "organisationsyear2",
                                      value: event.target.value,
                                    },
                                  },
                                  "organisations",
                                  "organisations2"
                                )
                                : this.onInputChange(
                                  event,
                                  "organisations",
                                  "organisations2"
                                ),
                            options: this.state.yearOptions,
                          }}
                          className="orginput_fld"
                        />
                      </div>
                      <div className="input_group_horizontal">
                        <div className="organizationTextbox">
                          <TextFieldGroup
                            labelProps={{
                              label: "Organisation Name",
                            }}
                            inputProps={{
                              name: "name",
                              value: organisations?.organisations3?.name || "",
                              onChange: (event) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(
                                    {
                                      target: {
                                        name: "organisationsname3",
                                        value: event.target.value,
                                      },
                                    },
                                    "organisations",
                                    "organisations3"
                                  )
                                  : this.onInputChange(
                                    event,
                                    "organisations",
                                    "organisations3"
                                  ),
                            }}
                          />
                        </div>
                        <SelectFieldGroup
                          labelProps={{
                            label: "Start Year",
                          }}
                          inputProps={{
                            name: "year",
                            disabled: organisations?.organisations3?.name
                              ? false
                              : true,
                            value: organisations?.organisations3?.year || "",
                            onChange: (event) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(
                                  {
                                    target: {
                                      name: "organisationsyear3",
                                      value: event.target.value,
                                    },
                                  },
                                  "organisations",
                                  "organisations3"
                                )
                                : this.onInputChange(
                                  event,
                                  "organisations",
                                  "organisations3"
                                ),
                            options: this.state.yearOptions,
                          }}
                          className="orginput_fld"
                        />
                      </div>
                      <div className="input_group_horizontal">
                        <div className="organizationTextbox">
                          <TextFieldGroup
                            labelProps={{
                              label: "Organisation Name",
                            }}
                            inputProps={{
                              name: "name",
                              value: organisations?.organisations4?.name || "",
                              onChange: (event) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(
                                    {
                                      target: {
                                        name: "organisationsname4",
                                        value: event.target.value,
                                      },
                                    },
                                    "organisations",
                                    "organisations4"
                                  )
                                  : this.onInputChange(
                                    event,
                                    "organisations",
                                    "organisations4"
                                  ),
                            }}
                          />
                        </div>
                        <SelectFieldGroup
                          labelProps={{
                            label: "Start Year",
                          }}
                          inputProps={{
                            name: "year",
                            disabled: organisations?.organisations4?.name
                              ? false
                              : true,
                            value: organisations?.organisations4?.year || "",
                            onChange: (event) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(
                                  {
                                    target: {
                                      name: "organisationsyear4",
                                      value: event.target.value,
                                    },
                                  },
                                  "organisations",
                                  "organisations4"
                                )
                                : this.onInputChange(
                                  event,
                                  "organisations",
                                  "organisations4"
                                ),
                            options: this.state.yearOptions,
                          }}
                          className="orginput_fld"
                        />
                      </div>
                      <div className="input_group_horizontal">
                        <div className="organizationTextbox">
                          <TextFieldGroup
                            labelProps={{
                              label: "Organisation Name",
                            }}
                            inputProps={{
                              name: "name",
                              value: organisations?.organisations5?.name || "",
                              onChange: (event) =>
                                this.state.advancedSearch
                                  ? this.setAdvancedString(
                                    {
                                      target: {
                                        name: "organisationsname5",
                                        value: event.target.value,
                                      },
                                    },
                                    "organisations",
                                    "organisations5"
                                  )
                                  : this.onInputChange(
                                    event,
                                    "organisations",
                                    "organisations5"
                                  ),
                            }}
                          />
                        </div>
                        <SelectFieldGroup
                          labelProps={{
                            label: "Start Year",
                          }}
                          inputProps={{
                            name: "year",
                            disabled: organisations?.organisations5?.name
                              ? false
                              : true,
                            value: organisations?.organisations5?.year || "",
                            onChange: (event) =>
                              this.state.advancedSearch
                                ? this.setAdvancedString(
                                  {
                                    target: {
                                      name: "organisationsyear5",
                                      value: event.target.value,
                                    },
                                  },
                                  "organisations",
                                  "organisations5"
                                )
                                : this.onInputChange(
                                  event,
                                  "organisations",
                                  "organisations5"
                                ),
                            options: this.state.yearOptions,
                          }}
                          className="orginput_fld"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </PrivateProfileStyles>
      </>
    );
  }
}

export default UserSearch;

const PrivateProfileStyles = styled.div`
  font-size: calc(0.9vh + 6px);
  padding: 5px 0;

  .utilitiesUnderline {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 0px 20px;
    margin-bottom: 10px;
  }

  label{
    font-weight:400;
  }
  .utilitiesUnderline .icons-action{
    padding-bottom:5px;
  }
  .detailsContainer .form {
    height: calc(68vh - 35px);
    overflow-y: auto;
    padding-left: 20px;
  }
  .search-box {
    height: 27px;
  }
  .search_section,
  .font_align {
    font-size: calc(0.9vw + 0.01em) !important;
  }
  .orginput_fld {
    margin-left: 10px;

    span:first-child span {
      left: 2px !important;
      z-index: 1;
      top: -14px;
      max-width: 90%;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }
  form {
    .cancel_button,
    button {
    }
    .submit_button_holder {
      margin-top: 20px;
    }
  }
  .form-fields {
    display: flex;
    flex-direction: row;
    color: #666;
    padding: 0px 0px 0px 0px !important;
  }
  .main-header,
  .search_section h3 {
    font-size: calc(0.9vh + 8px);
    font-weight: 600;
    margin: 0;
    color: rgba(0, 0, 0, 0.87);
    margin-top: 10px;
  }
  .search_section {
    border-right: 1px solid #ccc;
    padding: 0 10px;
    margin-right: 5px;
    min-width: 25%;
    .label {
      text-align: left;
      font-size: 10px;
      padding-left: 10px;
      color: #4395a6;
      margin-bottom: 0;
    }
    .button-text {
      font-size: 8px;
      color: #ffffff;
      align-self: center;
    }
  }
  .form {
    display: flex;
    flex-direction: row;
    width: 100%;
    justify-content: space-between;
  }
  .personal_details_section,
  .contact_details_section,
  .qualifications_organisations_section {
    width: 26%;
    margin-right: 10px;
    margin-left: 10px;
    h3 {
      font-size: calc(0.9vh + 8px) !important;
      font-weight: 600 !important;
      color: #4395a6 !important;
      margin: 0 !important;
      text-align: left !important;
      line-height: 20px !important;
    }
    .input-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 5px;
      input {
        height: 20px;
        border: 1px solid ${(props) => props.inputColor};
      }
      select {
        height: 20px;
        border: 1px solid ${(props) => props.inputColor};
      }
      textarea {
        height: 80px;
        resize: none;
        border: 1px solid ${(props) => props.inputColor};
      }
      label {
        font-size: 8px !important;
        font-weight:400 !important;
        color: ${(props) => props.styles.label_text.font_colour};
        margin-bottom: 0px;
        display: flex;
        justify-content: space-between;
      }
      span {
        font-size: 8px !important;
        color: ${(props) => props.styles.label_text.font_colour};
        margin-bottom: 0px;
        display: flex;
        justify-content: space-between;
      }
      svg {
        font-size: 20px;
        cursor: pointer;
      }
    }

    .qualifications_sections {
      width: 62%;
      .input-group {
        margin-bottom: 10px;
      }
      .pt {
        margin-top: 15px;
      }
    }
    .organisations_section {
      select {
        margin-bottom: 0px;
      }
      .input_group_horizontal {
        display: flex;
        width: 86.41%;
        .input-group {
          width: 100%;
          :last-child {
            width: 25%;
            margin-left: 15px;
          }
        }
      }
    }
  }
  .qualifications_organisations_section {
    width: 40%;
  }
  .descriptions_section {
    margin-right: 50px;
  }
  .personal_details_section,
  .contact_details_section {
    input {
      margin-bottom: 20px;
      border: 1px solid ${(props) => props.inputColor};
    }
    select {
      margin-bottom: 20px;
      border: 1px solid ${(props) => props.inputColor};
    }
    textarea {
      margin-bottom: 20px;
      border: 1px solid ${(props) => props.inputColor};
    }
  }
  .qualifications_organisations_section {
    input {
      margin-bottom: 20px;
      border: 1px solid ${(props) => props.inputColor};
    }
    select{
      border: 1px solid ${(props) => props.inputColor};
    }
    }
  }
  @media (max-width: 810px) {
    form {
      padding: 0 10px;
    }
    .form {
      display: flex;
      flex-direction: column;
    }
    .form-fields {
      flex-direction: column;
      .personal_details_section,
      .contact_details_section,
      .qualifications_organisations_section {
        width: 100%;
        .qualifications_sections {
          width: 100%;
        }
        .form {
          display: flex;
          flex-direction: row;
          width: 80%;
          justify-content: space-between;
        }
        .organisations_section {
          .input_group_horizontal {
            flex-direction: column;
            width: 100%;
            .input-group:first-child {
              width: 100%;
            }
            .input-group:last-child {
              min-width: 80px;
              width: 30%;
              margin-left: 0;
            }
          }
        }
      }
    }
    .action-buttons {
      margin-top: 20px;
    }
  }
  .error {
    color: red;
  }
  .qualifications_sections > select {
    margin-bottom: 16px;
  }
  textarea {
    resize: none;
  }
  
`;
