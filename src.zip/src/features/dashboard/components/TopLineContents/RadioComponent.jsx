import React, { Component } from "react";
import styled from "styled-components";

export default class RadioComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      one: false,
      two: false,
      three: false,
      styles: {
        popup: {},
        panels: {},
      },
    };
  }
  componentDidUpdate() {
    window.addEventListener("message", this.receiveMessageFromIndex, false);
  }
  receiveMessageFromIndex(event) {
    let data = JSON.parse(event.data);
    localStorage.setItem("groupId", data.groupId);
  }
  render() {
    let groupid = localStorage.getItem("groupId");
    const { setFilter } = this.props;
    const handleChange = (e) => {
      let value = e.target.value;
      setFilter(value);
      if (value === "one") {
        this.setState({
          one: true,
          two: false,
          three: false,
        });
      }
      if (value === "two") {
        this.setState({
          one: false,
          two: true,
          three: false,
        });
      }
      if (value === "three") {
        this.setState({
          one: false,
          two: false,
          three: true,
        });
      }
    };
    return (
      <Radio onChange={(e) => handleChange(e)}>
        <div className="row">
          <input
            className="radio"
            type="radio"
            checked={this.state.one}
            value="one"
          />
          <p>Within Organisation</p>
        </div>
        <div className="row">
          <input
            className="radio"
            type="radio"
            checked={this.state.two}
            disabled={localStorage.getItem("groupId") ? false : true}
            value="two"
          />
          <p>Within Group</p>
        </div>
        <div className="row">
          <input
            className="radio"
            type="radio"
            checked={this.state.three}
            value="three"
          />
          <p>Search All</p>
        </div>
      </Radio>
    );
  }
}
const Radio = styled.div`
  .row {
    display: flex;
    flex-direction: row;
    align-items: center;
    height: 15px;
    p {
      font-size: 8px;
      margin-left: 5px;
      color: #eba434;
      margin-right: 11px;
      margin-top: 13px;
    }
    .radio {
      box-shadow: 0px 0px 0px rgba(0, 0, 0, 0);
      width: 8px;
    }
    input:checked {
      background-color: #ccc;
      border-color: #ccc;
    }
  }
`;
