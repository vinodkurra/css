import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { useSelector, useDispatch, batch } from "react-redux";
import styled from "styled-components";
import Spinner from "../../components/Spinner";

const HeaderMenu = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const { isLoading } = useSelector((state) => state.content);

  return (
    <>
      {
        <HeaderStyle theme={styles.landing_page}>
          {isLoading ? <Spinner /> : ""}
          <li>
            <NavLink
              exact
              to="/dashboard/home"
              onClick={() => (window.location.href = "/dashboard/home")}
            >
              <p>
                <i className="fa fa-home"></i>
              </p>
              <p>HUB</p>
            </NavLink>
          </li>
          <li>
            <NavLink to="/dashboard/patients">
              <p>
                <i className="fa fa-user-md"></i>
                {/* <img src={styles.icons.calendar? styles.icons.calendar : null} /> */}
              </p>
              <p>PATIENTS</p>
            </NavLink>
          </li>
          <li>
            <NavLink to="/dashboard/scheduler">
              <p>
                <i className="fa fa-calendar"></i>
                {/* <img src={styles.icons.calendar? styles.icons.calendar : null} /> */}
              </p>
              <p>SCHEDULER</p>
            </NavLink>
          </li>

          <li>
            <NavLink to="/dashboard/notes">
              <p>
                <i className="fa fa-sticky-note-o"></i>
              </p>
              <p>NOTES</p>
            </NavLink>
          </li>

          <li>
            <NavLink to="/dashboard/admin">
              <p>
                <i className="fa fa-user-o"></i>
              </p>
              <p>ADMIN</p>
            </NavLink>
          </li>

          <li>
            <NavLink to="/dashboard/content">
              <p>
                <i className="fa fa-building-o"></i>
              </p>
              <p>CONTENT</p>
            </NavLink>
          </li>

          {/* <li>
            <NavLink to="/About">
              <p>
                <i className="fa fa-file-text-o"></i>
              </p>
              <p>LIBRARY</p>
            </NavLink>
          </li>

          <li>
            <NavLink to="/About">
              <p>
                <div><svg xmlns="http://www.w3.org/2000/svg"  aria-hidden="true" focusable="false" width="3em" height="4em"  preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M5 3c-1.11 0-2 .89-2 2v14c0 1.11.89 2 2 2h6V3m2 0v8h8V5c0-1.11-.89-2-2-2m-6 10v8h6c1.11 0 2-.89 2-2v-6" fill="#738c87"/></svg></div> */}
          {/* <i className="fa fa-bar-chart"></i> */}
          {/* </p>
              <p>EDITOR</p>
            </NavLink>
          </li> */}
          <li>
            <NavLink to="/dashboard/consultation-process">
              <p>
                <i className="fa fa-building-o"></i>
              </p>
              <p>CONSULTATION</p>
            </NavLink>
          </li>
          {/* <li>
            <NavLink to="/dashboard/consultation-process">
              <p>
                <i className="fa fa-building-o"></i>
              </p>
              <p>consultation</p>
            </NavLink>
          </li> */}
        </HeaderStyle>
      }
    </>
  );
};

export default HeaderMenu;

const HeaderStyle = styled.ul`
  ul {
    list-style: none;
    margin: 0;
    li {
      display: inline-block;
      padding: 10px 20px;
      a {
        text-transform: capitalize;

        p {
          margin: 0;
          color: ${(props) => props.theme.tl_navbtn_font_color};
          font-size: 15px;
          i {
            text-align: center;
            display: block;
            margin: 0 auto;
            color: ${(props) => props.theme.tl_navbtn_font_color};
            font-size: ${(props) => props.theme.tl_navbtn_font_size};
            margin-bottom: 5px;
            img {
              text-align: center;
              display: block;
              margin: 0 auto;
              color: ${(props) => props.theme.tl_navbtn_font_color};
              font-size: ${(props) => props.theme.tl_navbtn_font_size};
              margin-bottom: 5px;
            }
          }
        }
      }
      .active p {
        color: ${(props) =>
          props.theme.tl_navbtn_active_font_color};
      }
      .active p i {
        color: ${(props) =>
          props.theme.tl_navbtn_active_font_color};
        border-top: 5px solid
          ${(props) =>
            props.theme.tl_navbtn_active_font_color};
        width: 30px;
        border-radius: 5px;
      }
    }
  }
`;
