import React, { useState } from 'react';
import { useSelector, useDispatch, batch } from "react-redux";

import logo from '../../../assets/logo.png';

import {
    setIsGlobalLogoPopupVisible
} from "../../../store/content";

// console.log('location ', window.location)

const HubLogo = ({ history }) => {
    const dispatch = useDispatch();
    const styles = useSelector((state) => state.ui.styles);
    const {
        isGlobalLogoPopupVisible
    } = useSelector(state => state.content);
    // const [isPopupVisible, setIsPopupVisible] = useState(false);
            
    const handleHubLogoClick = () => {
        dispatch(setIsGlobalLogoPopupVisible(!isGlobalLogoPopupVisible));
        // setIsPopupVisible(!isPopupVisible);
        // alert('clicked');
    }
    return (
        <>
            {
                window.location.pathname.includes('/content') ?
                    <div onClick={handleHubLogoClick}>
                        <img
                            src={styles.icons.hub_logo ? styles.icons.hub_logo : logo}
                            alt=".."
                        />
                        {/* <strong>HUB</strong>
                        <span>0</span> */}
                    </div> :
                    <div>
                        <img
                            src={styles.icons.hub_logo ? styles.icons.hub_logo : logo}
                            alt=".."
                        />
                        {/* <strong>HUB</strong>
                        <span>0</span> */}
                    </div>
            }

        </>

    )
}

export default HubLogo;