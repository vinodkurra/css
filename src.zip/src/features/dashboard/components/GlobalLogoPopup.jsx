import React, { useState, useEffect } from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from "react-redux";
import jwt from "jsonwebtoken";
import { setIsGlobalLogoPopupVisible, setGlobalLogoSelectedWidgets } from "../../../store/content";
import { apiUrlWithToken, tagApiUrlWithToken } from '../../../calls/apis'
import {
    COMPRESSED_VIEW,
    STANDARD_VIEW,
    ADVANCED_VIEW,
    BOOKMARK,
    EXPORT,
    REQUIRED,
    HIDE,
    TEXT_INPUT_WIDGET,
    BINARY_INPUT_WIDGET,
    TIME_INPUT_WIDGET,
    WARNING_INPUT_WIDGET,
    SINGLE_CHOICE_WIDGET,
    MULTI_CHOICE_WIDGET,
    DATE_WIDGET,
    DROPDOWNLIST_WIDGET,
    NUMBER_WIDGET,
    NARRATIVE_WIDGET,
    CALCULATION_WIDGET,
    BRANCH_CONTROL_WIDGET
} from '../../../content-builder/components/Constants';
import Widget from "../../../content-builder/components/Widget";

export default function GlobalLogoPopup({ tags }) {
    const dispatch = useDispatch();
    const styles = useSelector((state) => state.ui.styles);
    const {
        contents,
        activeContentId,
        isGlobalLogoPopupVisible
    } = useSelector(state => state.content);

    let currentContent = contents.length > 0 ? contents.find((content) => content.contentId === activeContentId) : '';

    const [widgetTypes, setWidgetTypes] = useState([]);
    const [widgetList, setWidgetList] = useState([]);
    const [selectedModule, setSelectedModule] = useState(0);
    const [tagList, setTagList] = useState(tags);
    const [isTag, setIsTag] = useState(false);
    const [isProcess, setIsProcess] = useState(false);
    const [widgetFields, setWidgetFields] = useState([]);
    const [currentModule, setCurrentModule] = useState([]);
    const [widget, setWidget] = useState({});
    const [widgetTypeIndex, setWidgetTypeIndex] = useState(null);
    const [fieldNameFocus, setFieldNameFocus] = useState(null);
    const [isBranch, setIsBranch] = useState(false);

    useEffect(() => {
        if (currentContent?.moduleList?.length > 0) {
            setCurrentModule(currentContent?.moduleList[0]);
            loadWidget(currentContent?.moduleList[0]?.widgetList);
        }
        else if (currentContent?.widgetList?.length > 0) {
            setIsProcess(true);
            loadWidget(currentContent?.widgetList);
        }
        else
            setIsTag(true);
    }, []);

    const handleHubLogoClick = () => {
        dispatch(setIsGlobalLogoPopupVisible(!isGlobalLogoPopupVisible));
        // setIsPopupVisible(!isPopupVisible);
    }

    const hanldeModule = (module, index) => {
        setIsProcess(false);
        setIsTag(false);
        setSelectedModule(index);
        setCurrentModule(module);
        loadWidget(module.widgetList);
        setWidgetFields([]);
        setWidgetTypeIndex(null);
        setFieldNameFocus(null);
        setWidget({});
    }

    const loadWidget = (widgetList) => {

        if (widgetList?.length > 0) {
            let branchWidgetList = widgetList?.filter(widget => widget.type === "branch");
            let exportWidgetList = branchWidgetList;
            // if (branchWidgetList?.length > 0) {
            //     branchWidgetList.map((nestedWidget) => {
            //         if (nestedWidget.type != "branch" && nestedWidget.export) {
            //             exportWidgetList = [...exportWidgetList, nestedWidget];
            //         }
            //         else {
            //             if (nestedWidget.widgetList?.length > 0) {
            //                 nestedWidget.widgetList.map((innerNestedWidget) => {
            //                     if (innerNestedWidget.type != "branch" && innerNestedWidget.export) {
            //                         exportWidgetList = [...exportWidgetList, innerNestedWidget];
            //                     }
            //                 });
            //             }
            //         }
            //     })
            // }
            //// branchWidgetList?.widgetList?.filter(widget => widget.export === true);
            exportWidgetList = [...exportWidgetList, ...widgetList.filter(widget => widget.export === true)];
            if (exportWidgetList?.length > 0) {
                let currentWidgetTypes = [];
                exportWidgetList.map((nestedWidget) => {
                    if (nestedWidget.type != "branch") {
                        let widgetInputTypes = ["text", "binary", "time", "single_choice", "multiple_choice", "date", "drop_down", "number"];
                        const widgetInputTypesExist = widgetInputTypes.indexOf(nestedWidget.type) >= 0;
                        if (widgetInputTypesExist)
                            currentWidgetTypes.push('Input');
                        let withoutInputWidgetTypesExist = widgetInputTypes.indexOf(nestedWidget.type) < 0;
                        if (withoutInputWidgetTypesExist) {
                            let withoutInputWidgetTypes = [];
                            withoutInputWidgetTypes.push(nestedWidget.type);
                            currentWidgetTypes = [...currentWidgetTypes, ...withoutInputWidgetTypes];
                        }
                    }
                    else {
                        if (nestedWidget.widgetList?.length > 0) {
                            nestedWidget.widgetList.map((innerNestedWidget) => {
                                if (innerNestedWidget.export) {
                                    currentWidgetTypes.push('branch');
                                    exportWidgetList = [...exportWidgetList, nestedWidget];
                                }
                                if (innerNestedWidget.type === "branch" && innerNestedWidget.widgetList?.length > 0) {
                                    innerNestedWidget.widgetList.map((innerBranch) => {
                                        if (innerBranch.export) {
                                            currentWidgetTypes.push('branch');
                                            exportWidgetList = [...exportWidgetList, innerBranch];
                                        }
                                    });
                                }
                                else if (innerNestedWidget.type === "execution_frame" && innerNestedWidget.widgetList?.length > 0) {
                                    innerNestedWidget.widgetList.map((innerBranch) => {
                                        if (innerBranch.export) {
                                            currentWidgetTypes.push('branch');
                                            exportWidgetList = [...exportWidgetList, innerBranch];
                                        }
                                    });
                                }
                            });
                        }
                    }
                });

                // let currentWidgetTypes = [];
                // let widgetInputTypes = ["text", "binary", "time", "single_choice", "multiple_choice", "date", "drop_down", "number"];
                // const widgetInputTypesExist = exportWidgetList.filter(widget => widgetInputTypes.indexOf(widget.type) >= 0);
                // if (widgetInputTypesExist.length > 0)
                //     currentWidgetTypes.push('Input');
                // let withoutInputWidgetTypesExist = exportWidgetList.filter(widget => widgetInputTypes.indexOf(widget.type) < 0);
                // if (withoutInputWidgetTypesExist.length > 0) {
                //     let withoutInputWidgetTypes = withoutInputWidgetTypesExist.map(x => x.type);
                //     currentWidgetTypes = [...currentWidgetTypes, ...withoutInputWidgetTypes];
                // }
                let uniqueWidgetTypes = [...new Set(currentWidgetTypes)];
                if (uniqueWidgetTypes?.length > 0) {
                    setWidgetTypes(uniqueWidgetTypes);
                    setWidgetList(exportWidgetList);
                }
                else {
                    setWidgetTypes([]); setWidgetList([]);
                }
            }
        }
        else {
            setWidgetTypes([]); setWidgetList([]);
        }
    }

    const handleWidgetTypeClick = (widgetFieldType, index) => {
        // setIsBranch(widgetFieldType === "branch" ? true : false);

        setWidgetTypeIndex(index);
        setFieldNameFocus(null);
        setWidget({});
        let currentWidgetFields = [];
        let widgetListArray = isProcess ? currentContent.widgetList : currentModule.widgetList;
        let branchWidgetList = widgetListArray?.filter(widget => widget.type === "branch");
        let exportWidgetList = [...branchWidgetList, ...widgetListArray?.filter(widget => widget.export === true)];
        if (exportWidgetList?.length > 0) {
            let widgetInputTypes = ["text", "binary", "time", "single_choice", "multiple_choice", "date", "drop_down", "number"];
            if (widgetFieldType === 'Input') {
                currentWidgetFields = exportWidgetList.filter(widget => widgetInputTypes.indexOf(widget.type) >= 0);
            }
            else if (widgetFieldType === 'branch') {
                let data = exportWidgetList.filter(x => x.widgetList);
                if (data?.length > 0) {
                    data.map((widget) => {
                        if (widget.widgetList.length > 0) {
                            widget.widgetList.map((nestedWidget) => {
                                
                                if ((nestedWidget.type === 'branch' && !nestedWidget.export) || (nestedWidget.type != 'branch' && nestedWidget.export)) {
                                    if (nestedWidget.widgetList?.length > 0) {
                                        nestedWidget.widgetList.map((innerNestedWidget) => {
                                            if (innerNestedWidget.export) {
                                                innerNestedWidget.branchType = 'branch';
                                                innerNestedWidget.branchTitle = widget.title + " -> " + nestedWidget.title + " -> " + innerNestedWidget.title;
                                                currentWidgetFields = [...currentWidgetFields, innerNestedWidget];
                                            }
                                        });
                                    }
                                    else {
                                        if (nestedWidget.export) {
                                            nestedWidget.branchType = 'branch';
                                            nestedWidget.branchTitle = widget.title + " -> " + nestedWidget.title;
                                            currentWidgetFields = [...currentWidgetFields, nestedWidget];
                                        }
                                    }
                                }
                                else if (nestedWidget.type === 'execution_frame' && nestedWidget.widgetList?.length > 0) {
                                    nestedWidget.widgetList.map((innerNestedWidget) => {
                                        if (innerNestedWidget.export) {
                                            innerNestedWidget.branchType = 'branch';
                                            innerNestedWidget.branchTitle = widget.title + " -> " + innerNestedWidget.title;
                                            currentWidgetFields = [...currentWidgetFields, innerNestedWidget];
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }
            else {
                currentWidgetFields = exportWidgetList.filter(widget => widget.type.includes(widgetFieldType));
            }
        }
        setWidgetFields(currentWidgetFields);
    }

    const handleSelectWidget = (widget) => {
        dispatch(setGlobalLogoSelectedWidgets(widget));
        dispatch(setIsGlobalLogoPopupVisible(!isGlobalLogoPopupVisible));
    }

    const hanldeViewWidget = (index, widget) => {
        setFieldNameFocus(index);
        setWidget(widget);
    }

    const handleTagNameClick = (currentTag) => {
        let selectedTag = tagList.filter(tag => tag.tag_id === currentTag.tag_id);
        if (selectedTag?.length > 0) {
            let tag = {
                title: selectedTag[0].tag_name,
                type: 'Tag'
            }
            dispatch(setGlobalLogoSelectedWidgets(tag));
            dispatch(setIsGlobalLogoPopupVisible(!isGlobalLogoPopupVisible));
        }
    }

    const getBackgroundClass = (widgetType) => {
        //widgetType = isBranch ? 'branch' : widgetType;
        switch (widgetType) {
            case WARNING_INPUT_WIDGET:
                return { class: 'background_warn', color: '#f1420d' };
            case NARRATIVE_WIDGET:
                return { class: 'nara_bg', color: '#e74ee6' };
            case CALCULATION_WIDGET:
                return { class: 'calc_bg', color: '#ef8f31' };
            // case BRANCH_CONTROL_WIDGET:
            //     return { class: 'branch_bg', color: '#f7f9fb' };
            default:
                return { class: 'background', color: '#2479f2' };
        }
    };

    const hanldleProcess = () => {
        setIsProcess(true);
        setIsTag(false);
        loadWidget(currentContent?.widgetList);
        setWidgetFields([]);
        setWidgetTypeIndex(null);
        setFieldNameFocus(null);
        setWidget({});
    }

    const hanldleTag = () => {
        setIsTag(true);
        setIsProcess(false);
    }

    return (
        <HubLogoPopupStyles>
            <div className="hubLogoPopupContainer">
                <div className="hubLogoPopup">
                    <div className="hubLogoPopupLeft">
                        <div className="popupLogo" onClick={handleHubLogoClick}>
                            <img src="https://hypaiq-local.s3-eu-west-2.amazonaws.com/icons/hub-hub_logo-20200704-133216.png" />
                        </div>
                        <ul>
                            <li className="popupActiveBg"> Insert Field </li>
                            <li> Open Recent </li>
                        </ul>
                    </div>
                    <div className="hubLogoPopupRight yellowBg">
                        <div className="listHeading">
                            <div className="moduleSection"> <h3>Module / Tag</h3> </div>
                            <div className="typeSection"> <h3>Type</h3> </div>
                            <div className="fieldSection"> <h3>Field Name</h3> </div>
                        </div>
                        <div className="listContainer">
                            <div className="moduleSection">
                                <div>
                                    <ul>
                                        {currentContent?.moduleList?.map((module, index) => (
                                            <li className={selectedModule == index && !isTag && !isProcess ? 'greyBg focusBorder' : 'greyBg'} key={index} onClick={(e) => hanldeModule(module, index)} >{module.title || null}
                                                {selectedModule == index && !isTag && !isProcess ?
                                                    <span className="greaterThanSymbol">
                                                        <svg version="1.1" x="0px" y="0px"
                                                            width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20">
                                                            <rect x="9.735" y="0.014" transform="matrix(0.7127 -0.7014 0.7014 0.7127 -1.1368 9.3579)" fill="#800000018000000180000001" width="2.243" height="12.106" />
                                                            <rect x="10.206" y="7.667" transform="matrix(0.707 0.7072 -0.7072 0.707 13.4156 -3.7565)" fill="#800000018000000180000001" width="2.07" height="13.29" />
                                                        </svg>
                                                    </span> : null}
                                            </li>
                                        ))}
                                        <li className={isProcess ? "darkGreyBg focusBorder" : "darkGreyBg"} onClick={() => hanldleProcess(true)}>Process
                                            {isProcess ?
                                                <span className="greaterThanSymbol">
                                                    <svg version="1.1" x="0px" y="0px"
                                                        width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20">
                                                        <rect x="9.735" y="0.014" transform="matrix(0.7127 -0.7014 0.7014 0.7127 -1.1368 9.3579)" fill="#800000018000000180000001" width="2.243" height="12.106" />
                                                        <rect x="10.206" y="7.667" transform="matrix(0.707 0.7072 -0.7072 0.707 13.4156 -3.7565)" fill="#800000018000000180000001" width="2.07" height="13.29" />
                                                    </svg>
                                                </span> : null}
                                        </li>
                                        <li className={isTag ? "darkGreyBg focusBorder" : "darkGreyBg"} onClick={() => hanldleTag(true)}>TAGS
                                            {isTag ?
                                                <span className="greaterThanSymbol">
                                                    <svg version="1.1" x="0px" y="0px"
                                                        width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20">
                                                        <rect x="9.735" y="0.014" transform="matrix(0.7127 -0.7014 0.7014 0.7127 -1.1368 9.3579)" fill="#800000018000000180000001" width="2.243" height="12.106" />
                                                        <rect x="10.206" y="7.667" transform="matrix(0.707 0.7072 -0.7072 0.707 13.4156 -3.7565)" fill="#800000018000000180000001" width="2.07" height="13.29" />
                                                    </svg>
                                                </span> : null}
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            {!isTag && widgetTypes?.length > 0 ?
                                <div className="typeSection">
                                    <div>
                                        <ul>
                                            {widgetTypes.map((type, index) => (
                                                <li key={index}
                                                    // className={
                                                    //     type?.toLowerCase().includes('war') ?
                                                    //         "orangeBg" :
                                                    //         "blueBg"
                                                    // }
                                                    className={widgetTypeIndex == index ? 'focusBorder ' + getBackgroundClass(type).class : getBackgroundClass(type).class}
                                                    onClick={() => handleWidgetTypeClick(type, index)}>
                                                    {type?.toUpperCase() || "null"}
                                                    {widgetTypeIndex == index ?
                                                        <span className="greaterThanSymbol">
                                                            <svg version="1.1" x="0px" y="0px"
                                                                width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20">
                                                                <rect x="9.735" y="0.014" transform="matrix(0.7127 -0.7014 0.7014 0.7127 -1.1368 9.3579)" fill="#800000018000000180000001" width="2.243" height="12.106" />
                                                                <rect x="10.206" y="7.667" transform="matrix(0.707 0.7072 -0.7072 0.707 13.4156 -3.7565)" fill="#800000018000000180000001" width="2.07" height="13.29" />
                                                            </svg>
                                                        </span> : null}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                                : null
                            }
                            {!isTag && widgetList?.length > 0 && widgetFields?.length > 0 ?
                                <div className="fieldSection">
                                    <div>
                                        <ul>
                                            {widgetFields.map((widget, index) => (
                                                <li
                                                    key={index}
                                                    // className={
                                                    //     widget.type?.toLowerCase().includes('war') ?
                                                    //         "orangeBg" :
                                                    //         "blueBg"
                                                    // }
                                                    className={fieldNameFocus == index ? 'focusBorder ' + getBackgroundClass(widget.type).class : getBackgroundClass(widget.type).class}
                                                    onClick={() => handleSelectWidget(widget)}
                                                    onMouseOver={() => hanldeViewWidget(index, widget)}
                                                >
                                                    {widget.branchType === 'branch' ? widget.branchTitle : widget.title || "null"}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div> : null
                            }

                            {
                                (!isTag && widgetList?.length === 0 || isTag && tagList?.length == 0) ?
                                    <div className="noRecordsDiv">No Records Found!</div>
                                    : null
                            }

                            {/* {isTag && tagList?.length > 0 ?
                                <div className="fieldSection marLeft60">
                                    <h3>Tag Name</h3>
                                    <div>
                                        <ul>
                                            {tagList.map((tag, index) => (
                                                <li key={index}
                                                    className="darkGreyBg"
                                                    onClick={handleTagNameClick}
                                                >
                                                    {tag.tag_name || "null"}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div> : null
                            } */}

                            {isTag && tagList?.length > 0 ?
                                <div className="typeSection">
                                    <h3>Tag Name</h3>
                                    <div>
                                        <ul>
                                            {tagList.map((tag, index) => (
                                                <li key={index}
                                                    className="darkGreyBg"
                                                    onClick={() => handleTagNameClick(tag)}
                                                >
                                                    {tag.tag_name || "null"}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                                : null
                            }
                        </div>
                        <div className="afterListContainer"></div>
                        <div className="pointerEventContainer">
                            <div className={widget.bookmark ? "pointerEvent pointerEventBookmark" : "pointerEvent"}>
                                {Object.keys(widget).length > 0 ?
                                    <Widget
                                        widgetDetails={widget}
                                        isGlobalLogoPopup={true}
                                    // handleSelectWidget={handleSelectWidget}
                                    // widgetPosition="insideModule"
                                    // widgetIndex={widget.id}
                                    />
                                    : null}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </HubLogoPopupStyles >
    )
}

const HubLogoPopupStyles = Styled.div`
position: fixed;
top: 0;
z-index: 1000;
background: #ffffff5c;
height: 100vh;
width: 100%;
overflow-y: auto;
font-weight: 600;
.pointerEventContainer{
    border-top: 1px solid #bcbcbc;
    padding: 10px;
    display: flex;
    justify-content: center;
}
.pointerEvent{
    width: 500px;
}

.popupLogo img{
    clip-path: circle(67.4% at 38% 44%);
    height: calc(1vw + 30px);
}
.greyBg{
    background: #e3e5e6;
}
.darkGreyBg{
    background: #999999;
}
.blueBg{
    background: #2479f2;
}
.orangeBg{
    background: #f1420d;
}
.pinkBg{
    background: #eb13eb;
}
.popupActiveBg, .yellowBg{
    background: #f7f8c9;
}
.hubLogoPopupContainer{
    .hubLogoPopup{
        display: flex;
        height: calc(100vh - 0.3rem);
        width: 850px;
        background: #fff;
        border: 1px solid #3b91e9;
        position: relative;
        top: 0.3rem;
        left: 0.3rem;

        ul{
        list - style: none;
            margin-top: 1rem;
            li{
                padding: 0.4rem;
                position: relative;
                font-size: 14px;
            }
        }
        .hubLogoPopupLeft{
            width: 225px;
            border: 1px solid #3b91e9;
            ul{
            position: relative;
            }
            li:after{
                content: '';
                width: 0px;
                height: 0px;
                border-top: 8px solid transparent;
                border-bottom: 8px solid transparent;
                border-right: 10px solid #727272;
                position: absolute;
                right: 16px;
                transform: rotate(180deg);
                top: 10px;
            }
        }
        .hubLogoPopupRight{
            width: 625px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border: 1px solid #3b91e9;
            overflow-y: auto;
            justify-content: flex-start;
            li{
                padding: 0.2rem;
                //font-size: 0.9rem;
                margin: 0.4rem;
                list-style: none;
            }
            .focusBorder{
                border: 2px solid #444242;
            }
            h3{
                text-align: center;
                color: #4a4a4b;
                font-size: 1.5rem;
            }
            .listContainer{
                    display: flex;
                    height: calc(50vh - 10px);
                    overflow: auto;
                    ::-webkit-scrollbar-thumb {background: black}
                .moduleSection{
                    width: 180px;
                }
                .typeSection{
                    width: 140px;
                }
                .fieldSection{
                    width: 305px;
                }
            }
            .WidgetContainer{
                margin: 1rem auto;
                .widget{
                    display: flex;
                }
            }
        }
    }
}

// widget start

.widgetMain{
    overflow: hidden;
    width: 450px;
}
.background {
    background: #eb4913;
}
.widget_header {
    display: flex;
    border-top-left-radius: 15px;
}
.widget_icon {
    width: 19%;
    position: relative;
}
.widget_icon img {
    width: 50px;
    height: auto;
    // position: absolute;
}
.widget_arrow_collapse {
    width: 20px !important;
    bottom: 2px;
    right: 2px;
}
.widget_header_info {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 85%;
}
.widget_header_info .field_label {
    text-align: right;
    color: white;
    padding-right: 10px;
    font-weight: 500;
    font-size: 14px;
}
.widget_header_info .widget_form_text_input{
    height: 25px;
    label {
        background: #8c8c8c;
        position: relative;
        width: 350px;
        z-index: 1;
        font-size: 0.9rem;
        left: 15px;
        padding: 2px 10px;
        line-height: 1.2rem;
    }
}
.widget_base {
    display: flex;
    border-bottom-left-radius: 15px;
    border: 1px solid #99d2c3;
    border-top: 0;
    background: #8c8c8c;
    position: relative;
    .all_options{
        
    }
}
.generic_options {
    width: 25%;
    border-bottom-left-radius: 15px;
    overflow: hidden;
    padding: 5px;
}
input[type=checkbox], input[type=radio] {
    box-sizing: border-box;
    padding: 0;
}
.generic_options .input_group label {
    margin-bottom: 0;
    padding-left: 5px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
}
.all_options {
    width: 75%;
    padding: 5px;
    position: relative;
    .colorBox{
        background: #fff;
        position: relative;
        top: 21px;
        height: 67px;
    }
}
.widget_view_mode_icon {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-bottom: 15px solid #05155f;
    border-left: 15px solid transparent;
    cursor: pointer;
}
.widgetLabel{
    width: 80px;
    background: #eb4913;
    margin-left: 1rem;
    clip-path: polygon(100% 0, 100% 100%, 49% 91%, 0 100%, 0 0);
    position: relative;
    .labelNo{
        position: absolute;
    top: 1rem;
    font-size: 1.3rem;
    right: 1rem;
    font-weight: 700;
    }
    .labelName{
        position: absolute;
        transform: rotate(-90deg);
        bottom: 2.8rem;
        left: -1rem;
        width: 78px;
        line-height: 1.2rem;
    }
}
.noRecordsDiv{
    margin-top: 65px;
    text-align: center;
    width:60%;
}
.background {
    background: #2479f2;
  }
  .background_warn {
    background: #f1420d;
  }
  .marLeft60{
    margin-left: 60px;
  }
  .background {
    background: #2479f2;
  }
  .background_warn {
    background: #f1420d;
  }
  .nara_bg {
    background: #e74ee6;
  }
  .calc_bg {
    background: #ef8f31;
  }
  .branch_bg{
      background: #f7f9fb;
  }
  .pointerEventBookmark{
    width: 566px;
  }
  .pointerEvent {
    pointer-events: none;
  }
  .generic_options .input_group label{
    pointer-events: none;
  }
  .whiteSpace{
    background: #f7f8c9 !important;
  }
  .pointerEvent>div>div{
    position:relative;
  }
  .dark_bg, .dark_bg .generic_options, .dark_bg .all_options{
    background: #ebebea !important;
  }
  .widget_form_text_input input{
    font-size: 14px;
  }
  .greaterThanSymbol{
    position: absolute;
    right: 2px;
    height: 16px;
    bottom: 10px;
  }
// widget end
.listHeading{
    display: flex;
    height: 20px;
    text-align: center;
    .fieldSection{
        width: 305px;
    }
    .typeSection{
        width: 140px;
    }
    .moduleSection{
        width: 180px;
    }
}

.afterListContainer{
    height:18vh;
}
`;