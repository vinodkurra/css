import React, { Component } from 'react';
import styled, { ThemeProvider } from 'styled-components'
import * as mytheme from '../../../exportables/Colors'
import { useSelector } from 'react-redux';

export default class FooterMenu extends Component {
    render() {
        return (
            <ThemeProvider theme={mytheme}>
                <div className="footer">
                    <div className="container-fluid">
                        <div className="row">
                            <FooterBottom>
                                <ul>
                                    <li><a href="#">Help</a></li>
                                    <li><a href="#">System Setting</a></li>
                                    <li><a href="#">Terms of Service</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Send Feedback</a></li>
                                    <li><a href="#">Report a Problem</a></li>
                                </ul>
                            </FooterBottom>
                        </div>
                    </div>
                </div>
            </ThemeProvider>
        )
    }
}

const FooterBottom = styled.div`
  ul {
    li {
      display: inline-block;
      padding: 10px;
      font-weight: 500;
      a {
        color: ${props=>props.theme.FooterMenuColors.FooterBottom.li_a_color} !important;
      }
      ::before {
        float: left;
        border-bottom: 3px solid transparent;
        border-right: 3px solid red;
      }
    }
  }
`;