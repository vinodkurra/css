import React, { useState, useEffect } from "react";
import styled, { ThemeProvider } from "styled-components";
import { NavLink } from "react-router-dom";
import { GrHelp } from "react-icons/gr";
import { MdMenu, MdClose } from "react-icons/md";
import jwtDecode from "jwt-decode";
import { useSelector } from "react-redux";

import private_img from "../../../assets/user-profile.jpg";
import { apiUrlWithToken } from "../../../calls/apis";
import { device } from "../../../exportables/exportables";
import { letter } from "../helper/profileLetter";
// import HubLogo from "./HubLogo";
import HubLogo from "./HubLogo";
import ButtonLink from "./TopLineContents/ButtonLink";
import Modal from "./Modal";
import HeaderMenu from "./TopLineContents/HeaderMenu";
import CreateContent from "./TopLineContents/CreateContent";
import NotificationTab from "./TopLineContents/NotificationTab";
import SearchBar from "./TopLineContents/SearchBar";
import ProfileMenu from "./TopLineContents/ProfileMenu";
import * as mytheme from "../../../exportables/Colors";
import UpdateModal from './TopLineContents/AppointmentPopup'

function TopMenu({ theme, history, setIsLoading, authObj }) {
  const styles = useSelector((state) => state.ui.styles);
  const [brandLinkWidth, setBrandLinkWidth] = useState(160);
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);
  const [toggled, setToggled] = useState(false);
  const [width, setWidth] = useState(window.innerWidth);
  const [persona, setPersona] = useState(null);
  const [orgId, setOrgId] = useState("");
  const [groups, setGroups] = useState([]);
  const [type, setType] = useState(
    localStorage.getItem("groupName") || "private"
  );
  const [loading, setloading] = useState(false);
  const { isLoading } = useSelector((state) => state.content);
  const [logo, setLogo] = useState("");
  const [key, setKey] = useState(1)

  let accessDecode = jwtDecode(localStorage.getItem("accesstoken"));

  const handleLogout = () => {
    setIsLoading(true);
    apiUrlWithToken.post("/auth/logout").then((res) => {
      authObj.authenticate(false);
      localStorage.removeItem("email");
      localStorage.removeItem("token");
      localStorage.removeItem("isAuthenticated");
      localStorage.removeItem("groupId");
      localStorage.removeItem("groupName");
      localStorage.removeItem("orgId");
      history.push("/");
    });
    // .catch((err) => {
    //   if (err.response) {
    // 		console.log(err.response);
    //
    //   } else if (err.request) {
    // 		console.log(err.request);
    //
    //   } else {
    // 		console.log(err)
    //
    //   }
    // });
  };

  const handleSideMenu = () => {
    setToggled(!toggled);
  };

  const getValueIfExists = (value) => {
    return value ? value : "";
  };

  useEffect(() => {
    window.addEventListener(
      "message",
      function (event) {
        if (event.data !== "closePopups") {
          var { name } = event.data;
          setPersona({ ...persona, name });
        } else {
          setKey(Math.random())
        }
      },
      false
    );

    window.localStorage.removeItem("group");

    window.addEventListener("message", function (event) {
      getData(accessDecode);
    });
    getData(accessDecode);
  }, []);



  function getData(accessDecode) {
    setGroups([]);
    setloading(true);
    apiUrlWithToken
      .get(`/auth/find/${accessDecode.userReference}`)
      .then(({ data }) => {
        const profile = data.account[0];

        const { email } = profile;
        const { title, firstname, lastname } = profile;
        let name = `${getValueIfExists(title)} ${getValueIfExists(
          firstname
        )} ${getValueIfExists(lastname)}`;

        setPersona({ name, email });
        setLogo(data.account[0].profilepic);

        apiUrlWithToken
          .get(`/groupuser/workgrouplist/${accessDecode.userReference}`)
          .then((res) => {
            setGroups(res.data.groups);
            setloading(false);
          });
      });
  }

  /*
      corrections on style-api
      main_menu.highlight_colour = #4395A6;
   */
  const setGroup = (e) => {
    setIsDropdownVisible(false);
    localStorage.setItem("groupId", e.workgroup_id);
    localStorage.setItem("groupName", e.workgroup_name);
    localStorage.setItem("orgId", e.organisation_id);
    setType(e.workgroup_name);
    let group = {
      groupId: e.workgroup_id,
      groupName: e.workgroup_name,
      orgId: e.organisation_id,
    };
    const childFrameObj = document.getElementById("iframeContent");
    if (childFrameObj) {
      childFrameObj.contentWindow.postMessage(JSON.stringify(group), "*");
    }
  };

  const setPrivate = (e) => {
    setIsDropdownVisible(false);
    setType("Private");

    let group = {
      groupId: "",
      groupName: "",
      orgId: "",
    };
    const childFrameObj = document.getElementById("iframeContent");
    childFrameObj.contentWindow.postMessage(JSON.stringify(group), "*");
    localStorage.removeItem("groupId");
    localStorage.removeItem("groupName");
    localStorage.removeItem("orgId");
  };

  return (
    <ThemeProvider theme={mytheme}>
      <GlobalStyle>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12 topMenu">
              <div className="leftmenu">
                <HeaderLogopart>
                  <ul>
                    <li>
                      <HubLogo />
                    </li>
                    <li
                      className="btn btn-info btn-lg"
                      data-toggle="modal"
                      data-target="#myModalcollage"
                    >
                      <ButtonLink />
                    </li>
                  </ul>
                </HeaderLogopart>
                <Modal />
              </div>
              <div className="centermenu">
                <HeaderMenupart>
                  <HeaderMenu />
                </HeaderMenupart>
              </div>
              <div className="right_menu">
                <HeeaderProfile theme={styles.landing_page}>
                  <ul key={key}>
                    <CreateContent />
                    <SearchBar />
                    <NotificationTab />
                    <ProfileMenu authObj={authObj} />
                  </ul>
                </HeeaderProfile>
              </div>
            </div>
          </div>
        </div>
        <UpdateModal />
      </GlobalStyle>

    </ThemeProvider>
  );
}

export default TopMenu;

const GlobalStyle = styled.section`
  background-color: #fff;
  position: sticky;
  width: 100%;
  top: 0;
  z-index: 99;
  .updatemodaltimer{
    position:absolute;
  }
  .topMenu {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
  }
  .centermenu {
    flex: 2 1 0%;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    text-align: center;
  }
  .rightmenu,
  topMenu {
    flex: 1 1 0%;
  }
`;

const HeaderLogopart = styled.div`
  ul {
    list-style: none;
    margin: 0;
    li {
      display: inline-block;
      padding: 2px 20px;
      font-size: 14px;
      img {
        width: 50px;
        height: 50px;
        border-radius: 25px;
      }
      :nth-child(2) {
        color: ${(props) =>
    props.theme.TopMenuColors.HeaderLogopart.nthChild_2_color} !important;
        border: 2px solid
          ${(props) =>
    props.theme.TopMenuColors.HeaderLogopart.nthChild_2_borderColor};
        padding: 10px 20px;
        border-radius: 30px;
        background-color: transparent !important;
        font-weight: 600 !important;
      }
      :nth-child(2):hover {
        cursor: pointer;
      }
      i {
        margin-right: 5px;
      }
    }
  }
`;

const HeaderMenupart = styled.div`
  ul {
    list-style: none;
    margin: 0;
    li {
      display: inline-block;
      padding: 10px 20px;
      a {
        text-transform: capitalize;

        p {
          margin: 0;
          color: ${(props) => props.theme.TopMenuColors.HeaderMenupart.p_color};
          font-size: ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart.topmenu_nav_text_fontsize};
          font-weight: ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart
      .topmenu_nav_text_fontWeight};
          i {
            text-align: center;
            display: block;
            margin: 0 auto;
            color: ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart.i_color};
            font-size: 25px;
            margin-bottom: 5px;
          }
        }
      }
      .active p {
        color: ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart.active_p_color};
      }
      .active p i {
        color: ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart.active_p_i_color};
        border-top: 5px solid
          ${(props) =>
    props.theme.TopMenuColors.HeaderMenupart.active_p_i_borderTopcolor};
        width: 30px;
        border-radius: 5px;
      }
    }
  }
`;

const HeeaderProfile = styled.div`
  ul {
    list-style: none;
    margin: 0;
    li {
      display: inline-block;
      padding: 10px 8px;
      :nth-child(1) a {
        color: ${(props) =>
    props.theme.tl_createbtn_font_color};
        border-radius: 30px;
        background-color: ${(props) =>
    props.theme.tl_createpopup_header_font_color};
        border-color: ${(props) =>
    props.theme.tl_createpopup_header_font_color};
        font-size: 16px;
        font-weight: 600;
        padding: 10px 25px;

        :active {
          color: ${(props) =>
    props.theme.tl_createbtn_font_color} !important;
          background-color: ${(props) =>
    props.theme.tl_createpopup_header_font_color} !important;
          border-color: ${(props) =>
    props.theme.tl_createpopup_header_font_color};
        }
        :hover {
          border-color: ${(props) =>
    props.theme.tl_createpopup_header_font_color} !important;
        }
      }
      :nth-child(2) {
        padding: 10px;
      }
      :nth-child(3) {
        padding: 10px;
        a {
          background-color: transparent;
          border: none;
        }
      }
      img {
        height: 50px;
        width: 50px;
        border-radius: 25px;
      }
      a {
        i {
          background-color: ${(props) =>
    props.theme.tl_search_bg_color};
          color: ${(props) =>
    props.theme.tl_search_font_color};
          padding: 10px;
          border-radius: 20px;
        }
      }
    }
    .open > .dropdown-toggle.btn-primary {
      background-color: #0e8a8b !important;
    }
  }
`;
