import React, { Component, useEffect, useState, useRef } from "react";
import styled, { ThemeProvider } from "styled-components";
import { } from "react-redux";
import * as mytheme from "../../exportables/Colors";

import moment from "moment";
import {
  selectedAppointments,
  saveAppointments,
  manageslicerScheduler,
  setSelectedPatient,
  viewUserSearch,
  setSelectedUser,
  editTimerAppointment,
  getAppointments,
  viewProcessPopup
} from "../../store/LandingPage/index";
import axios from "axios";
import PatientSearch from "../../features/dashboard/components/TopLineContents/PatientSearch";
import UserSearchPopup from "../../features/dashboard/components/TopLineContents/UserSearchPopup";
import Popup from "../../features/dashboard/components/TopLineContents/PopupComponent";
import { useSelector, useDispatch } from "react-redux";
import {
  apiSearchUrlWithToken,
  appointmentUrlWithToken,
} from "../../calls/apis";
import { result } from "lodash";
import Firechat from './Firechat'

function Message() {
  // var userDetails = JSON.parse(localStorage.getItem("account"));
  const styles = useSelector((state) => state.ui.styles);
  const [datetime, setDateTime] = useState("");
  const [dayandmonth, setDayMonth] = useState("");
  const [startandendtime, setStartEnd] = useState("");
  //const [process, setProcess] = useState("");
  const [location, setLocation] = useState("");
  const [comments, setComment] = useState("");
  const [duration, setDuration] = useState("");
  const [showPatiensearch, setshowPatiensearch] = useState(false);
  const [offsettime, setOffset] = useState("");
  const [offsettimeError, showOffsetError] = useState(false);
  const [offsettimeErrorText, setOffsetErrorText] = useState('');
  const [nameError, showUsernameError] = useState(false);
  const [durationError, showDurationError] = useState(false);
  const [durationErrorText, setDurationErrorText] = useState("");
  const name = useSelector((state) => state.landingpage.selectedUser.name)
  const [addAndupdateDiffer, setaddAndupdateDiffer] = useState(1);
  const [scheduleid, setSelectedschedulerID] = useState("");
  const [discardEnable, setDiscardEnable] = useState(false);
  const editTimerData = useSelector((state) => state.landingpage.editTimerData)
  const viewModeOfProcess = useSelector((state) => state.landingpage.viewProcessPopup);
  const process = useSelector((state) => state.landingpage.selectedProcess)
  const [savebtnDisable, setSavebtnDisable] = useState(false)

  const dispatch = useDispatch();
  const selUser = useSelector((state) => {
    if (state.landingpage.selectedUser.name == "") {
      dispatch(setSelectedUser({ userId: state.landingpage.selectedUser.userId, name: localStorage.getItem('email').split('@')[0] + '@' }));
    }
    return state.landingpage.selectedUser
  });


  const scheduleSlicer = useSelector(
    (state) => state.landingpage.schedulerSlicer
  );
  let cur_dd = new Date().getDate();
  let cur_mm = new Date().getMonth() + 1;
  if ((cur_mm + "").length === 1) cur_mm = "0" + cur_mm;
  if ((cur_dd + "").length === 1) cur_dd = "0" + cur_dd;
  let cur_yy = new Date().getFullYear();
  let cur_date = `${cur_yy}-${cur_mm}-${cur_dd}`;

  const appointmentData = useSelector(
    (state) => {
      let a = state.landingpage.appointments;
      return a;

    }
  );
  const selectedData = useSelector(
    (state) => state.landingpage.selectedAppointment
  );
  const selPatient = useSelector((state) => state.landingpage.selectedPatient);

  const path = window.location.href.split("/")[4];
  useEffect(() => {
    if (editTimerData) {
      setaddAndupdateDiffer(2);
      var recreate_date =
        selectedData.scheduler_date.split(
          "-"
        )[2] +
        "-" +
        selectedData.scheduler_date.split(
          "-"
        )[1] +
        "-" +
        selectedData.scheduler_date.split(
          "-"
        )[0] +
        "T" +
        selectedData.scheduler_time;
      document.getElementById(
        "myDate"
      ).defaultValue = recreate_date;

      let alt_d =
        moment(recreate_date).format("dddd") +
        ", " +
        moment(recreate_date).date() +
        " " +
        moment(recreate_date).format("MMM") +
        " " +
        moment(recreate_date).format("hh:mm");

      setDateTime(alt_d);
      //  setProcess(selectedData.process);
      setLocation(selectedData.location)
      setDuration(
        selectedData.scheduler_duration
      );
      setComment(
        selectedData.scheduler_comment
      );
      setOffset(recreate_date);
      setSelectedschedulerID(
        selectedData.scheduler_id
      );
      dispatch(
        setSelectedPatient({
          id: selectedData.patient_id,
          name: selectedData.patient_name,
        })
      );
    }
  }, [selectedData])


  const addAppointment = async (e) => {
    e.preventDefault();
    let dd = new Date(offsettime).getDate();
    let mm = new Date(offsettime).getMonth() + 1;
    if ((mm + "").length === 1) mm = "0" + mm;
    if ((dd + "").length === 1) dd = "0" + dd;
    let yy = new Date(offsettime).getFullYear();
    let selected_date = `${yy}-${mm}-${dd}`;

    if (moment(selected_date).isBefore(cur_date, 'day') == true) {
      setOffsetErrorText('* past dates are not allowed')
      showOffsetError(true)

    }
    else {
      if (offsettime == "") {
        setOffsetErrorText('* please choose Date/Time')
        showOffsetError(true)
        setSavebtnDisable(false)
      }
      if (name == "" || name == undefined) {
        showUsernameError(true)
        setSavebtnDisable(false)
      }
      if (duration == "") {
        setDurationErrorText("* please mention duration time")
        showDurationError(true)
        setSavebtnDisable(false)
      }
      if (offsettime != "" && duration != "") {

        let obj = {
          location: location,
          offsetDateTime: offsettime + ":00+05:30",
          patient_id: selPatient ? selPatient.id == "" ? 0 : selPatient.id : 0,
          patient_name: selPatient ? selPatient.name == "" ? "" : selPatient.name : "",
          process: process ? process.title : '',
          scheduler_comment: comments,
          scheduler_date: (
            moment(new Date(offsettime)).date() +
            "-" +
            (moment(new Date(offsettime)).month() + 1) +
            "-" +
            moment(new Date(offsettime)).year()
          ).toString(),
          scheduler_duration: duration,
          scheduler_id: scheduleid,
          scheduler_time:
            offsettime.split("T")[1].split(":")[0] +
            ":" +
            offsettime.split("T")[1].split(":")[1],
          user_name: name,
          userchecksum_id: selUser.userId,
          workgroup_id: "null",
          processId: process ? process.id : null
        };

        await appointmentUrlWithToken.post(`/scheduler`, obj).then(async (res) => {
          if (res.status === 200) {
            window.$('.modal').modal('hide');
            alert("Appointment added successfully");
            obj['scheduler_id'] = res.data.scheduler_id;
            let ex_appointmnet_data = appointmentData;
            let d = new Date(offsettime).getDate();
            let m = new Date(offsettime).getMonth() + 1;
            if ((m + "").length === 1) m = "0" + m;
            if ((d + "").length === 1) d = "0" + d;
            let y = new Date(offsettime).getFullYear();
            let date = `${d}-${m}-${y}`;
            obj['scheduler_date'] = date;
            ex_appointmnet_data.push(obj);
            dispatch(saveAppointments(ex_appointmnet_data));
            dispatch(getAppointments(ex_appointmnet_data));
            dispatch(setSelectedPatient({ id: "", name: "" }));
            if (editTimerData === true) {
              dispatch(editTimerAppointment())
            }
            setSavebtnDisable(false)
          }
        })
          .catch((err) => {
            alert(err.response.data.message)
            setSavebtnDisable(false)
          });

        discard();
      }
    }
  };

  const updateAppointment = async (e) => {
    e.preventDefault();
    let dd = new Date(offsettime).getDate();
    let mm = new Date(offsettime).getMonth() + 1;
    if ((mm + "").length === 1) mm = "0" + mm;
    if ((dd + "").length === 1) dd = "0" + dd;
    let yy = new Date(offsettime).getFullYear();
    let selected_date = `${yy}-${mm}-${dd}`;

    if (moment(selected_date).isBefore(cur_date, 'day') == true) {
      setOffsetErrorText('* past dates are not allowed')
      showOffsetError(true)
      setSavebtnDisable(false)
    }
    else {
      if (offsettime == "") {
        setOffsetErrorText('* please choose Date/Time')
        showOffsetError(true)
        setSavebtnDisable(false)
      }
      if (duration == "") {
        setDurationErrorText("* please mention duration time")
        showDurationError(true)
        setSavebtnDisable(false)
      }
      if (offsettime != "" && duration != "") {

        let obj = {
          location: location,
          offsetDateTime: offsettime + ":00+05:30",
          patient_id: selPatient !== '{}' ? selPatient.id == "" ? 0 : selPatient.id : 0,
          patient_name: selPatient !== '{}' ? selPatient.name == "" ? "" : selPatient.name : "",
          process: process ? process.title : '',
          scheduler_comment: comments,
          scheduler_date: (
            moment(new Date(offsettime)).date() +
            "-" +
            (moment(new Date(offsettime)).month() + 1) +
            "-" +
            moment(new Date(offsettime)).year()
          ).toString(),
          scheduler_duration: duration,
          scheduler_id: scheduleid,
          scheduler_time:
            offsettime.split("T")[1].split(":")[0] +
            ":" +
            offsettime.split("T")[1].split(":")[1],
          user_name: name,
          userchecksum_id: selUser.userId,
          workgroup_id: "null",
          processId: process ? process.id : null
        };
        let currentUser = {
          userId: JSON.parse(localStorage.getItem("account")).userid,
          name: JSON.parse(localStorage.getItem("account")).firstname,
        };
        await appointmentUrlWithToken
          .put(`/scheduler/${obj.scheduler_id}`, obj)
          .then(async (res) => {
            if (res.status === 200) {
              window.$('.modal').modal('hide');
              alert("Appointment updated successfully");
              obj['scheduler_id'] = res.data.scheduler_id;
              let ex_appointmnet_data = appointmentData;
              let d = new Date(offsettime).getDate();
              let m = new Date(offsettime).getMonth() + 1;
              if ((m + "").length === 1) m = "0" + m;
              if ((d + "").length === 1) d = "0" + d;
              let y = new Date(offsettime).getFullYear();
              let date = `${d}-${m}-${y}`;
              obj['scheduler_date'] = date;
              var foundIndex = ex_appointmnet_data.findIndex(x => x.scheduler_id == obj.scheduler_id);
              ex_appointmnet_data[foundIndex] = obj;
              dispatch(saveAppointments(ex_appointmnet_data));
              dispatch(getAppointments(ex_appointmnet_data));
              dispatch(setSelectedPatient({ id: "", name: "" }));
              setSavebtnDisable(false)
              if (editTimerData === true) {
                dispatch(editTimerAppointment())
              }
            } else {

            }
          })
          .catch((err) => {
            alert(err.response.data.message)
            setSavebtnDisable(false)
          });
        dispatch(setSelectedUser(currentUser));
        setaddAndupdateDiffer(1);

        // .catch((err) => {
        //   console.log(err)
        // });
        discard();
      }
    }
  };

  const removeAppointment = async (scheduler_id) => {
    const options = {
      headers: {
        Authorization: "Bearer" + " " + localStorage.getItem("token"),
      },
    };
    await appointmentUrlWithToken
      .delete(`/scheduler/${scheduler_id}`)
      .then(async (res) => {
        if (res.status === 200) {
          alert("Appointment deleted successfully. ");
          let alt_data = appointmentData.filter(el => el.scheduler_id != scheduler_id);
          dispatch(getAppointments(alt_data));
          dispatch(saveAppointments(alt_data));
          if (editTimerData === true) {
            dispatch(editTimerAppointment())
          }
        }
      })
      .catch((err) => {
        alert(err.response.data.message)
        setSavebtnDisable(false)
      });
    discard();
  };
  const discard = () => {
    document.getElementById(
      "myDate"
    ).defaultValue = "";
    dispatch(setSelectedUser({ userId: "", name: "" }));
    setDateTime("")
    setComment("");
    setLocation("");
    // setProcess("");
    setOffset("");
    setDuration("");
    setDiscardEnable(false);
    showDurationError(false);
    showOffsetError(false);
    showUsernameError(false);
    localStorage.removeItem("local_patientsearch");
  };
  let discardBtnColour = discardEnable ? "#738c87" : "#e5e5e5";
  let discordTextColour = discardEnable ? "#fff" : "#738c87";
  return (
    <ThemeProvider theme={mytheme}>
      <div>
        <GlobalStyle
          discardBtnColour={discardBtnColour}
          discordTextColour={discordTextColour}
        >
          <div className="container">
            <div className="row">
              <Schedule>
                <div>
                  <h3>Your Schedule</h3>
                </div>
                <div>
                  <ul>
                    <li>
                      <i class="fa fa-search" aria-hidden="true"></i>
                    </li>
                    <li>
                      <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                    </li>
                  </ul>
                </div>
              </Schedule>
              <DaySchedule>
                <div style={{ float: "left" }}>
                  <h3>Day, MM Month YYYY</h3>
                </div>
                <div style={{ float: "right" }}>
                  <ul>
                    {appointmentData && appointmentData.length > 0 ? <li
                      onClick={() =>
                        dispatch(
                          manageslicerScheduler({
                            start: scheduleSlicer.start - scheduleSlicer.length,
                            end: scheduleSlicer.start,
                          })
                        )
                      }
                    >
                      <i class="fa fa-angle-left" aria-hidden="true"></i>
                    </li> : <li><i class="fa fa-angle-left" aria-hidden="true"></i></li>}
                    {appointmentData && appointmentData.length > 0 ? <li
                      onClick={() =>
                        dispatch(
                          manageslicerScheduler({
                            start: scheduleSlicer.start + scheduleSlicer.length,
                            end: scheduleSlicer.end + scheduleSlicer.length,
                          })
                        )
                      }
                    >
                      <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </li> : <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>}
                  </ul>
                </div>
              </DaySchedule>
              {appointmentData && appointmentData.length > 0
                ? appointmentData
                  .slice(scheduleSlicer.start, scheduleSlicer.end)
                  .map((data) => (
                    //moment(data.scheduler_date.split('-')[2] + '-' + data.scheduler_date.split('-')[1] + '-' + data.scheduler_date.split('-')[0]).isBefore(cur_date, 'day') === false ?
                    <MySchedule
                      style={{ cursor: "pointer", fontWeight: "500" }}
                      data-toggle="modal"
                      data-target="#appoinmentdetails"
                      data-backdrop="false"
                      onClick={() => {
                        let selData = appointmentData.filter(
                          (el) => el.scheduler_id == data.scheduler_id
                        );

                        let y =
                          moment(
                            selData[0].scheduler_date.split("-")[2] +
                            "-" +
                            selData[0].scheduler_date.split("-")[1] +
                            "-" +
                            selData[0].scheduler_date.split("-")[0] +
                            "T00:00:00"
                          ).format("dddd") +
                          ", " +
                          selData[0].scheduler_date.split("-")[0] +
                          " " +
                          moment(
                            selData[0].scheduler_date.split("-")[2] +
                            "-" +
                            selData[0].scheduler_date.split("-")[1] +
                            "-" +
                            selData[0].scheduler_date.split("-")[0] +
                            "T00:00:00"
                          ).format("MMMM");

                        let z = moment(
                          selData[0].scheduler_time.split(":")[0] +
                          ":" +
                          selData[0].scheduler_time.split(":")[1],
                          "HH:mm"
                        );
                        z.add(selData[0].scheduler_duration, "m");
                        z.format("HH:mm");
                        setDayMonth(y);
                        setStartEnd(
                          selData[0].scheduler_time + "-" + z.format("HH:mm")
                        );
                        dispatch(selectedAppointments(selData[0]));
                      }}
                    >
                      <div>
                        <p>{data.scheduler_time}</p>
                      </div>
                      <div>
                        <p>
                          {data.patient_name ? data.patient_name : "PRIVATE"}
                        </p>
                      </div>
                      <div>
                        <p>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            aria-hidden="true"
                            focusable="false"
                            width="1.3em"
                            height="1.3em"
                            preserveAspectRatio="xMidYMid meet"
                            viewBox="0 0 1024 1024"
                          >
                            <path
                              d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448s448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372s372 166.6 372 372s-166.6 372-372 372z"
                              fill="#000"
                            />
                            <path
                              d="M464 336a48 48 0 1 0 96 0a48 48 0 1 0-96 0zm72 112h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V456c0-4.4-3.6-8-8-8z"
                              fill="#000"
                            />
                            <rect
                              x="0"
                              y="0"
                              width="1024"
                              height="1024"
                              fill="rgba(0, 0, 0, 0)"
                            />
                          </svg>
                          {/* <i class="fa fa-info" aria-hidden="true"></i> */}
                        </p>
                      </div>
                    </MySchedule>
                    //: null
                  ))
                : null}
            </div>
            <MyScheduuleOne>
              <OpenSchedule>
                <div>
                  <p>Open Scheduler</p>
                </div>
                <div>
                  <p className="icon_allignment">
                    <div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        aria-hidden="true"
                        focusable="false"
                        width="1em"
                        height="1em"
                        preserveAspectRatio="xMidYMid meet"
                        viewBox="0 0 512 512"
                      >
                        <path
                          fill="#000"
                          d="M472 96h-88V40h-32v56H160V40h-32v56H40a24.028 24.028 0 0 0-24 24v336a24.028 24.028 0 0 0 24 24h432a24.028 24.028 0 0 0 24-24V120a24.028 24.028 0 0 0-24-24zm-8 352H48V128h80v40h32v-40h192v40h32v-40h80z"
                        />
                        <path fill="#000" d="M112 224h32v32h-32z" />
                        <path fill="#000" d="M200 224h32v32h-32z" />
                        <path fill="#000" d="M280 224h32v32h-32z" />
                        <path fill="#000" d="M368 224h32v32h-32z" />
                        <path fill="#000" d="M112 296h32v32h-32z" />
                        <path fill="#000" d="M200 296h32v32h-32z" />
                        <path fill="#000" d="M280 296h32v32h-32z" />
                        <path fill="#000" d="M368 296h32v32h-32z" />
                        <path fill="#000" d="M112 368h32v32h-32z" />
                        <path fill="#000" d="M200 368h32v32h-32z" />
                        <path fill="#000" d="M280 368h32v32h-32z" />
                        <path fill="#000" d="M368 368h32v32h-32z" />
                        <rect
                          x="0"
                          y="0"
                          width="512"
                          height="512"
                          fill="rgba(0, 0, 0, 0)"
                        />
                      </svg>
                    </div>
                    {/* <i class="fa fa-calendar-o icon_allignment" aria-hidden="true"></i> */}
                  </p>
                </div>
              </OpenSchedule>
              <OpenSchedule>
                <div
                  onClick={() => {
                    setaddAndupdateDiffer(1);
                    discard();
                    setOffset("");
                    document.getElementById("myDate").defaultValue = "";
                    setDateTime("");
                    if (localStorage.getItem("account")) {
                      let currentUser = {
                        userId: JSON.parse(localStorage.getItem("account"))
                          .userid,
                        name: JSON.parse(localStorage.getItem("account"))
                          .firstname,
                      };
                      dispatch(setSelectedUser(currentUser));
                    }
                  }}
                >
                  <p data-toggle="modal" data-target="#myModalappoinment" >
                    Create New Appointment
                  </p>
                </div>
                <div style={{ cursor: "pointer" }} >
                  <p className="icon_allignment" data-toggle="modal" data-target="#myModalappoinment" >
                    <i class="fa fa-calendar-plus-o" aria-hidden="true"></i>
                  </p>
                </div>
              </OpenSchedule>

              {/* modal start */}
              <AppointmentModal>
                <div
                  class="modal "
                  id="myModalappoinment"
                  role="dialog"
                  data-backdrop="false"
                  style={{ zIndex: 0 }}
                >
                  <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Add New Appoinment</h4>
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                          onClick={() => {
                            discard()
                            if (editTimerData === true) {
                              dispatch(editTimerAppointment())
                            }
                          }
                          }
                        >
                          &times;
                        </button>
                      </div>
                      <div class="modal-body">
                        <p className="datetxt">{datetime}</p>
                        <div className="appoinementmodalform">
                          <form>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  id="myDate"
                                  style={{ cursor: "pointer" }}
                                  type="datetime-local"
                                  value={offsettime}
                                  pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}"
                                  onChange={(e) => {
                                    showOffsetError(false)
                                    let d = e.target.value;

                                    let alt_d =
                                      moment(d).format("dddd") +
                                      ", " +
                                      moment(d).date() +
                                      " " +
                                      moment(d).format("MMM") +
                                      " " +
                                      moment(d).format("LT");

                                    setDateTime(alt_d);
                                    setOffset(d);
                                    setDiscardEnable(true);
                                  }}
                                />

                              </div>
                              {offsettimeError ?
                                <span style={{ color: 'red' }}> {offsettimeErrorText}</span> : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  className="mr-auto p-2"
                                  value={selUser ? selUser.name : null
                                  }
                                  placeholder="Name"
                                // onChange={(e) => setName(e.target.value)}

                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    onClick={() => {
                                      showUsernameError(false)
                                      dispatch(viewUserSearch(true));
                                    }}
                                  ></i>
                                </span>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Name</label> */}
                              </div>
                              {nameError ?
                                <span style={{ color: 'red' }}> * please choose user</span> : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  className="mr-auto p-2"
                                  type="text"
                                  placeholder="Patient"
                                  value={
                                    selPatient !== {}
                                      ? selPatient.name
                                      : null
                                  }
                                // onChange={(e) => setPatient(e.target.value)}

                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    onClick={() => {
                                      // dispatch(viewUserSearch(true));
                                      setshowPatiensearch(true);
                                    }}
                                  ></i>
                                </span>

                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Patient</label> */}
                              </div>
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={process ? process.title : ''}
                                  placeholder="Process"
                                  onChange={(e) => {
                                    // setProcess(e.target.value);
                                    setDiscardEnable(true);
                                  }}

                                />
                                <span
                                  className="p-2"
                                  style={{
                                    // marginRight: "50px",
                                    cursor: "pointer",
                                  }}
                                >
                                  <i
                                    class="fa fa-search"
                                    // data-toggle="modal" data-target="#patientSearch"
                                    onClick={() => {
                                      dispatch(viewProcessPopup())
                                      //dispatch(viewUserSearch(true));
                                    }}
                                  ></i>
                                </span>

                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Process</label> */}
                              </div>
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={duration}
                                  placeholder="Duration"

                                  onChange={(e) => {

                                    if (e.target.value.toString().length === 0) {
                                      setDurationErrorText('* please mention duration time')
                                      showDurationError(true)
                                    }
                                    else {
                                      showDurationError(false)
                                    }

                                    setDuration(e.target.value);
                                    setDiscardEnable(true);


                                  }}

                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                {/* <label>Duration</label> */}
                              </div>
                              {durationError ?
                                <span style={{ color: 'red' }}> {durationErrorText} </span> : null}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={
                                    location
                                  }
                                  placeholder="Location"
                                  onChange={(e) => setLocation(e.target.value)}

                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                              </div>
                              {/* <label>Location</label> */}
                            </div>
                            <div className="group">
                              <div className="d-flex">
                                <input
                                  type="text"
                                  value={comments}
                                  placeholder="Comment"
                                  onChange={(e) => {
                                    setComment(e.target.value);
                                    setDiscardEnable(true);
                                  }}

                                />
                                <span class="highlight"></span>
                                <span class="bar"></span>
                              </div>
                              {/* <label>Comment</label> */}
                            </div>
                            <div className="appoinmentbutton">
                              <ul>
                                <li>
                                  <button style={{ cursor: "pointer" }}
                                    // data-toggle="modal"
                                    // data-target="#myModalappoinment"
                                    type="button"
                                    onClick={() => {

                                      discard()
                                    }}
                                    // className="discradBtn"
                                    className="savedBtn"
                                  // disabled={!discardEnable}
                                  >
                                    Discard
                                  </button>
                                </li>
                                <li>
                                  <button
                                    className="savedBtn"
                                    type="submit"
                                    disabled={savebtnDisable}
                                    //data-toggle="modal"
                                    // data-target="#myModalappoinment"
                                    onClick={(e) => {
                                      setSavebtnDisable(true)
                                      addAndupdateDiffer === 1 && !editTimerData
                                        ? addAppointment(e)
                                        : updateAppointment(e)
                                    }
                                    }
                                  // disabled={
                                  //   offsettime && name && duration
                                  //     ? false
                                  //     : true
                                  // }
                                  >
                                    {addAndupdateDiffer === 1 && !editTimerData
                                      ? "Save"
                                      : "Update"}
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {showPatiensearch ? (
                  <div style={{ zIndex: 1 }}>
                    <PatientSearch
                      //isPopupVisible={showPatiensearch}
                      togglePatient={() => setshowPatiensearch(false)}
                      styles={styles}
                      setPatient={(e) => setDiscardEnable(true)}
                      toggleDelete={(e) => null}
                    />
                  </div>
                ) : null}
              </AppointmentModal>
              {/* modal end */}

              {/* modal start */}

              {selectedData ? (
                <AppoinmentDetailsContnet>
                  <div class="modal" id="appoinmentdetails" role="dialog">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <div className="appoinmentdetailsheader">
                            <div>
                              <h4 class="modal-title">Appointment</h4>
                              <p>{selectedData.user_name}</p>
                            </div>
                            <div>
                              <div>
                                <ul
                                  className="row"
                                  style={{ listStyle: "none" }}
                                >
                                  <li style={{ cursor: "pointer" }}>
                                    <span
                                      style={{
                                        cursor: "pointer",
                                      }}
                                      data-toggle="modal"
                                      data-target="#myModalappoinment"
                                      onClick={() => {
                                        setaddAndupdateDiffer(2);

                                        let selData = appointmentData.filter(
                                          (el) =>
                                            el.scheduler_id ==
                                            selectedData.scheduler_id
                                        );
                                        var recreate_date =
                                          selData[0].scheduler_date.split(
                                            "-"
                                          )[2] +
                                          "-" +
                                          selData[0].scheduler_date.split(
                                            "-"
                                          )[1] +
                                          "-" +
                                          selData[0].scheduler_date.split(
                                            "-"
                                          )[0] +
                                          "T" +
                                          selData[0].scheduler_time;
                                        document.getElementById(
                                          "myDate"
                                        ).defaultValue = recreate_date;

                                        let alt_d =
                                          moment(recreate_date).format("dddd") +
                                          ", " +
                                          moment(recreate_date).date() +
                                          " " +
                                          moment(recreate_date).format("MMM") +
                                          " " +
                                          moment(recreate_date).format("hh:mm");

                                        setDateTime(alt_d);
                                        // setProcess(selData[0].process);
                                        setLocation(selData[0].location)
                                        setDuration(
                                          selData[0].scheduler_duration
                                        );
                                        setComment(
                                          selData[0].scheduler_comment
                                        );
                                        setOffset(recreate_date);
                                        setSelectedschedulerID(
                                          selData[0].scheduler_id
                                        );
                                        dispatch(
                                          selectedAppointments(selData[0])
                                        );
                                        dispatch(setSelectedUser({ userId: selData[0].userchecksum_id, name: selData[0].user_name }))
                                        dispatch(
                                          setSelectedPatient({
                                            id: selData[0].patient_id,
                                            name: selData[0].patient_name,
                                          })
                                        );
                                      }}
                                    >
                                      <i
                                        class="fa fa-pencil"
                                        data-toggle="modal"
                                        data-target="#appoinmentdetails"
                                      ></i>
                                    </span>
                                  </li>
                                  <li
                                    data-toggle="modal"
                                    data-target="#appoinmentdetails"
                                    onClick={() =>
                                      removeAppointment(
                                        selectedData.scheduler_id
                                      )
                                    }
                                    style={{ cursor: "pointer" }}
                                  >
                                    <i
                                      class="fa fa-trash-o"
                                      aria-hidden="true"
                                    ></i>
                                  </li>
                                  <li>
                                    <button
                                      type="button"
                                      class="close"
                                      data-dismiss="modal"
                                    >
                                      &times;
                                    </button>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="modal-body">
                          {/* <p>Day, DD Month . HH:MM - HH:MM</p> */}
                          <ul className="add_appmnt_popup">
                            <li>
                              {/* <i class="fa fa-calendar-o"> </i> */}
                              <div className="apmt_icons">
                                <svg aria-hidden="true" focusable="false" width="1.3em" height="1.3em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2m0 16H5V10h14v10M5 8V6h14v2H5m2 4h10v2H7v-2m0 4h7v2H7v-2z" fill="#738c87" /></svg>
                              </div>
                              {dayandmonth}
                            </li>
                            <li>
                              {/* <i class="fa fa-clock-o"> </i> */}
                              <div className="apmt_icons"><svg aria-hidden="true" focusable="false" width="1.3em" height="1.3em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 36 36"><path d="M31.47 3.84a5.78 5.78 0 0 0-7.37-.63a16.08 16.08 0 0 1 8.2 7.65a5.73 5.73 0 0 0-.83-7.02z" class="clr-i-outline clr-i-outline-path-1" fill="#738c87" /><path d="M11.42 3.43a5.77 5.77 0 0 0-7.64.41a5.72 5.72 0 0 0-.38 7.64a16.08 16.08 0 0 1 8.02-8.05z" class="clr-i-outline clr-i-outline-path-2" fill="#738c87" /><path d="M16.4 4.09a14 14 0 0 0-8.29 23.79l-2.55 2.55A1 1 0 1 0 7 31.84l2.66-2.66a13.9 13.9 0 0 0 16.88-.08l2.74 2.74a1 1 0 0 0 1.41-1.41L28 27.78A14 14 0 0 0 16.4 4.09zm3.18 25.81a12 12 0 1 1 10.34-10.34A12 12 0 0 1 19.58 29.9z" class="clr-i-outline clr-i-outline-path-3" fill="#738c87" /><path d="M24.92 20.34l-6.06-3V9.5a.9.9 0 0 0-1.8 0v9l7.06 3.5a.9.9 0 1 0 .79-1.62z" class="clr-i-outline clr-i-outline-path-4" fill="#738c87" /></svg></div>
                              {startandendtime} (
                              {selectedData.scheduler_duration} Minutes)
                            </li>
                            <li>
                              <div className="apmt_icons">
                                <svg aria-hidden="true" focusable="false" width="1.3em" height="1.3em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M16 18a5 5 0 1 1 5-5a5.006 5.006 0 0 1-5 5zm0-8a3 3 0 1 0 3 3a3.003 3.003 0 0 0-3-3z" fill="#738c87" /><path d="M16 30l-8.436-9.949a35.076 35.076 0 0 1-.348-.451A10.889 10.889 0 0 1 5 13a11 11 0 0 1 22 0a10.884 10.884 0 0 1-2.215 6.597l-.001.003s-.3.394-.345.447zM8.812 18.395c.002 0 .234.308.287.374L16 26.908l6.91-8.15c.044-.055.278-.365.279-.366A8.901 8.901 0 0 0 25 13a9 9 0 1 0-18 0a8.905 8.905 0 0 0 1.813 5.395z" fill="#738c87" /></svg>
                              </div>
                              {/* <i class="fa fa-map-marker"> </i> */}
                              {selectedData.location}
                            </li>
                            <li>
                              <div className="apmt_icons">
                                <svg aria-hidden="true" focusable="false" width="1.3em" height="1.3em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 36 36"><path d="M18 17a7.46 7.46 0 1 0-7.45-7.46A7.46 7.46 0 0 0 18 17zm0-12.93a5.46 5.46 0 1 1-5.45 5.45A5.46 5.46 0 0 1 18 4.07z" class="clr-i-outline clr-i-outline-path-1" fill="#738c87" /><path d="M6 31.89v-6.12a16.13 16.13 0 0 1 12-5a16.61 16.61 0 0 1 8.71 2.33l1.35-1.51A18.53 18.53 0 0 0 18 18.74A17.7 17.7 0 0 0 4.21 24.8a1 1 0 0 0-.21.6v6.49A2.06 2.06 0 0 0 6 34h12.39l-1.9-2z" class="clr-i-outline clr-i-outline-path-2" fill="#738c87" /><path d="M30 31.89V32h-3.15l-1.8 2H30a2.06 2.06 0 0 0 2-2.07V26.2l-2 2.23z" class="clr-i-outline clr-i-outline-path-3" fill="#738c87" /><path d="M34.76 18.62a1 1 0 0 0-1.41.08l-11.62 13l-5.2-5.59a1 1 0 0 0-1.41-.11a1 1 0 0 0-.06 1.42l6.69 7.2L34.84 20a1 1 0 0 0-.08-1.38z" class="clr-i-outline clr-i-outline-path-4" fill="#738c87" /></svg>
                              </div>
                              {/* <i class="fa fa-user"> </i>{" "} */}
                              {selectedData.patient_name ? selectedData.patient_name : "PRIVATE"}
                            </li>
                            <li>
                              <div className="apmt_icons">
                                <svg aria-hidden="true" focusable="false" width="1.3em" height="1.3em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M4 6v20h24V6zm2 2h5v4H6zm7 0h13v4H13zm-7 6h5v4H6zm7 0h13v4H13zm-7 6h5v4H6zm7 0h13v4H13z" fill="#738c87" /></svg>
                              </div>
                              {/* <i class="fa fa-th-list"> </i> */}
                              {selectedData.process}
                            </li>
                            <li>
                              <i class="fa fa-align-left"> </i>
                              {selectedData.scheduler_comment}
                            </li>
                          </ul>
                          <div className="startconsulation">
                            <a href="#">
                              <i class="fa fa-edit" aria-hidden="true"></i>Start
                              Consulation
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </AppoinmentDetailsContnet>
              ) : null}
              {/* modal end */}
            </MyScheduuleOne>
          </div>
        </GlobalStyle>
        <br />

        <MessageChat>
          <Firechat />
        </MessageChat>
      </div>
    </ThemeProvider>
  );
}
export default Message;

const GlobalStyle = styled.section`
  padding: 10px 15px;
  margin-top: 30px;
  font-size: 14px;
  h3 {
    font-size: 16px;
  }

  #myDate {
    text-transform: uppercase;
  }

  .appoinmentdetailsheader li {
    margin-left: 17px;
  }

  #appoinmentdetails .modal-body {
    padding: 0px;
  }

  .discradBtn:focus,
  .savedBtn:focus {
    outline: 0;
  }
  .savedBtn {
    background: #738c87;
    color: #fff;
  }

  .discradBtn {
    border: solid 1px #e5e5e5;
    background: ${(props) => props.discardBtnColour};
    color: ${(props) => props.discordTextColour};
  }
  .discradBtn:focus,
  .savedBtn:focus {
    outline: 0;
  }
  .savedBtn {
    border: solid 1px #e5e5e5;
    background: #738c87;
    color: #fff;
  }
  .add_appmnt_popup {
    color: #738c87;
    padding: 10px;
    li i {
      margin-right: 10px;
    }
  }

  .startconsulation {
    border-top: solid 1px #eeeeee;
  }
  .startconsulation a:hover {
    text-decoration: none;
    cursor: pointer;
  }

  .add_appmnt_popup li {
    line-height: 2.3;
  }
`;

const Schedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      li {
        display: inline-block;
        padding: 0px 10px;
        :nth-child(2) {
          padding: 0px 10px;
        }
      }
    }
  }
`;

const DaySchedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) p {
      font-size: 14px;
    }
    :nth-child(2) ul {
      list-style: none;
      li {
        display: inline-block;
        padding: 5px;
        margin-left: -3px;
        font-size: 21px;
        margin-top: -14px;
        cursor: pointer;
      }
    }
  }
`;

const MySchedule = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) {
      width: 30%;
    }
    :nth-child(2) {
      width: 60%;
    }
    :nth-child(3) {
      width: 10%;
      p {
        background-color: transparent;
        border: none;
        font-size: 15px;
        margin-left: 8px;
        i {
          color: ${(props) =>
    props.theme.DashboardContentFourColors.MySchedule
      .nthChild_3_p_i_color} !important;
          cursor: pointer;
        }
      }
    }
  }
`;

const MyScheduuleOne = styled.div`
  border-top: 1px solid lightgray;
  border-bottom: 1px solid lightgray;
  margin-right: -15px;
  margin-left: -15px;
  border-top-style: dashed;
  border-bottom-style: dashed;
`;

const OpenSchedule = styled.div`
  display: table;
  margin-top: 5px;
  width: 100%;
  .icon_allignment {
    position: absolute;
    right: 38px;
  }
  div {
    display: table-cell;
    :nth-child(1) p {
      cursor: pointer;
    }
    :nth-child(2) p {
      text-align: center;
    }
  }
`;

const AppointmentModal = styled.div`
  .group {
    position: relative;
    margin-bottom: 10px;
  }

  .d-flex {
    border-bottom: 0.5px solid
      ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .input_border_bottom};
  }
  input {
    // font-size: 16px;
    padding: 5px 10px 5px 5px;
    display: block;
    width: 100%;
    border: none;
  }
  input:focus {
    outline: none;
  }
  #myModalappoinment {
    z-index: 1 !important;
    .datetxt {
      text-transform: uppercase;
    }
  }
  #myModalappoinment .appoinementmodalform span {
    color: lightgray;
  }
  #myModalappoinment label {
    color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal.label};
    font-size: 15px;
    font-weight: normal;
    position: absolute;
    pointer-events: none;
    left: 5px;
    top: 10px;
    transition: 0.2s ease all;
    -moz-transition: 0.2s ease all;
    -webkit-transition: 0.2s ease all;
  }
  input:focus ~ label,
  input:valid ~ label {
    top: -10px;
    font-size: 14px;
    color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .webkit_inputHighlighter_from_backgroundcolor};
  }

  .highlight {
    position: absolute;
    height: 60%;
    width: 100px;
    top: 25%;
    left: 0;
    pointer-events: none;
    opacity: 0.5;
  }
  input:focus ~ .highlight {
    -webkit-animation: inputHighlighter 0.3s ease;
    -moz-animation: inputHighlighter 0.3s ease;
    animation: inputHighlighter 0.3s ease;
  }
  @-webkit-keyframes inputHighlighter {
    from {
      background: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .webkit_inputHighlighter_from_backgroundcolor};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @-moz-keyframes inputHighlighter {
    from {
      background: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .moz_inputHighlighter_from_backgroundcolor};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  @keyframes inputHighlighter {
    from {
      background: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .keyframes_inputHighlighter};
    }
    to {
      width: 0;
      background: transparent;
    }
  }
  .modal .modal-dialog {
    float: right;
    left: -100px;
    top: 150px;
    margin: 0;
  }
  .modal-content {
    width: 350px !important;
    border-radius: 10px;
    border: none;
  }
  .modal-header {
    background-color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .modal_header_backgroundcolor};
    border-radius: 10px 10px 0px 0px;
    h4 {
      color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .h4_color} !important;
      font-size: 20px;
    }
    button {
      font-size: 30px;
      color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .button_color} !important;
      opacity: 1;
      font-weight: 400;
      padding: 5px;
    }
  }
  .modal-body p {
    font-weight: 500;
    margin-top: 10px;
    font-size: 16px;
  }
  .appoinmentbutton ul li {
    display: inline-block;
    padding: 20px;
    button {
      padding: 5px 30px;
      border-radius: 20px;
      :nth-child(1) button {
        border: 1.5px solid
          ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .appoinmentbutton_nthChild_1_button_border};
        background-color: transparent;
        color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .appoinmentbutton_nthChild_1_button_color};
      }
      :nth-child(2) button {
        background-color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .appoinmentbutton_nthChild_2_button_backgroundcolor};
        color: ${(props) =>
    props.theme.DashboardContentFourColors.AppointmentModal
      .appoinmentbutton_nthChild_2_button_color};
        border: none;
      }
    }
  }
`;

const AppoinmentDetailsContnet = styled.div`
  .modal-content {
    width: 340px !important;
    border-radius: 10px;
    border: none;
  }
  .modal .modal-dialog {
    float: right;
    left: -90px;
    top: 150px;
    margin: 0;
  }
  .modal-header {
    background-color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .modal_header_backgroundcolor};
    border-radius: 10px 10px 0px 0px;
  }
  .appoinmentdetailsheader {
    display: flex;
    flex-direction: row;
    width: 100%;
    div {
      display: flex;
      flex-direction: column;
      :nth-child(1) {
        flex: 66%;
        h4 {
          color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .appoinmentdetailsheader_nthChild_1_h4_color};
          font-size: 20px;
        }
        p {
          color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .appoinmentdetailsheader_nthChild_1_p_color};
        }
      }
      :nth-child(2) {
        flex: 1 1 auto;
        color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .appoinmentdetailsheader_nthChild_2_button_color} !important;
        button {
          font-size: 30px;
          color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .appoinmentdetailsheader_nthChild_2_button_color} !important;
          opacity: 1;
          font-weight: 400;
          padding: 5px;
        }
      }
      .modal-body {
        padding: 0;
        p {
          font-weight: 500;
          margin-top: 10px;
          font-size: 16px;
          padding: 0px 10px;
        }
        ul {
          list-style: none;
          border-bottom: 1px solid
            ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .modalbody_ul_bordercolor};
          li {
            line-height: 35px;
            font-size: 14px;
            color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .modalbody_li_color};
            padding: 0px 10px;
            margin-left: 30px;
            :nth-child(1)::before {
              content: "\f00c";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(2)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(3)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(5)::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
            :nth-child(6) {
              margin-bottom: 10px;
            }
            ::before {
              content: "\f00b";
              position: absolute;
              font-family: FontAwesome;
              left: 15px;
            }
          }
        }
      }
    }
  }
  .startconsulation a {
    color: ${(props) =>
    props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
      .startconsulation_a_color};
    text-align: right !important;
    display: block;
    padding: 10px 10px 10px 0px;
    font-size: 16px;
    font-weight: 600;
    i {
      margin-right: 10px;
    }
  }
`;

const MessageChat = styled.div`
  background-color: ${(props) =>
    props.theme.DashboardContentFourColors.MessageChat.backgroundcolor};
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  margin-top: -25px;
  position: absolute;
  font-size: 14px;
  right: 24px;
  width: 85%;
  height:400px;
  button {
    width: 100%;
  }
  input {
    border: none;
    box-shadow: none;
  }
  .inbox_txt {
    position: absolute;
    margin-top: 27px;
    margin-left: 75px;
  }
  .user_online {
    width: 10px;
    height: 10px;
    position: absolute;
    background-color: #00c72c;
    border-radius: 30px;
    right: 11px;
    top: 23px;
  }
  .d-flex1 {
    height: 55px;
    background-color: ${(props) =>
    props.theme.DashboardContentFourColors.MessageChat
      .d_flex_backgroundcolor};
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
`;

const MessageIcon = styled.div`
  display: table;
  width: 100%;
  div {
    h6 {
      font-weight: bold;
      font-size: medium;
    }
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      margin-right: 10px;
      li {
        display: inline-block;
        padding: 10px;
      }
    }
  }
`;

const CreateMessage = styled.div`
  margin-top: 20px;
  button {
    background-color: ${(props) =>
    props.theme.DashboardContentFourColors.CreateMessage
      .d_flex_backgroundcolor};
    border: 2px solid
      ${(props) =>
    props.theme.DashboardContentFourColors.CreateMessage
      .button_border_color};
    color: ${(props) =>
    props.theme.DashboardContentFourColors.CreateMessage.button_border_color};
    border-radius: 30px;
    padding: 10px 40px;
    font-weight: 500;
  }
`;
