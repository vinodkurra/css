import React, { useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import { Multiselect } from "multiselect-react-dropdown";
import { apiSearchUrlWithToken, apiContentUrlWithToken } from "../../calls/apis";
import JwtDecode from "jwt-decode";
import { device } from "../../exportables/exportables";
import { setCreatePostSelectedTaggedUsers, setSelectedProcess, viewProcessPopup } from "../../store/LandingPage/index";
import { useSelector, useDispatch } from "react-redux";
import Search from "antd/lib/input/Search";

function Tagusersearch({ styles, togglePatient }) {
    const dispatch = useDispatch();
    const [option, setOptions] = useState([]);
    const [selectedUsers, setSelectedUsers] = useState([]);

    function processSearch(searchKey) {
        apiContentUrlWithToken
            .get(`/process?param=${searchKey}`)
            .then((res) => {
                console.log(res.data)
                setOptions(res.data)
            })
    }
    return (
        <>
            <Styles themes={styles}>
                <div className="popup add_tag_popup" style={{ zIndex: "1", marginTop: "100px" }}>
                    <div className="popup-header">
                        <h3 style={{ color: "#fff" }}>Search For Process</h3>
                        <span
                            className="close"
                            style={{ color: "#fff" }}
                            onClick={() => dispatch(viewProcessPopup())}
                        >
                            X
            </span>
                    </div>
                    <div className="popup-body" style={{ height: "450px" }}>
                        <Multiselect
                            options={option}
                            selectedValues={selectedUsers}

                            onSelect={(e) => {
                                setSelectedUsers(e);
                                alert(e[0].id)
                                dispatch(setSelectedProcess(e[0]))
                                dispatch(viewProcessPopup())
                            }}
                            onRemove={(e) => { }}
                            onSearch={async (e) => {
                                if (e.toString().length === 0) {
                                    console.log("empty");
                                } else {
                                    processSearch(e)
                                }
                            }}
                            displayValue="title"
                            avoidHighlightFirstOption={true}
                            placeholder=""
                            emptyRecordMsg=""
                            
                            style={{
                                chips: {
                                    background: "#e2e2e2",
                                    color: "#4a4a4a",
                                },
                                // searchBox: {
                                //   border: "none",
                                //   "border": "1px solid",
                                //   "border": "0px",
                                // },
                                multiselectContainer: {
                                    color: "black",
                                    marginTop: "12px",
                                },
                                optionContainer: {
                                    border: "none",
                                    border: "0px solid",
                                    border: "0px",
                                },
                            }}
                        />
                        <div className="cncl_sv">
                            {/* <button
                type="button"
                style={{ backgroundColor: "#4395a6", color: "#fff" }}
                className="btn"
                onClick={() => {
                  closePopup();
                }}
              >
                Cancel
              </button>
              <button
                type="button"
                style={{ backgroundColor: "#4395a6", color: "#fff" }}
                className="btn"
                onClick={() => {
                  dispatch(setCreatePostSelectedTaggedUsers(selectedUsers));
                  closePopup();
                }}
              >
                OK
              </button> */}
                        </div>
                    </div>
                </div>
            </Styles>
        </>
    );
}

export default Tagusersearch;

const Styles = styled.div`
  height: calc(100vh - 30px);
  width: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  color: #666;
  right: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
  font-size: calc(0.9vh + 6px);
  background: rgb(0, 0, 0, 0.5);

  label span span {
    font-weight: 400 !important;
  }

  label {
    font-weight: 400 !important;
    font-size: 12px;
  }

  // input{
  //   padding:0px !important;
  // }

  .icons-action {
    padding-bottom: 5px;
  }

  .popup {
    height: 89%;
    overflow-y: auto;
    overflow-x: hidden;
    min-width: 1082px;
    width: 70%;
    .popup-body {
      .main-box {
        .toolbar {
          margin: 0 auto;
          width: 100%;
          .content {
            height: calc(68vh - 35px);
            overflow-y: auto;
          }
        }
      }
    }

    button {
      border: 0;
    }

    .popup-header {
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #0e8a8bed;
      color: black;
      padding: 5px 10px;
      border-radius: 5px 5px 0 0;
     
      h3 {
        margin: 0;
        font-weight: 500;
        padding: 0;
        font-size: calc(80% + 5px);
      }
      .close {
        font-weight: bold;
        cursor: pointer;
        font-size: 12px;
      }
    }
    .popup-body {
      position: relative;
     
      padding: 0px 5px;
      background: white;
      .row {
        flex-direction: row;
        display: flex;
      }

      .sub-content > div {
        margin-bottom: 20px;
      }

      .main-box {
        flex-direction: row;
        display: flex;
        padding: 2px 0 5px 0;
      }
      .space {
        height: 180px;
      }
      .content {
        flex-direction: row;
        display: flex;
        padding: 0 20px;
      }
      .email {
        width: 94%;
        padding: 0px;
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
      }
      .input {
        padding: 0px;
        width: 90%;
        border: none;
      }
      .date-input {
        width: 90%;
      }
      .search-box {
        height: 27px;
        display: flex;
        flex-direction: row;

        border-radius: 5px;
        align-items: center;
        box-shadow: 0px 0px 2px #999;
        svg {
          font-size: 15px !important;
        }
      }
      .search-panel {
        position: absolute;
        background-color: #ffffff;
        padding: 0px 5px;
        width: 100%;
     
        min-height: 100px;
      }
      .count {
        color: rgb(67, 149, 166);
        padding: 1%;
        font-size: 10px;
      }
      .filter {
              font-size: 20px;
        z-index: 99;
      }
      .search {
        width: 90%;
        border-radius: 5px;
        height: 20px;
        border: 0;
        padding: 2%;
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        box-shadow: 0px 0px 0px #999;
      }
      .search:disabled {
        background-color: #ffffff;
      }
      .label-error {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin-top: 5px;
        align-items: center;
        height: 10px;
        padding-right: 10%;
      }
      > div > input,
      > div > select {
        width: 90%;
        border-radius: 5px;
      
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
        box-shadow: 0px 0px 2px #999;
      }
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }
      select {
        border-radius: 5px;
      
        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 0px;
        background-color: #ffffff;
        box-shadow: 0px 0px 2px #999;
      }

      .header {
        font-size: calc(0.9vh + 8px);
        margin: 0;
        font-weight: bolder;
        margin-top: 10px;
      }
      .heading {
        font-size: calc(0.9vh + 8px);
        margin: 0;
        font-weight: bolder;
        color: #4395a6;
        margin-bottom: 20px;
      }
      .address {
        width: 90%;
        border-radius: 5px;
        height: 27px;

        outline: 0px;
        font-size: 10px;
        box-sizing: border-box;
        margin-top: 12px;
        box-shadow: 0px 0px 2px #999;
      }
      .row {
        flex-direction: row;
        display: flex;
      }
      .dropdown-item {
        font-size: 10px;
      }
      .dropdown-item:hover {
        background-color: #ccc;
      }
      .content-box1 {
        border-right: 1px solid #ccc;
        padding: 0 10px;
        margin-right: 5px;
        min-width: 25%;
      }
      .content-box {
        padding: 0 0 5px 5px;
        margin: 0 auto;
        width: 100%;
        .sub-content {
          width: 48%;
          margin-right: 5px;
          .radio {
            width: 12px;
            height: 12px;
            box-shadow: 0px 0px 0px #999;
          }
        }
        .sub-content1 {
          width: 50%;
          .radio {
            margin-left: 2px;
            width: 20px;
            height: 10px;
            box-shadow: 0px 0px 0px #999;
          }
        }
      }
    }
  }

  @media ${device.tablet} {
    right: 2.5%;
    .popup {
      margin-top: 50%;
      max-width: 350px;
      margin-right: 0;
      .popup-body {
        .main-box {
          flex-direction: column;
          display: flex;
          max-width: 350px;
        }
        .content {
          flex-direction: column;
          display: flex;
        }
        .space {
          height: 30px;
        }
        .content-box1 {
          max-width: 350px;
        }
        .content-box {
          min-width: 350px;
          max-width: 350px;
        }
      }
    }
  }

  .genderContainer {
    display: flex;
    justify-content: center;
    align-items: center;
    color: #666;

    input {
      margin-top: -1px;
    }
    .row {
      width: 50%;
      display: flex;
      padding: 5px;
      height: 30px;
      align-items: center;
      label {
        padding-right: 4px;
        font-weight: 400 !important;
      }
    }
  }
`;
