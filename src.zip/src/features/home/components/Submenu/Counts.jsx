import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";

const Count = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const landingpage = useSelector((state) => state.landingpage);
  return (
    <>
      {
        <CountStyle>
          <ul>
            <li>
              {" "}
              <i className="fa fa-envelope-o"></i>
              {landingpage.userMails
                ? landingpage.userMails.totalMailCount
                : "00"}{" "}
              E-mails
            </li>
            <li>
              {" "}
              <i className="fa fa-bell-o"></i>
              {landingpage.notification
                ? landingpage.notification.length
                : "00"}{" "}
              Notifications
            </li>
            <li>
              {" "}
              <i className="fa fa-calendar-check-o"></i>
              {landingpage.appointments
                ? landingpage.appointments.length
                : "00"}{" "}
              Appointments
            </li>
          </ul>
          <hr />
        </CountStyle>
      }
    </>
  );
};

export default Count;

const CountStyle = styled.div`
  ul {
    list-style: none;
    margin: 0;
    li {
      line-height: 35px;
      color: ${(props) => props.theme.submenu_counts_font_color};
      font-size: 16px;
      font-weight: 500;
      i {
        font-weight: 600;
        font-size: 16px;
        margin-right: 15px;
        color: ${(props) => props.theme.submenu_counts_font_color};
      }
    }
  }
`;
