import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";
import  defaultLogo from '../../../../assets/default-avatar-profile.jpg'
const Persona = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <div>
          <img src={defaultLogo} />
          <h2>Name Lastname</h2>
          <h5>Account Name</h5>
        </div>
      }
    </>
  );
};

export default Persona;
