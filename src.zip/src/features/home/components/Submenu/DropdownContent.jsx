import React, { useState } from "react";
import { useSelector, useDispatch, batch } from "react-redux";
import styled, { createGlobalStyle } from "styled-components";

const DropdownContent = ({ history }) => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);

  return (
    <>
      {
        <DropdownContentStyle theme={styles.landing_page}>
          <RecentModal>
            <h4 class="dropdown">
              <a
                class="btn btn-primary dropdown-toggle"
                type="button"
                data-toggle="dropdown"
              >
                Recently Editited Contents <span class="caret"></span>
              </a>
              <ReacentLabel className="dropdown-menu">
                <p>
                  <a href="#">
                    <RecentLabelContent>
                      <div style={{padding:"0px"}}>
                        <img
                          src={require("../../../../assets/circleimage.png")}
                          className="img-responsive"
                        />
                      </div>
                      <div style={{padding:"0px"}}>
                        <p>Recent Folder Label One</p>
                      </div>
                    </RecentLabelContent>
                  </a>
                </p>
                <p>
                  <a href="#">
                    <RecentLabelContent>
                      <div style={{padding:"0px"}}>
                        <img
                          src={require("../../../../assets/circleimage.png")}
                          className="img-responsive"
                        />
                      </div>
                      <div style={{padding:"0px"}}>
                        <p>Recent Folder Label One</p>
                      </div>
                    </RecentLabelContent>
                  </a>
                </p>
                <p>
                  <a href="#">
                    <RecentLabelContent>
                      <div style={{padding:"0px"}}>
                        <img
                          src={require("../../../../assets/circleimage.png")}
                          className="img-responsive"
                        />
                      </div>
                      <div style={{padding:"0px"}}>
                        <p>Recent Folder Label One</p>
                      </div>
                    </RecentLabelContent>
                  </a>
                </p>
                <p>
                  <a href="#">
                    <RecentLabelContent>
                      <div style={{padding:"0px"}}>
                        <img
                          src={require("../../../../assets/circleimage.png")}
                          className="img-responsive"
                        />
                      </div>
                      <div style={{padding:"0px"}}>
                        <p>Recent Folder Label One</p>
                      </div>
                    </RecentLabelContent>
                  </a>
                </p>
                <p>
                  <a href="#">
                    <RecentLabelContent>
                      <div style={{padding:"0px"}}>
                        <img
                          src={require("../../../../assets/circleimage.png")}
                          className="img-responsive"
                        />
                      </div>
                      <div style={{padding:"0px"}}>
                        <p>Recent Folder Label One</p>
                      </div>
                    </RecentLabelContent>
                  </a>
                </p>
              </ReacentLabel>
            </h4>
          </RecentModal>
        </DropdownContentStyle>
      }
    </>
  );
};

export default DropdownContent;

const DropdownContentStyle = styled.ul`
  
    list-style: none;
    margin: 0;
    li {
      line-height: 35px;
      color: ${(props) =>
        props.theme.submenu_recentcontent_drp_font_color};
      font-size: 16px;
      font-weight: 500;
      i {
        font-weight: 600;
        font-size: 16px;
        margin-right: 15px;
        color: ${(props) =>
          props.theme.submenu_recentcontent_drp_font_color};
      }
    }
  
`;

const RecentModal = styled.div`
  h4 {
    a {
      background-color: transparent !important;
      font-size: 18px;
      border: none;
      font-weight: 500;
      padding: 0px;
      color: ${(props) =>
        props.theme.submenu_recentcontent_drp_font_color};
    }
  }
  .open > .dropdown-toggle.btn-primary {
    color: ${(props) =>
      props.theme.submenu_recentcontent_drp_font_color};
  }
`;

const ReacentLabel = styled.div`
  background-color: transparent;
  box-shadow: none;
  border: none;
  margin: 0px;
  padding: 0px !important;
  p {
    margin: 0;
  }
`;

const RecentLabelContent = styled.div`
  display: table;
  width: 100%;
  margin-top: 10px;
  padding:0px !important;
  margin-bottom: 5px;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 10%;
      img {
        height: 25px;
        width: 25px;
        border-radius: 25px;
        margin-right: 10px;
        margin: 0;
      }
    }
    :nth-child(2) {
      width: 90%;
      p {
        margin: 0;
        margin-left: 10px;
        font-size: 16px;
      }
    }
  }
`;
