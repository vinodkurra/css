import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import FooterMenu from "../dashboard/components/FooterMenu";
import DashboardContentTwo from "./seconddashboard";
import Thirddashboard from "./thirddashboard";
import Message from "./message";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";
import moment from 'moment'
import Persona from "../home/components/Submenu/Persona";
import DropdownContent from "../home/components/Submenu/DropdownContent";
import Counts from "../home/components/Submenu/Counts";
import { viewLatestpostFullscreen, getUserMails, viewNewsExpander, getAllNotifications, getAppointments, getAllNews, getUserLatestPosts, addNewPost, setSelectedPost, addReminderAppointment, viewUserSearch, setSelectedUser, switchConsulationProcessView, viewSpecificPost } from "../../store/LandingPage/index";
import { MakePost, GridButton } from "./seconddashboard";
import { scheduler } from "../../json/sitedata";
import MailExpander from './mailExpander';
import MailBoxExpand from './mailBoxExpander';
import Scheduler from './scheduler'
import PatientSearch from '../dashboard/components/TopLineContents/PatientSearch'
import PopupComponent from '../dashboard/components/TopLineContents/PopupComponent'
import UserSearchPopup from '../dashboard/components/TopLineContents/UserSearchPopup';
import LatestPostFullView from './latestPostFullView';
import ConsultationProcess from '../../consultation-process/index';
import NewsBoxExpander from '../home/newsExpander';
import NewsSpecificView from '../home/newsFullView';
import ProcessSearchPopup from '../home/processSearchPopup';

import { postandnewsServiceUrlWithToken, mailServiceUrlWithToken, apiSearchUrlWithToken, notificationUrl } from "../../calls/apis";
import JwtDecode from "jwt-decode";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import {
  FacebookShareButton,
  FacebookIcon,
  EmailShareButton,
  EmailIcon,
  InstapaperShareButton,
  InstapaperIcon,
  LinkedinShareButton,
  LinkedinIcon,
  TwitterIcon,
  TwitterShareButton,
  TelegramIcon,
  TelegramShareButton,
  WhatsappIcon,
  WhatsappShareButton,
} from "react-share";
import { CopyToClipboard } from "react-copy-to-clipboard";

export default function Home() {


  const dispatch = useDispatch();
  const [name, setName] = useState("");
  const styles = useSelector((state) => state.ui.styles)
  const checked = useSelector((state) => state.landingpage.latestPostScreen);
  const LatestPostData = useSelector((state) => state.landingpage.latestposts);
  const mailFullScreen = useSelector((state) => state.landingpage.mailFullScreen);
  const mailBoxExpander = useSelector((state) => state.landingpage.mailBoxExpander);
  const viewUserSearchPopup = useSelector((state) => state.landingpage.viewUserSearch);
  const viewSpecificPostFull = useSelector((state) => state.landingpage.viewSpecificPost);
  const viewNewsExpander = useSelector((state) => state.landingpage.newsBoxExpander);
  const viewSpecificNews = useSelector((state) => state.landingpage.newsFullScreen);
  const viewProcessPopup = useSelector((state) => state.landingpage.processPopup);

  //const isConsultationProcess = useSelector((state) => state.landingpage.isConsultationProcess);
  let path = window.location.href.split("/")[4];
  path = path?.includes('#') ? path.split('#')[0] : path;
  const isConsultationProcess = path === "consultation-process" ? true : false;
  const [postUrl, setPostUrl] = useState("");


  // useEffect(() => {
  //   if (!isConsultationProcess) {
  //     console.log('home')
  //     const today = moment().format('DD-MM-YYYY');
  //     const todate = moment(moment().format('YYYY-MM-DD')).add(7, 'days').format('DD-MM-YYYY')
  //     apiSearchUrlWithToken
  //       .get(`/scheduler/datewise?date=${today}&todate=${todate}`)
  //       .then((result) => {
  //         dispatch(getAppointments(result.data.schedulerList));
  //       })
  //       .catch((err) => {
  //         console.log(err);
  //       });
  //     setInterval(() => {
  //       apiSearchUrlWithToken
  //         .get(`/scheduler/datewise?date=${today}&todate=${todate}`)
  //         .then((result) => {
  //           dispatch(getAppointments(result.data.schedulerList));
  //         })
  //         .catch((err) => {
  //           console.log(err);
  //         });
  //     }, 30000);
  //   }
  // }, [])


  useEffect(() => {
    if (!isConsultationProcess) {
      let access = localStorage.getItem("accesstoken");
      let decoded = JwtDecode(access);
      postandnewsServiceUrlWithToken
        .get(`/post/list?limit=50&&page=1`)
        .then((result) => {
          dispatch(getUserLatestPosts(result.data));
        })
        .catch((err) => {
          console.log(err);
        });
      setInterval(() => {
        postandnewsServiceUrlWithToken
          .get(`/post/list?limit=50&&page=1`)
          .then((result) => {
            dispatch(getUserLatestPosts(result.data));
          })
          .catch((err) => {
            console.log(err);
          });
      }, 30000);
    }
  }, []);


  useEffect(() => {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    postandnewsServiceUrlWithToken
      .get(`/news/getall/1/10`)
      .then((result) => {
        dispatch(getAllNews(result.data.data));
      })
      .catch((err) => {
        console.log(err);
      });
    setInterval(() => {
      postandnewsServiceUrlWithToken
        .get(`/news/getall/1/10`)
        .then((result) => {
          dispatch(getAllNews(result.data.data));
        })
        .catch((err) => {
          console.log(err);
        });
    }, 30000);
  }, []);

  useEffect(() => {
    if (!isConsultationProcess) {
      let access = localStorage.getItem("accesstoken");
      let decoded = JwtDecode(access);
      mailServiceUrlWithToken
        .get(`/email/${decoded.userReference}/userdetails`)
        .then((result) => {
          localStorage.setItem("uniqueUserId", result.data.userId);
          localStorage.setItem("fromMailObj", JSON.stringify(result));
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: 1,
            pageSize: 14,
          };
          mailServiceUrlWithToken
            .post("/email/getall", obj)
            .then((result) => {
              dispatch(getUserMails(result.data));
            })
            .catch((err) => {
              console.log(err);
            });
        });
      setInterval(() => {
        mailServiceUrlWithToken
          .get(`/email/${decoded.userReference}/userdetails`)
          .then((result) => {
            localStorage.setItem("uniqueUserId", result.data.userId);
            localStorage.setItem("fromMailObj", JSON.stringify(result));
            let obj = {
              emailId: result.data.emailId,
              mailType: "INBOX",
              page: 1,
              pageSize: 14,
            };
            mailServiceUrlWithToken
              .post("/email/getall", obj)
              .then((result) => {
                dispatch(getUserMails(result.data));
              })
              .catch((err) => {
                console.log(err);
              });
          });
      }, 30000)
    }
  }, []);

  useEffect(() => {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    // notificationUrl
    //   .get(`/notification/getAllNotification/${decoded.userReference}`)
    //   .then((result) => {
    //     console.log(result.data)
    //     dispatch(getAllNotifications(result.data))
    //   })
    //   .catch((err) => {
    //     console.log(err)
    //   })
    // setInterval(() => {
    //   notificationUrl
    //     .get(`/notification/getAllNotification/${decoded.userReference}`)
    //     .then((result) => {
    //       console.log(result.data)
    //       dispatch(getAllNotifications(result.data))
    //     })
    //     .catch((err) => {
    //       console.log(err)
    //     })
    // }, 30000)
  }, [])

  let commonData = LatestPostData.posts;
  const notification = useSelector((state) => state.landingpage.notification);

  let appointments = scheduler;
  let today = new Date();
  let dd = today.getDate();
  let mm = today.getMonth() + 1;
  let hh = today.getHours();
  let mn = today.getMinutes() + 1;
  const yyyy = today.getFullYear();
  if (dd < 10)
    dd = `0${dd}`;
  if (mm < 10)
    mm = `0${mm}`;
  if (hh < 10)
    hh = `0${hh}`;
  if (mn < 10)
    mn = `0${mn}`;
  today = `${dd}-${mm}-${yyyy} ${hh}:${mn}`;
  setInterval(() => {

    appointments.map(t => {
      if (t.date.split(' ')[0] == `${dd}-${mm}-${yyyy}`) {

        var start = moment.duration(`${hh}:${mn}`, "HH:mm");
        var end = moment.duration(`${t.date.split(' ')[1]}`, "HH:mm");
        var diff = end.subtract(start);
        var minutes_diff = diff.minutes();

        if (minutes_diff <= 10 && minutes_diff > 0) {
          let checkExistance = notification.filter(el => el.type === 1)
          if (checkExistance.length > 0) {

            if (checkExistance.filter(tr => tr.appointment_id === t.id).length === 0) {

              let obj = {
                id: 1,
                appointment_id: t.id,
                type: 1,
                body: `Appointment in ${minutes_diff} minutes`,
                name: t.patientname,
                time: `${yyyy}-${mm}-${dd} ${hh}:${mn}:00`,
                read: false
              };
              let exData = notification;
              exData.unshift(obj)
              dispatch(addReminderAppointment(exData))
            }
          }
          else {
            let obj = {
              id: 1,
              appointment_id: t.id,
              type: 1,
              body: `Appointment in ${minutes_diff} minutes`,
              name: t.patientname,
              time: `${yyyy}-${mm}-${dd} ${hh}:${mn}:00`,
              read: false
            };
            let exData = notification;
            exData.unshift(obj)
            dispatch(addReminderAppointment(exData))
          }
        }
      }
    })
  }, 20000)

  return (
    <>
      <ThemeProvider theme={mytheme}>
        <GlobalStyle>
          <div className="container-fluid">
            <div className="row">
              {
                !isConsultationProcess ?
                  <div className="col-md-3">
                    <SubMenu theme={styles.landing_page}>
                      <Persona />
                      <Counts />
                      <DropdownContent />
                    </SubMenu>
                  </div> : ''
              }


              {
                isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ?
                  (
                    <div className="col-md-6">
                      <ConsultationProcess />
                    </div>
                  )
                  : ''
              }
              {/* isConsultationPrcoess - point to consulation process page/route */}
              {checked && !isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ? (
                <div className="col-md-6">
                  <LatestPost>
                    <Header>
                      <div >
                        <h3>Latest Posts</h3>
                      </div>

                      {/* <div>
                        <input placeholder="Search" />
                      </div> */}

                      <button className="closeButn btn_clos"
                        onClick={() => dispatch(viewLatestpostFullscreen())}
                      >
                        x
                        </button>

                    </Header>

                    <Firstschedule className="row"  >
                      {LatestPostData.length > 0 ? LatestPostData.map((data) =>
                        <div className="postContainer" >
                          <img
                            src={data.postPictureURL !== "" ? data.postPictureURL : data.postPlaceHolder}
                            className="img-responsive" onClick={() => {
                              dispatch(setSelectedPost(LatestPostData.filter(el => el.postId === data.postId)))
                              dispatch(viewSpecificPost());
                            }}
                          />
                          <div className="postContentContainer">
                            <GridText2>
                              <div className="postContent">
                                <div className="senderTitle">
                                  <p className="d-flex bd-highlight no_mrbt" >
                                    <p className="p-RT flex-grow-1 bd-highlight no_mrbt" onClick={() => {
                                      dispatch(setSelectedPost(LatestPostData.filter(el => el.postId === data.postId)))
                                      dispatch(viewSpecificPost());
                                    }}>
                                      {data.postUserName}
                                    </p>
                                    <p className="p-RT bd-highlight "> {data.publishedTime == "0m"
                                      ? `now`
                                      : data.publishedTime}</p>
                                    <div
                                      className="p-RT bd-highlight dropdown elipse_icn"
                                      style={{ cursor: "pointer" }}
                                    >
                                      <i
                                        className="fa fa-ellipsis-v dropdown-toggle "
                                        id="dropdownMenu2"
                                        data-toggle="dropdown"
                                        aria-haspopup="true"
                                        aria-expanded="false"
                                      ></i>
                                      <div
                                        className="dropdown-menu drp_menu2"
                                        aria-labelledby="dropdownMenu2"
                                      >

                                        <button
                                          className="dropdown-item"
                                          tabindex="-1"
                                          type="button"
                                          data-toggle="modal"
                                          data-target="#exampleModalCenter"
                                          onClick={() => {
                                            if (
                                              window.location.hostname == "localhost"
                                            ) {
                                              setPostUrl(
                                                `https://hypaiqdev.cyb.co.uk/post/${data.checksumId}/${data.postId}`
                                              );
                                            } else {
                                              setPostUrl(
                                                `https://${window.location.hostname}/post/${data.checksumId}/${data.postId}`
                                              );
                                            }
                                          }}
                                        >
                                          <i className="fa fa-share " aria-hidden="true"></i>{" "}
                            Share
                          </button>
                                        <CopyToClipboard
                                          text={
                                            window.location.hostname === "localhost"
                                              ? `https://hypaiqdev.cyb.co.uk/post/${data.checksumId}/${data.postId}`
                                              : `https://${window.location.hostname}/post/${data.checksumId}/${data.postId}`
                                          }
                                          onCopy={() => alert("link copied")}
                                        >
                                          <button className="dropdown-item" type="button">
                                            <i className="fa fa-clipboard" aria-hidden="true"></i>{" "}
                              Copy Link
                            </button>
                                        </CopyToClipboard>
                                        <button className="dropdown-item" type="button">
                                          <i className="fa fa-flag-o" aria-hidden="true">
                                            {" "}
                                            <a href="mailto:no-one@snai1mai1.com?subject=look at this website&body=Hi,I found this website and thought you might like it http://www.geocities.com/wowhtml/">
                                              Report
                              </a>
                                          </i>{" "}
                                        </button>
                                      </div>
                                    </div>
                                    {/* <p className="p-RT bd-highlight no_mrbt">
                                      <i className="fa fa-ellipsis-v"></i>
                                    </p> */}



                                  </p>
                                  <h3 className="title" onClick={() => {
                                    dispatch(setSelectedPost(LatestPostData.filter(el => el.postId === data.postId)))
                                    dispatch(viewSpecificPost());
                                  }}>{data.postTitle}</h3>
                                  <p className="content" onClick={() => {
                                    dispatch(setSelectedPost(LatestPostData.filter(el => el.postId === data.postId)))
                                    dispatch(viewSpecificPost());
                                  }}>{ReactHtmlParser(data.postContent.slice(0, 300))}</p>
                                </div>
                                {/* <div className="contentTime">
                                  <p className="time">{commonData[0].time}</p>
                                </div> */}
                              </div>
                              {/* <GridText3>
                          <span>
                            {" "}
                            {commonData[0].department} |{" "}
                            {commonData[0].branch} | {commonData[0].name}
                          </span>
                        </GridText3> */}
                            </GridText2>
                          </div>
                        </div>

                      ) : null}

                      {/* Start Social media modal **/}
                      <div
                        className="modal"
                        id="exampleModalCenter"
                        tabindex="-1"
                        role="dialog"
                        aria-labelledby="exampleModalCenterTitle"
                        aria-hidden="true"
                      >
                        <div
                          className="modal-dialog modal-dialog-centered"
                          role="document"
                        >
                          <div className="modal-content">
                            <div className="modal-header">
                              <h5
                                className="modal-title"
                                id="exampleModalLongTitle"
                              >
                                Share at
                              </h5>
                              <button
                                type="button"
                                className="close"
                                data-dismiss="modal"
                                aria-label="Close"
                              >
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div className="modal-body ">
                              <FacebookShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={"About post"}
                              >
                                <FacebookIcon size={36} />
                              </FacebookShareButton>
                              <TwitterShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={"About post"}
                              >
                                <TwitterIcon size={36} />
                              </TwitterShareButton>
                              <LinkedinShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={"About post"}
                              >
                                <LinkedinIcon size={36} />
                              </LinkedinShareButton>
                              <TelegramShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={"About post"}
                              >
                                <TelegramIcon size={36} />
                              </TelegramShareButton>
                              <WhatsappShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={"About post"}
                              >
                                <WhatsappIcon size={36} />
                              </WhatsappShareButton>
                            </div>
                            <div className="modal-footer">
                              <button
                                type="button"
                                className="btn btn-secondary"
                                data-dismiss="modal"
                              >
                                Close
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* End Social media modal **/}

                    </Firstschedule>
                    <MakePost />
                  </LatestPost>
                </div>
              ) : null}

              <PopupComponent
                width="75%"
                // Zindex="1"
                minWidth="1075px"
                visible={viewUserSearchPopup}
                styles={styles}
                header="User Search"
                children={
                  <UserSearchPopup
                    styles={styles}
                    userid={JSON.parse(localStorage.getItem('account')) ? JSON.parse(localStorage.getItem('account')).userid : ''}
                    select={(e) => {
                      dispatch(viewUserSearch(false))
                      dispatch(setSelectedUser(e))
                    }}
                    close={() => this.closeUser()}
                    fetch={() => this.newData()}
                  />
                }
                close={() => dispatch(viewUserSearch(false))}
              />
              {viewProcessPopup && !viewSpecificPostFull && !isConsultationProcess && !viewNewsExpander && !viewSpecificNews ?
                <ProcessSearchPopup />
                : null}
              {viewSpecificPostFull && !isConsultationProcess && !viewNewsExpander && !viewSpecificNews ?
                <LatestPostFullView />
                : null}
              {mailFullScreen && !isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ?
                <MailExpander />
                : null}
              {viewNewsExpander && !isConsultationProcess && !viewSpecificPostFull && !mailFullScreen && !viewSpecificNews ?
                <NewsBoxExpander />
                : null}
              {viewSpecificNews && !isConsultationProcess && !viewSpecificPostFull && !mailFullScreen && !viewNewsExpander ?
                <NewsSpecificView />
                : null}
              {mailBoxExpander && !isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ?
                <MailBoxExpand />
                : null}
              {!checked && !mailFullScreen && !mailBoxExpander && !isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ? (
                <div className="col-md-3">
                  <DashboardContentTwo />
                </div>
              ) : null}
              {!checked && !mailFullScreen && !mailBoxExpander && !isConsultationProcess && !viewSpecificPostFull && !viewNewsExpander && !viewSpecificNews ? (
                <div className="col-md-3">
                  <Thirddashboard />
                </div>
              ) : null}
              {/* <div className="col-md-1"></div> */}
              {
                !isConsultationProcess ?
                  <div className="col-md-3">
                    <Message />
                  </div> : ''
              }

              {/* <div className="col-md-3">
                <Scheduler />
              </div> */}
            </div>
          </div>
        </GlobalStyle>
      </ThemeProvider>
    </>
  );
}

const GlobalStyle = styled.section`
button i a{
  color:#16181b !important;
}

.newpost_expn .mailtablesecond p{
  font-size:${(props) =>
    props.theme.DashboardContentThreeColors.NewsMail.newsmail_fontsize} !important;
  } 
.closeBtn, .closeBtn:focus, .closeButn, .closeButn:focus{
  border: none;
    background: transparent;
    font-weight: 600;
    font-size: 20px;
    position: absolute;
    right: 4%;
    top: 4.5%;
    outline: 0;
}
.postContentContainer{
  flex: 1;
}
.postContainer{
  width: 100%;
  display: flex;
    padding: 5px 10px 5px 10px;
    border-bottom: 1px solid #ebebeb;
  &:hover{
    background: #f3fffd;
  }
img{
  height: 85px;
  width:89px;
}
}
.postContent{
  display: flex;
    align-items: center;
    justify-content: space-between;
    height: 85px;
.senderTitle{
  width:100%;
  position:relative;
.sender{

}
.title{
  
}
}
.contentTime{
.content{
  
}
.time{}
}
}
`;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
    props.theme.submenu_username_font_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
    props.theme.submenu_account_font_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;

const LatestPost = styled.div`

    padding: 10px 15px;
    margin-top: 30px;
    border-radius: 10px;
  background-color: #fff;
  input {
    float: right;
  }
`;

const Header = styled.div`
  display: table;
  width: 100%;
  div {
    ul{
      list-style:none
    }
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 80%;
    }
    :nth-child(2) input {
      background-color: #dae7e4;
      border-radius: 50px;
      padding: 5px;
      border: none;
      margin: 10px;
    }
  }
`;

const Firstschedule = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
  margin-bottom: 10px;
  height: 77vh;
  overflow-y: auto;
  flex-direction: column;
  flex-wrap: nowrap;

`;

const GridText2 = styled.div`
  padding-left: 10px;
  padding-right: 0px;
  h3 {
    font-size: 16px;
    color: green;
    margin-bottom: 0px;
  }
  p {
    margin-bottom: 5px;
    font-size: 11px;
  }
`;

const GridText3 = styled.div`
  p {
    color: #738c87;
    font-size: 11px;
  }
`;

const OwnNetwotk = styled.div`
  padding: 10px;
`;

const OwnNetwotkHeader = styled.div`
  background-color: red;
  padding: 0px 10px 0px 10px;
`;

const OwnNetwotkBg = styled.div`
  background-color: #f3fffd;
  margin-top: -10px;
  h4 {
    color: #7f00ab;
    font-weight: 600;
    padding: 10px 12px 0px 12px;
  }
  .gridtext3 {
    p {
      padding: 0px 12px;
    }
  }
  ul {
    list-style: none;
    margin: 0px;
    li {
      display: inline-block;
      padding: 5px 10px;
      :nth-child(2) {
        float: right;
      }
    }
  }
`;

const History = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
`;

const Readhistory = styled.div`
  ul {
    display: flex;
    margin: 0;
    list-style: none;
    li {
      margin-right: 5px;
      h1 {
        color: #e5ccee;
        font-size: 45px;
      }
    }
  }
`;

const Trends = styled.div`
  padding: 0px;
`;

const Checklib = styled.div`
  p {
    text-align: right;
    padding: 0px 10px;
    color: #0e8a8b;
    font-size: 13px;
    font-weight: 600;
  }
`;
