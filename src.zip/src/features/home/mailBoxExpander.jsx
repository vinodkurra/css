import React, { useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";
import { useSelector, useDispatch } from "react-redux";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import {
  viewMailExpander,
  readMail,
  changeMailSlicer,
  readAllMail,
  deleteMail,
  addToStarred,
  getUserMails,
  selectedMailtoView,
  viewMailFullscreen,
} from "../../store/LandingPage/index";
import { MailContent } from "../home/thirddashboard";
import "../dashboard/components/header.css";
import axios from "axios";
import { mailServiceUrlWithToken } from "../../calls/apis";
import { ComposeMessage } from "../home/thirddashboard";
import JwtDecode from "jwt-decode";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, convertToRaw } from "draft-js";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { MessageBody } from "./thirddashboard";

export default function Mailbox() {
  const dispatch = useDispatch();
  const [show_options, setShowOptions] = useState(false);
  const [action_visible, setActionVisible] = useState(false);
  var [choosenMailId, pushId] = useState([]);
  const [checked, setChecked] = useState(false);
  const [showPrevNext, setshowPrevNext] = useState(true);
  const [current_page_mail, setCurrentPage] = useState(1);
  const [userdetails, setUserDetails] = useState({});
  //create mail
  const [fromMailId, setFromMail] = useState(localStorage.getItem("email"));
  const [toMailIds, setToMails] = useState({});
  const [ccMailIds, setCcMailIds] = useState({});
  const [bccMailIds, setBccMailIds] = useState({});
  const [subject, setSubject] = useState("");
  const [files, setFiles] = useState([]);
  const [link, setLink] = useState("");

  const mailData = useSelector((state) => state.landingpage.mail);
  const mailSlicer = useSelector((state) => state.landingpage.mailSlicer);

  const userMails = useSelector((state) => state.landingpage.userMails);

  const handleCheck = (data) => {
    setShowOptions(true);
    if (choosenMailId.filter((el) => el.id === data.id).length === 0) {
      choosenMailId.push(data);
    } else {
      const index = choosenMailId.findIndex((el) => el.id === data.id);
      if (index > -1) {
        choosenMailId.splice(index, 1);
      }
    }
    if (choosenMailId.length === 0) {
      setShowOptions(false);
    }
  };

  const createMail = () => {
    let obj = {
      fromMailId: fromMailId,
      toMailIds: toMailIds,
      ccMailIds: ccMailIds,
      bccMailIds: bccMailIds,
      subject: subject,
      files: files,
      link: link,
    };
  };

  async function getMail(page_id) {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        if (page_id === 0) {
          setCurrentPage(1);
        } else if (page_id > 0) {
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: page_id,
            pageSize: 14,
          };

          mailServiceUrlWithToken
            .post("/email/getall", obj)
            .then((result) => {
              if (result.data.emailList.length > 0) {
                dispatch(getUserMails(result.data));
              } else {
                setCurrentPage(current_page_mail - 1);
                // dispatch(getUserMails(userMails));
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      });
  }

  async function getMailAfterRemove(page_id) {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        setUserDetails(result.data);
        setFromMail(result.data.emailId);

        if (page_id === 0) {
          setCurrentPage(1);
        } else if (page_id > 0) {
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: page_id,
            pageSize: 14,
          };

          mailServiceUrlWithToken
            .post(`/email/getall`, obj)
            .then((result) => {
              dispatch(getUserMails(result.data));
            })
            .catch((err) => {
              console.log(err);
            });
        }
      });
  }

  async function bulkUpdateUserMAil(data) {
    setShowOptions(false);
    pushId([]);
    var checkboxes = document.getElementsByName("rowSelectCheckBox");
    for (var i = 0, n = checkboxes.length; i < n; i++) {
      checkboxes[i].checked = false;
    }
    // await axios
    //   .put(
    //     "https://hypaiqemailservice-dev.cyb.co.uk:8088/email/bulkupdate",
    //     data
    //   )
    //   .then(async (result) => {
    //     await getMail(current_page_mail);
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //   });
    await mailServiceUrlWithToken
      .put(`/email/bulkupdate`, data)
      .then(async (result) => {
        await getMailAfterRemove(current_page_mail);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  return (
    <>
      <ThemeProvider theme={mytheme}>
        <div className="col-md-6 mail_box_ex box">
          <div className="divschedule">
            <div>
              <div className="mail_expandr_header">
                <div className="headr_txt">
                  <h3>Inbox</h3>
                </div>
                <div className="inbox_count_pg">
                  {userMails
                    ? userMails.totalMailCount > 0
                      ? userMails.startingMailIndex
                      : 0
                    : null}{" "}
                  -{" "}
                  {userMails
                    ? userMails.totalMailCount > 0
                      ? userMails.endingMailIndex
                      : 0
                    : null}{" "}
                  of {userMails ? userMails.totalMailCount : null}
                  {"  "}
                  {showPrevNext ? (
                    <i
                      class="fa fa-angle-left"
                      onClick={() => {
                        pushId([]);
                        var checkboxes = document.getElementsByName(
                          "rowSelectCheckBox"
                        );
                        for (var i = 0, n = checkboxes.length; i < n; i++) {
                          checkboxes[i].checked = false;
                        }
                        setCurrentPage(
                          current_page_mail > 1
                            ? current_page_mail - 1
                            : current_page_mail
                        );
                        getMail(
                          current_page_mail > 1
                            ? current_page_mail - 1
                            : current_page_mail
                        );
                      }}
                      aria-hidden="true"
                    ></i>
                  ) : null}
                  {showPrevNext ? (
                    <i
                      style={{ marginLeft: "15px" }}
                      class="fa fa-angle-right"
                      onClick={() => {
                        pushId([]);
                        var checkboxes = document.getElementsByName(
                          "rowSelectCheckBox"
                        );
                        for (var i = 0, n = checkboxes.length; i < n; i++) {
                          checkboxes[i].checked = false;
                        }
                        setCurrentPage(current_page_mail + 1);
                        getMail(current_page_mail + 1);
                      }}
                      aria-hidden="true"
                    ></i>
                  ) : null}
                </div>
                <div
                  className="eye_trash_icn_align"
                  style={{ width: "80%", float: "right" }}
                >
                  <div
                    className="dropdown"
                    id="bulkaction"
                    style={{ marginLeft: "25px", float: "right" }}
                  >
                    <span
                      type="button"
                      onClick={() => {
                        setActionVisible(!action_visible);
                      }}
                    >
                      <i className="fa fa-ellipsis-v"></i>{" "}
                      {action_visible ? (
                        <div
                          className="dropdown-menu"
                          aria-labelledby="bulkaction"
                        >
                          <form>
                            <p
                              className="dropdown-item"
                              style={{ cursor: "pointer" }}
                            >
                              <input
                                id="rowSelectCheckBox"
                                name="rowSelectCheckBox"
                                type="checkbox"
                                checked={checked}
                                onChange={() => {
                                  setChecked(!checked);
                                  setShowOptions(!show_options);
                                  pushId(userMails.emailList);

                                  var checkboxes = document.getElementsByName(
                                    "rowSelectCheckBox"
                                  );
                                  for (
                                    var i = 0, n = checkboxes.length;
                                    i < n;
                                    i++
                                  ) {
                                    checkboxes[i].checked = !checked;
                                    if (show_options === true) {
                                      pushId([]);
                                    }
                                  }
                                }}
                              />{" "}
                              <label
                                onClick={() => {
                                  setChecked(!checked);
                                  setShowOptions(!show_options);
                                  pushId(userMails.emailList);

                                  var checkboxes = document.getElementsByName(
                                    "rowSelectCheckBox"
                                  );
                                  for (
                                    var i = 0, n = checkboxes.length;
                                    i < n;
                                    i++
                                  ) {
                                    checkboxes[i].checked = !checked;
                                  }
                                }}
                                for="rowSelectCheckBox"
                              >
                                {" "}
                                {checked === false
                                  ? "Select All"
                                  : "Unselect All"}
                              </label>
                            </p>
                          </form>
                        </div>
                      ) : null}
                    </span>
                  </div>

                  {show_options ? (
                    <div
                      style={{
                        marginLeft: "25px",
                        float: "right",
                        marginTop: "10px",
                      }}
                      onClick={() => {
                        var aa = choosenMailId.map((t) => {
                          return {
                            isDeleted: true,
                            isRead: true,
                            isStarred: t.isStarred,
                            mailBoxId: t.id,
                          };
                        });
                        let obj = {
                          updateRequest: aa,
                          updateType: "DELETE",
                        };
                        bulkUpdateUserMAil(obj);
                      }}
                    >
                      <i class="fa fa-trash" aria-hidden="true"></i>
                    </div>
                  ) : null}

                  {show_options ? (
                    <div
                      style={{
                        marginLeft: "25px",
                        float: "right",
                        marginTop: "5px",
                      }}
                      onClick={() => {
                        //dispatch(deleteMail(choosenMailId));
                        var aa = choosenMailId.map((t) => {
                          return {
                            isDeleted: true,
                            isRead: t.isRead,
                            isStarred: t.isStarred,
                            mailBoxId: t.id,
                          };
                        });
                        let obj = {
                          updateRequest: aa,
                          updateType: "READ",
                        };
                        bulkUpdateUserMAil(obj);
                      }}
                    >
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </div>
                  ) : null}
                </div>
              </div>
            </div>

            <div>
              <ul style={{ listStyle: "none" }}>
                <li>
                  <div>
                    <button
                      className="closeBtn"
                      onClick={() => dispatch(viewMailExpander())}
                    >
                      x
                    </button>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div
            className="boxcontent"
            style={{
              overflowY: "scroll",
              height: "550px",
              overflowX: "hidden",
            }}
          >
            {userMails
              ? userMails.emailList.map((data) => (
                  <div
                    className={
                      data.isRead === false
                        ? "mailtable highlight_unread"
                        : "mailtable"
                    }
                  >
                    <div
                      className="mailtablefirst mail_icon_align"
                      style={{ textAlign: "center", width: "6%" }}
                    >
                      <input
                        style={{ cursor: "pointer" }}
                        name="rowSelectCheckBox"
                        type="checkbox"
                        onChange={handleCheck.bind(null, data)}
                      />
                      <p>
                        {data.isStarred === false ? (
                          <i
                            style={{ cursor: "pointer" }}
                            class="fa fa-star-o"
                            aria-hidden="true"
                            onClick={() => {
                              let aa = {
                                isDeleted: false,
                                isRead: data.isRead,
                                isStarred: !data.isStarred,
                                mailBoxId: data.id,
                              };

                              let obj = {
                                updateRequest: [aa],
                                updateType: "STARRED",
                              };
                              bulkUpdateUserMAil(obj);
                              //dispatch(addToStarred([data.id]))
                            }}
                          ></i>
                        ) : (
                          <i
                            style={{ color: "#f5aa42", cursor: "pointer" }}
                            class="fa fa-star"
                            aria-hidden="true"
                            onClick={
                              () => {
                                let aa = {
                                  isDeleted: false,
                                  isRead: data.isRead,
                                  isStarred: !data.isStarred,
                                  mailBoxId: data.id,
                                };

                                let obj = {
                                  updateRequest: [aa],
                                  updateType: "STARRED",
                                };
                                bulkUpdateUserMAil(obj);
                              }
                              // dispatch(addToStarred([data.id]))
                            }
                          ></i>
                        )}
                      </p>
                    </div>
                    <div
                      className="mailtablesecond"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        dispatch(selectedMailtoView(data));
                        dispatch(viewMailFullscreen());
                        let aa = {
                          isDeleted: false,
                          isRead: true,
                          isStarred: data.isStarred,
                          mailBoxId: data.id,
                        };

                        let obj = {
                          updateRequest: [aa],
                          updateType: "READ",
                        };
                        bulkUpdateUserMAil(obj);
                      }}
                    >
                      {data.isRead === false ? (
                        <div>
                          <p>
                            <strong>{data.fromMail.userName}</strong>
                          </p>
                          <h3>
                            <strong>{data.subject}</strong>
                          </h3>
                          <p>
                            <strong>
                              {ReactHtmlParser(data.body.slice(0, 20))}
                            </strong>
                          </p>
                        </div>
                      ) : (
                        <div>
                          <p>{data.fromMail.userName}</p>
                          <h3>{data.subject}</h3>
                          <p>{ReactHtmlParser(data.body.slice(0, 35))}</p>
                        </div>
                      )}
                    </div>
                    <div className="rightContent">
                      {data.isRead ? (
                        <div className="">
                          <p>
                            <strong>{data.entry_time}</strong>
                          </p>
                        </div>
                      ) : (
                        <div className="">
                          <p>{data.entry_time}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              : null}
          </div>
          <div className="row">
            <div className="col-md-6 maillall">
              <p>All</p>
            </div>
            <div className="col-md-6 maillall" style={{ cursor: "pointer" }}>
              <span>
                <i class="fa fa-pencil" aria-hidden="true"></i>Compose
              </span>
            </div>
          </div>
        </div>
      </ThemeProvider>
    </>
  );
}

const GlobalStyle = styled.section`
  .closeBtn,
  .closeBtn:focus {
    border: none;
    background: transparent;
    font-weight: 600;
    font-size: 20px;
    position: absolute;
    right: 2%;
    top: 1%;
    outline: 0;
  }
`;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne
          .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;
