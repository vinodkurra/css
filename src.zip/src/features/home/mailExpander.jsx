import React, { Component, useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";
import { useSelector, useDispatch } from "react-redux";
import { Multiselect } from "multiselect-react-dropdown";
import { mailServiceUrlWithToken, createMailUrl } from "../../calls/apis";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import {
  addToStarred,
  deleteMail,
  readAllMail,
  readMail,
  changeMailSlicer,
  viewMailFullscreen,
  viewMailExpander,
  getUserMails,
  selectedMailtoView,
} from "../../store/LandingPage/index";
import "../dashboard/components/header.css";
import JwtDecode from "jwt-decode";
import { Editor } from "react-draft-wysiwyg";
import {
  EditorState,
  convertToRaw,
  Modifier,
  convertFromHTML,
  ContentState,
} from "draft-js";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import draftToHtml from "draftjs-to-html";
import moment from "moment";
import { mail } from "../../json/sitedata";

export default function Mailbox() {
  const styles = useSelector((state) => state.ui.styles);
  const dispatch = useDispatch();
  const [editorState, setEditorState] = useState(EditorState.createEmpty());
  const [editorStateReply, setEditorStateReply] = useState(
    EditorState.createEmpty()
  );
  const [ccDiv, showCcDiv] = useState(false);
  const [bccDiv, showbccDiv] = useState(false);
  const [option1, setOption1] = useState([]);
  const [replyAll, setReplyAll] = useState(false);
  const [fromMailObj, setFromMail] = useState(
    JSON.parse(localStorage.getItem("fromMailObj"))
  );
  const [toMailIds, setToMails] = useState([]);
  const [ccMailIds, setCcMailIds] = useState([]);
  const [bccMailIds, setBccMailIds] = useState([]);
  const [subject, setSubject] = useState("");
  const [files, setFiles] = useState([]);
  const [link, setLink] = useState("");
  const [content, setContent] = useState("");
  const [replyThread, setReplyThread] = useState("");
  const [replyContent, setReplyContent] = useState("");
  const [showReplyThread, setshowReplyThread] = useState(false);
  const [forward, setForward] = useState(false);

  const [show_options, setShowOptions] = useState(false);
  // const [show_options_two, setShowOptionsTwo] = useState(false);
  const [action_visible, setActionVisible] = useState(false);
  var [choosenMailId, pushId] = useState([]);
  const [checked, setChecked] = useState(false);
  const [showPrevNext, setshowPrevNext] = useState(true);
  const [current_page_mail, setCurrentPage] = useState(1);
  const [userdetails, setUserDetails] = useState(
    JSON.parse(localStorage.getItem("fromMailObj"))
  );
  const mailData = useSelector((state) => state.landingpage.selectedMailtoView);

  async function createMail() {
    let date = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format("DD");
    let dayname = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format(
      "ddd"
    );
    let monthname = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format(
      "MMM"
    );
    let year = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format("YYYY");
    let hourandminutes = moment(
      mailData.sentDate,
      "YYYY-MM-DD HH:mm:ss"
    ).format("HH:mm");

    let aa = `<p style="display: none;"><span style="color: rgb(0,0,0);background-color:rgb(0,0,0);">
    On ${dayname}, ${date} ${monthname} ${year}, ${hourandminutes} ${mailData.fromMail.userName}, <${mailData.fromMail.emailId}> wrote:
 <span> ${mailData.body}</span>
 </span>
  </p>`;
    let mailObj = {
      fromMail: {
        // emailId: localStorage.getItem("email"),
        // userId: JSON.parse(localStorage.getItem("account")).userid,
        // userName: JSON.parse(localStorage.getItem("account")).firstname,
        emailId: userdetails.data.emailId,
        userId: userdetails.data.userId,
        userName: userdetails.data.userName,
      },
      toMails: toMailIds,
      bccMails: replyAll === true ? ccMailIds : [],
      ccMails: replyAll === true ? bccMailIds : [],
      parentId: 0,
      body: draftToHtml(convertToRaw(editorState.getCurrentContent())) + aa,
      //draftToHtml(convertToRaw(editorStateReply.getCurrentContent())),
      subject: subject,
    };
    console.log(mailObj);
    var formData = new FormData();
    formData.append("file", files[0]);
    formData.append("request", JSON.stringify(mailObj));

    await createMailUrl
      .post(`/email/create`, formData)
      .then((result) => {
        alert("Mail sent");
        dispatch(getUserMails(result.data));

        // dispatch(getUserMails(userMails));
      })
      .catch((err) => {
        console.log(err);
      });
    setEditorState(EditorState.createEmpty());
    setToMails([]);
    setCcMailIds([]);
    setBccMailIds([]);
    setFiles([]);
    setContent("");
    setSubject("");
    setLink("");
    document.getElementById("file").value = "";
  }

  async function getMail(page_id) {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        setUserDetails(result.data);
        setFromMail(result.data.emailId);

        if (page_id === 0) {
          setCurrentPage(1);
        } else if (page_id > 0) {
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: page_id,
            pageSize: 14,
          };

          mailServiceUrlWithToken
            .post(`/email/getall`, obj)
            .then((result) => {
              if (result.data.emailList.length > 0) {
                dispatch(getUserMails(result.data));
              } else {
                setCurrentPage(current_page_mail - 1);
                // dispatch(getUserMails(userMails));
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      });
  }

  async function makeThread(input) {
    let date = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format("DD");
    let dayname = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format(
      "ddd"
    );
    let monthname = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format(
      "MMM"
    );
    let year = moment(mailData.sentDate, "YYYY-MM-DD HH:mm:ss").format("YYYY");
    let hourandminutes = moment(
      mailData.sentDate,
      "YYYY-MM-DD HH:mm:ss"
    ).format("HH:mm");

    setEditorStateReply(
      EditorState.createWithContent(
        ContentState.createFromBlockArray(
          convertFromHTML(`<p style="display: none;"><span style="color: rgb(0,0,0);background-color:rgb(0,0,0);">
        On ${dayname}, ${date} ${monthname} ${year}, ${hourandminutes} ${mailData.fromMail.userName}, <${mailData.fromMail.emailId}> wrote:
     <span> ${mailData.body}</span>
     </span>
      </p>`)
        )
      )
    );
    // setReplyThread(render)

    if (input) {
      let a = mailData.body.replace("display: none","diplay: block");

      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`
          <p>
          <span style="color: rgb(0,0,0);">
          On ${dayname}, ${date} ${monthname} ${year}, ${hourandminutes} ${mailData.fromMail.userName}, <${mailData.fromMail.emailId}> wrote:
       <span> ${a}</span>
      </span>
        </p>`)
          )
        )
      );
    } else {
      console.log(content);
      setEditorState(content);
    }
  }

  return (
    <>
      <ThemeProvider theme={styles.landing_page}>
        <div className="col-md-6 fullmail">
          <div className="mailtitle">
            <div>
              <h3>{mailData.subject}</h3>
            </div>
            <div>
              <ul className="row">
                <li>
                  <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                </li>
                <li>
                  <div>
                    <button
                      className="btn"
                      onClick={() => dispatch(viewMailFullscreen())}
                    >
                      X
                    </button>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="mailtext">
            <div className="mailsender">
              <div>
                <div className="mailsender_name">
                  {mailData.fromMail.userName}
                </div>
                {/* <h3></h3> */}
                <p>
                  <strong>to </strong> Me{" "}
                  {mailData.toMails.map((m) => {
                    if (m.userId == localStorage.getItem("uniqueUserId")) {
                      return ``;
                    } else {
                      return m.userName + "<" + m.emailId + "> ";
                    }
                  })}{" "}
                  <br />
                  {mailData.ccMails.length > 0 ? <strong>cc :</strong> : null}
                  {mailData.ccMails.map((t) => {
                    return t.userName + "<" + t.emailId + ">";
                  })}
                  <br />
                  {mailData.bccMails.length > 0 &&
                  mailData.bccMails.filter(
                    (el) => el.userId == localStorage.getItem("uniqueUserId")
                  ).length > 0 ? (
                    <strong>bcc :</strong>
                  ) : null}
                  {mailData.bccMails.length > 0 &&
                  mailData.bccMails.filter(
                    (el) => el.userId == localStorage.getItem("uniqueUserId")
                  ).length > 0
                    ? mailData.bccMails.map((t) => {
                        return t.userName + "<" + t.emailId + ">";
                      })
                    : null}
                  {/* <br /> */}
                </p>
              </div>

              <div>{mailData.entry_time}</div>
            </div>
            {ReactHtmlParser(mailData.body)}

            {mailData.filepaths.length > 0 ? (
              <p>
                Attchments: <br />
                {mailData.filepaths.map((t) => {
                  var filename = t.substring(t.lastIndexOf("/") + 1);

                  return (
                    <a href={t}>
                      <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
                      <br />
                      {filename}
                    </a>
                  );
                })}
              </p>
            ) : null}

            {/* <p className="lastpara">Thanks David</p> */}
          </div>
          <div className="row reply_btn">
            <button
              type="button"
              data-toggle="modal"
              data-target="#replyModal"
              onClick={() => {
                setForward(false);
                makeThread(false);
                setshowReplyThread(true);
                setToMails([mailData.fromMail]);
                setCcMailIds(mailData.ccMails);
                setBccMailIds(mailData.bccMails);
                setSubject(`Re: ${mailData.subject.replace("Re: ", "")}`);
                setReplyAll(false);
              }}
            >
              <i class="fa fa-reply"></i>
              Reply
            </button>
            <button
              type="button"
              data-toggle="modal"
              data-target="#replyModal"
              onClick={() => {
                setForward(false);
                makeThread(false);
                setToMails([mailData.fromMail]);
                setCcMailIds(mailData.ccMails);
                setBccMailIds(mailData.bccMails);
                setSubject(`Re: ${mailData.subject.replace("Re: ", "")}`);
                setReplyAll(true);
              }}
            >
              <i class="fa fa-reply-all"></i>Reply All
            </button>
            <button
              type="button"
              data-toggle="modal"
              data-target="#replyModal"
              onClick={() => {
                setForward(true);
                makeThread(true);
                setToMails([mailData.fromMail]);
                setCcMailIds(mailData.ccMails);
                setBccMailIds(mailData.bccMails);
                setSubject(`Re: ${mailData.subject.replace("Re: ", "")}`);
                setReplyAll(true);
              }}
            >
              <i class="fa fa-arrow-right"></i>
              Forward
            </button>
          </div>
          {/* modal start */}
          <ComposeMessage>
            <div class="modal" id="replyModal" role="dialog">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">Reply Message</h4>
                    <button type="button" class="close" data-dismiss="modal">
                      &times;
                    </button>
                  </div>
                  <div class="modal-body">
                    <MessageForm>
                      <div>
                        <p>
                          From <input value={fromMailObj.data.emailId} />{" "}
                        </p>
                      </div>

                      {replyAll === true ? (
                        <div>
                          <ul>
                            <li
                              style={{ cursor: "pointer" }}
                              onClick={() => showCcDiv(!ccDiv)}
                            >
                              <a>Cc</a>
                            </li>
                            <li
                              style={{ cursor: "pointer" }}
                              onClick={() => showbccDiv(!bccDiv)}
                            >
                              <a>Bcc</a>
                            </li>
                          </ul>
                        </div>
                      ) : null}
                    </MessageForm>

                    <div className="messageto">
                      <p>
                        {/* To <input /> */}
                        To
                        <Multiselect
                          options={option1}
                          selectedValues={toMailIds}
                          onSelect={(e) => {
                            if (
                              e[0].userId == "all" ||
                              e.filter((el) => el.userId == "all").length > 0
                            ) {
                              option1.shift();
                              e = option1;
                              setOption1([]);
                            }
                            setToMails(e);
                          }}
                          onRemove={(e) => {
                            setToMails(e);
                          }}
                          onSearch={async (e) => {
                            setOption1([]);

                            if (e.toString().length === 0) {
                              console.log("empty");
                            } else {
                              let access = localStorage.getItem("accesstoken");
                              let decoded = JwtDecode(access);
                              await mailServiceUrlWithToken
                                .get(
                                  `/email/search/${decoded.userReference}/users?filter=${e}`
                                )
                                .then((result) => {
                                  console.log(result.data.userDetails.length);
                                  result.data.userDetails.unshift({
                                    emailId: "-----Select All-----",
                                    userName: "-----Select All-----",
                                    userId: "all",
                                  });
                                  setOption1(result.data.userDetails);
                                  //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                })
                                .catch((err) => {
                                  console.log(err);
                                });
                            }
                          }}
                          displayValue="emailId"
                          avoidHighlightFirstOption={true}
                          placeholder=""
                          emptyRecordMsg=""
                          style={{
                            chips: {
                              background: "#e2e2e2",
                              color: "#4a4a4a",
                            },
                            // searchBox: {
                            //   border: "none",
                            //   "border": "1px solid",
                            //   "border": "0px",
                            // },
                            multiselectContainer: {
                              color: "black",
                            },
                            optionContainer: {
                              border: "none",
                              border: "0px solid",
                              border: "0px",
                            },
                          }}
                        />
                      </p>
                    </div>
                    {(mailData.ccMails.length > 0 && replyAll === true) ||
                    ccDiv ? (
                      <div className="messageto">
                        <p>
                          {/* To <input /> */}
                          Cc
                          <Multiselect
                            options={option1}
                            selectedValues={ccMailIds}
                            onSelect={(e) => {
                              if (
                                e[0].userId == "all" ||
                                e.filter((el) => el.userId == "all").length > 0
                              ) {
                                option1.shift();
                                e = option1;
                                setOption1([]);
                              }
                              setCcMailIds(e);
                            }}
                            onRemove={(e) => {
                              setCcMailIds(e);
                            }}
                            onSearch={async (e) => {
                              setOption1([]);

                              if (e.toString().length === 0) {
                                console.log("empty");
                              } else {
                                let access = localStorage.getItem(
                                  "accesstoken"
                                );
                                let decoded = JwtDecode(access);
                                await mailServiceUrlWithToken
                                  .get(
                                    `/email/search/${decoded.userReference}/users?filter=${e}`
                                  )
                                  .then((result) => {
                                    console.log(result.data.userDetails.length);
                                    setOption1(result.data.userDetails);
                                    //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                  })
                                  .catch((err) => {
                                    console.log(err);
                                  });
                              }
                            }}
                            displayValue="emailId"
                            avoidHighlightFirstOption={true}
                            placeholder=""
                            emptyRecordMsg=""
                            style={{
                              chips: {
                                background: "#e2e2e2",
                                color: "#4a4a4a",
                              },
                              // searchBox: {
                              //   border: "none",
                              //   "border": "1px solid",
                              //   "border": "0px",
                              // },
                              multiselectContainer: {
                                color: "black",
                              },
                              optionContainer: {
                                border: "none",
                                border: "0px solid",
                                border: "0px",
                              },
                            }}
                          />
                        </p>
                      </div>
                    ) : null}
                    {(mailData.bccMails.length > 0 && replyAll === true) ||
                    bccDiv ? (
                      <div className="messageto">
                        <p>
                          {/* To <input /> */}
                          Bcc
                          <Multiselect
                            options={option1}
                            selectedValues={bccMailIds}
                            onSelect={(e) => {
                              if (
                                e[0].userId == "all" ||
                                e.filter((el) => el.userId == "all").length > 0
                              ) {
                                option1.shift();
                                e = option1;
                                setOption1([]);
                              }
                              setBccMailIds(e);
                            }}
                            onRemove={(e) => {
                              setBccMailIds(e);
                            }}
                            onSearch={async (e) => {
                              setOption1([]);

                              if (e.toString().length === 0) {
                                console.log("empty");
                              } else {
                                let access = localStorage.getItem(
                                  "accesstoken"
                                );
                                let decoded = JwtDecode(access);
                                await mailServiceUrlWithToken
                                  .get(
                                    `/email/search/${decoded.userReference}/users?filter=${e}`
                                  )
                                  .then((result) => {
                                    console.log(result.data.userDetails.length);
                                    setOption1(result.data.userDetails);
                                    //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                  })
                                  .catch((err) => {
                                    console.log(err);
                                  });
                              }
                            }}
                            displayValue="emailId"
                            avoidHighlightFirstOption={true}
                            placeholder=""
                            emptyRecordMsg=""
                            style={{
                              chips: {
                                background: "#e2e2e2",
                                color: "#4a4a4a",
                              },
                              // searchBox: {
                              //   border: "none",
                              //   "border": "1px solid",
                              //   "border": "0px",
                              // },
                              multiselectContainer: {
                                color: "black",
                              },
                              optionContainer: {
                                border: "none",
                                border: "0px solid",
                                border: "0px",
                              },
                            }}
                          />
                        </p>
                      </div>
                    ) : null}
                    {/* <MessageSubject>
                      <input
                        placeholder="subject"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                      />
                    </MessageSubject> */}
                    <MessageBody>
                      <Editor
                        editorState={editorState}
                        toolbarClassName={{ order: 2 }}
                        wrapperClassName={{
                          display: "flex",
                          "flex-direction": "column",
                          top: "auto",
                          bottom: "10px",
                        }}
                        editorClassName={{ order: 1 }}
                        toolbar={{
                          options: ["inline", "textAlign", "link"],
                        }}
                        onEditorStateChange={(e) => {
                          setEditorState(e);
                          console.log(e);
                          if (editorState !== "") {
                            const blocks = convertToRaw(
                              editorState.getCurrentContent()
                            ).blocks;
                            const value = blocks
                              .map(
                                (block) =>
                                  (!block.text.trim() && "\n") || block.text
                              )
                              .join("\n");
                            setContent(e);
                          }
                        }}
                      />
                    </MessageBody>
                   {forward ?  <input
                        type="button"
                        onClick={() => {
                          makeThread(true);
                        }}
                        value="..."
                      />:null}
                    {/* <FileFormat>
                            <ul>
                              <li>Formatting Options</li>
                              <li>
                                <a href="">
                                  <i className="fa fa-bold"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-italic"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-underline"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-bold"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-list"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-align-justify"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-align-left"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-align-center"></i>
                                </a>
                              </li>
                              <li>
                                <a href="">
                                  <i className="fa fa-align-right"></i>
                                </a>
                              </li>
                            </ul>
                          </FileFormat> */}
                    <MailSend>
                      <div>
                        <ul>
                          <li
                            style={{ cursor: "pointer" }}
                            onClick={() => createMail()}
                            data-toggle="modal"
                            data-target="#replyModal"
                          >
                            <i className="fa fa-send-o"></i> Send
                          </li>

                          <li>
                            {/* <i className="fa fa-paperclip"></i> */}
                            <input
                              id="file"
                              type="file"
                              onChange={(e) => setFiles(e.target.files)}
                            />{" "}
                            {/* Attach Files */}
                          </li>
                        </ul>
                      </div>

                      <div>
                        <ul>
                          <li>
                            <a href="#">
                              <i className="fa fa-ellipsis-v"></i>
                            </a>
                          </li>

                          <li>
                            <a href="#">
                              <i className="fa fa-trash-o"></i>{" "}
                            </a>
                          </li>
                        </ul>
                      </div>
                    </MailSend>
                  </div>
                </div>
              </div>
            </div>
          </ComposeMessage>
          {/* modal end */}
          {/* modal end */}
        </div>
      </ThemeProvider>
    </>
  );
}

const GlobalStyle = styled.section``;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne
          .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;

export const ComposeMessage = styled.div`
  .modal .modal-dialog {
    transform: translate(0px, 100px) !important;
  }
  .modal-header {
    background-color: ${(props) =>
      props.theme.DashboardContentThreeColors.ComposeMessage
        .modal_header_backgroundcolor};
    color: ${(props) =>
      props.theme.DashboardContentThreeColors.ComposeMessage.h4_color};

    border-radius: 10px 10px 0px 0px;
    h4 {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      font-size: 20px;
    }
    button {
      font-size: 30px;
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      opacity: 1;
      font-weight: 400;
      padding: 5px;
    }
  }
  .modal-content {
    border: none;
    border-radius: 10px;
    width: 500px;
  }

  .messageto {
    color: ${(props) =>
      props.theme.DashboardContentThreeColors.MessageForm
        .nthChild_2_li_color} !important;
    p input {
      border: none;
    }
  }
`;

const MessageForm = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) {
      p {
        margin: 0px;
        color: ${(props) =>
          props.theme.mail_fullview_sendername_font_color};
        input {
          border: none;
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        color: ${(props) =>
          props.theme.mail_fullview_ccbccname_font_color};
        a {
          color: ${(props) =>
            props.theme.mail_fullview_ccbccname_font_color};
        }
      }
    }
  }
`;

const MessageSubject = styled.div`
  border-top: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.MessageSubject.border_top};
  border-bottom: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.MessageSubject.border_bottom};
  input {
    border: none;
    padding: 5px;
  }
`;

const MessageBody = styled.div`
  width: 100%;
  border: none;
  height: 200px;
`;

const FileFormat = styled.div`
  border-top: 1.5px solid
    ${(props) => props.theme.DashboardContentThreeColors.FileFormat.border_top};
  border-bottom: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.FileFormat.border_bottom};
  ul {
    list-style: none;
    margin: 0;
    li {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.MessageForm
          .nthChild_2_li_color} !important;
      display: inline-block;
      padding: 10px;
      a {
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.FileFormat.li_a_color};
      }
    }
  }
`;

export const MailSend = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        font-weight: 500;
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.MailSend.li_color};
        i {
          margin-right: 5px;
        }
        :nth-child(1) {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MailSend.nthChild_1_color};
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        a {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MailSend.li_color};
        }
        display: inline-block;
        padding: 10px;
        text-align: right;
      }
    }
  }
`;
