import React, { useState, useEffect } from "react";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";
import {
  swapPost,
  addNewPost,
  viewLatestpostFullscreen,
  getUserLatestPosts,
  viewSpecificPost,
  setSelectedPost,
  setFileError,
  setCreatePostSelectedTaggedUsers,
} from "../../store/LandingPage/index";
import { useSelector, useDispatch } from "react-redux";
import {
  postandnewsServiceUrlWithToken,
  createPostUrl,
} from "../../calls/apis";
import JwtDecode from "jwt-decode";
import { latestPosts } from "../../json/sitedata";
import draftToHtml from "draftjs-to-html";
import htmlToDraft from "html-to-draftjs";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, convertToRaw, ContentState } from "draft-js";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import emojiUnicode from "emoji-unicode";
import fs, { readFile } from "fs";
import { fileURLToPath } from "url";
import TagUserSearch from "../dashboard/components/TopLineContents/tagUserSearch";
import { Multiselect } from "multiselect-react-dropdown";
import {
  FacebookShareButton,
  FacebookIcon,
  EmailShareButton,
  EmailIcon,
  InstapaperShareButton,
  InstapaperIcon,
  LinkedinShareButton,
  LinkedinIcon,
  TwitterIcon,
  TwitterShareButton,
  TelegramIcon,
  TelegramShareButton,
  WhatsappIcon,
  WhatsappShareButton,
} from "react-share";
import { CopyToClipboard } from "react-copy-to-clipboard";

function Seconddashboard({ history }) {
  const styles = useSelector((state) => state.ui.styles);
  const [title, setTitle] = useState("");
  const [name, setName] = useState("");
  const [editorState, setEditorState] = useState(EditorState.createEmpty());
  const [files, setFiles] = useState([]);

  const dispatch = useDispatch();
  const LatestPostData = useSelector((state) => state.landingpage.latestposts);
  const userGroup = useSelector((state) => state.landingpage.userGroup);
  const [userTagSearch, showUserTagSearch] = useState(false);
  const usersToTag = useSelector(
    (state) => state.landingpage.createPostSelectedTaggedUsers
  );
  const [showPatiensearch, setshowPatiensearch] = useState(false);
  const [discardEnable, setDiscardEnable] = useState(false);
  const [postUrl, setPostUrl] = useState("");
  //const viewSpecificPost = useSelector((state) => state.landingpage.viewSpecificPost);
  //let commonData = LatestPostData.posts;
  // const switchPost = (data) => dispatch(swapPost(data));
  const profilepic = () => {
    if (JSON.parse(localStorage.getItem("account")) !== null) {
      if (JSON.parse(localStorage.getItem("account")).profilepic !== "") {
        return JSON.parse(localStorage.getItem("account")).profilepic;
      } else {
        return "https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-image-182145777.jpg";
      }
    } else {
      return "https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-image-182145777.jpg";
    }
  };

  let src = profilepic();

  const hiddenFileInput = React.useRef(null);

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  const getUserNameForPost = () => {
    if (JSON.parse(localStorage.getItem("account")) !== null) {
      let title;
      let firstname;
      let lastname;
      if (
        (JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == "") &&
        (JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == "")
      ) {
        return localStorage.getItem("email").split("@")[0] + "@";
      } else {
        if (
          JSON.parse(localStorage.getItem("account")).title == undefined ||
          JSON.parse(localStorage.getItem("account")).title == ""
        ) {
          title = "";
        } else {
          title = JSON.parse(localStorage.getItem("account")).title;
        }
        if (
          JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == ""
        ) {
          firstname = "";
        } else {
          firstname = JSON.parse(localStorage.getItem("account")).firstname;
        }
        if (
          JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == ""
        ) {
          lastname = "";
        } else {
          lastname = JSON.parse(localStorage.getItem("account")).lastname;
        }
        return title + " " + firstname + " " + lastname;
      }
    }
  };
  let usernameforpost = getUserNameForPost();
  //
  function isEmoji(str) {
    var ranges = [
      "(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|[\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|[\ud83c[\ude32-\ude3a]|[\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])", // U+1F680 to U+1F6FF
    ];

    if (str.match(ranges.join("|"))) {
      var emojiRegexp = /([\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2694-\u2697]|\uD83E[\uDD10-\uDD5D])/g;
      if (!str) return;
      try {
        var newMessage = str.match(emojiRegexp);
        for (var emoj in newMessage) {
          var emojmessage = newMessage[emoj];
          var index = str.indexOf(emojmessage);
          if (index === -1) continue;
          emojmessage = `&#x` + emojiUnicode(emojmessage);
          str = str.substr(0, index) + emojmessage + str.substr(index + 2);
        }

        return str;
      } catch (err) {
        console.error("error in emojiToUnicode" + err.stack);
      }
    } else {
      return str;
    }
  }

  const addNewPost = async (evt) => {
    evt.preventDefault();

    let alt_str = isEmoji(
      convertToRaw(editorState.getCurrentContent()).blocks[0].text
    );
    let sender;

    let taggedUsers = usersToTag.map((t) => {
      return {
        postUserId: "0",
        checksumId: t.userid,
      };
    });

    if (userGroup.length > 0) {
      let grpname = userGroup[0].groupName;
      let title;
      let firstname;
      let lastname;
      if (
        (JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == "") &&
        (JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == "")
      ) {
        sender =
          grpname + "-" + localStorage.getItem("email").split("@")[0] + "@";
      } else {
        if (
          JSON.parse(localStorage.getItem("account")).title == undefined ||
          JSON.parse(localStorage.getItem("account")).title == ""
        ) {
          title = "";
        } else {
          title = JSON.parse(localStorage.getItem("account")).title;
        }
        if (
          JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == ""
        ) {
          firstname = "";
        } else {
          firstname = JSON.parse(localStorage.getItem("account")).firstname;
        }
        if (
          JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == ""
        ) {
          lastname = "";
        } else {
          lastname = JSON.parse(localStorage.getItem("account")).lastname;
        }
        sender = grpname + "-" + title + " " + firstname + " " + lastname;
      }
    } else {
      let title;
      let firstname;
      let lastname;
      if (
        (JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == "") &&
        (JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == "")
      ) {
        sender = localStorage.getItem("email").split("@")[0] + "@";
      } else {
        if (
          JSON.parse(localStorage.getItem("account")).title == undefined ||
          JSON.parse(localStorage.getItem("account")).title == ""
        ) {
          title = "";
        } else {
          title = JSON.parse(localStorage.getItem("account")).title;
        }
        if (
          JSON.parse(localStorage.getItem("account")).firstname == undefined ||
          JSON.parse(localStorage.getItem("account")).firstname == ""
        ) {
          firstname = "";
        } else {
          firstname = JSON.parse(localStorage.getItem("account")).firstname;
        }
        if (
          JSON.parse(localStorage.getItem("account")).lastname == undefined ||
          JSON.parse(localStorage.getItem("account")).lastname == ""
        ) {
          lastname = "";
        } else {
          lastname = JSON.parse(localStorage.getItem("account")).lastname;
        }
        sender = title + " " + firstname + " " + lastname;
      }
    }
    let postObj = {
      title: title,
      content: `<!DOCTYPE html>
      <html>
      <head>
      <meta charset="UTF-8">
      </head>
      <body>
      <p>${alt_str}</p>
      </body>
      </html>`,
      userName: sender,
      workgroupIds: [
        {
          postWorkgroupId: 0,
          workgroupId: "abc",
        },
      ],
      checksumIds: taggedUsers,
    };
    console.log(postObj);
    let formData = new FormData();
    if (files.length > 0) {
      formData.append("picture", files[0]);
      formData.append("thumbnail", files[0]);
      formData.append(
        "postreq",
        new Blob([JSON.stringify(postObj)], { type: "application/json" })
      );
      await createPostUrl
        .post(`/post`, formData)
        .then(async (result) => {
          window.$(".modal").modal("hide");
          alert("Post Added Successfully.");
          setFiles([]);
          document.getElementById("file").value = "";
          setTitle("");
          setEditorState(EditorState.createEmpty());
          await postandnewsServiceUrlWithToken
            .get(`/post/list?limit=50&&page=1`)
            .then((result) => {
              dispatch(getUserLatestPosts(result.data));
            })
            .catch((err) => {
              console.log(err);
            });
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      //  let defaultFile;
      var getFileBlob = function (url, cb) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.responseType = "blob";
        xhr.addEventListener("load", function () {
          cb(xhr.response);
        });
        xhr.send();
      };

      var blobToFile = function (blob, name) {
        blob.lastModifiedDate = new Date();
        blob.name = name;
        return blob;
      };

      var getFileObject = function (filePathOrUrl, cb) {
        getFileBlob(filePathOrUrl, function (blob) {
          cb(blobToFile(blob, "test.jpg"));
        });
      };

      getFileObject(
        "https://postandnews.portcullisindia.in/download/asserts/placeholder.png",
        async function (fileObject) {
          let defaultFile = new File([fileObject], "test.jpg");
          formData.append("picture", defaultFile);
          formData.append("thumbnail", defaultFile);
          formData.append(
            "postreq",
            new Blob([JSON.stringify(postObj)], { type: "application/json" })
          );
          await createPostUrl
            .post(`/post`, formData)
            .then(async (result) => {
              window.$(".modal").modal("hide");
              alert("Post Added Successfully.");
              setFiles([]);
              document.getElementById("file").value = "";
              setTitle("");
              setEditorState(EditorState.createEmpty());
              await postandnewsServiceUrlWithToken
                .get(`/post/list?limit=50&&page=1`)
                .then((result) => {
                  dispatch(getUserLatestPosts(result.data));
                  dispatch(setCreatePostSelectedTaggedUsers([]));
                })
                .catch((err) => {
                  console.log(err);
                });
            })
            .catch((err) => {
              console.log(err);
            });
        }
      );
    }
  };

  return (
    <>
      <ThemeProvider theme={styles.landing_page}>
        <div>
          <GlobalStyle>
            <div className="container" style={{ padding: "0px" }}>
              <div className="row">
                <div className="secondposticon">
                  <div>
                    <h3>Latest Posts</h3>
                  </div>
                  <div>
                    <ul>
                      <li>
                        <i class="fa fa-search" aria-hidden="true"></i>
                      </li>
                      <li>
                        <i
                          class="fa fa-crosshairs"
                          aria-hidden="true"
                          onClick={() => dispatch(viewLatestpostFullscreen())}
                        ></i>
                      </li>
                    </ul>
                  </div>
                </div>
                {LatestPostData.length > 0 ? (
                  <div className="img_res">
                    <img
                      src={
                        LatestPostData[0].postPictureURL !== ""
                          ? LatestPostData[0].postPictureURL
                          : LatestPostData[0].postPlaceHolder
                      }
                      className="img-responsive"
                      onClick={() => {
                        dispatch(setSelectedPost([LatestPostData[0]]));
                        dispatch(viewSpecificPost());
                      }}
                    />
                  </div>
                ) : null}
                {LatestPostData.length > 0 ? (
                  <GridTextTwo
                    style={{
                      marginBottom: "5px",
                      minHeight: "80px",
                      borderBottom: "solid 1px lightgray",
                    }}
                  >
                    <p
                      className="d-flex bd-highlight no_mrbt"
                      style={{ position: "relative" }}
                    >
                      <div
                        class="p-RT flex-grow-1 bd-highlight"
                        onClick={() => {
                          dispatch(setSelectedPost([LatestPostData[0]]));
                          dispatch(viewSpecificPost());
                        }}
                      >
                        {LatestPostData[0].postUserName}
                      </div>
                      <div
                        class="p-RT bd-highlight"
                        onClick={() => {
                          dispatch(setSelectedPost([LatestPostData[0]]));
                          dispatch(viewSpecificPost());
                        }}
                      >
                        {LatestPostData[0].publishedTime === "0m"
                          ? `now`
                          : LatestPostData[0].publishedTime}
                      </div>
                      <div
                        class="p-RT bd-highlight dropdown elipse_icn"
                        style={{ cursor: "pointer" }}
                      >
                        <i
                          className="fa fa-ellipsis-v dropdown-toggle "
                          id="dropdownMenu2"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        ></i>
                        <div
                          class="dropdown-menu drp_menu2"
                          aria-labelledby="dropdownMenu2"
                        >
                          {/* <button class="dropdown-item" type="button">
                            <i class="fa fa-share" aria-hidden="true"></i> Share
                          </button> */}
                          <button
                            class="dropdown-item"
                            tabindex="-1"
                            type="button"
                            data-toggle="modal"
                            data-target="#exampleModalCenter"
                            onClick={() => {
                              if (window.location.hostname == "localhost") {
                                setPostUrl(
                                  `https://hypaiqdev.cyb.co.uk/post/${LatestPostData[0].checksumId}/${LatestPostData[0].postId}`
                                );
                              } else {
                                setPostUrl(
                                  `https://${window.location.hostname}/post/${LatestPostData[0].checksumId}/${LatestPostData[0].postId}`
                                );
                              }
                            }}
                          >
                            <i class="fa fa-share " aria-hidden="true"></i>{" "}
                            Share
                          </button>
                          <CopyToClipboard
                            text={
                              window.location.hostname === "localhost"
                                ? `https://hypaiqdev.cyb.co.uk/post/${LatestPostData[0].checksumId}/${LatestPostData[0].postId}`
                                : `https://${window.location.hostname}/post/${LatestPostData[0].checksumId}/${LatestPostData[0].postId}`
                            }
                            onCopy={() => alert("link copied")}
                          >
                            <button class="dropdown-item" type="button">
                              <i class="fa fa-clipboard" aria-hidden="true"></i>{" "}
                              Copy Link
                            </button>
                          </CopyToClipboard>
                          <button class="dropdown-item" type="button">
                            <i class="fa fa-flag-o" aria-hidden="true">
                              {" "}
                              <a href="mailto:no-one@snai1mai1.com?subject=look at this website&body=Hi,I found this website and thought you might like it http://www.geocities.com/wowhtml/">
                                Report
                              </a>
                            </i>{" "}
                          </button>
                        </div>
                      </div>
                    </p>
                    <h3
                      onClick={() => {
                        dispatch(setSelectedPost([LatestPostData[0]]));
                        dispatch(viewSpecificPost());
                      }}
                    >
                      {LatestPostData[0].postTitle}
                    </h3>
                    <p
                      className="msg_contnt"
                      onClick={() => {
                        dispatch(setSelectedPost([LatestPostData[0]]));
                        dispatch(viewSpecificPost());
                      }}
                    >
                      {ReactHtmlParser(LatestPostData[0].postContent)}{" "}
                    </p>

                    {/* <div className="gridtext3">
                    {LatestPostData[0].department} | {LatestPostData[0].branch} |{" "}
                    {LatestPostData[0].name}
                  </div> */}
                    {/* <p className="static_dscrip_nop">
                      Health | Technology | St.Mary's
                    </p> */}
                    {/* <hr /> */}
                  </GridTextTwo>
                ) : null}
              </div>
              <div className="row">
                <div className="latest_post_hgt">
                  {/*  <div className="img_res">
                    <img
                      src={commonData[0].source}
                      className="img-responsive"
                    />
                  </div>
                  <GridTextTwo>
                    <p>{commonData[0].sender}</p>
                    <h3>{commonData[0].title}</h3>
                    <p>{commonData[0].content} </p>
                    <div className="gridtext3">
                      {commonData[0].department} | {commonData[0].branch} |{" "}
                      {commonData[0].name}
                    </div>
                    <hr />
                  </GridTextTwo>*/}
                  {LatestPostData.slice(1).map((data) => (
                    <CommomnGrid>
                      <div className="col-md-3 gridtext1 img_txt_res ">
                        <img
                          src={
                            data.postPictureURL !== ""
                              ? data.postPictureURL
                              : data.postPlaceHolder
                          }
                          className="img-responsive"
                          onClick={() => {
                            dispatch(
                              setSelectedPost(
                                LatestPostData.filter(
                                  (el) => el.postId == data.postId
                                )
                              )
                            );
                            dispatch(viewSpecificPost());
                          }}
                        />
                      </div>
                      <div className="col-md-9 gridtext2">
                        <div>
                          <div className="d-flex bd-highlight">
                            <div
                              class="flex-grow-1 f-12 bd-highlight"
                              onClick={() => {
                                dispatch(
                                  setSelectedPost(
                                    LatestPostData.filter(
                                      (el) => el.postId == data.postId
                                    )
                                  )
                                );
                                dispatch(viewSpecificPost());
                              }}
                            >
                              {data.postUserName}
                            </div>
                            <div
                              class="bd-highlight f-12 margn_rt"
                              onClick={() => {
                                dispatch(
                                  setSelectedPost(
                                    LatestPostData.filter(
                                      (el) => el.postId == data.postId
                                    )
                                  )
                                );
                                dispatch(viewSpecificPost());
                              }}
                            >
                              {" "}
                              {data.publishedTime == "0m"
                                ? `now`
                                : data.publishedTime}
                            </div>
                            <div
                              className="bd-highlight f-12 elipse_icn dropdown"
                              style={{ cursor: "pointer" }}
                            >
                              <i
                                className="fa fa-ellipsis-v dropdown-toggle"
                                id="dropdownMenu2"
                                data-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              ></i>
                              <div
                                class="dropdown-menu drp_menu2"
                                aria-labelledby="dropdownMenu2"
                              >
                                <button
                                  class="dropdown-item"
                                  tabindex="-1"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#exampleModalCenter"
                                  onClick={() => {
                                    if (
                                      window.location.hostname == "localhost"
                                    ) {
                                      setPostUrl(
                                        `https://hypaiq.cyb.co.uk/post/${data.checksumId}/${data.postId}`
                                      );
                                    } else {
                                      setPostUrl(
                                        `https://${window.location.hostname}/post/${data.checksumId}/${data.postId}`
                                      );
                                    }
                                  }}
                                >
                                  <i
                                    class="fa fa-share "
                                    aria-hidden="true"
                                  ></i>{" "}
                                  Share
                                </button>

                                <CopyToClipboard
                                  text={
                                    window.location.hostname === "localhost"
                                      ? `https://hypaiqdev.cyb.co.uk/post/${data.checksumId}/${data.postId}`
                                      : `https://${window.location.hostname}/post/${data.checksumId}/${data.postId}`
                                  }
                                  onCopy={() => alert("link copied")}
                                >
                                  <button class="dropdown-item" type="button">
                                    <i
                                      class="fa fa-clipboard"
                                      aria-hidden="true"
                                    ></i>{" "}
                                    Copy Link
                                  </button>
                                </CopyToClipboard>
                                <button class="dropdown-item" type="button">
                                  <i class="fa fa-flag-o" aria-hidden="true">
                                    {" "}
                                    <a href="mailto:no-one@snai1mai1.com?subject=look at this website&body=Hi,I found this website and thought you might like it http://www.geocities.com/wowhtml/">
                                      Report
                                    </a>
                                  </i>{" "}
                                </button>
                              </div>
                            </div>
                          </div>

                          <h3
                            onClick={() => {
                              dispatch(
                                setSelectedPost(
                                  LatestPostData.filter(
                                    (el) => el.postId == data.postId
                                  )
                                )
                              );
                              dispatch(viewSpecificPost());
                            }}
                          >
                            {data.postTitle}
                          </h3>

                          <p
                            onClick={() => {
                              dispatch(
                                setSelectedPost(
                                  LatestPostData.filter(
                                    (el) => el.postId == data.postId
                                  )
                                )
                              );
                              dispatch(viewSpecificPost());
                            }}
                          >
                            <p className="msg_contnt">
                              {ReactHtmlParser(data.postContent)}
                              {/* Hey this <strong>editor</strong> rocks 😀 */}
                            </p>
                            {/* <p className="static_dscrip">
                              Health | Technology | St.Mary's
                            </p> */}
                          </p>

                          {/* <div className="gridtext3">
                            <p>
                              {data.department} | {data.branch} | {data.name}
                            </p>
                          </div> */}
                        </div>
                      </div>
                      {/* Start Social media modal **/}
                      <div
                        class="modal"
                        id="exampleModalCenter"
                        tabindex="-1"
                        role="dialog"
                        aria-labelledby="exampleModalCenterTitle"
                        aria-hidden="true"
                      >
                        <div
                          class="modal-dialog modal-dialog-centered"
                          role="document"
                        >
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5
                                class="modal-title"
                                id="exampleModalLongTitle"
                              >
                                Share at
                              </h5>
                              <button
                                type="button"
                                class="close"
                                data-dismiss="modal"
                                aria-label="Close"
                              >
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body ">
                              {" "}
                              <FacebookShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={data.postTitle}
                              >
                                <FacebookIcon size={36} />
                              </FacebookShareButton>
                              <TwitterShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={data.postTitle}
                              >
                                <TwitterIcon size={36} />
                              </TwitterShareButton>
                              <LinkedinShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={data.postTitle}
                              >
                                <LinkedinIcon size={36} />
                              </LinkedinShareButton>
                              <TelegramShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={data.postTitle}
                              >
                                <TelegramIcon size={36} />
                              </TelegramShareButton>
                              <WhatsappShareButton
                                style={{ marginLeft: "5px" }}
                                url={postUrl}
                                quote={data.postTitle}
                              >
                                <WhatsappIcon size={36} />
                              </WhatsappShareButton>
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="btn btn-secondary"
                                data-dismiss="modal"
                              >
                                Close
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* End Social media modal **/}
                    </CommomnGrid>
                  ))}
                </div>

                <GridButton>
                  <button
                    className="btn create_pst"
                    type="button"
                    data-toggle="modal"
                    data-target="#myModalcreatepost"
                  >
                    <i className="fa fa-plus" aria-hidden="true"></i> Create
                    Post
                  </button>
                </GridButton>

                {/* modal start */}

                <MakePost>
                  <div
                    class="modal"
                    id="myModalcreatepost"
                    role="dialog"
                    data-backdrop="false"
                    style={userTagSearch ? { zIndex: 1 } : null}
                  >
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">New Post</h4>
                          <button
                            type="button"
                            class="close"
                            data-dismiss="modal"
                          >
                            &times;
                          </button>
                        </div>
                        <div class="modal-body">
                          <PostContent>
                            <div>
                              <img
                                src={src}
                                className="img-responsive img_rounded"
                              />
                            </div>
                            <div>
                              <h4>{usernameforpost}</h4>
                              <p>
                                {userGroup.length === 0
                                  ? `PRIVATE`
                                  : userGroup[0].groupName}
                              </p>
                            </div>
                          </PostContent>

                          <AddPost>
                            <div
                              style={{
                                width: "100%",
                                display: "block",
                                border: "none",
                              }}
                            >
                              Title{" "}
                              <input
                                className="form-control"
                                type="text"
                                value={title}
                                required={true}
                                onChange={(e) => setTitle(e.target.value)}
                              />
                              Content
                              <Editor
                                id="editor"
                                editorState={editorState}
                                toolbarClassName={{ order: 2 }}
                                wrapperClassName={{
                                  display: "flex",
                                  "flex-direction": "column",
                                  top: "auto",
                                  bottom: "10px",
                                }}
                                editorClassName={{ order: 1 }}
                                toolbar={{
                                  options: ["inline", "textAlign", "emoji"],
                                }}
                                onEditorStateChange={(e) => {
                                  setEditorState(e);
                                  // setContent(

                                  //     convertToRaw(
                                  //       editorState.getCurrentContent()

                                  //   )
                                  // );
                                  const blocks = convertToRaw(
                                    editorState.getCurrentContent()
                                  ).blocks;
                                  const value = blocks
                                    .map(
                                      (block) =>
                                        (!block.text.trim() && "\n") ||
                                        block.text
                                    )
                                    .join("\n");

                                  // setContent(value);
                                }}
                              />
                            </div>

                            {/* <div className="icon_txt_align">
                              <div style={{ float: "left" }}>
                                <p>Add Attachments</p>
                              </div>
                              <div style={{ float: "right" }}>
                                <ul>
                                  <li>
                                    <i
                                      class="fa fa-smile-o"
                                      aria-hidden="true"
                                    ></i>
                                  </li>
                                  <li>
                                    <i
                                      class="fa fa-file-image-o"
                                      aria-hidden="true"
                                    ></i>
                                  </li>
                                  <li>
                                    <i
                                      class="fa fa-user"
                                      aria-hidden="true"
                                    ></i>
                                  </li>
                                  <li>
                                    <i
                                      class="fa fa-book"
                                      aria-hidden="true"
                                    ></i>
                                  </li>
                                </ul>
                              </div>
                            </div>  */}
                            {/* <div className="row tag_user" style={{ fontSize: "12px" }}>
                              <strong>
                                {usersToTag
                                  ? usersToTag.length > 0
                                    ? `Tagged users  `
                                    : null
                                  : null}{" "}
                              </strong>
                              {usersToTag
                                ? usersToTag.map((user) => (
                                    <div style={{ marginLeft: "8px" }}>
                                      <span
                                        style={{
                                          backgroundColor: "gray",
                                          color: "white",
                                        }}
                                      >
                                        {user.firstname}{" "}
                                      </span>
                                      <button
                                        onClick={() => {
                                          let skipuser = usersToTag.filter(
                                            (el) => el.userid !== user.userid
                                          );
                                          console.log(skipuser);
                                          dispatch(
                                            setCreatePostSelectedTaggedUsers(
                                              skipuser
                                            )
                                          );
                                        }}
                                        type="button"
                                      >
                                        x
                                      </button>
                                    </div>
                                  ))
                                : null}
                            </div> */}
                          </AddPost>
                          <div
                            className="row crt_post"
                            style={{
                              padding: "5px",
                              borderBottom: "1px solid #0e8a8b",
                              marginLeft: "0px",
                              width: "100%",
                              color: "#0e8a8b",
                            }}
                          >
                            {usersToTag.length > 0 ? (
                              <div
                                className="row tag_user"
                                style={{ fontSize: "12px" }}
                              >
                                <strong>
                                  {usersToTag
                                    ? usersToTag.length > 0
                                      ? `Tagged users  `
                                      : null
                                    : null}{" "}
                                </strong>
                                {usersToTag
                                  ? usersToTag.map((user) => (
                                      <div>
                                        <span>{user.firstname} </span>
                                        <i
                                          className="fa fa-times-circle-o"
                                          onClick={() => {
                                            let skipuser = usersToTag.filter(
                                              (el) => el.userid !== user.userid
                                            );
                                            console.log(skipuser);
                                            dispatch(
                                              setCreatePostSelectedTaggedUsers(
                                                skipuser
                                              )
                                            );
                                          }}
                                        ></i>
                                        {/* <button
                                        onClick={() => {
                                          let skipuser = usersToTag.filter(
                                            (el) => el.userid !== user.userid
                                          );
                                          console.log(skipuser);
                                          dispatch(
                                            setCreatePostSelectedTaggedUsers(
                                              skipuser
                                            )
                                          );
                                        }}
                                        type="button"
                                      >
                                        x
                                      </button> */}
                                      </div>
                                    ))
                                  : null}
                              </div>
                            ) : null}

                            <div className="col-md-7 f-12 p_0">
                              Add to your Post
                              {files.length > 0 ? (
                                <div style={{ float: "right" }}>
                                  <label className="filename_align">
                                    {files[0].name}
                                  </label>
                                  <input
                                    className="filereject"
                                    type="button"
                                    onClick={() => {
                                      setFiles([]);
                                    }}
                                    value="X"
                                  />
                                </div>
                              ) : null}
                            </div>
                            <div className="f-12 col-md-5">
                              {" "}
                              <i class="fa fa-file-text-o fnt-sz"></i>
                              {/* <i className="fa fa-file-text-o fnt-sz"></i> */}
                              <i
                                className="fa fa-id-badge fnt-sz"
                                style={{ cursor: "pointer" }}
                                onClick={() =>
                                  showUserTagSearch(!userTagSearch)
                                }
                              ></i>
                              <i
                                className="fa fa-file-image-o fnt-sz"
                                onClick={handleClick}
                              ></i>
                              <input
                                id="file"
                                type="file"
                                multiple={false}
                                ref={hiddenFileInput}
                                style={{ display: "none" }}
                                onChange={(e) => {
                                  console.log(e.target.files);
                                  setFiles(e.target.files);
                                  dispatch(setFileError());
                                }}
                              />{" "}
                            </div>
                          </div>

                          <PostButton>
                            <button onClick={addNewPost}>Post</button>
                          </PostButton>
                        </div>
                      </div>
                    </div>
                  </div>

                  {userTagSearch ? (
                    <div style={{ zIndex: 1 }}>
                      <TagUserSearch
                        //isPopupVisible={showPatiensearch}
                        togglePatient={() => {
                          showUserTagSearch(!userTagSearch);
                        }}
                        styles={styles}
                        // setPatient={(e) => setDiscardEnable(true)}
                        toggleDelete={(e) => null}
                      />
                    </div>
                  ) : null}
                </MakePost>
                {/* modal end */}
              </div>
            </div>
          </GlobalStyle>
        </div>
      </ThemeProvider>
    </>
  );
}

export default Seconddashboard;

const GlobalStyle = styled.section`
  background-color: #fff;
  padding: 10px 15px;
  margin-top: 30px;
  border-radius: 10px;

  button i a {
    color: #16181b !important;
  }

  .img_res {
    width: 100%;
    height: 150px;
    padding: 0 10px 0 10px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .secondposticon {
    display: table;
    padding: 0 10px 0 10px;
    width: 100%;
    div {
      display: table-cell;
      vertical-align: middle;
      :nth-child(2) {
        text-align: right;

        vertical-align: middle;
        ul {
          list-style: none;
          li {
            display: inline-block;
            padding: 10px;
            text-align: right;
            i {
              cursor: pointer;
            }
          }
        }
      }
    }
  }
`;

const GridTextTwo = styled.div`
  padding-left: 10px;
  padding-right: 10px;
  width: 100%;
  h3 {
    font-size: 16px;
    color: ${(props) => props.theme.post_primarypost_title_font_color};
    margin-bottom: 0px;
  }
  p {
    margin-bottom: 5px;
    font-size: 12px;
    color: ${(props) => props.theme.post_primarypost_sendersource_font_color};
  }
`;

const CommomnGrid = styled.div`
  cursor: pointer;
  width: 100%;
  padding: 0px 10px 0px 10px;
  border-bottom: 2px solid #ddd;
  // margin-bottom: 10px;
  margin-bottom: 5px;
  display: flex;
  // min-height: 86px;
  hr {
    border-top: 1px solid rgb(255 0 0);
  }
  .gridtext1 {
    padding: 0;
  }
  .gridtext2 h3 {
    font-size: 16px;
    color: ${(props) => props.theme.post_secondarypost_title_font_color};
    margin-bottom: 0px;
  }
`;

export const GridButton = styled.div`
  cursor: pointer;
  text-align: right;
  width: 100%;

  .btn.active.focus,
  .btn.active:focus,
  .btn.focus,
  .btn:active.focus,
  .btn:active:focus,
  .btn:focus {
    outline: unset !important;
    outline-offset: unset !important;
    box-shadow: unset !important;
    border: none !important;
  }

  .create_pst {
    color: ${(props) =>
      props.theme.DashboardContentTwoColors.GridButton.p_a_color} !important;
    font-size: ${(props) =>
      props.theme.DashboardContentTwoColors.GridButton
        .gridbutton_font_size} !important;
  }
  p {
    a {
      font-size: 16px;
      background-color: transparent;
      color: ${(props) =>
        props.theme.DashboardContentTwoColors.GridButton.p_a_color};
      border: none;
      text-align: center;
    }
    :hover {
      background-color: transparent;
    }
  }
  .gridbutton button {
    font-size: 16px;
    background-color: transparent;
    color: ${(props) => props.theme.post_createbtn_font_color};
    border: none;
    text-align: center;
  }
`;

export const MakePost = styled.div`
  .addpost {
    display: table;
    width: 100%;
    border-bottom: 1px solid #0e8a8b;
    border-top: 1px solid #0e8a8b;

    div {
      display: table-cell;
      vertical-align: middle;
      :nth-child(2) {
        ul {
          list-style: none;
          margin: 0;
          float: right;
          li {
            display: inline-block;
            padding: 10px;
            font-size: 16px;
            color: ${(props) =>
              props.theme.DashboardContentTwoColors.MakePost
                .nthChild_2_li_color};
          }
        }
        :nth-child(1) {
          p {
            color: ${(props) =>
              props.theme.DashboardContentTwoColors.MakePost
                .nthChild_1_li_color};
            font-size: 16px;
            margin-bottom: 0px;
            padding: 10px;
          }
        }
      }
    }
  }
  .modal-body {
    p {
      font-size: 16px;
      color: ${(props) =>
        props.theme.DashboardContentTwoColors.MakePost.modalbody_p_color};
      font-weight: 500;
      padding-right: 30px;
      margin-bottom: 70px;
    }
  }
  .postcontnet {
    display: table;
    width: 100%;
    div {
      display: table-cell;
      vertical-align: middle;

      :nth-child(1) {
        width: 10%;
        vertical-align: top;
      }

      :nth-child(2) {
        width: 90%;
        h4 {
          color: ${(props) =>
            props.theme.post_addpostpopup_username_font_color};
          margin: 0;
        }
        p {
          font-weight: 500;
          font-size: 14px;
          color: ${(props) =>
            props.theme.post_addpostpopup_account_font_colorr};
          margin-bottom: 0px;
        }
      }
    }
  }
  .modal-content {
    width: 450px !important;
    border-radius: 10px;
    border: none;
  }
  .modal-header {
    background-color: #0e8a8b;
    .modal-title,
    button {
      color: #fff !important;
      opacity: 1 !important;
    }

    border-top-left-radius: calc(1rem - 1px);
    border-top-right-radius: calc(1rem - 1px);
  }
  .modal {
    background-color: #ffffff8c !important;
    .modal-dialog {
      right: 2%;
      top: 20%;
    }
  }
`;

const PostButton = styled.div`
  margin-top: 20px;
  button {
    background-color: ${(props) => props.theme.post_addpostpopup_postbtn_bg_color};;
    border: 1px solid #e5e5e5;
    color: ${(props) => props.theme.post_addpostpopup_postbtn_font_color};
    width: 100%;
    padding: 5px;
    border-radius: 20px;
  }
`;

const AddPost = styled.form`
  display: table;
  width: 100%;
  height: 300px;
  border-bottom: 1px solid #0e8a8b;
  .icon_txt_align {
    border-bottom: 1px solid #0e8a8b;
    display: block !important;
  }
  .txt_area_align {
    min-height: 100px;
    border: none !important;
  }
`;

const PostContent = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 12%;
      vertical-align: top;
    }
    :nth-child(2) {
      width: 88%;
      h4 {
        color: ${(props) => props.theme.post_addpostpopup_username_font_color};
        margin: 0;
      }
      p {
        font-weight: 500;
        font-size: 14px;
        color: ${(props) => props.theme.post_addpostpopup_account_font_color};
        margin-bottom: 0px;
      }
    }
  }
`;
