import React, { Component } from "react";
import FooterMenu from "../dashboard/components/FooterMenu";
import DashboardContentTwo from "./seconddashboard";
import Thirddashboard from "./thirddashboard";
import Message from "./message";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";

import Persona from "./components/Submenu/Persona";
import DropdownContent from "./components/Submenu/DropdownContent";
import Counts from "./components/Submenu/Counts";
import "../dashboard/components/header.css";

function Lastestpost() {
  return (
    <>
      
        <GlobalStyle>
          <Header>
            <div>
              <h3>Your Schedule</h3>
            </div>

            <div>
              <input placeholder="Search" />
            </div>
          </Header>

          <Firstschedule className="row">
            <div className="col-md-4">
              <img
                src={require("../../assets/webimage1.png")}
                className="img-responsive"
              />
              <div className="gridtext2">
                <p>Sendor or Source</p>
                <h3>Title Goes Here</h3>
                <p>
                  Preview text goes here, no more then two rows like this one
                  with two dots at the end.
                </p>
                <div className="gridtext3">
                  <p>Health | Technology | St.Mary's</p>
                </div>
              </div>
            </div>
            <div className="col-md-5">
              <Readhistory>
                <ul>
                  <li>
                    <img
                      src={require("../../assets/image1.png")}
                      className="img-responsive"
                    />
                  </li>
                  <li>
                    <GridText2>
                      <p>Thomas Smith</p>
                      <h3>Eureka Moment</h3>
                      <p>A Supercomputer Analyzed Covid-19 and an interes...</p>
                      <GridText3>
                        <p>Health | Technology | St.Mary's</p>
                      </GridText3>
                    </GridText2>
                  </li>
                  <li>
                    <p>4h</p>
                    <p>
                      <i className="fa fa-smile-o" aria-hidden="true"></i>
                    </p>
                  </li>
                </ul>
              </Readhistory>
              <Readhistory>
                <ul>
                  <li>
                    <img
                      src={require("../../assets/image1.png")}
                      className="img-responsive"
                    />
                  </li>
                  <li>
                    <GridText2>
                      <p>Thomas Smith</p>
                      <h3>Eureka Moment</h3>
                      <p>A Supercomputer Analyzed Covid-19 and an interes...</p>
                      <GridText3>
                        <p>Health | Technology | St.Mary's</p>
                      </GridText3>
                    </GridText2>
                  </li>
                  <li>
                    <p>4h</p>
                    <p>
                      <i className="fa fa-smile-o" aria-hidden="true"></i>
                    </p>
                  </li>
                </ul>
              </Readhistory>
            </div>
            <OwnNetwotk className="col-md-3">
              <OwnNetwotkHeader>
                <h2>New Content from your network</h2>
              </OwnNetwotkHeader>
              <OwnNetwotkBg>
                <ul>
                  <li>Can Hoskan</li>

                  <li>Sep 1</li>
                </ul>
                <h4>Title Goes Here, maybe 2 line possible</h4>

                <GridText2>
                  <p>Health | Technology | St.Mary's</p>
                </GridText2>
                <Checklib>
                  <p>Check in Library</p>
                </Checklib>
              </OwnNetwotkBg>
            </OwnNetwotk>
          </Firstschedule>
          <div className="row ">
            <History>
              <div className="col-md-7 ">
                <h3>Based on your Reading History</h3>
                <Readhistory>
                  <ul>
                    <li>
                      <img
                        src={require("../../assets/image1.png")}
                        className="img-responsive"
                      />
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interesting
                          New Theory Has Emerged. A closer look at the
                          Bradykinin hypothesis
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <img
                        src={require("../../assets/image1.png")}
                        className="img-responsive"
                      />
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interesting
                          New Theory Has Emerged. A closer look at the
                          Bradykinin hypothesis
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <img
                        src={require("../../assets/image1.png")}
                        className="img-responsive"
                      />
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interesting
                          New Theory Has Emerged. A closer look at the
                          Bradykinin hypothesis
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <img
                        src={require("../../assets/image1.png")}
                        className="img-responsive"
                      />
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interesting
                          New Theory Has Emerged. A closer look at the
                          Bradykinin hypothesis
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <img
                        src={require("../../assets/image1.png")}
                        className="img-responsive"
                      />
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interesting
                          New Theory Has Emerged. A closer look at the
                          Bradykinin hypothesis
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
              </div>
              <Trends className="col-md-5">
                <h3>Trending on HypalQ</h3>

                <Readhistory>
                  <ul>
                    <li>
                      <h1>01</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <h1>02</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <h1>03</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <h1>04</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <h1>05</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
                <Readhistory>
                  <ul>
                    <li>
                      <h1>06</h1>
                    </li>
                    <li>
                      <GridText2>
                        <p>Thomas Smith</p>
                        <h3>Eureka Moment</h3>
                        <p>
                          A Supercomputer Analyzed Covid-19 and an interes...
                        </p>
                        <GridText3>
                          <p>Health | Technology | St.Mary's</p>
                        </GridText3>
                      </GridText2>
                    </li>
                    <li>
                      <p>4h</p>
                      <p>
                        <i className="fa fa-smile-o" aria-hidden="true"></i>
                      </p>
                    </li>
                  </ul>
                </Readhistory>
              </Trends>
            </History>
            <button
              type="button"
              data-toggle="modal"
              data-target="#myModalcreatepost"
            >
              <i className="fa fa-plus" aria-hidden="true"></i> Make a Post
            </button>
          </div>
        </GlobalStyle>
    
    </>
  );
}


export default Lastestpost;

const GlobalStyle = styled.div`
  background-color: #fff;
  input {
    float: right;
  }
`;

const Header = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 80%;
    }
    :nth-child(2) input {
      background-color: #dae7e4;
      border-radius: 50px;
      padding: 5px;
      border: none;
      margin: 10px;
    }
  }
`;

const Firstschedule = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
  margin-bottom: 10px;
`;

const GridText2 = styled.div`
  padding-left: 10px;
  padding-right: 0px;
  h3 {
    font-size: 16px;
    color: #7f00ab;
    margin-bottom: 0px;
  }
  p {
    margin-bottom: 5px;
    font-size: 11px;
  }
`;

const GridText3 = styled.div`
  p {
    color: #738c87;
    font-size: 11px;
  }
`;

const OwnNetwotk = styled.div`
  padding: 10px;
`;

const OwnNetwotkHeader = styled.div`
  background-color: #7f00ab;
  padding: 0px 10px 0px 10px;
`;

const OwnNetwotkBg = styled.div`
  background-color: #f3fffd;
  margin-top: -10px;
  h4 {
    color: #7f00ab;
    font-weight: 600;
    padding: 10px 12px 0px 12px;
  }
  .gridtext3 {
    p {
      padding: 0px 12px;
    }
  }
  ul {
    list-style: none;
    margin: 0px;
    li {
      display: inline-block;
      padding: 5px 10px;
      :nth-child(2) {
        float: right;
      }
    }
  }
`;

const History = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
`;

const Readhistory = styled.div`
  ul {
    display: flex;
    margin: 0;
    list-style: none;
    li {
      margin-right: 5px;
      h1 {
        color: #e5ccee;
        font-size: 45px;
      }
    }
  }
`;

const Trends = styled.div`
  padding: 0px;
`;

const Checklib = styled.div`
  p {
    text-align: right;
    padding: 0px 10px;
    color: #0e8a8b;
    font-size: 13px;
    font-weight: 600;
  }
`;
