import React, { Component, useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../../exportables/Colors";
import { useSelector, useDispatch } from "react-redux";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import { viewSpecificPost } from "../../store/LandingPage/index";
import "../dashboard/components/header.css";

export default function PostView() {
  const dispatch = useDispatch();
  const selPost = useSelector((state) => state.landingpage.selectedPost);

  return (
    <>
      <ThemeProvider theme={mytheme}>
        <div className="col-md-6 fullmail">
          <div className="mailtitle">
            <div>
              {selPost.length > 0 ? <h3>{selPost[0].postTitle}</h3> : null}
            </div>
            <div>
              <ul className="row">
                <li>
                  <div>
                    <button
                      className="btn"
                      onClick={() => dispatch(viewSpecificPost())}
                    >
                      X
                    </button>
                  </div>
                  <li className="mail_time">
                    <div>
                      {" "}
                      {selPost[0].publishedTime == "0m"
                        ? `now`
                        : selPost[0].publishedTime}
                    </div>
                  </li>
                </li>
              </ul>
            </div>
          </div>
          {selPost.length > 0 ? (
            <div>
              <img
                src={
                  selPost[0].postThumbnailURL !== ""
                    ? selPost[0].postThumbnailURL
                    : selPost[0].postPlaceHolder
                }
                style={{ width: "100%", height: "200px" }}
              />{" "}
              <br />
              <br />
              <p> {selPost[0].postUserName}</p>
              <p>{ReactHtmlParser(selPost[0].postContent)}</p>
              {selPost[0].postChecksumIds &&
              selPost[0].postChecksumIds.length > 0
                ? 
                <div className="row" style={{marginLeft:"0px"}}>
                  <b>Tagged Users :</b>
                  {selPost[0].postChecksumIds.map((user)=>(
                    <p style={{marginLeft:"5px"}}>{user.userTitle}{user.userFirstName}{' '}{user.userLastName}</p>
                  ))}
                </div>
                : null}
            </div>
          ) : null}
        </div>
      </ThemeProvider>
    </>
  );
}

const GlobalStyle = styled.section``;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne
          .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;

export const ComposeMessage = styled.div`
  .modal .modal-dialog {
    transform: translate(0px, 100px) !important;
  }
  .modal-header {
    background-color: ${(props) =>
      props.theme.DashboardContentThreeColors.ComposeMessage
        .modal_header_backgroundcolor};
    color: ${(props) =>
      props.theme.DashboardContentThreeColors.ComposeMessage.h4_color};

    border-radius: 10px 10px 0px 0px;
    h4 {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      font-size: 20px;
    }
    button {
      font-size: 30px;
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      opacity: 1;
      font-weight: 400;
      padding: 5px;
    }
  }
  .modal-content {
    border: none;
    border-radius: 10px;
    width: 500px;
  }

  .messageto {
    color: ${(props) =>
      props.theme.DashboardContentThreeColors.MessageForm
        .nthChild_2_li_color} !important;
    p input {
      border: none;
    }
  }
`;

const MessageForm = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) {
      p {
        margin: 0px;
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.MessageForm
            .nthChild_2_li_color};
        input {
          border: none;
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.MessageForm
            .nthChild_2_li_color};
        a {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MessageForm
              .nthChild_2_li_a_color};
        }
      }
    }
  }
`;

const MessageSubject = styled.div`
  border-top: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.MessageSubject.border_top};
  border-bottom: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.MessageSubject.border_bottom};
  input {
    border: none;
    padding: 5px;
  }
`;

const MessageBody = styled.div`
  width: 100%;
  border: none;
  height: 200px;
`;

const FileFormat = styled.div`
  border-top: 1.5px solid
    ${(props) => props.theme.DashboardContentThreeColors.FileFormat.border_top};
  border-bottom: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.FileFormat.border_bottom};
  ul {
    list-style: none;
    margin: 0;
    li {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.MessageForm
          .nthChild_2_li_color} !important;
      display: inline-block;
      padding: 10px;
      a {
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.FileFormat.li_a_color};
      }
    }
  }
`;

export const MailSend = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        font-weight: 500;
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.MailSend.li_color};
        i {
          margin-right: 5px;
        }
        :nth-child(1) {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MailSend.nthChild_1_color};
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        a {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MailSend.li_color};
        }
        display: inline-block;
        padding: 10px;
        text-align: right;
      }
    }
  }
`;
