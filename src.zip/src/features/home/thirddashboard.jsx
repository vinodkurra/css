import React, { useState, useEffect } from "react";
import styled, { ThemeProvider } from "styled-components";
import { GridButton } from "./seconddashboard";
import * as mytheme from "../../exportables/Colors";
import { Multiselect } from "multiselect-react-dropdown";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import {
  addToStarred,
  deleteMail,
  readAllMail,
  readMail,
  changeMailSlicer,
  viewMailFullscreen,
  viewMailExpander,
  getUserMails,
  selectedMailtoView,
  saveSearchedMailUsers,
  viewNewsExpander,
  viewSpecificNews,
  setSelectedNews,
  getAllNews,
} from "../../store/LandingPage/index";
import { useSelector, useDispatch } from "react-redux";
import { notification } from "../../json/sitedata";
import axios from "axios";
import { PageItem } from "react-bootstrap";
import draftToHtml from "draftjs-to-html";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, convertToRaw } from "draft-js";
import {
  mailServiceUrlWithToken,
  createMailUrl,
  checkSumId,
  postandnewsServiceUrlWithToken,
} from "../../calls/apis";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import JwtDecode from "jwt-decode";
import { result } from "lodash";

const Thirddashboard = () => {
  const styles = useSelector((state) => state.ui.styles);
  const [editorState, setEditorState] = useState(EditorState.createEmpty());

  const [ccDiv, showCcDiv] = useState(false);
  const [bccDiv, showbccDiv] = useState(false);
  const [option1, setOption1] = useState([]);

  const [show_options, setShowOptions] = useState(false);
  const [action_visible, setActionVisible] = useState(false);
  var [choosenMailId, pushId] = useState([]);
  const [checked, setChecked] = useState(false);
  const [showPrevNext, setshowPrevNext] = useState(true);
  const [current_page_mail, setCurrentPage] = useState(1);
  const [userdetails, setUserDetails] = useState({});

  //create mail
  const [fromMailId, setFromMail] = useState("");
  const [toMailIds, setToMails] = useState([]);
  const [ccMailIds, setCcMailIds] = useState([]);
  const [bccMailIds, setBccMailIds] = useState([]);
  const [subject, setSubject] = useState("");
  const [files, setFiles] = useState([]);
  const [link, setLink] = useState("");
  const [content, setContent] = useState("");

  const [linkName, setLinkName] = useState("");
  const [linkUrl, setLinkUrl] = useState("");

  const dispatch = useDispatch();
  const mailData = useSelector((state) => state.landingpage.mail);
  const mailSlicer = useSelector((state) => state.landingpage.mailSlicer);

  const userMails = useSelector((state) => state.landingpage.userMails);
  const newsData = useSelector((state) => state.landingpage.news);
  const searchedMailUserList = useSelector(
    (state) => state.landingpage.searchedMailUsers
  );

  const handleCheck = (data) => {
    setShowOptions(!false);
    if (choosenMailId.filter((el) => el.id === data.id).length === 0) {
      choosenMailId.push(data);
      setShowOptions(true);
    } else {
      setShowOptions(true);
      const index = choosenMailId.findIndex((el) => el.id === data.id);
      if (index > -1) {
        choosenMailId.splice(index, 1);
      }
    }
    if (choosenMailId.length === 0) {
      setShowOptions(false);
    }
  };

  useEffect(() => {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        setUserDetails(result.data);
        setFromMail(result.data.emailId);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  async function createMail() {
    let mailObj = {
      fromMail: {
        // emailId: localStorage.getItem("email"),
        // userId: JSON.parse(localStorage.getItem("account")).userid,
        // userName: JSON.parse(localStorage.getItem("account")).firstname,
        emailId: userdetails.emailId,
        userId: userdetails.userId,
        userName: userdetails.userName,
      },
      toMails: toMailIds,
      ccMails: ccMailIds,
      bccMails: bccMailIds,
      parentId: 0,
      body: draftToHtml(convertToRaw(editorState.getCurrentContent())),
      subject: subject,
    };
    console.log(mailObj)
    var formData = new FormData();
    formData.append("file", files[0]);
    formData.append("request", JSON.stringify(mailObj));

    await createMailUrl
      .post(`/email/create`, formData)
      .then((result) => {
        alert("Mail sent");
        dispatch(getUserMails(result.data));

        // dispatch(getUserMails(userMails));
      })
      .catch((err) => {
        console.log(err);
      });
    setEditorState(EditorState.createEmpty());
    setToMails([]);
    setCcMailIds([]);
    setBccMailIds([]);
    setFiles([]);
    setContent("");
    setSubject("");
    setLink("");
    document.getElementById("file").value = "";
  }

  async function getMail(page_id) {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        setUserDetails(result.data);
        setFromMail(result.data.emailId);

        if (page_id === 0) {
          setCurrentPage(1);
        } else if (page_id > 0) {
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: page_id,
            pageSize: 14,
          };

          mailServiceUrlWithToken
            .post(`/email/getall`, obj)
            .then((result) => {
              if (result.data.emailList.length > 0) {
                dispatch(getUserMails(result.data));
              } else {
                setCurrentPage(current_page_mail - 1);
                // dispatch(getUserMails(userMails));
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      });
  }

  async function getMailAfterRemove(page_id) {
    let access = localStorage.getItem("accesstoken");
    let decoded = JwtDecode(access);
    mailServiceUrlWithToken
      .get(`/email/${decoded.userReference}/userdetails`)
      .then((result) => {
        setUserDetails(result.data);
        setFromMail(result.data.emailId);

        if (page_id === 0) {
          setCurrentPage(1);
        } else if (page_id > 0) {
          let obj = {
            emailId: result.data.emailId,
            mailType: "INBOX",
            page: page_id,
            pageSize: 14,
          };

          mailServiceUrlWithToken
            .post(`/email/getall`, obj)
            .then((result) => {
              dispatch(getUserMails(result.data));
            })
            .catch((err) => {
              console.log(err);
            });
        }
      });
  }
  async function bulkUpdateUserMAil(data) {
    setShowOptions(false);
    pushId([]);
    var checkboxes = document.getElementsByName("rowSelectCheckBox");
    for (var i = 0, n = checkboxes.length; i < n; i++) {
      checkboxes[i].checked = false;
    }
    await mailServiceUrlWithToken
      .put(`/email/bulkupdate`, data)
      .then(async (result) => {
        await getMailAfterRemove(current_page_mail);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  return (
    <>
      <ThemeProvider theme={styles.landing_page}>
        {" "}
        <div>
          <GlobalStyle>
            <div
              className="container thirddashboard"
              style={{ padding: "0px " }}
            >
              <div className="row">
                <MailContent>
                  <div className="mail_box_hr_align">
                    <h3>Mail</h3>
                    <h6>
                      {userMails
                        ? userMails.totalMailCount > 0
                          ? userMails.startingMailIndex
                          : 0
                        : null}{" "}
                      -{" "}
                      {userMails
                        ? userMails.totalMailCount > 0
                          ? userMails.endingMailIndex
                          : 0
                        : null}{" "}
                      of {userMails ? userMails.totalMailCount : null}
                      {"  "}
                      {showPrevNext ? (
                        <i
                          class="fa fa-angle-left"
                          onClick={() => {
                            pushId([]);
                            var checkboxes = document.getElementsByName(
                              "rowSelectCheckBox"
                            );
                            for (var i = 0, n = checkboxes.length; i < n; i++) {
                              checkboxes[i].checked = false;
                            }
                            setCurrentPage(
                              current_page_mail > 1
                                ? current_page_mail - 1
                                : current_page_mail
                            );
                            getMail(
                              current_page_mail > 1
                                ? current_page_mail - 1
                                : current_page_mail
                            );
                          }}
                          aria-hidden="true"
                        ></i>
                      ) : null}
                      {showPrevNext ? (
                        <i
                          class="fa fa-angle-right"
                          onClick={() => {
                            pushId([]);
                            var checkboxes = document.getElementsByName(
                              "rowSelectCheckBox"
                            );
                            for (var i = 0, n = checkboxes.length; i < n; i++) {
                              checkboxes[i].checked = false;
                            }
                            setCurrentPage(current_page_mail + 1);
                            getMail(current_page_mail + 1);
                          }}
                          aria-hidden="true"
                        ></i>
                      ) : null}
                    </h6>
                  </div>
                  <div>
                    <ul>
                      {show_options ? (
                        <li
                          onClick={() => {
                            var aa = choosenMailId.map((t) => {
                              return {
                                isDeleted: false,
                                isRead: true,
                                isStarred: t.isStarred,
                                mailBoxId: t.id,
                              };
                            });
                            let obj = {
                              updateRequest: aa,
                              updateType: "READ",
                            };
                            bulkUpdateUserMAil(obj);
                          }}
                        >
                          <i class="fa fa-eye" aria-hidden="true"></i>
                        </li>
                      ) : null}
                      {show_options ? (
                        <li
                          onClick={() => {
                            //dispatch(deleteMail(choosenMailId));
                            var aa = choosenMailId.map((t) => {
                              return {
                                isDeleted: true,
                                isRead: t.isRead,
                                isStarred: t.isStarred,
                                mailBoxId: t.id,
                              };
                            });
                            let obj = {
                              updateRequest: aa,
                              updateType: "DELETE",
                            };
                            bulkUpdateUserMAil(obj);
                          }}
                        >
                          <i class="fa fa-trash" aria-hidden="true"></i>
                        </li>
                      ) : null}
                      <li>
                        <i class="fa fa-search" aria-hidden="true"></i>
                      </li>
                      <li className="dropdown" id="bulkaction">
                        <span
                          style={{ padding: "0px 0px 0px 0px" }}
                          type="button"
                          className="dropdown-toggle"
                          data-toggle="dropdown"
                        >
                          <i
                            style={{ width: "5px" }}
                            className="fa fa-ellipsis-v"
                          ></i>{" "}
                          <div
                            className="dropdown-menu"
                            aria-labelledby="bulkaction"
                          >
                            <form>
                              <p
                                className="dropdown-item"
                                style={{ cursor: "pointer" }}
                              >
                                <input
                                  id="rowSelectCheckBox"
                                  name="rowSelectCheckBox"
                                  type="checkbox"
                                  style={{ cursor: "pointer" }}
                                  // checked={checked}
                                  onChange={() => {
                                    // setChecked(!checked);
                                    setShowOptions(!show_options);
                                    pushId(userMails.emailList);
                                    var checkboxes = document.getElementsByName(
                                      "rowSelectCheckBox"
                                    );
                                    for (
                                      var i = 0, n = checkboxes.length;
                                      i < n;
                                      i++
                                    ) {
                                      checkboxes[i].checked = !show_options;
                                    }

                                    if (show_options === true) {
                                      pushId([]);
                                    }
                                  }}
                                />{" "}
                                <label
                                  for="rowSelectCheckBox"
                                  style={{ cursor: "pointer" }}
                                >
                                  {" "}
                                  {show_options === false
                                    ? "Select All"
                                    : "Unselect All"}
                                </label>
                              </p>
                            </form>
                          </div>
                        </span>
                      </li>
                      <li>
                        <i
                          class="fa fa-crosshairs"
                          aria-hidden="true"
                          onClick={() => dispatch(viewMailExpander())}
                        ></i>
                      </li>
                    </ul>
                  </div>
                </MailContent>
              </div>
              <div
                className="row"
                style={{
                  overflowY: "scroll",
                  height: "400px",
                  overflowX: "hidden",
                  display: "block",
                  //flexDirection:"column"
                }}
              >
                {userMails
                  ? userMails.emailList.map((data) => (
                      <InboxGrid
                        className={
                          data.isRead === false
                            ? "highlight_unread read"
                            : "read"
                        }
                      >
                        <InboxGridInnerTwo className="col-md-1">
                          <input
                            style={{ cursor: "pointer" }}
                            name="rowSelectCheckBox"
                            type="checkbox"
                            onChange={handleCheck.bind(null, data)}
                          />
                          <p>
                            {data.isStarred === false ? (
                              <i
                                style={{ cursor: "pointer" }}
                                class="fa fa-star-o"
                                aria-hidden="true"
                                onClick={() => {
                                  let aa = {
                                    isDeleted: false,
                                    isRead: data.isRead,
                                    isStarred: !data.isStarred,
                                    mailBoxId: data.id,
                                  };

                                  let obj = {
                                    updateRequest: [aa],
                                    updateType: "STARRED",
                                  };
                                  bulkUpdateUserMAil(obj);
                                  //dispatch(addToStarred([data.id]))
                                }}
                              ></i>
                            ) : (
                              <i
                                style={{ color: "#f5aa42", cursor: "pointer" }}
                                class="fa fa-star"
                                aria-hidden="true"
                                onClick={
                                  () => {
                                    let aa = {
                                      isDeleted: false,
                                      isRead: data.isRead,
                                      isStarred: !data.isStarred,
                                      mailBoxId: data.id,
                                    };

                                    let obj = {
                                      updateRequest: [aa],
                                      updateType: "STARRED",
                                    };
                                    bulkUpdateUserMAil(obj);
                                  }
                                  // dispatch(addToStarred([data.id]))
                                }
                              ></i>
                            )}
                          </p>
                        </InboxGridInnerTwo>

                        <InboxGridInnerOne
                          className="col-md-9"
                          onClick={() => {
                            dispatch(selectedMailtoView(data));
                            dispatch(viewMailFullscreen());
                            let aa = {
                              isDeleted: false,
                              isRead: true,
                              isStarred: data.isStarred,
                              mailBoxId: data.id,
                            };

                            let obj = {
                              updateRequest: [aa],
                              updateType: "READ",
                            };
                            bulkUpdateUserMAil(obj);
                          }}
                        >
                          {data.isRead === false ? (
                            <div>
                              <p>
                                <strong>{data.fromMail.userName}</strong>
                              </p>
                              <h3>
                                <strong>{data.subject}</strong>
                              </h3>
                              <p>
                                <strong>
                                  {ReactHtmlParser(data.body.slice(0, 20))}
                                </strong>
                              </p>
                            </div>
                          ) : (
                            <div>
                              <p>{data.fromMail.userName}</p>
                              <h3>{data.subject}</h3>
                              <p>{ReactHtmlParser(data.body.slice(0, 35))}</p>
                            </div>
                          )}
                        </InboxGridInnerOne>
                        {data.isRead === false ? (
                          <div className="col-md-2 inboxtime">
                            <p>
                              <strong>{data.entry_time}</strong>
                            </p>
                          </div>
                        ) : (
                          <div className="col-md-2 inboxtime">
                            <p>{data.entry_time}</p>
                          </div>
                        )}
                      </InboxGrid>
                    ))
                  : null}

                {/* modal start */}

                {/* modal start */}
                <ComposeMessage>
                  <div className="modal" id="compossmsg" role="dialog">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">New Message</h4>
                          <button
                            type="button"
                            class="close"
                            data-dismiss="modal"
                          >
                            &times;
                          </button>
                        </div>
                        <div class="modal-body">
                          <MessageForm>
                            <div>
                              <p>
                                From <input value={fromMailId} />{" "}
                              </p>
                            </div>

                            <div>
                              <ul>
                                <li
                                  style={{ cursor: "pointer" }}
                                  onClick={() => showCcDiv(!ccDiv)}
                                >
                                  <a>Cc</a>
                                </li>
                                <li
                                  style={{ cursor: "pointer" }}
                                  onClick={() => showbccDiv(!bccDiv)}
                                >
                                  <a>Bcc</a>
                                </li>
                              </ul>
                            </div>
                          </MessageForm>

                          <div className="messageto">
                            <p>
                              {/* To <input /> */}
                              To
                              <Multiselect
                                options={option1}
                                selectedValues={toMailIds}
                                onSelect={(e) => {
                                  if (
                                    e[0].userId == "all" ||
                                    e.filter((el) => el.userId == "all")
                                      .length > 0
                                  ) {
                                    option1.shift();
                                    e = option1;
                                    setOption1([]);
                                  }
                                  setToMails(e);
                                }}
                                onRemove={(e) => {
                                  setToMails(e);
                                }}
                                onSearch={async (e) => {
                                  setOption1([]);

                                  if (e.toString().length === 0) {
                                  } else {
                                    let access = localStorage.getItem(
                                      "accesstoken"
                                    );
                                    let decoded = JwtDecode(access);
                                    await mailServiceUrlWithToken
                                      .get(
                                        `/email/search/${decoded.userReference}/users?filter=${e}`
                                      )
                                      .then((result) => {
                                        console.log(
                                          result.data.userDetails.length
                                        );
                                        // result.data.userDetails.unshift({
                                        //   emailId: "-----Select All-----",
                                        //   userName: "-----Select All-----",
                                        //   userId: "all",
                                        // });
                                        setOption1(result.data.userDetails);
                                        //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                      })
                                      .catch((err) => {
                                        console.log(err);
                                      });
                                  }
                                }}
                                displayValue="emailId"
                                avoidHighlightFirstOption={true}
                                placeholder=""
                                emptyRecordMsg=""
                                style={{
                                  chips: {
                                    background: "#e2e2e2",
                                    color: "#4a4a4a",
                                  },
                                  // searchBox: {
                                  //   border: "none",
                                  //   "border": "1px solid",
                                  //   "border": "0px",
                                  // },
                                  multiselectContainer: {
                                    color: "black",
                                  },
                                  optionContainer: {
                                    border: "none",
                                    border: "0px solid",
                                    border: "0px",
                                  },
                                }}
                              />
                            </p>
                          </div>
                          {ccDiv === true ? (
                            <div className="messageto">
                              <p>
                                {/* To <input /> */}
                                Cc
                                <Multiselect
                                  options={option1}
                                  selectedValues={ccMailIds}
                                  onSelect={(e) => {
                                    // if (
                                    //   e[0].userId == "all" ||
                                    //   e.filter((el) => el.userId == "all")
                                    //     .length > 0
                                    // ) {
                                    //   option1.shift();
                                    //   e = option1;
                                    //   setOption1([]);
                                    // }
                                    setCcMailIds(e);
                                  }}
                                  onRemove={(e) => {
                                    setCcMailIds(e);
                                  }}
                                  onSearch={async (e) => {
                                    setOption1([]);

                                    if (e.toString().length === 0) {
                                    } else {
                                      let access = localStorage.getItem(
                                        "accesstoken"
                                      );
                                      let decoded = JwtDecode(access);
                                      await mailServiceUrlWithToken
                                        .get(
                                          `/email/search/${decoded.userReference}/users?filter=${e}`
                                        )
                                        .then((result) => {
                                          console.log(
                                            result.data.userDetails.length
                                          );
                                          setOption1(result.data.userDetails);
                                          //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                        })
                                        .catch((err) => {
                                          console.log(err);
                                        });
                                    }
                                  }}
                                  displayValue="emailId"
                                  avoidHighlightFirstOption={true}
                                  placeholder=""
                                  emptyRecordMsg=""
                                  style={{
                                    chips: {
                                      background: "#e2e2e2",
                                      color: "#4a4a4a",
                                    },
                                    // searchBox: {
                                    //   border: "none",
                                    //   "border": "1px solid",
                                    //   "border": "0px",
                                    // },
                                    multiselectContainer: {
                                      color: "black",
                                    },
                                    optionContainer: {
                                      border: "none",
                                      border: "0px solid",
                                      border: "0px",
                                    },
                                  }}
                                />
                              </p>
                            </div>
                          ) : null}
                          {bccDiv === true ? (
                            <div className="messageto">
                              <p>
                                {/* To <input /> */}
                                Bcc
                                <Multiselect
                                  options={option1}
                                  selectedValues={bccMailIds}
                                  onSelect={(e) => {
                                    // if (
                                    //   e[0].userId == "all" ||
                                    //   e.filter((el) => el.userId == "all")
                                    //     .length > 0
                                    // ) {
                                    //   option1.shift();
                                    //   e = option1;
                                    //   setOption1([]);
                                    // }
                                    setBccMailIds(e);
                                  }}
                                  onRemove={(e) => {
                                    setBccMailIds(e);
                                  }}
                                  onSearch={async (e) => {
                                    setOption1([]);

                                    if (e.toString().length === 0) {
                                      console.log("empty");
                                    } else {
                                      let access = localStorage.getItem(
                                        "accesstoken"
                                      );
                                      let decoded = JwtDecode(access);
                                      await mailServiceUrlWithToken
                                        .get(
                                          `/email/search/${decoded.userReference}/users?filter=${e}`
                                        )
                                        .then((result) => {
                                          console.log(
                                            result.data.userDetails.length
                                          );
                                          setOption1(result.data.userDetails);
                                          //dispatch(saveSearchedMailUsers(result.data.userDetails))
                                        })
                                        .catch((err) => {
                                          console.log(err);
                                        });
                                    }
                                  }}
                                  displayValue="emailId"
                                  avoidHighlightFirstOption={true}
                                  placeholder=""
                                  emptyRecordMsg=""
                                  style={{
                                    chips: {
                                      background: "#e2e2e2",
                                      color: "#4a4a4a",
                                    },
                                    // searchBox: {
                                    //   border: "none",
                                    //   "border": "1px solid",
                                    //   "border": "0px",
                                    // },
                                    multiselectContainer: {
                                      color: "black",
                                    },
                                    optionContainer: {
                                      border: "none",
                                      border: "0px solid",
                                      border: "0px",
                                    },
                                  }}
                                />
                              </p>
                            </div>
                          ) : null}
                          <MessageSubject>
                            <input
                              placeholder="subject"
                              value={subject}
                              onChange={(e) => setSubject(e.target.value)}
                            />
                          </MessageSubject>
                          <MessageBody>
                            <Editor
                              id="editor"
                              editorState={editorState}
                              toolbarClassName={{ order: 2 }}
                              wrapperClassName={{
                                display: "flex",
                                "flex-direction": "column",
                                top: "auto",
                                bottom: "10px",
                              }}
                              editorClassName={{ order: 1 }}
                              toolbar={{
                                options: ["inline", "textAlign", "link"],
                              }}
                              onEditorStateChange={(e) => {
                                setEditorState(e);
                                // setContent(

                                //     convertToRaw(
                                //       editorState.getCurrentContent()

                                //   )
                                // );
                                const blocks = convertToRaw(
                                  editorState.getCurrentContent()
                                ).blocks;
                                const value = blocks
                                  .map(
                                    (block) =>
                                      (!block.text.trim() && "\n") || block.text
                                  )
                                  .join("\n");
                                setContent(value);
                              }}
                            />
                          </MessageBody>

                          <MailSend>
                            <div>
                              <ul>
                                <li
                                  style={{ cursor: "pointer" }}
                                  onClick={() => createMail()}
                                  data-toggle="modal"
                                  data-target="#compossmsg"
                                >
                                  <i className="fa fa-send-o"></i> Send
                                </li>

                                <li>
                                  {/* <i className="fa fa-paperclip"></i> */}
                                  <input
                                    id="file"
                                    type="file"
                                    onChange={(e) => setFiles(e.target.files)}
                                  />{" "}
                                  {/* Attach Files */}
                                </li>
                              </ul>
                            </div>

                            <div>
                              <ul>
                                <li>
                                  <a href="#">
                                    <i className="fa fa-ellipsis-v"></i>
                                  </a>
                                </li>

                                <li>
                                  <a href="#">
                                    <i className="fa fa-trash-o"></i>{" "}
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </MailSend>
                        </div>
                      </div>
                    </div>
                  </div>
                </ComposeMessage>
                {/* modal end */}

                {/* modal end */}
              </div>

              <GridButton className="col-md-12">
                <p class="dropdown">
                  <a
                    class="btn btn-lg btn_create"
                    data-toggle="modal"
                    data-target="#compossmsg"
                  >
                    + Create Mail
                  </a>
                </p>
              </GridButton>
            </div>
          </GlobalStyle>

          <GlobalStyle>
            <div className="container news_board">
              <div className="row">
                <NewsMail >
                  <div>
                    <h3>News</h3>
                  </div>
                  <div>
                    <ul>
                      <li>
                        <i class="fa fa-search" aria-hidden="true"></i>
                      </li>

                      <li>
                        <i
                          class="fa fa-crosshairs"
                          aria-hidden="true"
                          style={{ cursor: "pointer" }}
                          onClick={() => dispatch(viewNewsExpander())}
                        ></i>
                      </li>
                    </ul>
                  </div>
                </NewsMail>
              </div>
              <div className="row new_post">
                {newsData && newsData.length > 0
                  ? newsData.map((data) => (
                      <InboxGrid>
                        <InboxGridInnerTwo className="col-md-1 news_post_icn">
                          <p>
                            {data.starred === false ? (
                              <i
                                style={{ cursor: "pointer" }}
                                class="fa fa-star-o"
                                aria-hidden="true"
                                onClick={async () => {
                                  await postandnewsServiceUrlWithToken
                                    .put(
                                      `/news/starred/${
                                        data.id
                                      }/${!data.starred}`
                                    )
                                    .then(async (result) => {
                                      await postandnewsServiceUrlWithToken
                                        .get(`/news/getall/1/10`)
                                        .then((result) => {
                                          dispatch(
                                            getAllNews(result.data.data)
                                          );
                                        })
                                        .catch((err) => {
                                          console.log(err);
                                        });
                                    })
                                    .catch((err) => {
                                      console.log(err);
                                    });
                                }}
                              ></i>
                            ) : (
                              <i
                                style={{ color: "#f5aa42", cursor: "pointer" }}
                                class="fa fa-star"
                                aria-hidden="true"
                                onClick={async () => {
                                  await postandnewsServiceUrlWithToken
                                    .put(
                                      `/news/starred/${
                                        data.id
                                      }/${!data.starred}`
                                    )
                                    .then(async (result) => {
                                      await postandnewsServiceUrlWithToken
                                        .get(`/news/getall/1/10`)
                                        .then((result) => {
                                          dispatch(
                                            getAllNews(result.data.data)
                                          );
                                        })
                                        .catch((err) => {
                                          console.log(err);
                                        });
                                    })
                                    .catch((err) => {
                                      console.log(err);
                                    });
                                }}
                              ></i>
                            )}
                          </p>
                        </InboxGridInnerTwo>
                        <InboxGridInnerOne
                          className="col-md-9"
                          onClick={() => {
                            dispatch(setSelectedNews(data));
                            dispatch(viewSpecificNews());
                          }}
                        >
                          <div>
                            <p>Sendor or Source</p>
                            <h3 className="hr_title">{data.title}</h3>
                            <p className="msg_contnt">{data.content}</p>
                          </div>
                        </InboxGridInnerOne>
                        <div className="col-md-2 inboxtime">
                          <p>{data.entry_time}</p>
                        </div>
                      </InboxGrid>
                    ))
                  : null}
              </div>
            </div>
          </GlobalStyle>
        </div>
      </ThemeProvider>
    </>
  );
};

export default Thirddashboard;

const GlobalStyle = styled.section`
  background-color: #fff;
  padding: 10px 15px;
  margin-top: 30px;
  border-radius: 10px;
  .thirddashboard input[type="checkbox"],
  .news_board input[type="checkbox"] {
    margin: 4px 3px 0px !important;
  }

  .btn:hover,
  .btn:focus {
    color: unset !important;
  }
  .btn_create,
  .btn_create:focus,
  .btn_create:hover {
    color: #0094ff !important;
  }
  button:focus {
    outline: unset !important;
  }
  textarea {
    height: 100%;
    width: 100%;
    border: none;
  }
  .read {
    display: table;
  }
  .highlight_unread {
    background-color: ${(props) =>
      props.theme.DashboardContentThreeColors.InboxGridInnerOne
        .highlight_unread_post} !important;
  }
  .news_board {
    padding: 0px;
    h3.hr_title {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.InboxGridInnerOne
          .h3_highlight_green} !important;
    }
  }
`;

export const MailContent = styled.div`
  display: table;
  width: 100%;
  .mail_box_hr_align {
    padding: 0px 10px 0px 10px;
  }
  .dropdown-menu {
    display: none;
  }
  .dropdown.open {
    .dropdown-menu {
      display: block;
    }
  }
  div {
    h3 {
      color: ${(props) => props.theme.mail_header_font_color};
    }
    display: table-cell;
    :nth-child(2) {
      ul {
        list-style: none;
        text-align: right;
        li {
          display: inline-block;
          padding: 10px;
          cursor: pointer;
        }
      }
    }
    :nth-child(1) {
      display: inline-flex;
      h6 {
        margin-left: 10px;
        margin-top: 5px;
        i {
          margin-right: 10px;
          font-size: 14px;
          cursor: pointer;
          .dropdown-menu {
            display: none;
          }
          .dropdown.open {
            .dropdown-menu {
              display: block;
            }
          }
        }
      }
    }
  }
`;

const InboxGrid = styled.div`
  padding: 0px 10px 0px 10px;
  border-bottom: 2px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.InboxGrid.border_bottom};
  // margin-bottom: 5px;
  width: 100%;
  strong {
    font-weight: bold;
  }
`;

const InboxGridInnerOne = styled.div`
  b {
    font-weight: bold;
  }
  cursor: pointer;
  padding: 3px;
  p {
    color: ${(props) => props.theme.mail_read_sendersource_font_color};
    font-weight: 500;
    margin-bottom: 0px;
    font-size: 12px;
  }
  h3 {
    color: ${(props) => props.theme.mail_read_title_font_color};
    margin-bottom: 0px;
    font-size: 16px;
  }
`;

const InboxGridInnerTwo = styled.div`
  padding: 0;
  .col-md-1 {
    text-align: center;
  }
  .col-md-1 input[type="checkbox"] {
    width: 100%;
  }
  p {
    i {
      font-size: 14px;
      text-align: center;
      margin-left: 3px;
      margin-top: 4px;
    }
  }
`;

export const ComposeMessage = styled.div`
  .modal .modal-dialog {
    transform: translate(0px, 100px) !important;
  }
  .modal-header {
    background-color: ${(props) =>
      props.theme.DashboardContentThreeColors.ComposeMessage
        .modal_header_backgroundcolor};
    color: ${(props) => props.theme.mail_createpopup_header_font_color};

    border-radius: 10px 10px 0px 0px;
    h4 {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      font-size: 20px;
    }
    button {
      font-size: 30px;
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.ComposeMessage
          .h4_color} !important;
      opacity: 1;
      font-weight: 400;
      padding: 5px;
    }
  }
  .modal-content {
    border: none;
    border-radius: 10px;
    width: 500px;
  }

  .messageto {
    color: ${(props) =>
      props.theme.DashboardContentThreeColors.MessageForm
        .nthChild_2_li_color} !important;
    p input {
      border: none;
    }
  }
`;

const MessageForm = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) {
      p {
        margin: 0px;
        color: ${(props) => props.theme.mail_createpopup_frommail_font_color};
        input {
          border: none;
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        color: ${(props) => props.theme.mail_createpopup_ccbcclbl_font_color};
        a {
          color: ${(props) => props.theme.mail_createpopup_ccbcclbl_font_color};
        }
      }
    }
  }
`;

const MessageSubject = styled.div`
  border-top: 1.5px solid #c4c4c4;
  border-bottom: 1.5px solid #c4c4c4;
  input {
    border: none;
    padding: 5px;
  }
`;

export const MessageBody = styled.div`
  width: 100%;
  border: none;
  height: 200px;
`;

const FileFormat = styled.div`
  border-top: 1.5px solid
    ${(props) => props.theme.DashboardContentThreeColors.FileFormat.border_top};
  border-bottom: 1.5px solid
    ${(props) =>
      props.theme.DashboardContentThreeColors.FileFormat.border_bottom};
  ul {
    list-style: none;
    margin: 0;
    li {
      color: ${(props) =>
        props.theme.DashboardContentThreeColors.MessageForm
          .nthChild_2_li_color} !important;
      display: inline-block;
      padding: 10px;
      a {
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.FileFormat.li_a_color};
      }
    }
  }
`;

export const MailSend = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    :nth-child(1) ul {
      list-style: none;
      margin: 0;
      li {
        display: inline-block;
        padding: 10px;
        font-weight: 500;
        color: ${(props) =>
          props.theme.DashboardContentThreeColors.MailSend.li_color};
        i {
          margin-right: 5px;
        }
        :nth-child(1) {
          color: ${(props) =>
            props.theme.mail_createpopup_sendbtn_font_color};
        }
      }
    }
    :nth-child(2) ul {
      list-style: none;
      margin: 0;
      li {
        a {
          color: ${(props) =>
            props.theme.DashboardContentThreeColors.MailSend.li_color};
        }
        display: inline-block;
        padding: 10px;
        text-align: right;
      }
    }
  }
`;

const NewsMail = styled.div`
  display: table;
  width: 100%;
  padding: 0px 10px 0px 10px;
  div {
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      li {
        display: inline-block;
        padding: 10px;
      }
    }
  }
`;
