import React, { Component, useRef, useEffect, useState } from "react";
import firebase from "firebase/app";
import "firebase/analytics";
import "firebase/auth";
import "firebase/firestore";
import axios from "axios";
import "./fire.css";
import styled, { ThemeProvider } from "styled-components";
import { checkSumId } from "../../calls/apis";
import userIcon from "../.././assets/user-icon.jpg";
import ScrollableFeed from "react-scrollable-feed";
import { apiUrlWithToken } from "./../../calls/apis";

const firebaseConfig = {
  apiKey: "AIzaSyA5QBvFZMLBvA4JfMSGP66RtY5pntnfVTI",
  authDomain: "hypaiq-dev.firebaseapp.com",
  databaseURL: "https://hypaiq-dev.firebaseio.com",
  projectId: "hypaiq-dev",
  storageBucket: "hypaiq-dev.appspot.com",
  messagingSenderId: "959637468476",
  appId: "1:959637468476:web:1653bd158339e881e39a39",
  measurementId: "G-DNBPSMMTKP",
};

firebase.initializeApp(firebaseConfig);
firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE);

let db = firebase.firestore();
const firetoken = localStorage.getItem("firebasetoken");

const Firechat = () => {
  const [users, setUsers] = useState([]);
  const [chat, setChat] = useState([]);
  const [user2id, setUser2id] = useState("");
  const [message, setMessage] = useState("");
  const [conversations, setConversations] = useState([]);
  const [status, setStatus] = useState(null);
  const [person, setPerson] = useState("");
  const [show, setShow] = useState(false);
  const [search, setSearch] = useState("");
  const [userid, setUserid] = useState();
  const [filteredUsers, setFilteredUsers] = useState([]);
  const token = localStorage.getItem("token");
  const myRef = useRef(null);

  useEffect(() => {
    checkSumId.then((res) => {
      setUserid(res);
    });
  }, []);

  useEffect(() => {
    apiUrlWithToken
      .get(`/chat/search/${userid}/users?filter=`, {
        headers: {
          authorization: "Bearer " + token,
        },
      })
      .then((res) => {
        setUsers(res.data.userDetails);
      });
  }, [userid]);

  useEffect(() => {
    const usersList = () => {
      setFilteredUsers(
        users.filter((user) =>
          user.userName.toLowerCase().includes(search.toLowerCase())
        )
      );
    };
    usersList();
  }, [search, users]);

  useEffect(() => {
    firebase.auth().signInWithCustomToken(firetoken);
  }, []);
  useEffect(() => {
    fetchData();
  });
  const fetchData = async () => {
    // collecting messages from firestore
    const data = await db
      .collection("conversations")
      .orderBy("timestamp", "asc")
      .get();
    setConversations(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
  };

  const sendMessage = (e) => {
    e.preventDefault();
    if (message != "") {
      const messageinfo = {
        message: message,
        u_id: userid,
        u2_id: user2id,
        isView: false,
        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
      };
      // To send Messages to firestore
      db.collection("conversations").doc().set(messageinfo);
      setMessage("");
    }
  };

  return (
    <div>
      <MessageIcon>
        <div>
          <h6>Message</h6>
        </div>
        <div>
          <ul>
            <li>
              <div
                class="d-flex"
                style={{ display: "flex", alignItems: "center" }}
              >
                <input
                  type="text"
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search User"
                />
                <i
                  class="fa fa-search"
                  aria-hidden="true"
                  style={{ background: "white", height: "21px" }}
                ></i>
              </div>
            </li>
            <li>
              <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
            </li>
          </ul>
        </div>
      </MessageIcon>
      {filteredUsers.length > 0
        ? filteredUsers.map((user) => {
            return (
              <div
                onClick={() => {
                  setShow(!show);
                  setPerson(
                    user.userName.charAt(0).toUpperCase() +
                      user.userName.slice(1)
                  );
                  setUser2id(user.userId);
                  if (user.availableStatus == "1") {
                    setStatus("online");
                  } else {
                    setStatus("offline");
                  }
                }}
                class="d-flex "
                style={{
                  cursor: "pointer",
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                }}
                key={user.userId}
              >
                <span
                  className={
                    user.availableStatus == "1"
                      ? `onlineStatus`
                      : `onlineStatus off`
                  }
                ></span>
                <div class="p-2">
                  <img
                    src="https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
                    alt=""
                    style={{
                      marginLeft: "15px",
                      borderRadius: "50%",
                      width: "40px",
                    }}
                  />
                </div>
                <div
                  className="p-2"
                  style={{ fontSize: "15px", fontWeight: "400" }}
                >
                  {user.userName.charAt(0).toUpperCase() +
                    user.userName.slice(1)}
                </div>
                <br></br>
                <div className="inbox_txt"></div>
              </div>
            );
          })
        : null}
      {show == true ? (
        <div
          className="messagechat"
          style={{
            position: "fixed",
            bottom: 0,
            right: 30,
          }}
        >
          <div
            className="d-flex"
            style={{
              height: "55px",
              backgroundColor: "#388574",
              borderTopLeftRadius: "10px",
              borderTopRightRadius: "10px",
            }}
          >
            <div className="p-2">
              <img
                onClick={() => {}}
                src={userIcon}
                alt=""
                style={{ borderRadius: "50%", width: "35px" }}
              />
            </div>
            <div className="mr-auto p-2" style={{ color: "#FFFFFF" }}>
              <b>{person}</b>
              <br />
              <p>{status}</p>
            </div>
            <div
              className="p-2"
              style={{ cursor: "pointer", color: "#FFFFFF" }}
            >
              <i
                onClick={() => setShow(!show)}
                class="fa fa-minus"
                aria-hidden="true"
              ></i>
              <i
                onClick={() => setShow(!show)}
                class="fa fa-times"
                style={{ cursor: "pointer", marginLeft: "10px" }}
                aria-hidden="true"
              ></i>
            </div>
          </div>
          <div
            style={{
              backgroundColor: "#FFFFFF",
              height: "200px",
              overflowY: "scroll",
            }}
            className="chat-area"
          >
            <ScrollableFeed>
              {conversations
                .filter(
                  (con) =>
                    (con.u_id == userid && con.u2_id == user2id) ||
                    (con.u2_id == userid && con.u_id == user2id)
                )
                .map((con, i) => (
                  <div
                    className={
                      "chat-bubble " +
                      (userid == con.u_id ? "current-user" : "")
                    }
                    key={i}
                  >
                    <p style={{ width: "200px", wordWrap: "break-word" }}>
                      {con.message}
                    </p>
                  </div>
                ))}
            </ScrollableFeed>
          </div>
          <div
            className="d-flex"
            style={{ backgroundColor: "#FFFFFF", borderTop: "2px solid green" }}
          >
            <div className="mr-auto p-2 form-group">
              <form onSubmit={sendMessage} style={{ display: "flex" }}>
                <input
                  type="text"
                  style={{
                    padding: "5px 0px 0px 20px",
                    width: "220px",
                    fontSize: "16px",
                    flex: "0.80",
                    border: "1.5px solid lightseagreen",
                  }}
                  value={message}
                  onChange={(e) => {
                    setMessage(e.target.value);
                  }}
                  autoFocus
                ></input>

                <button
                  type="submit"
                  style={{
                    border: "none",
                    flex: "0.18",
                    marginLeft: "5px",
                    background: "white",
                  }}
                >
                  <i
                    class="fa fa-paper-plane-o"
                    aria-hidden="true"
                    color="white"
                  ></i>
                </button>
              </form>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
export default Firechat;
const MessageIcon = styled.div`
  display: table;
  width: 100%;
  div {
    h6 {
      font-weight: bold;
      font-size: medium;
    }
    display: table-cell;
    :nth-child(2) ul {
      list-style: none;
      text-align: right;
      margin-right: 10px;
      li {
        display: inline-block;
        padding: 10px;
      }
    }
  }
`;

const CreateMessage = styled.div`
  margin-top: 20px;
  button {
    background-color: ${(props) =>
      props.theme.DashboardContentFourColors.CreateMessage
        .d_flex_backgroundcolor};
    border: 2px solid
      ${(props) =>
        props.theme.DashboardContentFourColors.CreateMessage
          .button_border_color};
    color: ${(props) =>
      props.theme.DashboardContentFourColors.CreateMessage.button_border_color};
    border-radius: 30px;
    padding: 10px 40px;
    font-weight: 500;
  }
`;
