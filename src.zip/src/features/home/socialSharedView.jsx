import React, { useState, useEffect } from "react";
import ReactHtmlParser from "react-html-parser";
import logopng from "../../assets/logo.png";
import Axios from 'axios'
const SocialView = ({}) => {
  const [postData, setPostData] = useState([]);

  useEffect(() => {
    let checksumid = window.location.pathname.split("/")[2];
    let postId = window.location.pathname.split("/")[3];
    let apiUrl;
    let location = window.location.hostname;

    if (location == "localhost" || location == "hypaiqdev.cyb.co.uk") {
      apiUrl = "https://postandnews.portcullisindia.in/";
    } else if (location == "hypaiqqa.cyb.co.uk") {
      apiUrl = "https://postandnews.hypaiq-staging.cyb.co.uk/";
    } else if (location == "hypaiq.cyb.co.uk") {
      apiUrl = "https://hypaiqnews.cyb.co.uk:8087/";
    }

    function setBaseUrl(url) {
      return Axios.create({
        baseURL: url,
      });
    }

    const getPostURL = setBaseUrl(apiUrl);

    [
      getPostURL
    ].map((apiInstance) => {
      apiInstance.interceptors.request.use(function (config) {
        config.headers.accept = "application/json";
        config.headers.checksumid = checksumid;
        return config;
      });
    });

    getPostURL
      .get(`${apiUrl}/post/${postId}`)
      .then((result) => {
        setPostData(result.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
      <div
        className="container ">
           <div style={{width:"100%",textAlign:"center"}}> <img
              src="https://hypaiq.cyb.co.uk/static/media/hypaiq.c86b8bf9.png"
              style={{ height: "70px",marginBottom: "9px",marginTop: "5px"}}
            /></div>
          <div className="shrd_pg_sty">
          {postData ? (
          <div style={{width:"100%"}}>
            <br />
            <h4>{postData.retUserName}</h4>
           
            <br />
            
            <div className="row" style={{margin:"0px"}} >
              <h2 className="sharpost_hdr">{postData.retTitle}</h2>
              {"  "} <p>{postData.retpublishedOn}</p>
             
            </div>

            <br />
            <img
              src={postData.retPictureURL}
              style={{ width: "500px", height: "200px" }}
            />
            <br />
            <br />
            <p>{ReactHtmlParser(postData.retContent)}</p>
            <div className="shard_pg_btn">
              
              <a href={`https://${window.location.hostname}`} className="float_lft">
                <button className="btn btn-primary btn-lg">Sign in to Continue</button>
              </a>
              {"  "}
              <div className="float_lft">Or</div>
              <a href={`https://${window.location.hostname}/signup`}>
                <button className="btn btn-primary btn-lg">Sign Up</button>
              </a>
            </div>
          </div>
        ) : null}
        </div>
      </div>
    </>
  );
};

export default SocialView;
