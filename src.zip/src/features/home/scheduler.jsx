// import React, { useState } from "react";
// import styled, { ThemeProvider } from "styled-components";
// import * as mytheme from "../../exportables/Colors";
// import moment from "moment";
// import {
//   selectedAppointments,
//   saveAppointments,
//   manageslicerScheduler,
//   setSelectedPatient,
//   viewUserSearch
  
// } from "../../store/LandingPage/index";
// import axios from "axios";
// import PatientSearch from "../../features/dashboard/components/TopLineContents/PatientSearch";
// import UserSearchPopup from "../../features/dashboard/components/TopLineContents/UserSearchPopup";
// import Popup from "../../features/dashboard/components/TopLineContents/PopupComponent";
// import { useSelector, useDispatch } from "react-redux";

// function Scheduler() {
  
//   const [show, setShow] = useState(false);
//   const styles = useSelector((state) => state.ui.styles);
//   const [scheduleid, setSelectedschedulerID] = useState("");
//   const dispatch = useDispatch();
//   const LatestPostData = useSelector((state) => state.landingpage.latestposts);
//   const [datetime, setDateTime] = useState("");
//   const [dayandmonth, setDayMonth] = useState("");
//   const [startandendtime, setStartEnd] = useState("");
//   const [addAndupdateDiffer, setaddAndupdateDiffer] = useState(1);
 

//   const scheduleSlicer = useSelector(
//     (state) => state.landingpage.schedulerSlicer
//   );
//   const selUser = useSelector((state) => state.landingpage.selectedUser);

//   var userDetails = JSON.parse(localStorage.getItem("account"));
//   const checksumid = useState(userDetails.userid);

//   const [offsettime, setOffset] = useState("");
//   const [name, setName] = useState(userDetails.firstname);
//   const [process, setProcess] = useState("");
//   const [location, setLocation] = useState("");
//   const [comments, setComment] = useState("");
//   const [duration, setDuration] = useState("");
//   const [showPatiensearch, setshowPatiensearch] = useState(false);

//   const selPatient = useSelector((state) => state.landingpage.selectedPatient);

//   const selectedData = useSelector(
//     (state) => state.landingpage.selectedAppointment
//   );

//   const appointmentData = useSelector(
//     (state) => state.landingpage.appointments
//   );

//   const addAppointment = async (e) => {
//     e.preventDefault();
//     let d = offsettime.getDate();
//     let m = offsettime.getMonth() + 1;
//     if ((m + "").length === 1) m = "0" + m;
//     if ((d + "").length === 1) d = "0" + d;
//     let y = offsettime.getFullYear();
//     let date = `${y}-${m}-${d}T`;
//     // schedule.scheduler_date = `${d}-${m}-${y}`;
//     date = date + moment(offsettime).format("hh:mm") + ":00+";
//     let zone = new Date().toString().split(" ")[5].split("+")[1];
//     zone = zone.substr(0, 2) + ":" + zone.substr(2);

//     // offsettime = date + zone;

//     let obj = {
//       offsetDateTime: date + zone,
//       patient_id: selPatient.id,
//       patient_name: selPatient.name,
//       process: process,
//       scheduler_comment: comments,
//       scheduler_date: (
//         moment(offsettime).date() +
//         "-" +
//         (moment(offsettime).month() + 1) +
//         "-" +
//         moment(offsettime).year()
//       ).toString(),
//       scheduler_duration: duration,
//       scheduler_id: scheduleid,
//       scheduler_time: moment(offsettime).format("hh:mm"),
//       user_name: name,
//       userchecksum_id: selUser.userId,
//       workgroup_id: "null",
//     };
 
//     const options = {
//       headers: {
//         Authorization: "Bearer" + " " + localStorage.getItem("token"),
//       },
//     };
//     await axios
//       .post(`https://jvscheduler-dev.cyb.co.uk:8081/scheduler`, obj, options)
//       .then(async (res) => {
//         if (res.status === 200) {
//           alert("appointment added");
//           const options1 = {
//             headers: {
//               Authorization: "Bearer" + " " + localStorage.getItem("token"),
//               checksumid: JSON.parse(localStorage.getItem("account")).userid,
//             },
//           };
//           setTimeout(async () => {
//             await axios
//               .get(
//                 "https://searchservice-dev.cyb.co.uk:8085/search/scheduler",
//                 options1
//               )
//               .then((res) => {
//                 dispatch(saveAppointments(res.data));
//               })
//               .catch((err) => console.log(err));
//           }, 2000);
//         } else {

//         }
//       });

//     // .catch((err) => {
//     //   console.log(err)
//     // });
//     discard();
//   };

//   const updateAppointment = async (e) => {
//     e.preventDefault();
//     let d = offsettime.getDate();
//     let m = offsettime.getMonth() + 1;
//     if ((m + "").length === 1) m = "0" + m;
//     if ((d + "").length === 1) d = "0" + d;
//     let y = offsettime.getFullYear();
//     let date = `${y}-${m}-${d}T`;
//     // schedule.scheduler_date = `${d}-${m}-${y}`;
//     date = date + moment(offsettime).format("hh:mm") + ":00+";
//     let zone = new Date().toString().split(" ")[5].split("+")[1];
//     zone = zone.substr(0, 2) + ":" + zone.substr(2);


//     // offsettime = date + zone;

//     let obj = {
//       offsetDateTime: date + zone,
//       patient_id: selPatient.id,
//       patient_name: selPatient.name,
//       process: process,
//       scheduler_comment: comments,
//       scheduler_date: (
//         moment(offsettime).date() +
//         "-" +
//         (moment(offsettime).month() + 1) +
//         "-" +
//         moment(offsettime).year()
//       ).toString(),
//       scheduler_duration: duration,
//       scheduler_id: scheduleid,
//       scheduler_time: moment(offsettime).format("hh:mm"),
//       user_name: name,
//       userchecksum_id: selUser.userId,
//       workgroup_id: "null",
//     };

//     const options = {
//       headers: {
//         Authorization: "Bearer" + " " + localStorage.getItem("token"),
//         checksumid: selUser.userId,
//       },
//     };
//     await axios
//       .put(
//         `https://jvscheduler-dev.cyb.co.uk:8081/scheduler/${obj.scheduler_id}`,
//         obj,
//         options
//       )
//       .then(async (res) => {
//         if (res.status === 200) {
//           alert("appointment updated");

//           const options1 = {
//             headers: {
//               Authorization: "Bearer" + " " + localStorage.getItem("token"),
//               checksumid: JSON.parse(localStorage.getItem("account")).userid,
//             },
//           };
//           setTimeout(async () => {
//             await axios
//               .get(
//                 "https://searchservice-dev.cyb.co.uk:8085/search/scheduler",
//                 options1
//               )
//               .then((res) => {
//                 dispatch(saveAppointments(res.data));
//               })
//               .catch((err) => console.log(err));
//           }, 2000);
//         } else {
     
//         }
//       });
//     setaddAndupdateDiffer(1);
//     // .catch((err) => {
//     //   console.log(err)
//     // });
//     discard();
//   };

//   const removeAppointment = async (scheduler_id) => {
//     const options = {
//       headers: {
//         Authorization: "Bearer" + " " + localStorage.getItem("token"),
//       },
//     };
//     await axios
//       .delete(
//         `https://jvscheduler-dev.cyb.co.uk:8081/scheduler/${scheduler_id}`,
//         options
//       )
//       .then(async (res) => {
//         if (res.status === 200) {
//           alert("appointment removed");

//           const options1 = {
//             headers: {
//               Authorization: "Bearer" + " " + localStorage.getItem("token"),
//               checksumid: JSON.parse(localStorage.getItem("account")).userid,
//             },
//           };
//           setTimeout(async () => {
//             await axios
//               .get(
//                 "https://searchservice-dev.cyb.co.uk:8085/search/scheduler",
//                 options1
//               )
//               .then((res) => {
//                 dispatch(saveAppointments(res.data));
//               })
//               .catch((err) => console.log(err));
//           }, 2000);
//         } else {
    
//         }
//       });
//     discard();
//   };
//   const discard = () => {
//     // setName("");
//     setComment("");
//     setLocation("");
//     // setPatient("");
//     setProcess("");
//     setOffset("");
//     setDuration("");
//   };

//   return (
//     <>
//       <ThemeProvider theme={mytheme}>
//         <div>
//           <GlobalStyle>
//             <div className="container">
//               <div className="row">
//                 <Schedule>
//                   <div>
//                     <h3>Your Schedule</h3>
//                   </div>
//                   <div>
//                     <ul>
//                       <li>
//                         <i class="fa fa-search" aria-hidden="true"></i>
//                       </li>
//                       <li>
//                         <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
//                       </li>
//                     </ul>
//                   </div>
//                 </Schedule>
//                 <DaySchedule>
//                   <div>
//                     <h3>Day, MM Month YYYY</h3>
//                   </div>
//                   <div>
//                     <ul>
//                       <li style={{ cursor: "pointer" }}>
//                         <i
//                           class="fa fa-angle-left"
//                           onClick={() =>
//                             dispatch(
//                               manageslicerScheduler({
//                                 start:
//                                   scheduleSlicer.start - scheduleSlicer.length,
//                                 end: scheduleSlicer.start,
//                               })
//                             )
//                           }
//                           aria-hidden="true"
//                         ></i>
//                       </li>
//                       <li style={{ cursor: "pointer" }}>
//                         <i
//                           class="fa fa-angle-right"
//                           onClick={() =>
//                             dispatch(
//                               manageslicerScheduler({
//                                 start:
//                                   scheduleSlicer.start + scheduleSlicer.length,
//                                 end: scheduleSlicer.end + scheduleSlicer.length,
//                               })
//                             )
//                           }
//                           aria-hidden="true"
//                         ></i>
//                       </li>
//                     </ul>
//                   </div>
//                 </DaySchedule>
//                 {appointmentData
//                   .slice(scheduleSlicer.start, scheduleSlicer.end)
//                   .map((data) => (
//                     <MySchedule>
//                       <div>
//                         <p>{data.scheduler_time}</p>
//                       </div>
//                       <div>
//                         <p>
//                           {data.user_firstname} {data.user_lastname}
//                         </p>
//                       </div>
//                       <div
//                         onClick={() => {
//                           let selData = appointmentData.filter(
//                             (el) => el.scheduler_id == data.scheduler_id
//                           );

//                           let y =
//                             moment(
//                               selData[0].scheduler_date.split("-")[2] +
//                                 "-" +
//                                 selData[0].scheduler_date.split("-")[1] +
//                                 "-" +
//                                 selData[0].scheduler_date.split("-")[0] +
//                                 "T00:00:00"
//                             ).format("dddd") +
//                             ", " +
//                             selData[0].scheduler_date.split("-")[0] +
//                             " " +
//                             moment(
//                               selData[0].scheduler_date.split("-")[2] +
//                                 "-" +
//                                 selData[0].scheduler_date.split("-")[1] +
//                                 "-" +
//                                 selData[0].scheduler_date.split("-")[0] +
//                                 "T00:00:00"
//                             ).format("MMMM");

//                           let z = moment(
//                             selData[0].scheduler_time.split(":")[0] +
//                               ":" +
//                               selData[0].scheduler_time.split(":")[1],
//                             "HH:mm"
//                           );
//                           z.add(selData[0].scheduler_duration, "m");
//                           z.format("HH:mm");
//                           setDayMonth(y);
//                           setStartEnd(
//                             selData[0].scheduler_time + "-" + z.format("HH:mm")
//                           );
//                           dispatch(selectedAppointments(selData[0]));
//                         }}
//                       >
//                         <p
//                           data-toggle="modal"
//                           data-target="#appoinmentdetails"
//                           data-backdrop="false"
//                         >
//                           <i class="fa fa-search" aria-hidden="true"></i>
//                         </p>
//                       </div>
//                     </MySchedule>
//                   ))}
//               </div>
//               <MyScheduuleOne>
//                 <OpenSchedule>
//                   <div>
//                     <p>Open Scheduler</p>
//                   </div>
//                   <div>
//                     <p></p>
//                     <p>
//                       <i class="fa fa-search" aria-hidden="true"></i>
//                     </p>
//                   </div>
//                 </OpenSchedule>
//                 <OpenSchedule>
//                   <div>
//                     <p data-toggle="modal" data-target="#myModalappoinment">
//                       Create New Appointment
//                     </p>
//                   </div>
//                   <div>
//                     <p>
//                       <i class="fa fa-search" aria-hidden="true"></i>
//                     </p>
//                   </div>
//                 </OpenSchedule>

//                 {/* modal start */}
//                 <AppointmentModal>
//                   <div
//                     class="modal "
//                     id="myModalappoinment"
//                     role="dialog"
//                     data-backdrop="false"
//                     style={{ zIndex: 0 }}
//                   >
//                     <div class="modal-dialog modal-sm">
//                       <div class="modal-content">
//                         <div class="modal-header">
//                           <h4 class="modal-title">Add New Appoinment</h4>
//                           <button
//                             type="button"
//                             class="close"
//                             data-dismiss="modal"
//                           >
//                             &times;
//                           </button>
//                         </div>
//                         <div class="modal-body">
//                           {/* <p>Day, DD Month . HH:MM - HH:MM</p> */}
//                           <h2>{datetime}</h2>
//                           <div className="appoinementmodalform">
//                             <form>
//                               <div className="group">
//                                 <input
//                                   id="myDa"
//                                   style={{ cursor: "pointer" }}
//                                   type="datetime"
//                                   onChange={(e) => {
//                                     let d = e.target.value;

//                                     let alt_d =
//                                       moment(d).format("dddd") +
//                                       ", " +
//                                       moment(d).date() +
//                                       " " +
//                                       moment(d).format("MMM") +
//                                       " " +
//                                       moment(d).format("hh:mm");

//                                     setDateTime(alt_d);
//                                     setOffset(new Date(d));
//                                   }}
//                                 />
//                               </div>
//                               <div className="group">
//                                 <div className="d-flex">
//                                   <input
//                                     type="text"
//                                     className="mr-auto p-2"
//                                     value={selUser.name}
//                                     onChange={(e) => setName(e.target.value)}
//                                     required
//                                   />
//                                   <span
//                                     className="p-2"
//                                     style={{
//                                       marginRight: "50px",
//                                       cursor: "pointer",
//                                     }}
//                                   >
//                                     <i
//                                       class="fa fa-search"
//                                       // data-toggle="modal" data-target="#patientSearch"
//                                       onClick={() => {
//                                         dispatch(viewUserSearch(true));
//                                       }}
//                                     ></i>
//                                   </span>
//                                   <span class="highlight"></span>
//                                   <span class="bar"></span>
//                                   <label>Name</label>
//                                 </div>
//                               </div>
//                               <div className="group">
//                                 <div className="d-flex">
//                                   <input
//                                     className="mr-auto p-2"
//                                     type="text"
//                                     value={
//                                       addAndupdateDiffer === 1
//                                         ? selPatient !== {}
//                                           ? selPatient.name
//                                           : null
//                                         : selectedData.patient_name
//                                     }
//                                     // onChange={(e) => setPatient(e.target.value)}
//                                     required
//                                   />
//                                   <span
//                                     className="p-2"
//                                     style={{
//                                       marginRight: "50px",
//                                       cursor: "pointer",
//                                     }}
//                                   >
//                                     <i
//                                       class="fa fa-search"
//                                       // data-toggle="modal" data-target="#patientSearch"
//                                       onClick={() => {
//                                         // dispatch(viewUserSearch(true));
//                                         setshowPatiensearch(true);
//                                       }}
//                                     ></i>
//                                   </span>

//                                   <span class="highlight"></span>
//                                   <span class="bar"></span>
//                                   <label>Patient</label>
//                                 </div>
//                               </div>
//                               <div className="group">
//                                 <input
//                                   type="text"
//                                   value={process}
//                                   onChange={(e) => setProcess(e.target.value)}
//                                   required
//                                 />
//                                 <span class="highlight"></span>
//                                 <span class="bar"></span>
//                                 <label>Process</label>
//                               </div>
//                               <div className="group">
//                                 <input
//                                   type="text"
//                                   value={duration}
//                                   onChange={(e) => setDuration(e.target.value)}
//                                   required
//                                 />
//                                 <span class="highlight"></span>
//                                 <span class="bar"></span>
//                                 <label>Duration</label>
//                               </div>
//                               <div className="group">
//                                 <input
//                                   type="text"
//                                   value={location}
//                                   onChange={(e) => setLocation(e.target.value)}
//                                   required
//                                 />
//                                 <span class="highlight"></span>
//                                 <span class="bar"></span>
//                                 <label>Location</label>
//                               </div>
//                               <div className="group">
//                                 <input
//                                   type="text"
//                                   value={comments}
//                                   onChange={(e) => setComment(e.target.value)}
//                                   required
//                                 />
//                                 <span class="highlight"></span>
//                                 <span class="bar"></span>
//                                 <label>Comment</label>
//                               </div>
//                               <div className="appoinmentbutton">
//                                 <ul>
//                                   <li>
//                                     <button
//                                       data-toggle="modal"
//                                       data-target="#myModalappoinment"
//                                       onClick={() => discard()}
//                                     >
//                                       Discard
//                                     </button>
//                                   </li>
//                                   <li>
//                                     <button
//                                       type="submit"
//                                       data-toggle="modal"
//                                       data-target="#myModalappoinment"
//                                       onClick={(e) =>
//                                         addAndupdateDiffer === 1
//                                           ? addAppointment(e)
//                                           : updateAppointment(e)
//                                       }
//                                     >
//                                       {addAndupdateDiffer === 1
//                                         ? "Save"
//                                         : "Update"}
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                             </form>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   {showPatiensearch ? (
//                     <div style={{ zIndex: 1 }}>
//                       <PatientSearch
//                         //isPopupVisible={showPatiensearch}
//                         togglePatient={() => setshowPatiensearch(false)}
//                         styles={styles}
//                         setPatient={(e) => null}
//                         toggleDelete={(e) => null}
//                       />
//                     </div>
//                   ) : null}
//                 </AppointmentModal>
//                 {/* modal end */}

//                 {/* modal start */}
//                 {selectedData ? (
//                   <AppoinmentDetailsContnet>
//                     <div class="modal" id="appoinmentdetails" role="dialog">
//                       <div class="modal-dialog modal-sm">
//                         <div class="modal-content">
//                           <div class="modal-header">
//                             <div className="appoinmentdetailsheader">
//                               <div>
//                                 <h4 class="modal-title">Appoinment</h4>
//                                 <p>{selectedData.user_firstname}</p>
//                               </div>

//                               <div>
//                                 <span
//                                   style={{
//                                     marginRight: "25px",
//                                     cursor: "pointer",
//                                   }}
//                                   data-toggle="modal"
//                                   data-target="#myModalappoinment"
//                                   onClick={() => {
//                                     setaddAndupdateDiffer(2);

//                                     let selData = appointmentData.filter(
//                                       (el) =>
//                                         el.scheduler_id ==
//                                         selectedData.scheduler_id
//                                     );
//                                     var recreate_date =
//                                       selData[0].scheduler_date.split("-")[2] +
//                                       "-" +
//                                       selData[0].scheduler_date.split("-")[1] +
//                                       "-" +
//                                       selData[0].scheduler_date.split("-")[0] +
//                                       "T" +
//                                       selData[0].scheduler_time;
//                                     document.getElementById(
//                                       "myDate"
//                                     ).defaultValue = recreate_date;

//                                     let alt_d =
//                                       moment(recreate_date).format("dddd") +
//                                       ", " +
//                                       moment(recreate_date).date() +
//                                       " " +
//                                       moment(recreate_date).format("MMM") +
//                                       " " +
//                                       moment(recreate_date).format("hh:mm");

//                                     setDateTime(alt_d);
//                                     setProcess(selData[0].process);
//                                     setDuration(selData[0].scheduler_duration);
//                                     setComment(selData[0].scheduler_comment);
//                                     setOffset(new Date(recreate_date));
//                                     setSelectedschedulerID(
//                                       selData[0].scheduler_id
//                                     );
//                                     dispatch(selectedAppointments(selData[0]));
//                                     dispatch(
//                                       setSelectedPatient({
//                                         id: selData[0].patient_id,
//                                         name: selData[0].patient_name,
//                                       })
//                                     );
//                                   }}
//                                 >
//                                   <i
//                                     class="fa fa-pencil"
//                                     data-toggle="modal"
//                                     data-target="#appoinmentdetails"
//                                   ></i>
//                                 </span>

//                                 <i
//                                   class="fa fa-trash"
//                                   style={{ cursor: "pointer" }}
//                                   data-toggle="modal"
//                                   data-target="#appoinmentdetails"
//                                   onClick={() =>
//                                     removeAppointment(selectedData.scheduler_id)
//                                   }
//                                 ></i>
//                                 <button
//                                   type="button"
//                                   class="close"
//                                   data-dismiss="modal"
//                                 >
//                                   &times;
//                                 </button>
//                               </div>
//                             </div>
//                           </div>
//                           <div class="modal-body">
//                             <ul>
//                               <li>{dayandmonth}</li>
//                               <li>
//                                 {startandendtime} (
//                                 {selectedData.scheduler_duration} Minutes)
//                               </li>

//                               <li>
//                                 {selectedData.patient_firstname}{" "}
//                                 {selectedData.patient_lasttname}
//                               </li>
//                               <li>{selectedData.process}</li>
//                               <li>{selectedData.comments} </li>
//                             </ul>
//                             <div className="startconsulation">
//                               <a href="#">
//                                 <i class="fa fa-edit" aria-hidden="true"></i>
//                                 Start Consulation
//                               </a>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </AppoinmentDetailsContnet>
//                 ) : null}
//                 {/* modal end */}
//               </MyScheduuleOne>
//             </div>
//           </GlobalStyle>
//           <br />
//         </div>
//       </ThemeProvider>
//     </>
//   );
// }

// export default Scheduler;

// const GlobalStyle = styled.section`
//   padding: 10px 15px;
//   margin-top: 30px;
//   h3 {
//     font-size: 16px;
//   }
// `;

// const Schedule = styled.div`
//   display: table;
//   width: 100%;
//   div {
//     display: table-cell;
//     :nth-child(2) ul {
//       list-style: none;
//       text-align: right;
//       li {
//         display: inline-block;
//         padding: 0px 10px;
//         :nth-child(2) {
//           padding: 0px 10px;
//         }
//       }
//     }
//   }
// `;

// const DaySchedule = styled.div`
//   display: table;
//   width: 100%;
//   div {
//     display: table-cell;
//     :nth-child(1) p {
//       font-size: 14px;
//     }
//     :nth-child(2) ul {
//       list-style: none;
//       li {
//         display: inline-block;
//         padding: 5px;
//       }
//     }
//   }
// `;

// const MySchedule = styled.div`
//   display: table;
//   width: 100%;
//   div {
//     display: table-cell;
//     :nth-child(1) {
//       width: 30%;
//     }
//     :nth-child(2) {
//       width: 60%;
//     }
//     :nth-child(3) {
//       width: 10%;
//       p {
//         background-color: transparent;
//         border: none;
//         font-size: 15px;
//         margin-left: 10px;
//         i {
//           color: ${(props) =>
//             props.theme.DashboardContentFourColors.MySchedule
//               .nthChild_3_p_i_color} !important;
//           cursor: pointer;
//         }
//       }
//     }
//   }
// `;

// const MyScheduuleOne = styled.div`
//   border-top: 1px solid red;
// `;

// const OpenSchedule = styled.div`
//   display: table;
//   width: 100%;
//   div {
//     display: table-cell;
//     :nth-child(1) p {
//       cursor: pointer;
//     }
//     :nth-child(2) p {
//       text-align: center;
//     }
//   }
// `;

// const AppointmentModal = styled.div`
//   .group {
//     position: relative;
//     margin-bottom: 10px;
//   }
//   input {
//     font-size: 16px;
//     padding: 10px 10px 0px 5px;
//     display: block;
//     width: 300px;
//     border: none;
//     border-bottom: 0.5px solid
//       ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .input_border_bottom};
//   }
//   input:focus {
//     outline: none;
//   }
  
//   // label {
//     // color: 
//   //     props.theme.DashboardContentFourColors.AppointmentModal.label};
//   //   font-size: 15px;
//   //   font-weight: normal;
//   //   position: absolute;
//   //   pointer-events: none;
//   //   left: 5px;
//   //   top: 10px;
//   //   transition: 0.2s ease all;
//   //   -moz-transition: 0.2s ease all;
//   //   -webkit-transition: 0.2s ease all;
//   // }

//   input:focus ~ label,
//   input:valid ~ label {
//     top: -10px;
//     font-size: 14px;
//     color: ${(props) =>
//       props.theme.DashboardContentFourColors.AppointmentModal
//         .webkit_inputHighlighter_from_backgroundcolor};
//   }

//   .highlight {
//     position: absolute;
//     height: 60%;
//     width: 100px;
//     top: 25%;
//     left: 0;
//     pointer-events: none;
//     opacity: 0.5;
//   }
//   input:focus ~ .highlight {
//     -webkit-animation: inputHighlighter 0.3s ease;
//     -moz-animation: inputHighlighter 0.3s ease;
//     animation: inputHighlighter 0.3s ease;
//   }
//   @-webkit-keyframes inputHighlighter {
//     from {
//       background: ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .webkit_inputHighlighter_from_backgroundcolor};
//     }
//     to {
//       width: 0;
//       background: transparent;
//     }
//   }
//   @-moz-keyframes inputHighlighter {
//     from {
//       background: ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .moz_inputHighlighter_from_backgroundcolor};
//     }
//     to {
//       width: 0;
//       background: transparent;
//     }
//   }
//   @keyframes inputHighlighter {
//     from {
//       background: ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .keyframes_inputHighlighter};
//     }
//     to {
//       width: 0;
//       background: transparent;
//     }
//   }
//   .modal .modal-dialog {
//     float: right;
//     left: -100px;
//     top: 150px;
//     margin: 0;
//   }
//   .modal-content {
//     width: 350px !important;
//     border-radius: 10px;
//     border: none;
//   }
//   .modal-header {
//     background-color: ${(props) =>
//       props.theme.DashboardContentFourColors.AppointmentModal
//         .modal_header_backgroundcolor};
//     border-radius: 10px 10px 0px 0px;
//     h4 {
//       color: ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .h4_color} !important;
//       font-size: 20px;
//     }
//     button {
//       font-size: 30px;
//       color: ${(props) =>
//         props.theme.DashboardContentFourColors.AppointmentModal
//           .button_color} !important;
//       opacity: 1;
//       font-weight: 400;
//       padding: 5px;
//     }
//   }
//   .modal-body p {
//     font-weight: 500;
//     margin-top: 10px;
//     font-size: 16px;
//   }
//   .appoinmentbutton ul li {
//     display: inline-block;
//     padding: 20px;
//     button {
//       padding: 5px 30px;
//       border-radius: 20px;
//       :nth-child(1) button {
//         border: 1.5px solid
//           ${(props) =>
//             props.theme.DashboardContentFourColors.AppointmentModal
//               .appoinmentbutton_nthChild_1_button_border};
//         background-color: transparent;
//         color: ${(props) =>
//           props.theme.DashboardContentFourColors.AppointmentModal
//             .appoinmentbutton_nthChild_1_button_color};
//       }
//       :nth-child(2) button {
//         background-color: ${(props) =>
//           props.theme.DashboardContentFourColors.AppointmentModal
//             .appoinmentbutton_nthChild_2_button_backgroundcolor};
//         color: ${(props) =>
//           props.theme.DashboardContentFourColors.AppointmentModal
//             .appoinmentbutton_nthChild_2_button_color};
//         border: none;
//       }
//     }
//   }
// `;

// const AppoinmentDetailsContnet = styled.div`
//   .modal-content {
//     width: 340px !important;
//     border-radius: 10px;
//     border: none;
//   }
//   .modal .modal-dialog {
//     float: right;
//     left: -90px;
//     top: 150px;
//     margin: 0;
//   }
//   .modal-header {
//     background-color: ${(props) =>
//       props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//         .modal_header_backgroundcolor};
//     border-radius: 10px 10px 0px 0px;
//   }
//   .appoinmentdetailsheader {
//     display: table;
//     width: 100%;
//     div {
//       display: table-cell;
//       :nth-child(1) {
//         h4 {
//           color: ${(props) =>
//             props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//               .appoinmentdetailsheader_nthChild_1_h4_color};
//           font-size: 20px;
//         }
//         p {
//           color: ${(props) =>
//             props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//               .appoinmentdetailsheader_nthChild_1_p_color};
//         }
//       }
//       :nth-child(2) {
//         button {
//           font-size: 30px;
//           color: ${(props) =>
//             props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//               .appoinmentdetailsheader_nthChild_2_button_color} !important;
//           opacity: 1;
//           font-weight: 400;
//           padding: 5px;
//         }
//       }
//       .modal-body {
//         padding: 0;
//         p {
//           font-weight: 500;
//           margin-top: 10px;
//           font-size: 16px;
//           padding: 0px 10px;
//         }
//         ul {
//           list-style: none;
//           border-bottom: 1px solid
//             ${(props) =>
//               props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//                 .modalbody_ul_bordercolor};
//           li {
//             line-height: 35px;
//             font-size: 14px;
//             color: ${(props) =>
//               props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//                 .modalbody_li_color};
//             padding: 0px 10px;
//             margin-left: 30px;
//             :nth-child(1)::before {
//               content: "\f00c";
//               position: absolute;
//               font-family: FontAwesome;
//               left: 15px;
//             }
//             :nth-child(2)::before {
//               content: "\f00b";
//               position: absolute;
//               font-family: FontAwesome;
//               left: 15px;
//             }
//             :nth-child(3)::before {
//               content: "\f00b";
//               position: absolute;
//               font-family: FontAwesome;
//               left: 15px;
//             }
//             :nth-child(5)::before {
//               content: "\f00b";
//               position: absolute;
//               font-family: FontAwesome;
//               left: 15px;
//             }
//             :nth-child(6) {
//               margin-bottom: 10px;
//             }
//             ::before {
//               content: "\f00b";
//               position: absolute;
//               font-family: FontAwesome;
//               left: 15px;
//             }
//           }
//         }
//       }
//     }
//   }
//   .startconsulation a {
//     color: ${(props) =>
//       props.theme.DashboardContentFourColors.AppoinmentDetailsContnet
//         .startconsulation_a_color};
//     text-align: right !important;
//     display: block;
//     padding: 0px 10px 10px 0px;
//     font-size: 16px;
//     font-weight: 600;
//     i {
//       margin-right: 10px;
//     }
//   }
// `;

// const MessageChat = styled.div`
//   background-color: ${(props) =>
//     props.theme.DashboardContentFourColors.MessageChat.backgroundcolor};
//   border-top-left-radius: 10px;
//   border-top-right-radius: 10px;
//   margin-top: -25px;
//   position: absolute;
//   right: 24px;
//   input {
//     border: none;
//     box-shadow: none;
//   }
//   .d-flex1 {
//     height: 55px;
//     background-color: ${(props) =>
//       props.theme.DashboardContentFourColors.MessageChat
//         .d_flex_backgroundcolor};
//     border-top-left-radius: 10px;
//     border-top-right-radius: 10px;
//   }
// `;

// const MessageIcon = styled.div`
//   display: table;
//   width: 100%;
//   div {
//     h6 {
//       font-weight: bold;
//       font-size: medium;
//     }
//     display: table-cell;
//     :nth-child(2) ul {
//       list-style: none;
//       text-align: right;
//       margin-right: 10px;
//       li {
//         display: inline-block;
//         padding: 10px;
//       }
//     }
//   }
// `;

// const CreateMessage = styled.div`
//   margin-top: 20px;
//   button {
//     background-color: ${(props) =>
//       props.theme.DashboardContentFourColors.CreateMessage
//         .d_flex_backgroundcolor};
//     border: 2px solid
//       ${(props) =>
//         props.theme.DashboardContentFourColors.CreateMessage
//           .button_border_color};
//     color: ${(props) =>
//       props.theme.DashboardContentFourColors.CreateMessage.button_border_color};
//     border-radius: 30px;
//     padding: 10px 40px;
//     font-weight: 500;
//   }
// `;
