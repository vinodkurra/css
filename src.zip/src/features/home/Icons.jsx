import React from "react";
import styled from "styled-components";
import PropTypes from "prop-types";

function Icons({ isActive, src, triggerFunc, title }) {
  let activeClass = isActive ? "active" : "";
  let activeFunc = isActive ? triggerFunc : () => console.log("icon disabled");

  return (
    <Icon onClick={activeFunc} className={activeClass} title={title}>
      <img alt="icon" src={src} draggable={false} />
    </Icon>
  );
}

Icons.defaultProps = {
  alt: "",
  src: "https://img.icons8.com/fluent/48/000000/file.png",
  isActive: false,
};

Icons.propTypes = {
  triggerFunc: PropTypes.func.isRequired,
  title: PropTypes.string.isRequired,
};

export default Icons;

const Icon = styled.span`
  margin: 0;
  cursor: not-allowed;
  filter: grayscale(100%);
  &.active {
    cursor: pointer;
    filter: grayscale(0);
  }
  img {
    width: 30px;
    margin-bottom: -5px;
    padding: 10%;
  }
`;
