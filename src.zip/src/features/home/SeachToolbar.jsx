import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

import Icon from "./Icons";

function SearchToolbar({ page, iconsFragment, src, toggleAdvanced }) {
  return (
    <Style>
      <Icon
        title="Advanced-search"
        src={src}
        isActive={true}
        triggerFunc={toggleAdvanced}
      />
      <div className="icons-action">{iconsFragment}</div>
    </Style>
  );
}

export default SearchToolbar;

const Style = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0;
  border-bottom: 1px solid #4395a6;
  width: 80%;
  .breadcrumb {
    display: flex;
    color: gray;
    font-size: 12px;
    align-items: center;
  }
  .icons-action {
    display: flex;
    align-items: flex-end;
  }
`;
