import React, { Component } from "react";
import styled from "styled-components";
import { device } from "../../../exportables/exportables";
import PropTypes from "prop-types";

class PopupComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      styles: {
        popup: {},
        panels: {},
      },
    };
  }
  static propTypes = {
    visible: PropTypes.bool.isRequired,
    // dismiss: PropTypes.func.isRequired,
  };
  componentDidMount() {
    this.setState({
      styles: { ...this.props.styles, ...this.state.styles },
    });
  }

  render() {
    const { visible, close, styles, header, children, width } = this.props;
    const closePopup = () => {
      close();
    };
    return (
      <React.Fragment>
        {visible ? (
          <Popup width={width} styles={styles} id="main">
            <div className="popup">
              <div className="popup-header">
                <p>{header}</p>
                <span className="close" onClick={closePopup}>
                  X
                </span>
              </div>
              <div className="popup-body">{children}</div>
            </div>
          </Popup>
        ) : null}
      </React.Fragment>
    );
  }
}

export default PopupComponent;

const Popup = styled.div`
  overflow-x: auto;
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  flex-direction: column;
  min-width: 350px;
  align-items: center;
  justify-content: center;
  z-index: 2;
  .popup {
    height: 75%;
    overflow-y: auto;
    position: fixed;

    min-width: 350px;
    width: ${(props) => props.width};
    .popup-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: ${(props) => props.styles.panels.base_colour};
      color: ${(props) =>
        props.styles.popup.active_in_focus_banner_text_colour}!important;
      padding: 5px 10px;
      border-radius: 5px 5px 0 0;
      border: ${(props) => props.styles.panels.border_thickness} solid
        ${(props) => props.styles.panels.border_colour};
      height: 30px;
      p {
        color: ${(props) =>
          props.styles.popup.active_in_focus_banner_text_colour}!important;
        margin-bottom: 0;
      }
      h3 {
        margin: 0;
        font-weight: 500;
        padding: 0;
        font-size: 80%;
      }
      .close {
        font-weight: bold;
        cursor: pointer;
      }
    }
    .popup-body {
      position: relative;
      border: 1.5px solid
        ${(props) => props.styles.popup.active_in_focus_border_colour};
      border-radius: 0 0
        ${(props) => props.styles.popup.active_in_focus_corner_radius}
        ${(props) => props.styles.popup.active_in_focus_corner_radius};
      background: white;
    }
  }
  .close-button {
    background: ${(props) => props.styles.panels.base_colour};
    color: ${(props) => props.styles.popup.active_in_focus_banner_text_colour};
    margin-left: 45%;
    margin-top: 15px;
    font-size: 15px;
    width: 100px;
    height: 27px;
    border-radius: 5px;
  }

  @media ${device.tablet} {
    align-items: center;
    justify-content: center;
    .popup {
      max-width: 350px;
      margin-right: 0;
    }
  }
`;
const Errortext = styled.p({
  color: "#ff0000",
  margin: 0,
});
