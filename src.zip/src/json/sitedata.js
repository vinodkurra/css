// Get Logged user Data with image
export const userData = {
    userid: 1,
    username: "DSmith54",
    unit: "St Mary's Cardiology Unit",
    email: "dean12@gmail.com",
    firstname: "Dean",
    lastname: "smith",
    source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
};

// Get Notification Data 
export const notification = [
    {
        id: 1,
        type: 1,
        appointment_id: 11,
        body: "Appointment in 10 minutes",
        name: "Sandra",
        time: "2020-09-22 13:26:00",
        read: false
    },
    {
        id: 2,
        type: 2,
        from: "Can Hoskan",
        body: "tagged you in a post",
        content: "UX design tips",
        time: "2020-09-16 23:51:00",
        read: false
    },
    {
        id: 3,
        type: 2,
        from: "Can Hoskan",
        body: "tagged you in a post",
        content: "What to expect from NHS during pandemic",
        time: "2020-09-17 10:51:00",
        read: false
    },
    {
        id: 4,
        type: 2,
        from: "Simon Currey",
        body: "assigned edit to your content",
        content: "Landing Page Improvemental",
        time: "2020-09-14 20:51:00",
        read: false
    },
    {
        id: 5,
        type: 2,
        from: "Alan Crosble",
        body: "shared a content in one of your specialities",
        content: "Cardiology",
        time: "2020-09-13 20:51:00",
        read: false
    },
    {
        id: 6,
        type: 3,
        totalmail: 43,
        body: "You have received ",
        content: "since yoiour last login.",
        time: "2020-09-10 20:51:00",
        read: false
    },
    {
        id: 7,
        type: 2,
        from: "Can Hoskan",
        body: "made an edit to your document",
        content: "New Coding Language",
        time: "2020-09-09 20:51:00",
        read: false
    },
    {
        id: 8,
        type: 2,
        from: "Hao",
        bode: "gave 5 stars to your content",
        content: "Covid-19 cure might come longer than expected.",
        time: "2020-09-09 20:51:00",
        read: false
    },
    {
        id: 9,
        type: 2,
        from: "Hao",
        body: "shared a post you might be interested",
        content: "Covid-19 news are underestimated.",
        time: "2020-09-07 20:51:00",
        read: false
    }

];

// Get Recent Edited Content with content ID
export const recentEdited = [
    {
        id: 1,
        body: "Recent edited content one",
        source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
    },
    {
        id: 2,
        body: "Recent edited content two",
        source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
    },
    {
        id: 3,
        body: "Recent edited content three",
        source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
    },
    {
        id: 4,
        body: "Recent edited content four",
        source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg"
    }
];

// Get Latest posts with History based,hypalQ posts, Network posts
export const latestPosts = {
    posts: [
        {
            id: 1,
            sender: "Sender of source",
            title: "Title ONE here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQuXIlVKByozAKFWhS0nDhHpcpS8DeH3ht7WA&usqp=CAU",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 2,
            sender: "Sender of source",
            title: "Title TWO here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 3,
            sender: "Sender of source",
            title: "Title THREE here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://cdn.fastly.picmonkey.com/contentful/h6goo9gw1hh6/2sNZtFAWOdP1lmQ33VwRN3/24e953b920a9cd0ff2e1d587742a2472/1-intro-photo-final.jpg?w=800&q=70",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 4,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://images.unsplash.com/photo-1504473178671-6809ddc42af6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 5,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAAM1BMVEUKME7///+El6bw8vQZPVlHZHpmfpHCy9Ojsbzg5ekpSmTR2N44V29XcYayvsd2i5yTpLFbvRYnAAAJcklEQVR4nO2d17arOgxFs+kkofz/154Qmg0uKsuQccddT/vhnOCJLclFMo+//4gedzcApf9B4srrusk+GsqPpj+ypq7zVE9LAdLWWVU+Hx69y2FMwAMGyfusLHwIpooyw9IAQfK+8naDp3OGHvZ0FMhrfPMgVnVjC2kABOQ1MLvi0DEIFj1ILu0LU2WjNRgtSF3pKb4qqtd9IHmjGlJHlc09IHlGcrQcPeUjTAySAGNSkQlRhCCJMGaUC0HSYUx6SmxFAtJDTdylsr4ApC1TY0yquKbCBkk7qnYVzPHFBHkBojhVJWviwgPJrsP4qBgTgbQXdsesjm4pDJDmIuswVZDdFx0ENTtkihoeqSDXD6tVxOFFBHndMKxWvUnzexpIcx/Gg2goJJDhVo6PCMGRAnKTmZuKm3wcJO/upphUqUHy29yVrRhJDORXOKIkEZDf4YiRhEF+iSNCEgb5KY4wSRDkB/yurUEG8nMcocgYABnvbrVL3nMIP0h/d5udKnwzSC/InfPdkJ6eWb0PJE++dyVVyQP5iQmWW27X5QG5druEKafBu0Hqu9saVOHa8HKC/K6BzHKZiRMEZCDF0Nd1/ZfXI/fcOibHOssFgokg9uFA20BhztHEAZIjIohrD/o1wljeFBDEwBo8YUt5Ir/rNLjOIACPFdy/AbEcPdcJBOCxytjeYAM4Kzp6rhOIPhRGNzwmFP3rOoTFI0irtnQKx6fj1Zt+h9njEUS9mKJxfFRrX5lt7wcQtaWTOfTHeIXVJQcQrRW+OYex2j0a66XZINoO8a7fPH2iHF2mC7ZBtB3Czb5QvjizSx7A3308mRzqAwujSywQbYfwc0iU8zqjS0yQ6ztEHX9332KCaGNIYB/Qq1z3yN0oDZBWyeFYJBCkm2sXLhDtpKFwNDMu5TnrZpYGiHbK4Nlwikg5DrYV1g6iPoJmzE5MKd/fOp53EPUaQZaLqH3u+vo2ELWp3wSyWuYGoj9EEIJoV3L9AUS/ZLsJpLNBXmqOu0CW6P5A/dx9IL0FAji/FYKot9EqE0Tvs6QBUe/2CxMEkZAlBNGPhdoAQWyTSmbxUwvUygwQyMmniAPgLt87CODXHuftWJIQgzrfQDC5AfwSgz9MmmG/gWCOqDgZ4JsQeTvZBoJJDhAFEsSDyxUEEUUekk0UEMhjBcEcGsoWVpBU3NcCgkkPkJWrKbdRZvULCMTWhYEdMrayBQRyqHcnSLmAIH7LcWJ8Hch7BsHEdWFpJsZjziCgFBpZ9TPm4e0XBJTTJKt9xjy8RoLI4gimPLP5goCSgWTrEcyzsy8IqmZVMo0H5bJiQToBCOjZ5RcElhjLN3dU7uQMAvoxwQkJZKI1CQzCthJYEigahHuDDi4rFwzCPQ7F1fiDQZgTR5iJwEGYRgIsiECD8BwwMAEfDcIaW8CRBQdhjS1kJQEchDEFhiRKr4KDFPS9FGQNVwEHoW83QjsEHdkfnuIOl6C1NjMItiaCaCWgbdpFJXQ9soh2uoB9aJcCxFdgZwlcrTmvENGlrITBBdpK25Qhd1F2RScq8CKu/gsCL8qN5THjy+Rr5E6joYgPxpdl518QrCf8Kpgjn6C8HLkbb+vt7ZM8wdVvy258khsRfHaS5DalDnlidZT7Erk+SXV5Bj1D3LS29XyhVJuoKHs9Q8S6reK11oUc7vPcr9uswP3SLiDINefXOF5rwCuGzVT6zVkVPfh2wWmHcz4wAwba2cgN1/Tsvleu7//i69CgVyt1GwjOs2+XK3rtbl151Tg3vOeioG40Mz2V+6pQ4xbJHOZj6g0EMxk93tV7fuedvVZpQSPhbwNBGInrymGrwNh1GXmL8F+lAaJ+NU/fzcmvJqvKj7177+1v1GY/GiBKI1Fdy/2XK6upXwaIJpI8B/399W0mH9zzafKaeCF9J0WF+jyCuFusTGzZKhFH8dVLZql2brxgcdVBKb7KG/7UZTmB3XJ6uL/QYT5ScRI74FcHEJ7feopyfGkaeaGlPoCw/BbjZmSBWIvINQNmTxdjWJqwUI8sztR4nYPuIPSTSUnOCZOE3ierqRoJfNSQxDjLEYs8i91eqgFCDSWiFHiuqAN9CwEGCPEISVjvwhS7Mfx6dtX8kC5aqvneGBOEFN2v6RBiYwr3DQOkLhEW6fHFbIwFQnkLiWYmZxE220z/aedPx99C+hiyKR4OzNFhg8S75CJTnxQ1dyugHTLaY10iu9dBpmhQtMz1ABLrkgtHVnRsPUO3OcU25i8cWdGxZbflCBKJqBdMs3aF/dYhNexU9RFcYEmLXYQKghyWdufyldBSU3KpjkKhZclxTXQGCTkL/HZDUIH5+Gkt4SgoCtj7pSYSNJLTK3VVRnmXZxebSMBIzmHABeIdXBebiN9eHYtUZ62ab3BdGkUm+SKJw1bdRXeewaX7qqdAnljg2sVxg3guAk3baofcg9yZ2eZpnHNvSFrEqhB9YPjesmt0pt6Xc8hl7W5L9Q4Xx09ctsrd5VhWeF6nF8SRrZdw49qns//0xTK/AZ8vGr3caTliuzeFNeCJTgafpKlhHd2WP1sy1LqDF798gjKJPLqDr9keoTd43+NyNzC1CI8Xy2lcPtOaVBI5IiAWyQ3e125AcKoXs2Djhy5eVc3KiBxREIPkhjBiLhIjU++4T91IbggjRiCJLSEIwWGddkEaxlVN5KCArPHk8mXVpHk8FHH7JL3n5dPA7C90q7XkeFJucacNmGXeRfswLE71HA79efaGiCN/Ofjmfmtcp8X10tIsqCacV5xfRWjNUiXGYbovWgyFYHcQLak15K9oM5zqmgaeKsHJetbSHfSPzXOiw/rxE9YH4CXaUpsZ0ztemFurP95Jpyvrd29YTpIZr7cEJHqfc7Wl0PFm2+yJR70udaokKFtGPTdm8WdQe24+HmVLlueboWQquBcYYVH2vEzfh8kCks1p90eWsLCyZ8qK7E86Oe+3XYFnBuiWdth20UqZR5SvMoyPg3WNauJipi0LMTQgVq5xUUlZcrPsopPHJ926z8pm7xyFLrH/PxpHSoXKdWgXsLn1scZn1ZDd/2vszN3lt254qkE+qu3yoqLM+ghN3Qz2qcVzUC/ZMFsK/alU6l0OWV/bQz6v6yYbyuN5BaZ4A7Y30vs/PPksS2+qzlvfF7OQmzzcL7W+xa7OIfRuVdtn/tdvdFLnL4OTKcm2W16PmWc4FWWXNSlWM2n3D+uPxuyrcfo74aP+Ac30a82+oLmfAAAAAElFTkSuQmCC",
            time: "2020-09-18 17:26:00",
        }
    ],
    historybased: [
        {
            id: 1,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 2,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 3,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 4,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        }
    ],
    hypalqtrend: [
        {
            id: 1,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 2,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        },
        {
            id: 3,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        }
    ],
    networkpost: [
        {
            id: 1,
            sender: "Sender of source",
            title: "Title goes here",
            content: "preview text goes here",
            department: "Health",
            branch: "Technology",
            type: 1,
            source: "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "2020-09-18 17:26:00",
        }
    ]
};

// Get Mails with Read status,Starred,..etc 
export const mail = [
    {
        id: 1,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        content: "html content goes here...",
        read: 1,
        status: 1,
        starred: true,
        time: "2020-09-23 15:26:00"
    },
    {
        id: 2,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false,
        time: "2020-09-23 14:45:00"
    },
    {
        id: 3,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false,
        time: "2020-09-23 14:26:00"
    },
    {
        id: 4,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 13:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 5,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 12:10:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 6,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 11:56:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 7,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 10:10:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 8,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 10:03:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 9,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 09:54:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 10,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-15 09:34:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 11,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-23 08:42:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 12,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-22 08:26:00",
        content: "html content goes here...",
        read: 1,
        status: 1,
        starred: true
    },
    {
        id: 13,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-22 07:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 14,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-22 07:03:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 15,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-24 00:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 16,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-22 21:36:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 17,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-22 20:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 18,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-20 17:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 19,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-19 17:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 20,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-18 17:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 21,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-17 17:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    },
    {
        id: 22,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "2020-09-18 17:26:00",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: false
    }

];

// Get News Data
export const news = [
    {
        id: 1,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "4 hours",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: 0
    },
    {
        id: 1,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "4 hours",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: 0
    },
    {
        id: 1,
        sender: "Thompson",
        title: "Title goes here",
        subject: "Preview textr goes here with one line",
        time: "4 hours",
        content: "html content goes here...",
        read: 0,
        status: 1,
        starred: 0
    },
];

// Get User Scheduled lists with all respective fields
export const scheduler = [
    {
        id: 12,
        date: "25-09-2020 18:25",
        hour: 11,
        minutes: 5,
        duration: 40,
        status: 0,
        patientname: "Ram",
        location: "location",
        process: "",
        description: "description goes here",
        notified: false
    },
    {
        id: 13,
        date: "24-09-2020 14:16",
        hour: 21,
        minutes: 40,
        duration: 50,
        status: 0,
        patientname: "Guru",
        location: "location",
        process: "",
        description: "description goes here",
        notified: false
    },
    {
        id: 14,
        date: "24-09-2020 00:15",
        hour: 21,
        minutes: 56,
        duration: 40,
        status: 0,
        patientname: "Prasad",
        location: "location",
        process: "",
        description: "description goes here",
        notified: false
    },
    {
        id: 15,
        date: "24-09-2020 00:16",
        hour: 21,
        minutes: 28,
        duration: 40,
        status: 0,
        patientname: "Jane",
        location: "location",
        process: "",
        description: "description goes here",
        notified: false
    }
]

let RemoteMailData = {
    "totalMailCount": 14,
    "startingMailIndex": 1,
    "endingMailIndex": 2,
    "emailList": [
        {
            "id": 132,
            "fromMail": {
                "emailId": "abc@hypaiq.net",
                "checkSumId": "10",
                "userName": "Manju"
            },
            "toMails": [
                {
                    "emailId": "aru@hypaiq.net",
                    "checkSumId": "11",
                    "userName": "aru"
                }
            ],
            "ccMails": [
                {
                    "emailId": "abc22@hypaiq.net",
                    "checkSumId": "9",
                    "userName": "Allwin"
                }
            ],
            "bccMails": [
                {
                    "emailId": "string@hypaiq.net",
                    "checkSumId": "8",
                    "userName": "Suresh"
                }
            ],
            "subject": "Test email",
            "body": "Hi,  Please find the attachment and revertback to me Regards, Aravind",
            "sentDate": "2020-10-01 16:34:03.0",
            "isRead": false,
            "isStarred": false,
            "readTime": null,
            "filepaths": []
        },
        {
            "id": 128,
            "fromMail": {
                "emailId": "abc@hypaiq.net",
                "checkSumId": "10",
                "userName": "Manju"
            },
            "toMails": [
                {
                    "emailId": "aru@hypaiq.net",
                    "checkSumId": "11",
                    "userName": "aru"
                }
            ],
            "ccMails": [
                {
                    "emailId": "abc22@hypaiq.net",
                    "checkSumId": "9",
                    "userName": "Allwin"
                }
            ],
            "bccMails": [
                {
                    "emailId": "string@hypaiq.net",
                    "checkSumId": "8",
                    "userName": "Suresh"
                }
            ],
            "subject": "Test email",
            "body": "Hi,  Please find the attachment and revertback to me Regards, Aravind",
            "sentDate": "2020-10-01 16:33:36.0",
            "isRead": false,
            "isStarred": false,
            "readTime": null,
            "filepaths": []
        }
    ]
}