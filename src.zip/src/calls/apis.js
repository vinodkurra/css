import Axios from "axios";
import jwtDecode from "jwt-decode";
// import { mail } from "../json/sitedata";
import moment from "moment";

const CLIENT = "hypaiq.cyb.co.uk";
const QA = "hypaiqqa.cyb.co.uk";

// All dev urls

// let accountUrl = "https://gateway.portcullisindia.in/accounts/account";
// let authUrl = "https://authserviceswoft.portcullisindia.in/v1";
// let contentUrl = "https://gateway.portcullisindia.in/contentbuilder/";
// let stylesUrl = "https://gateway.portcullisindia.in/styles";
// let tagUrl = "https://gateway.portcullisindia.in/tags/tags/";
// let searchUrl = "https://gateway.portcullisindia.in/searchservice/search/";
// let patientsUrl = "https://gateway.portcullisindia.in/patients";
// let consulationUrl = "https://gateway.portcullisindia.in/consultation-process/"
// let mailserviceUrl = "https://gateway.portcullisindia.in/email-service";
// let appointmentUrl = "https://gateway.portcullisindia.in/scheduler";
// let postandnewsServiceUrl = "https://gateway.portcullisindia.in/postandnews";
// let notificationServiceUrl = "https://gateway.portcullisindia.in/notifications";

let accountUrl = "https://account.portcullisindia.in/account";
let authUrl = "https://authserviceswoft.portcullisindia.in/v1";
let contentUrl = "https://contentbuilder.portcullisindia.in/";
let stylesUrl = "https://style.portcullisindia.in";
let tagUrl = "https://tags.portcullisindia.in/tags/";
let searchUrl = "https://searchservice.portcullisindia.in/search/";
let patientsUrl = "https://patient.portcullisindia.in";
let consulationUrl = "https://consultation-process.portcullisindia.in/";
let mailserviceUrl = "https://hypaiqemailservice-latest.cyb.co.uk:88";
let appointmentUrl = "https://scheduler.portcullisindia.in";
let postandnewsServiceUrl = "https://hypaiqnews-latest.cyb.co.uk:89";
let notificationServiceUrl = "https://notifications.portcullisindia.in";


switch (window.location.hostname) {
  case CLIENT:

    accountUrl = "https://account.hypaiq-uat.cyb.co.uk/account";
    authUrl = "https://hypaiqauthapi.cyb.co.uk/v1";
    contentUrl = "https://contentbuilder.hypaiq-uat.cyb.co.uk/";
    stylesUrl = "https://style.hypaiq-uat.cyb.co.uk";
    tagUrl = "https://tags.hypaiq-uat.cyb.co.uk/tags/";
    searchUrl = "https://searchservice.hypaiq-uat.cyb.co.uk/search/";
    patientsUrl = "https://patient.hypaiq-uat.cyb.co.uk";
    appointmentUrl = "https://scheduler.hypaiq-uat.cyb.co.uk/";
    mailserviceUrl = "https://hypaiqemailservice-latest.cyb.co.uk:8088";
    consulationUrl = "https://consultation-process.hypaiq-uat.cyb.co.uk/";
    postandnewsServiceUrl = "https://hypaiqnews-latest.cyb.co.uk:8087/";
    break;
  case QA:
    accountUrl = "https://account.hypaiq-staging.cyb.co.uk/account";
    authUrl = "https://qa-hypaiqauthapi.cyb.co.uk/v1";
    contentUrl = "https://contentbuilder.hypaiq-staging.cyb.co.uk/";
    stylesUrl = "https://style.hypaiq-staging.cyb.co.uk";
    tagUrl = "https://tags.hypaiq-staging.cyb.co.uk/tags/";
    searchUrl = "https://searchservice.hypaiq-staging.cyb.co.uk/search/";
    patientsUrl = "https://patient-controller.hypaiq-staging.cyb.co.uk";
    appointmentUrl = "https://scheduler.hypaiq-staging.cyb.co.uk";
    mailserviceUrl = "https://emailservice.hypaiq-staging.cyb.co.uk";
    consulationUrl = "https://consultation-process.hypaiq-staging.cyb.co.uk/";
    postandnewsServiceUrl = "https://postandnews.hypaiq-staging.cyb.co.uk";
    break;
  default:
    break;
}

/**
 * to fetch token from localstorage
 */
function getToken() {
  return localStorage.getItem("token");
}

/**
 * To return axios instance for the passed baseURL
 * @param {string} url
 */
function setBaseUrl(url) {
  return Axios.create({
    baseURL: url,
  });
}

function getAccessToken() {
  let accessToken = localStorage.getItem("accesstoken");
  const acessdecoded = jwtDecode(accessToken);
  return acessdecoded;
}

const apiSearchUrl = setBaseUrl(searchUrl);
const apiSearchUrlWithToken = setBaseUrl(searchUrl);
const patientsWithToken = setBaseUrl(patientsUrl);
const mailServiceUrlWithToken = setBaseUrl(mailserviceUrl);
const appointmentUrlWithToken = setBaseUrl(appointmentUrl);
const createMailUrl = setBaseUrl(mailserviceUrl);
const postandnewsServiceUrlWithToken = setBaseUrl(postandnewsServiceUrl);
const createPostUrl = setBaseUrl(postandnewsServiceUrl);
const notificationUrl = setBaseUrl(notificationServiceUrl);

const accountApiUrlWithToken = setBaseUrl(accountUrl);
const apiContentUrlWithToken = setBaseUrl(contentUrl);
const apiUrl = setBaseUrl(authUrl);
const apiUrlWithToken = setBaseUrl(authUrl);
const stylesApi = setBaseUrl(stylesUrl);
const tagApiUrlWithToken = setBaseUrl(tagUrl);
const apiConsultationUrlWithToken = setBaseUrl(consulationUrl);

[
  accountApiUrlWithToken,
  apiContentUrlWithToken,
  apiUrlWithToken,
  tagApiUrlWithToken,
  apiSearchUrl,
  apiSearchUrlWithToken,
  patientsWithToken,
  apiConsultationUrlWithToken,
  mailServiceUrlWithToken,
  appointmentUrlWithToken,
  postandnewsServiceUrlWithToken,
].map((apiInstance) => {
  apiInstance.interceptors.request.use(function (config) {
    config.headers.accept = "application/json";
    config.headers.Authorization = `Bearer ${getToken()}`;
    return config;
  });
});

/**
 * To fetch fresh token with 1 hour expiry time
 */
async function refreshAccessToken() {
  let res = await fetch(authUrl + "/auth/gettoken", {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    redirect: "follow",
    referrer: "no-referrer",
    body: JSON.stringify({
      email: localStorage.getItem("email"),
      refreshtoken: localStorage.getItem("refreshtoken"),
    }),
  });
  const { token } = await res.json();
  localStorage.setItem("token", token);
  return token;
}
/**
 * To fetch user details
 */
async function getUserDetails() {
  if (localStorage.getItem("accesstoken")) {
    let accessDecode = jwtDecode(localStorage.getItem("accesstoken"));
    let userDetails = null;
    await apiUrlWithToken
      .get(`/auth/find/${accessDecode?.userReference}`)
      .then((result) => {
        if (result?.data?.account.length > 0)
          userDetails = result?.data?.account[0];
      })
      .catch((error) => {
        console.log("auth find api for user details:", error);
      });
    return userDetails;
  }
}

/**
 * To fetch user checksum id
 */
async function getCheckSumId() {
  if (localStorage.getItem("accesstoken")) {
    let accessDecode = jwtDecode(localStorage.getItem("accesstoken"));
    let checksumId = null;
    await apiUrlWithToken
      .get(`/auth/find/${accessDecode?.userReference}`)
      .then((result) => {
        if (result?.data?.account.length > 0)
          checksumId = result?.data?.account[0].userid;
        localStorage.setItem("account", JSON.stringify(result.data.account[0]));
      })
      .catch((error) => {
        console.log("autt find api:", error);
      });

    return checksumId;
  }
}

apiSearchUrlWithToken.interceptors.request.use(function (config) {
  config.headers.checksumid = getAccessToken().userReference;
  return config;
});

postandnewsServiceUrlWithToken.interceptors.request.use(function (config) {
  config.headers.checksumid = getAccessToken().userReference;
  return config;
});

createPostUrl.interceptors.request.use(function (config) {
  config.headers.checksumid = getAccessToken().userReference;
  return config;
});

apiSearchUrlWithToken.interceptors.request.use(function (config) {
  config.headers.checksumid = getAccessToken().userReference;
  return config;
});

apiContentUrlWithToken.interceptors.request.use(function (config) {
  config.headers.userid = 10000291;
  return config;
});

// mailServiceUrlWithToken.interceptors.request.use(function (config) {
//   config.headers.checksumid = getAccessToken().userReference;
//   config.headers.ContentType = "multipart/form-data";
//   return config;
// });

const checkSumId = getCheckSumId();
const userDetails = getUserDetails();

// Response interceptor for API calls
[
  accountApiUrlWithToken,
  apiUrlWithToken,
  apiContentUrlWithToken,
  tagApiUrlWithToken,
  apiConsultationUrlWithToken,
  mailServiceUrlWithToken,
  postandnewsServiceUrlWithToken,
].map(async (apiInstance) => {
  apiInstance.interceptors.response.use(
    async (response) => {
      const originalRequest = response.config;
      if (response.data?.code === 401 && !originalRequest._retry) {
        originalRequest._retry = true;
        const access_token = await refreshAccessToken();
        originalRequest.headers["Authorization"] = "Bearer " + access_token;
        return Axios(originalRequest);
      }
      return response;
    },
    async function (error) {
      const originalRequest = error.response?.config;
      if (error.response?.status === 401 && !originalRequest._retry) {
        originalRequest._retry = true;
        const access_token = await refreshAccessToken();
        originalRequest.headers["Authorization"] = "Bearer " + access_token;
        return Axios(originalRequest);
      }
      return Promise.reject(error);
    }
  );
});

export {
  checkSumId,
  userDetails,
  apiUrl,
  apiUrlWithToken,
  accountApiUrlWithToken,
  apiContentUrlWithToken,
  stylesApi,
  tagApiUrlWithToken,
  apiSearchUrlWithToken,
  patientsWithToken,
  apiConsultationUrlWithToken,
  appointmentUrlWithToken,
  mailServiceUrlWithToken,
  createMailUrl,
  postandnewsServiceUrlWithToken,
  createPostUrl,
  notificationUrl,
};
