/**
 * Validates web url
 * @param {string} url - The website url
 * @returns {boolean}
 */
export const validateUrl = (url) => {
  let regexp = /^((ftp|http|https):\/\/)?(www.)?(?!.*(ftp|http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+((\/)[\w#]+)*(\/\w+\?[a-zA-Z0-9_]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/;
  if (regexp.test(url)) {
    return true;
  } else {
    return false;
  }
};

export const numericValidation = (event) => {
  var charCode = (event.which) ? event.which : event.keyCode;
  if (!(charCode >= 48 && charCode <= 57)) {
    event.preventDefault();
  }
}