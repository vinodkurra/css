import 'react-app-polyfill/ie9';
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import store from './store';
import { BrowserRouter as Router } from 'react-router-dom';
import ContextProvider from './context';
import 'bootstrap/dist/css/bootstrap.min.css';

//import 'draft-js-mention-plugin/lib/plugin.css';

import App from './features';
import './index.css';

const rootElement = document.getElementById('root');

ReactDOM.render(
  <Provider store={store}>
    <ContextProvider>
      <Router>
        {/* <React.StrictMode> */}
          <App />
        {/* </React.StrictMode> */}
      </Router>
    </ContextProvider>
  </Provider>,
  rootElement
);
