import React, { useState, memo } from 'react';

function usePagination(data, itemsPerPage) {

    const [currentPage, setCurrentPage] = useState(1);
    const [startPage, setStartPage] = useState(1);
    const [endPage, setEndPage] = useState(itemsPerPage);
    const maxPage = Math.ceil(data.length / itemsPerPage);
    const totalRecords = data.length;
    const limit = itemsPerPage;
    const isNextEnable = (totalRecords < (startPage + itemsPerPage)) ? false : true;
    const isPrevEnable = ((startPage - itemsPerPage) <= 0) ? false : true;

    function currentData() {
        const begin = (currentPage - 1) * itemsPerPage;
        const end = begin + itemsPerPage;
        return data?.slice(begin, end) || [];
    }

    function next() {
        if (totalRecords < (startPage + itemsPerPage)) {
            return;
        }
        let lastPage = endPage + itemsPerPage;
        if (totalRecords < (endPage + itemsPerPage))
            lastPage = totalRecords;
        setCurrentPage((currentPage) => Math.min(currentPage + 1, maxPage));
        setStartPage((startPage) => startPage + itemsPerPage);
        setEndPage(lastPage);
    }

    function prev() {
        if ((startPage - itemsPerPage) <= 0) {
            return;
        }

        let lastPage = endPage;
        if (endPage === totalRecords) {
            const totalPages = maxPage * itemsPerPage;
            lastPage = totalPages === endPage ? endPage : totalPages;
        }

        setCurrentPage((currentPage) => Math.max(currentPage - 1, 1));
        setStartPage((startPage) => startPage - itemsPerPage);
        setEndPage(lastPage - itemsPerPage);
    }
    // function jump(page) {
    //     const pageNumber = Math.max(1, page);
    //     setCurrentPage((currentPage) => Math.min(pageNumber, maxPage));
    // }

    return { next, prev, currentData, currentPage, maxPage, totalRecords, limit, startPage, endPage, setEndPage, isNextEnable, isPrevEnable, setStartPage, setCurrentPage };
}

export default usePagination;