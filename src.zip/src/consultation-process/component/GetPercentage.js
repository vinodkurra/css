const requiredQuestions = (module) => {
    return module?.requiredQuestionAnsweredCount + ' of ' + module?.requiredQuestionCount;
}

const optionalQuestions = (module) => {
    return module?.optionalQuestionAnsweredCount + ' of ' + module?.optionalQuestionCount;
}

const requiredQuestionsPercentage = (module) => {
    const percentage = (module?.requiredQuestionAnsweredCount / module?.requiredQuestionCount || 0) * 100;
    return parseFloat(percentage.toFixed(1)) + '%';
}

const optionalQuestionsPercentage = (module) => {
    const percentage = (module?.optionalQuestionAnsweredCount / module?.optionalQuestionCount || 0) * 100;
    return parseFloat(percentage.toFixed(1)) + '%';
}

const totalQuestions = (module) => {
    return (module?.requiredQuestionAnsweredCount + module?.optionalQuestionAnsweredCount) +
        ' of ' + (module?.requiredQuestionCount + module?.optionalQuestionCount);
}

const totalQuestionsPercentage = (module) => {
    const percentage = ((module?.requiredQuestionAnsweredCount + module?.optionalQuestionAnsweredCount)
        / (module?.requiredQuestionCount + module?.optionalQuestionCount) || 0) * 100;
    return parseFloat(percentage.toFixed(1)) + '%';
}

export {
    requiredQuestions,
    optionalQuestions,
    requiredQuestionsPercentage,
    optionalQuestionsPercentage,
    totalQuestions,
    totalQuestionsPercentage
}