import React, { useState, Fragment, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Styled from 'styled-components';
import _ from "lodash";
import { map, reduce } from "awaity/esm";

import {
    TextInputWidget,
    BinaryInputWidget,
    SingleChoiceWidget,
    MultipleChoiceWidget,
    DateWidget,
    NumberWidget,
    DropdownListWidget,
    TimeInputWidget
} from '../widgets';
import {
    TEXT_INPUT_WIDGET,
    BINARY_INPUT_WIDGET,
    TIME_INPUT_WIDGET,
    SINGLE_CHOICE_WIDGET,
    MULTI_CHOICE_WIDGET,
    DATE_WIDGET,
    DROPDOWNLIST_WIDGET,
    NUMBER_WIDGET,
    SUCCESS,
    CREATED_SUCCESS,
} from '../../content-builder/components/Constants';
import {
    setContentModifiedStatus,
    updateRequiredQuestionAnsweredPercentage,
    setHighlightRequiredfields,
    setAppendNewWidgets,
    setUpdateBranchWidgetIndex
} from '../../store/consultationProcess';
import Icons from '../../content-builder/components/Header/Icons';
import GetActiveObject from '../component/GetActiveObject';
import {
    checkSumId, apiConsultationUrlWithToken,
    apiContentUrlWithToken,
} from '../../../src/calls/apis';

const WidgetByType = ({ widget }) => {
    const dispatch = useDispatch();
    const styles = useSelector((state) => state.ui.styles);
    const {
        selectedModuleId,
        processData,
        isHighlightRequiredFields,
        consultationAllWidgets
    } = useSelector((state) => state.consulationProcess);
    const inputRef = useRef(null);
    const activeObject = GetActiveObject(processData, selectedModuleId);
    let currentModuleOrWidget = activeObject.currentModuleOrWidget;
    const [branchLogicExecution, setBranchLogicExecution] = useState(false);

    //console.log('consultationAllWidgets', consultationAllWidgets);
    /**
     * Text Input Widget
     */
    const handleInputChange = (e) => {
        if (e) e.preventDefault();
        const value = e.target.value.replace(/[^\w\s]/g, '');
        e.target.value = value;
    }

    const handleTextBlur = (e) => {
        if (e) e.preventDefault();
        let isContentModified = !widget.widgetAnswer && !e.target.value ? false : true;
        widget.widgetAnswer = e.target.value;
        updateStore(widget, isContentModified);
    }

    const handleFocus = () => {
        if (inputRef.current) inputRef.current.focus();
        if (!widget?.widgetAnswer) {
            widget.widgetAnswer = widget?.defaultText;
            if (widget.widgetAnswer)
                updateStore(widget);
        }
    }

    const handleKeyPress = (event) => {
        if (event.key === "Enter") {
            inputRef.current.blur();
        }
    };

    /**
     * Binary & single choice widget
     */
    const handleRadioChange = (value, selectedIndex) => {       
        widget.widgetAnswer = '';
        widget.options.map((option, index) => {
            if (index === selectedIndex) {
                option.defaultStatus = true;
                widget.widgetAnswer = value;
            }
            else {
                option.defaultStatus = false;
            }
        });
        updateStore(widget);
    }

    /**
     * multi choice widget
     */
    const handleCheckboxChange = (value, selectedIndex) => {
        widget.widgetAnswer = '';
        widget.options.map((option, index) => {
            if (index === selectedIndex) {
                option.defaultStatus = !option.defaultStatus;
            }
        });
        widget.options.map((option, index) => {
            if (option.defaultStatus) {
                widget.widgetAnswer += option.value;
            }
        });
        updateStore(widget);
    }

    /**
    * date widget
    */
    const handleDateFieldChange = (date) => {
        widget.widgetAnswer = date;
        updateStore(widget);
    }

    const handleDateWidgetFocus = () => {
        if (!widget?.widgetAnswer) {
            widget.widgetAnswer = widget?.defaultDateValue;
            if (widget.widgetAnswer)
                updateStore(widget);
        }
    }

    /**
    * dropdown widget
    */
    const handleDropdownChange = (e) => {
        widget.options.map((option, index) => {
            option.defaultStatus = false;
            if (option.value === e.target.value)
                option.defaultStatus = true;

        })
        widget.widgetAnswer = e.target.value;
        updateStore(widget);
    };

    /**
    * time widget
    */
    const handleTimeFieldChange = (time) => {
        widget.widgetAnswer = time;
        updateStore(widget);
    }

    const handleTimeWidgetFocus = () => {
        if (!widget?.widgetAnswer) {
            widget.widgetAnswer = widget?.defaultTimeValue;
            if (widget.widgetAnswer)
                updateStore(widget);
        }
    }

    /**
     * Number widget
     */
    const handleNumberWidgetFocus = () => {
        if (inputRef.current) inputRef.current.focus();
        if (!widget?.widgetAnswer) {
            widget.widgetAnswer = widget?.defaultValue;
            if (widget.widgetAnswer)
                updateStore(widget);
        }
    }

    const handleNumberBlur = (e) => {
        if (e) e.preventDefault();
        if (widget?.minimumValue && e.target.value) {
            let currentValue = parseInt(e.target.value);
            let miniumValue = parseInt(widget?.minimumValue);
            if (currentValue < miniumValue) {
                e.target.value = '';
            }
        }
        if (widget?.maximumValue && e.target.value) {
            let currentValue = parseInt(e.target.value);
            let maximumValue = parseInt(widget?.maximumValue);
            if (currentValue > maximumValue) {
                e.target.value = '';
            }
        }
        //let isContentModified = (widget.widgetAnswer && !e.target.value) || (!widget.widgetAnswer && e.target.value);
        let isContentModified = !widget.widgetAnswer && !e.target.value ? false : true;
        widget.widgetAnswer = e.target.value;
        updateStore(widget, isContentModified);
    }

    const handleNumberInputChange = (e) => {
        if (e) e.preventDefault();
        const value = e.target.value.replace(/[^0-9.]/g, "");
        e.target.value = value;
    }

    const updateStore = (widget, isContentModified = true) => {
        setBranchLogicExecution(true);
        dispatch(setContentModifiedStatus(isContentModified, widget));
        dispatch(updateRequiredQuestionAnsweredPercentage(widget));

        //executeBranchLogic(widget);
    }

    useEffect(() => {
        if (branchLogicExecution) {
            let branchIds = _.cloneDeep(widget?.branchIds);
            executeBranchLogic(branchIds);
        }
    }, [branchLogicExecution])

    /**
     * branch widget logic
     */

    async function executeBranchLogic(branchIds) {

        //check if current widget have referred in any branch widget or not, if yes need to proceed further 
        if (branchIds?.length > 0) {
            // branchIds.map((branchId) => {
            await reduce(branchIds, async (all, branchId, branchIdIndex) => {
                //need to get branch object based on above branchid
                let currentBranchDetails = processData.branchWidgetDetails.find(branch => branch.branchId === branchId);
                let branchWidgetsExecuteStatus = processData.branchWidgetsExecuteStatus || [];
                if (currentBranchDetails !== undefined && Object.values(currentBranchDetails)?.length > 0) {
                    // let branchWidget = currentBranchDetails.branchWidget;//branch object
                    // let branchIndex = currentBranchDetails.branchIndex;//branch widget index position in response->componentList
                    // let referredWidgetIds = currentBranchDetails.referredWidgetIds;//referred widgetids from branch widget
                    // let branchChildWidgets = lodash.cloneDeep(currentBranchDetails.branchChildWidgets);//child widgets from inside branch
                    // let moduleId = currentBranchDetails.moduleId;
                    // let branchControlType = currentBranchDetails.branchControlType;
                    // let isJumpWidget = currentBranchDetails.isJumpWidget;
                    // let beforeJumpWidgets = currentBranchDetails.beforeJumpWidgets;
                    // let afterJumpWidgets = currentBranchDetails.afterJumpWidgets;
                    // let parentBranchId = currentBranchDetails.parentBranchId;
                    // let branchChildWidgetList = lodash.cloneDeep(currentBranchDetails.branchChildWidgetList);
                    // let jumpParentId = branchWidget?.jumpParentId;
                    // let jumpWidgetParentId = currentBranchDetails?.jumpWidgetParentId;
                    // let parentBranchHide = currentBranchDetails.parentBranchHide;
                    // let currentBranchHide = currentBranchDetails.currentBranchHide;

                    // let currentBranchIndex = consultationAllWidgets.findIndex(
                    //     (widget) => widget.widgetId == branchWidget.widgetId
                    // );

                    let {
                        branchWidget,
                        branchIndex,
                        referredWidgetId,
                        branchChildWidgets,
                        moduleId,
                        branchControlType,
                        isJumpWidget,
                        beforeJumpWidgets,
                        afterJumpWidgets,
                        parentBranchId,
                        branchChildWidgetList,
                        jumpWidgetParentId = undefined,
                        parentBranchHide,
                        currentBranchHide,
                        jumpChildWidgets
                    } = currentBranchDetails;
                    let jumpParentId = branchWidget?.jumpParentId;

                    branchChildWidgets = _.cloneDeep(branchChildWidgets); //child widgets from inside branch
                    branchChildWidgetList = _.cloneDeep(branchChildWidgetList);
                    let currentBranchIndex = consultationAllWidgets.findIndex(
                        (widget) => widget.widgetId == branchWidget.widgetId
                    );

                    //if branch widget and parent branch widget set hide then should not be visible
                    if (parentBranchHide || currentBranchHide)
                        return;
                    let isBranchLogicExecute = true;
                    if (parentBranchId) {
                        let parentBranchExecutionStatus = branchWidgetsExecuteStatus.findIndex(
                            (widget) => widget.branchId === parentBranchId
                        );
                        if (parentBranchExecutionStatus > -1) {
                            let parentBranchExecutionObject = branchWidgetsExecuteStatus.find(
                                (widget) => widget.branchId === parentBranchId
                            );
                            let type = parentBranchExecutionObject.type;
                            let status = parentBranchExecutionObject.status;
                            if (type === 'skip' && status)
                                isBranchLogicExecute = false;
                            if (type === 'execute' && !status)
                                isBranchLogicExecute = false;
                            if (type === 'switch' && !parentBranchExecutionObject.status[branchWidget.branchSwitchIndex])
                                isBranchLogicExecute = false;
                            if (jumpParentId) {
                                let parentJumpBranchExecutionStatus = branchWidgetsExecuteStatus.findIndex(
                                    (widget) => widget.branchId === jumpParentId
                                );
                                if (parentJumpBranchExecutionStatus > -1) {
                                    let parentJumpBranchExecutionObject = branchWidgetsExecuteStatus.find(
                                        (widget) => widget.branchId === jumpParentId
                                    );
                                    let Jumptype = parentJumpBranchExecutionObject.type;
                                    let Jumpstatus = parentJumpBranchExecutionObject.status;
                                    if (Jumptype === 'jump' && Jumpstatus)
                                        isBranchLogicExecute = false;
                                }
                                else
                                    isBranchLogicExecute = false;

                            }

                        }
                        else
                            isBranchLogicExecute = false;
                    }
                    //if parent branch doesn't execute child widget then don't need to check child branch widgets
                    if (!isBranchLogicExecute) {
                        setBranchLogicExecution(false);
                        dispatch(setAppendNewWidgets(branchChildWidgets, branchWidget, currentBranchIndex, moduleId, false));
                        return;
                    }

                    //get request for rule execution api
                    let branchInputList = getAllReferredWidgetsAnswer(branchWidget);
                    let isAnsweredAllQuestions = true;
                    branchInputList.inputList.map((input) => {//check all the questions answered
                        input.inputValues.map((reqWidget) => {
                            if (!reqWidget?.widgetAnswer)
                                isAnsweredAllQuestions = false;
                        })
                    })

                    if (!isAnsweredAllQuestions) {//if not answered all the question then don't need to check rule execution
                        //if any child widgets shows in consultation then needs to remove
                        dispatch(setAppendNewWidgets(branchChildWidgets, branchWidget, currentBranchIndex, moduleId, false));
                        setBranchLogicExecution(false);
                        return;
                    }

                    let branchLogicRequest = Object.assign({},
                        {
                            ruleId: branchWidget.widgetRuleId,
                            type: 'branch',
                            patientId: "",
                        },
                        { inputList: branchInputList.inputList });

                    //execute branch logic through api and which is return boolean response true/false
                    await apiConsultationUrlWithToken.post(`rule/execute`, branchLogicRequest)
                        .then(async (res) => {
                            if (
                                (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                                res.data != null
                            ) {

                                let branchStatus = await res.data?.answer;
                                let newWidgets = [];

                                let newBranchIds = [];
                                branchChildWidgets.map((branchChildWidget) => {
                                    if (
                                        branchChildWidget.type === 'branch'
                                        && branchIds.indexOf(branchChildWidget.widgetId) < 0
                                    ) {

                                        newBranchIds = newBranchIds.concat(branchIds);
                                        newBranchIds.push(branchChildWidget.widgetId);
                                    }
                                });

                                //check branch widget options type like skip,execute,when
                                if (branchControlType === 'jump') {
                                    let parentBranchId = branchWidget.parentBranchWidgetId;
                                    let branchDetails = processData.branchWidgetDetails.find(branch => branch.branchId === parentBranchId);
                                    if (branchDetails !== undefined && Object.values(branchDetails)?.length > 0) {
                                        // let beforeJumpWidgets = branchDetails.beforeJumpWidgets;
                                        // let childAfterJumpWidgets = branchDetails.afterJumpWidgets;
                                        let childAfterJumpWidgets = jumpChildWidgets.filter(widget => widget.widgetId === branchId)[0].widgets
                                        // let existBranchChildWidgets = lodash.cloneDeep(branchDetails.branchChildWidgets);//child widgets from inside branch
                                        //newWidgets = branchStatus ? beforeJumpWidgets : existBranchChildWidgets;
                                        // newWidgets = branchStatus ? [] : afterJumpWidgets;
                                        let currentJumpBranchIndex = consultationAllWidgets.findIndex(
                                            (widget) => widget.widgetId == parentBranchId
                                        );
                                        childAfterJumpWidgets.map((branchChildWidget) => {
                                            if (
                                                branchChildWidget.type === 'branch'
                                                && branchIds.indexOf(branchChildWidget.widgetId) < 0
                                            ) {

                                                newBranchIds = newBranchIds.concat(branchIds);
                                                newBranchIds.push(branchChildWidget.widgetId);
                                            }
                                        });

                                        dispatch(setAppendNewWidgets(childAfterJumpWidgets, branchWidget, currentJumpBranchIndex, moduleId, !branchStatus, 'jump'));
                                        setBranchLogicExecution(false);
                                        dispatch(setUpdateBranchWidgetIndex(branchWidget, branchStatus));
                                    }
                                }

                                // if (branchControlType === 'skip') {
                                //     newWidgets = isJumpWidget ? beforeJumpWidgets : branchChildWidgets;
                                //     dispatch(setAppendNewWidgets(newWidgets, branchWidget, currentBranchIndex, moduleId, !branchStatus));
                                //     dispatch(setUpdateBranchWidgetIndex(branchWidget, branchStatus));
                                //     setBranchLogicExecution(false);

                                // } else if (branchControlType === 'execute') {
                                //     newWidgets = isJumpWidget ? beforeJumpWidgets : branchChildWidgets;
                                //     dispatch(setAppendNewWidgets(newWidgets, branchWidget, currentBranchIndex, moduleId, branchStatus));
                                //     dispatch(setUpdateBranchWidgetIndex(branchWidget, branchStatus));
                                //     setBranchLogicExecution(false);
                                // } 

                                if (branchControlType === 'skip' || branchControlType === 'execute') {
                                    let parentJumpStatus = isJumpWidget;
                                    if (jumpWidgetParentId) {
                                        let parentJumpExecutionStatus = branchWidgetsExecuteStatus.findIndex(
                                            (widget) => widget.branchId === jumpWidgetParentId
                                        );
                                        if (parentJumpExecutionStatus > -1) {
                                            let parentJumpExecutionObject = branchWidgetsExecuteStatus.find(
                                                (widget) => widget.branchId === jumpWidgetParentId
                                            );
                                            //  let Jumptype = parentJumpExecutionObject.type;
                                            // let Jumpstatus = parentJumpExecutionObject.status;
                                            if (parentJumpExecutionObject.type === 'jump')
                                                parentJumpStatus = parentJumpExecutionObject.status;
                                        }
                                    }

                                    let currentBranchStatus = branchControlType === 'skip' ? !branchStatus : branchStatus;
                                    newWidgets = parentJumpStatus ? beforeJumpWidgets : branchChildWidgets;
                                    dispatch(setAppendNewWidgets(newWidgets, branchWidget, currentBranchIndex, moduleId, currentBranchStatus));
                                    dispatch(setUpdateBranchWidgetIndex(branchWidget, branchStatus));
                                    setBranchLogicExecution(false);
                                }
                                else if (branchControlType === 'switch') {
                                    let childWidgets = [];
                                    let isSwitchBranch = false;
                                    branchStatus.map((status, statusIndex) => {
                                        if (status) {
                                            isSwitchBranch = status;
                                            childWidgets.push(branchChildWidgetList[statusIndex]);
                                            if (branchChildWidgetList[statusIndex].type === 'execution_frame')
                                                childWidgets = childWidgets.concat(branchChildWidgetList[statusIndex].widgetList);
                                        }
                                    });
                                    dispatch(setAppendNewWidgets(childWidgets, branchWidget, currentBranchIndex, moduleId, isSwitchBranch));
                                    dispatch(setUpdateBranchWidgetIndex(branchWidget, branchStatus));
                                    setBranchLogicExecution(false);
                                }
                                //again loop
                                if (newBranchIds?.length > 0) {
                                    newBranchIds.splice(branchIdIndex, 1);
                                    if (branchIds?.length - 1 === branchIdIndex)
                                        callback(newBranchIds);
                                }
                            }
                        })
                        .catch((error) => {
                            console.log('publish api', error);

                        })
                }
            })
        }
    }

    function getAllReferredWidgetsAnswer(branchWidget) {

        // let referredWidgetsAnswer = [];
        branchWidget.referedWidgetIds.map((referredWidgetId) => {
            consultationAllWidgets.map((widget) => {
                if (widget?.widgetId === referredWidgetId) {
                    branchWidget.inputList.map((input) => {
                        input.inputValues.map((reqWidget) => {
                            if (reqWidget.widgetId === widget.widgetId) {
                                reqWidget.widgetAnswer = widget.widgetAnswer;
                            }
                        })
                        // if (reqWidget.widgetId === widget.widgetId) {
                        //     reqWidget.widgetAnswer = widget.widgetAnswer;
                        // }
                    })
                    // let requestWidget = {
                    //     id: widget.widgetId,
                    //     widgetAnswer: widget.widgetAnswer,
                    //     type: widget.type
                    // };
                    // referredWidgetsAnswer.push(requestWidget);
                }
            });
        });
        return branchWidget;
    }

    function callback(branchIds) {
        executeBranchLogic(branchIds);
    }



    const renderWidget = () => {
        switch (widget.type) {
            case TEXT_INPUT_WIDGET:
                return (
                    <TextInputWidget
                        inputRef={inputRef}
                        widget={widget}
                        handleInputChange={handleInputChange}
                        handleFocus={handleFocus}
                        handleTextBlur={handleTextBlur}
                        handleKeyPress={handleKeyPress}
                    />
                );
            case BINARY_INPUT_WIDGET:
                return (
                    <BinaryInputWidget
                        widget={widget}
                        handleRadioChange={handleRadioChange}
                    />
                );
            case SINGLE_CHOICE_WIDGET:
                return (
                    <SingleChoiceWidget
                        widget={widget}
                        handleRadioChange={handleRadioChange}
                    />
                );
            case MULTI_CHOICE_WIDGET:
                return (
                    <MultipleChoiceWidget
                        widget={widget}
                        handleCheckboxChange={handleCheckboxChange}
                    />
                );
            case DATE_WIDGET:
                return (
                    <DateWidget
                        widget={widget}
                        handleDateFieldChange={handleDateFieldChange}
                        handleDateWidgetFocus={handleDateWidgetFocus}
                    />
                );
            case NUMBER_WIDGET:
                return (
                    <NumberWidget
                        inputRef={inputRef}
                        widget={widget}
                        handleInputChange={handleNumberInputChange}
                        handleNumberWidgetFocus={handleNumberWidgetFocus}
                        handleTextBlur={handleNumberBlur}
                        handleKeyPress={handleKeyPress}
                    // handleKeyUp={handleKeyUp}
                    />
                );
            case DROPDOWNLIST_WIDGET:
                return (
                    <DropdownListWidget
                        widget={widget}
                        handleDropdownChange={handleDropdownChange}
                    />
                );
            case TIME_INPUT_WIDGET:
                return (
                    <TimeInputWidget
                        widget={widget}
                        inputRef={inputRef}
                        handleTimeFieldChange={handleTimeFieldChange}
                        handleTimeWidgetFocus={handleTimeWidgetFocus}
                    />
                );

            default:
                return false;
        }
    };

    return (
        <WidgetStyle>
            <Fragment key={widget.widgetId}>
                <div className="questionIcon">
                    {
                        //outside widget only
                        widget.componentType === 'widget' ?
                            !widget.widgetAnswer ?
                                <Icons
                                    className="asideIcon "
                                    src={styles.icons.consultation_Outside_Widget}
                                    title="Additonal Widget"
                                    triggerFunc={() => { }}
                                    isActive={true}
                                /> : <Icons
                                    className="asideIcon"
                                    src={styles.icons.consultation_Outside_Widget_Complete}
                                    title="Answered Well"
                                    triggerFunc={() => { }}
                                    isActive={true}
                                /> : ''
                    }
                    {
                        //isHighlightRequiredFields - use this field to apply animation
                        (widget.required && !widget.widgetAnswer) ?
                            <Icons
                                className="asideIcon"
                                src={styles.icons.consultation_answer_required}
                                title="Required"
                                triggerFunc={() => { }}
                                isActive={true}
                                requiredAnimation={isHighlightRequiredFields}
                            /> : widget.widgetAnswer ?
                                <Icons
                                    className="asideIcon"
                                    src={styles.icons.consultation_answered}
                                    title="Answered"
                                    triggerFunc={() => { }}
                                    isActive={true}
                                /> : ''
                    }
                    {
                        widget?.widgetQuestion ?
                            <div className="QuestionFields" title={widget?.widgetQuestion}>{widget?.widgetQuestion}</div>
                            : <div className="QuestionFields">--------------------</div>
                    }
                </div>
                {/* <div className="sub_txt">{widget?.widgetSubText}</div> */}
                {
                    renderWidget()
                }
            </Fragment>
        </WidgetStyle>
    );
}

export default WidgetByType;

const WidgetStyle = Styled.div`
.questionIcon{
    display: flex;
    align-items: center;
    position: relative;
    // height: 20px;
    margin-top: 16px;
    span{
        position: absolute;
        right: 0;
    }
}
[title="Additonal Widget"], [title="Answered Well"]{
    right: initial !important;
    left: -10px;
    top: -2px;
}
.QuestionFields{
    font-weight:600;
  }
  
  i{
    position:absolute;
    right:0px;  
  }
  
  
  i.inptfld_filled{
    color:#8bc34a;
  }
  .sub_txt{
    font-size:10px;
    margin-left:17px;
  }
  input[type='text'],input[type='radio'],input[type='check']{
    border:none;
    border-bottom:solid 1px lightgray;
    width: 92%;
    margin-left: 17px;
    margin-top:5px;
  }
`;