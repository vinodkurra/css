export default function GetActiveObject(processData, selectedModuleId) {
    let processTitle = processData?.title;
    const componentList = processData?.componentList?.length > 0 ? processData?.componentList : [];
    let currentModuleOrWidget = componentList?.find(module => module.moduleId === selectedModuleId);
    let isRequiredQuestionExist = currentModuleOrWidget?.requiredQuestionCount > 0 ? true : false;

    let currentObject = {
        processTitle: processTitle,
        currentModuleOrWidget: currentModuleOrWidget || [],
        title: currentModuleOrWidget?.title,
        isContentModified: currentModuleOrWidget?.isContentModified || false,
        isRestartModule: currentModuleOrWidget?.isRestartModule || false,
        isRequiredQuestionExist: isRequiredQuestionExist
    }
    return currentObject;
}