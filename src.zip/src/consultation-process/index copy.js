import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from "react-redux";
import FooterMenu from '../features/dashboard/components/FooterMenu';
import DashboardContentTwo from "../features/home/seconddashboard";
import Thirddashboard from "../features/home/thirddashboard";
import Message from "../features/home/message";
import styled, { ThemeProvider } from "styled-components";
import * as mytheme from "../exportables/Colors";

import Persona from "../features/home/components/Submenu/Persona";
import DropdownContent from "../features/home/components/Submenu/DropdownContent";
import Counts from "../features/home/components/Submenu/Counts";
import { viewLatestpostFullscreen, addNewPost } from "../store/LandingPage/index";
import { MakePost, GridButton } from "../features/home/seconddashboard";

import {
    ConsultationModules,
    ConsultationWidgets,
    ConsultationActionMenu,
    ConsultationInfoPanel
} from './landing-view';

import { getConsultationData, getConsultationProcessData } from '../store/consultationProcess';

const ConsultationProcess = () => {
    const dispatch = useDispatch();
    const [name, setName] = useState("");
    const checked = useSelector((state) => state.landingpage.latestPostScreen);
    const LatestPostData = useSelector((state) => state.landingpage.latestposts);

    let commonData = LatestPostData.posts;
    const handleSubmit = (evt) => {
        evt.preventDefault();
        let addObj = {
            id: commonData.length + 1,
            sender: "MyName",
            title: name,
            content: "sdf",
            department: "Health",
            branch: "Technology",
            name: "St Mary's",
            type: 1,
            source:
                "https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg",
            time: "now",
        };
        dispatch(addNewPost(addObj));
    }
    /**
     * get process data based on 
     */
    useEffect(() => {
        // dispatch(getConsultationData());
        dispatch(getConsultationProcessData());
    }, [])

    return (
        <>
            <ThemeProvider theme={mytheme}>
                <GlobalStyle>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-3">
                                <SubMenu>
                                    <Persona />
                                    <Counts />
                                    <DropdownContent />
                                </SubMenu>
                            </div>
                            {checked ? (
                                <div className="col-md-7">
                                    <LatestPost>
                                        <Header>
                                            <div>
                                                <h3>Latest Post</h3>
                                            </div>

                                            <div>
                                                <input placeholder="Search" />
                                            </div>
                                            <div>
                                                <button
                                                    onClick={() => dispatch(viewLatestpostFullscreen())}
                                                >
                                                    close
                        </button>
                                            </div>
                                        </Header>

                                        <Firstschedule className="row">
                                            <div className="col-md-4">
                                                <img
                                                    src={commonData[0].source}
                                                    className="img-responsive"
                                                />
                                                <GridText2>
                                                    <p>{commonData[0].sender}</p>
                                                    <h3>{commonData[0].title}</h3>
                                                    <p>{commonData[0].content}</p>
                                                    <p>{commonData[0].time}</p>
                                                    <GridText3>
                                                        <p>
                                                            {" "}
                                                            {commonData[0].department} |{" "}
                                                            {commonData[0].branch} | {commonData[0].name}
                                                        </p>
                                                    </GridText3>
                                                </GridText2>
                                            </div>
                                            <div className="col-md-5">
                                                {commonData.slice(1).map((data) => (
                                                    <Readhistory>
                                                        <ul>
                                                            <li>
                                                                <img
                                                                    src={data.source}
                                                                    className="img-responsive"
                                                                />
                                                            </li>
                                                            <li>
                                                                <GridText2>
                                                                    <p>{data.sender}</p>
                                                                    <h3>{data.title}</h3>
                                                                    <p>{data.content}</p>
                                                                    <GridText3>
                                                                        <p>
                                                                            {" "}
                                                                            {data.department} |{" "}
                                                                            {data.branch} | {data.name}
                                                                        </p>
                                                                    </GridText3>
                                                                </GridText2>
                                                            </li>
                                                            <li>
                                                                <p>{data.time}</p>
                                                                <p>
                                                                    <i class="fa fa-smile-o" aria-hidden="true"></i>
                                                                </p>
                                                            </li>
                                                        </ul>
                                                    </Readhistory>
                                                ))}
                                            </div>

                                            <OwnNetwotk className="col-md-3">
                                                <OwnNetwotkHeader>
                                                    <h2>New Content from your network</h2>
                                                </OwnNetwotkHeader>
                                                {LatestPostData.networkpost.map((data) => (
                                                    <OwnNetwotkBg>
                                                        <ul>
                                                            <li>{data.sender}</li>
                                                            <li>{data.time}</li>
                                                        </ul>
                                                        <h4>{data.content}</h4>
                                                        <GridText2>
                                                            <p>{data.department} |{" "}
                                                                {data.branch} | {data.name}</p>
                                                        </GridText2>
                                                        <Checklib>
                                                            <p>Check in Library</p>
                                                        </Checklib>
                                                    </OwnNetwotkBg>
                                                ))}
                                            </OwnNetwotk>
                                        </Firstschedule>
                                        <div className="row ">
                                            <History>
                                                <div className="col-md-7 ">
                                                    <h3>Based on your Reading History</h3>
                                                    {LatestPostData.historybased.map((data) => (
                                                        <Readhistory>
                                                            <ul>
                                                                <li>
                                                                    <img
                                                                        src={data.source}
                                                                        className="img-responsive"
                                                                    />
                                                                </li>
                                                                <li>
                                                                    <GridText2>
                                                                        <p>{data.sender}</p>
                                                                        <h3>{data.title}</h3>
                                                                        <p>{data.content}</p>
                                                                        <GridText3>
                                                                            <p>
                                                                                {data.department} |{" "}
                                                                                {data.branch} |{" "}
                                                                                {data.name}
                                                                            </p>
                                                                        </GridText3>
                                                                    </GridText2>
                                                                </li>
                                                                <li>
                                                                    <p>{data.time}</p>
                                                                    <p>
                                                                        <i
                                                                            class="fa fa-smile-o"
                                                                            aria-hidden="true"
                                                                        ></i>
                                                                    </p>
                                                                </li>
                                                            </ul>
                                                        </Readhistory>
                                                    ))}
                                                </div>
                                                <Trends className="col-md-5">
                                                    <h3>Trending on HypalQ</h3>
                                                    {LatestPostData.hypalqtrend.map((hypalq) => (
                                                        <Readhistory>
                                                            <ul>
                                                                <li>
                                                                    <h1>01</h1>
                                                                </li>
                                                                <li>
                                                                    <GridText2>
                                                                        <p>{hypalq.sender}</p>
                                                                        <h3>{hypalq.title}</h3>
                                                                        <p>{hypalq.content}</p>
                                                                        <GridText3>
                                                                            <p>
                                                                                {hypalq.department} |{" "}
                                                                                {hypalq.branch} |{" "}
                                                                                {hypalq.name}
                                                                            </p>
                                                                        </GridText3>
                                                                    </GridText2>
                                                                </li>
                                                                <li>
                                                                    <p>4h</p>
                                                                    <p>
                                                                        <i
                                                                            class="fa fa-smile-o"
                                                                            aria-hidden="true"
                                                                        ></i>
                                                                    </p>
                                                                </li>
                                                            </ul>
                                                        </Readhistory>
                                                    ))

                                                    }


                                                </Trends>
                                            </History>
                                            <GridButton>
                                                <button
                                                    type="button"
                                                    data-toggle="modal"
                                                    data-target="#myModalcreatepost"
                                                >
                                                    <i className="fa fa-plus" aria-hidden="true"></i> Make a
                        Post
                      </button>
                                            </GridButton>
                                        </div>
                                        <MakePost />
                                    </LatestPost>
                                </div>
                            ) : null}
                            {!checked ? (
                                <div className="col-md-7">
                                    {/* <DashboardContentTwo /> */}
                                    <ConsultationProcessStyles>

                                        <div className="container" style={{ padding: "0px", minHeight: "81.3vh" }} >
                                            <div className="row" style={{ padding: "0px" }}>
                                                <div className="col-md-9" style={{ padding: "0px" }}>
                                                    <GlobalStyle1 >
                                                        <div className="container" style={{ minHeight: "fit-content" }}>
                                                            <div className="row" style={{ height: "100%" }} >
                                                                <div className="col-md-3">
                                                                    <ConsultationModules />
                                                                </div>
                                                                <div className="col-md-7">
                                                                    <ConsultationWidgets />
                                                                </div>
                                                                <div className="col-md-2 icontxt_colr">
                                                                    <ConsultationActionMenu />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </GlobalStyle1>
                                                </div>
                                                <div className="col-md-3" >
                                                    <GlobalStyle1>
                                                        <div className="container" style={{ minHeight: "fit-content" }}>
                                                            <div className="row" >
                                                                <div className="col-md-12" style={{ padding: "0px" }}>
                                                                    <ConsultationInfoPanel />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </GlobalStyle1>
                                                </div>
                                            </div>



                                        </div>















                                        {/* <ConsultationModules /> */}
                                        {/* <ConsultationWidgets /> */}
                                        {/* <ConsultationActionMenu /> */}
                                        {/* <ConsultationInfoPanel /> */}
                                    </ConsultationProcessStyles>
                                </div>
                            ) : null}
                            {/* {!checked ? (
                <div className="col-md-3">
                  <Thirddashboard />
                </div>
              ) : null} */}
                            {/* <div className="col-md-1"></div> */}
                            <div className="col-md-2">
                                <Message />
                            </div>
                        </div>
                    </div>
                </GlobalStyle>
            </ThemeProvider>

        </>
    );
    // return (
    //     <ConsultationProcessStyles>
    //         <ConsultationModules />
    //         <ConsultationWidgets />
    //         <ConsultationActionMenu />
    //         <ConsultationInfoPanel />
    //     </ConsultationProcessStyles>
    // )
}

export default ConsultationProcess;

const ConsultationProcessStyles = styled.div`
`;
const GlobalStyle = styled.section``;
const GlobalStyle1 = styled.section`
    background-color: ${(props) => props.theme.DashboardContentThreeColors.backgroundColor};
    padding: 10px 15px;
    margin-top: 30px;
    border-radius: 10px;

    h4,.header_txt{
        font-size:16px !important;
    }

    .txt_blue_clr{
        color:#80d7d8;
    }
    .required{
        color:#c62828;
    }
    .col-md-3{
        padding-left:0px;
    }
    .vertical_lnbar{
        position: absolute;
        width: 109%;
        border-top: solid 2px lightgray;
        top: 0px;
        right: 0px;
    }
    .vertical_lnbar_right{
        position: absolute;
        top: -9px;
        width: 126%;
        left: -10px;
        border-bottom: solid 2px lightgray;
    }
    .bordr_top{
        border-top: solid 2px #738c87;
    }

    .tab1_fld{
        min-height: 40vh;
        max-height: 49vh;
        overflow-y: auto;
    }

    .input_flds{
        max-height: 49vh;
        overflow-y: auto;
        overflow-x: hidden;
    }
    .header_txt{
        margin-top:10px;
        font-weight:600;
    }
    .page_indx{
        position:absolute;
        bottom:0px;
        text-align:center;
        width:100%;
        padding: 12px;
        margin: 0px;
        font-size: 13px;
        color:#738c87;
        margin-top:20px;
        font-weight: 600;
        min-height: 47px;
    }

    .bx_shdw{
        box-shadow: 6px 2px 6px -9px;
    }

    .bx_shdwdiv{
        position: absolute;
        right: 0px;
        color: lightblue;
        top: -11px;
        /* border-right: solid 1px lightgray; */
        width: 0.5px;
        box-shadow: 3px 2px 4px 0px;
        height: 107%;
    }

    i{
        color:#80d7d8;
        font-size:18px !important;
    }
    .txt_gry_clr{
        color: #738c87;
        font-size:10px;
        font-weight:600; 
    }
    .icontxt_colr{
        color:#80d7d8;
        padding-right:0px;
        text-align:center;

        ul li{
            list-style: none;
            margin-top:20px;
        }

        ul li p{
            font-size: 10px !important;
            font-weight: 600;
            margin-top: 5px;
        }
    }
    .e-radio:checked + .e-success:hover::after { /* csslint allow: adjoining-classes */
        background-color: #449d44;
        border-color: #449d44;
      }
      table{
        font-size:12px;
         margin-top:10px;
        tr td:nth-child(odd){
            vertical-align: top;
        }
        tr td:nth-child(even){
            font-weight:600;
            padding-left: 5px;
            vertical-align: bottom;
        }
      }
      
      

`;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne
            .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;

const LatestPost = styled.div`


    padding: 10px 15px;
    margin-top: 30px;
    border-radius: 10px;
  background-color: #fff;
  input {
    float: right;
  }
`;

const Header = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 80%;
    }
    :nth-child(2) input {
      background-color: #dae7e4;
      border-radius: 50px;
      padding: 5px;
      border: none;
      margin: 10px;
    }
  }
`;

const Firstschedule = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
  margin-bottom: 10px;
`;

const GridText2 = styled.div`
  padding-left: 10px;
  padding-right: 0px;
  h3 {
    font-size: 16px;
    color: #7f00ab;
    margin-bottom: 0px;
  }
  p {
    margin-bottom: 5px;
    font-size: 11px;
  }
`;

const GridText3 = styled.div`
  p {
    color: #738c87;
    font-size: 11px;
  }
`;

const OwnNetwotk = styled.div`
  padding: 10px;
`;

const OwnNetwotkHeader = styled.div`
  background-color: #7f00ab;
  padding: 0px 10px 0px 10px;
`;

const OwnNetwotkBg = styled.div`
  background-color: #f3fffd;
  margin-top: -10px;
  h4 {
    color: #7f00ab;
    font-weight: 600;
    padding: 10px 12px 0px 12px;
  }
  .gridtext3 {
    p {
      padding: 0px 12px;
    }
  }
  ul {
    list-style: none;
    margin: 0px;
    li {
      display: inline-block;
      padding: 5px 10px;
      :nth-child(2) {
        float: right;
      }
    }
  }
`;

const History = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
`;

const Readhistory = styled.div`
  ul {
    display: flex;
    margin: 0;
    list-style: none;
    li {
      margin-right: 5px;
      h1 {
        color: #e5ccee;
        font-size: 45px;
      }
    }
  }
`;

const Trends = styled.div`
  padding: 0px;
`;

const Checklib = styled.div`
  p {
    text-align: right;
    padding: 0px 10px;
    color: #0e8a8b;
    font-size: 13px;
    font-weight: 600;
  }
`;