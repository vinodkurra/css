import React from 'react';
import styled from 'styled-components';
import DateField from 'hypaiq-rc/lib/DateField';
const moment = require('moment')
/**
 * DateWidget component, this will appear in content edit pane, when date type widget is selected.  
 */
export default function DateWidget({ widget, handleDateFieldChange, handleDateWidgetFocus }) {
  ;
  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <DateField
            selected={widget?.widgetAnswer}
            minDate={widget?.minimumDateValue ? new Date(widget?.minimumDateValue) : null}
            maxDate={widget?.maximumDateValue ? new Date(widget?.maximumDateValue) : null}
            onChange={e => handleDateFieldChange(e)}
            placeholderText={widget?.defaultDateValue ? moment(widget?.defaultDateValue).format('DD/MM/YYYY') : 'DD/MM/YYYY'}
            onFocus={handleDateWidgetFocus}
            onClick={handleDateWidgetFocus}
          />
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
