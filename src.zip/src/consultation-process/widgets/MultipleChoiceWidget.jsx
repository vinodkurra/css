import React, { Fragment } from 'react';
import styled from 'styled-components';

export default function MultipleChoiceWidget({ widget, handleCheckboxChange }) {
  //const styles = useSelector((state) => state.ui.styles);

  return (
    <Styles>
      <div
        className="multipleChoiceWidgetContainer">
        <Fragment key={widget.widgetId + '-' + widget.widgetAnswer}>
          {
            widget?.options.map((option, index) =>
              <Fragment key={widget.widgetId + '-' + index}>
                <div
                  className={
                    option.defaultStatus && !widget?.widgetAnswer ? 'labelInputContainer defaultAnswer' : option.defaultStatus && widget?.widgetAnswer ? 'labelInputContainer focusAnswer' : 'labelInputContainer'
                  }
                >
                  <input id={widget?.widgetId + '-' + index} type="checkbox"
                    name={widget?.widgetId + '-' + index}
                    value={option.value}
                    checked={option.defaultStatus}
                    onChange={(e) => handleCheckboxChange(option.value, index)}
                  />
                  <label htmlFor={widget?.widgetId + '-' + index} onClick={(e) => handleCheckboxChange(option.value, index)} title={option.option}>
                    {option.option?.slice(0, 1) == '@' ? option.option?.split('[').pop()?.split(']')[0] : option.option}
                  </label>
                </div>
              </Fragment>
            )
          }
        </Fragment>
      </div>
      {/* <div className="default_values">
        {widget?.defaultOptions?.map((each, i) => (
          <div className="input_group" key={i}>
            {i === 0 ? <label>Default</label> : <label></label>}
            <input type="radio" name={widget.title} value={i}
              //  checked={widget.selectedDefaultOptionindex === i ? true : false}
              checked={each?.defaultStatus}
              placeholder="(Value)" onClick={(e) => handleCommonInputWidget(e, "radio", i)} />
            <input type="text" className="width40 mr5" value={each.value} placeholder="(Value)" onChange={(e) => handleCommonInputWidget(e, "value", i)} />
            <input type="text" placeholder="Write option" value={each.option} onChange={(e) => handleCommonInputWidget(e, "option", i)} />
            <Icons
              src={styles.icons.widget_option_delete_icon}
              title="Delete"
              triggerFunc={(e) => handleCommonInputWidget(e, "delete_Default_option_set", i)}
              // isActive={i > -1}
              isActive={widget?.defaultOptions.length > 2}
              widgetOptionDeleteIcon={true}
            />
          </div>
        ))}
      </div> */}
    </Styles>
  );
}

const Styles = styled.div` 
.default_values {
    .input_group {
      display: flex;  
      align-items: center;   
      padding-bottom: 5px; 
      label {
        font-size: 14px;
        min-width: 50px;
        padding-top: 4px;
        margin-bottom: 0px !important;
      }      
      input[type="text"]{
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
      input[type="radio"]{
        margin: 0px 6px 0px 6px;
      }
    }      
  }
  .width40{
    width: 40% !important;
  }
  .mr5
  {
    margin-right: 5px;
  }
  .delete_option{
    font-size: 15px;
    margin-left:10px;
    font-weight: bold;
    color: black;
    cursor: pointer;
    border: solid 1px;
    border-radius:50px;
  }
  .widget_delete_icon {
    background: #494949;
    margin-right: 0;
    clip-path: ellipse(83% 58% at 103% 51%);
  }
.multipleChoiceWidgetContainer{
  display: flex;
  flex-direction: column;
  .labelInputContainer{
    display: flex;
    input[type='checkbox'], input[type='radio']{
      width: 30px;
      margin-left: 17px;
      position: relative;
      top: 4px;
    }
    label{
      width: 19vw;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }
}
.defaultAnswer{
    
}
`;