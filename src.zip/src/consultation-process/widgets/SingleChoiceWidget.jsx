import React, { Fragment } from 'react';
import styled from 'styled-components';

export default function SingleChoiceWidget({ widget, handleRadioChange }) {
  return (
    <Styles>
      <div className="singleChoiceWidgetContainer">
        <Fragment key={widget.widgetId + '-' + widget.widgetAnswer}>
          {
            widget?.options.map((option, index) =>
              <Fragment key={widget.widgetId + '-' + index}>
                <div
                  className={
                    option.defaultStatus && !widget?.widgetAnswer ? 'singleChoiseLabelInputContainer defaultAnswer' : option.defaultStatus && widget?.widgetAnswer ? 'singleChoiseLabelInputContainer focusAnswer' : 'singleChoiseLabelInputContainer'
                  }
                >
                  <input id={widget?.widgetId + '-' + index} type="radio"
                    name={widget?.widgetId + '-' + index}
                    value={option.value}
                    checked={option.defaultStatus}
                    onClick={(e) => handleRadioChange(option.value, index)}
                  />
                  <label htmlFor={widget?.widgetId + '-' + index}
                    onClick={(e) => handleRadioChange(option.value, index)} title={option.option}>
                    {option.option?.slice(0, 1) == '@' ? option.option?.split('[').pop()?.split(']')[0] : option.option}
                  </label>
                </div>
              </Fragment>
            )
          }
        </Fragment>
      </div>
    </Styles>
  );
}

const Styles = styled.div` 
.default_values {
    .input_group {
      display: flex;  
      padding-bottom: 5px; 
      align-items: center;
      label {
        font-size: 14px;
        min-width: 50px;
        padding-top: 4px;
        margin-bottom: 0px !important;
      }      
      input[type="text"]{
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
      input[type="radio"]{
        margin: 0px 6px 0px 6px;
      }
    }      
  }
  .width40{
    width: 40% !important;
  }
  .mr5
  {
    margin-right: 5px;
  }
  .delete_option{
    font-size: 15px;
    margin-left:10px;
    font-weight: bold;
    color: black;
    cursor: pointer;
    border: solid 1px;
    border-radius:50px;
  }
  .singleChoiceWidgetContainer{
    display: flex;
    flex-direction: column;
  .singleChoiseLabelInputContainer{
    display: flex;
    input[type='checkbox'], input[type='radio']{
      width: 30px;
      position: relative;
      top: 4px;
    }
    label{
      width: 19vw;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }
}
.defaultAnswer{
 
}
`;