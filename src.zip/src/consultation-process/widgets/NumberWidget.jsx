import React, { Fragment } from 'react';
import styled from 'styled-components';

export default function NumberWidget({ widget, handleInputChange, handleTextBlur, handleNumberWidgetFocus, inputRef, handleKeyPress, handleKeyUp }) {
  // return (
  //   <Styles>
  //     <div className="default_values">
  //       <div className="input_group">
  //         <input type="text"
  //           ref={inputRef}
  //           value={widget.minimumValue}
  //           onChange={(e) => handleInputChange(e)}
  //           onBlur={(e) => handleTextBlur(e)}
  //           onFocus={handleFocus}
  //           onKeyPress={handleKeyPress}
  //         />
  //       </div>
  //     </div>
  //   </Styles>
  // );
  return (
    <Styles>
      <Fragment key={widget.widgetId + '-' + widget.widgetAnswer}>
        <input type="text" placeholder="Type Here"
          ref={inputRef}
          defaultValue={widget?.widgetAnswer || ''}
          autoComplete="off"
          name={widget.widgetId}
          id={widget.widgetId}
          //value={widget?.widgetAnswer}
          onChange={(e) => handleInputChange(e)}
          onBlur={(e) => handleTextBlur(e)}
          onFocus={handleNumberWidgetFocus}
          onKeyPress={handleKeyPress}
          onKeyUp={handleKeyUp}
          placeholder={widget?.defaultValue || 'Type Here'}
        // min={widget?.minimumValue || ''}
        // max={widget?.maximumValue || ''}
        />
      </Fragment>
    </Styles>
  );
}

const Styles = styled.div`
 
.QuestionFields{
  font-weight:600;
}

i{
  position:absolute;
  right:0px;  
}


i.inptfld_filled{
  color:#8bc34a;
}
.sub_txt{
  font-size:10px;
  margin-left:17px;
}
input[type='text'],input[type='radio'],input[type='check']{
  border:none;
  border-bottom:solid 1px lightgray;
  width:87%;
  margin-left:17px;
  margin-top:5px;
}
input::placeholder{
  color: #cfcfcf;
}
`;