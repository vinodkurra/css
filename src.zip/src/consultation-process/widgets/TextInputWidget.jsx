import React, { Fragment } from 'react';
import styled from 'styled-components';


export default function TextInputWidget({ widget, handleInputChange, handleTextBlur, handleFocus, inputRef, handleKeyPress }) {

  return (
    <Styles>
      <Fragment key={widget.widgetId + '-' + widget.widgetAnswer}>
        <input type="text"
          ref={inputRef}
          defaultValue={widget?.widgetAnswer || ''}
          autoComplete="off"
          name={widget.widgetId}
          id={widget.widgetId}
          //value={widget?.widgetAnswer}
          onChange={(e) => handleInputChange(e)}
          onBlur={(e) => handleTextBlur(e)}
          onFocus={handleFocus}
          onKeyPress={handleKeyPress}
          placeholder={widget?.defaultText?.slice(0, 1) == '@' ? widget?.defaultText?.split('[').pop()?.split(']')[0] : widget.defaultText || 'Type Here'}
        />
      </Fragment>
    </Styles>
  );
}

const Styles = styled.div`
 
.QuestionFields{
  font-weight:600;
}

i{
  position:absolute;
  right:0px;  
}


i.inptfld_filled{
  color:#8bc34a;
}
.sub_txt{
  font-size:10px;
  margin-left:17px;
}
input[type='text'],input[type='radio'],input[type='check']{
  border:none;
  border-bottom:solid 1px lightgray;
  width:87%;
  margin-left:17px;
  margin-top:5px;
}
input::placeholder{
  color: #cfcfcf;
}
`;