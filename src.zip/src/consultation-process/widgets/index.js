import TextInputWidget from './TextInputWidget';
import BinaryInputWidget from './BinaryInputWidget';
import SingleChoiceWidget from './SingleChoiceWidget';
import MultipleChoiceWidget from './MultipleChoiceWidget';
import DateWidget from './DateWidget';
import NumberWidget from './NumberWidget';
import DropdownListWidget from './DropdownListWidget';
import TimeInputWidget from './TimeInputWidget';
import DropdownConsultation from './DropdownConsultationView';

export {
    TextInputWidget,
    BinaryInputWidget,
    SingleChoiceWidget,
    MultipleChoiceWidget,
    DateWidget,
    NumberWidget,
    DropdownListWidget,
    TimeInputWidget,
    DropdownConsultation
};