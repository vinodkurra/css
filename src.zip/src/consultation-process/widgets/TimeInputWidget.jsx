import React from 'react';
import { TimePicker } from 'antd';
import styled from 'styled-components';
import moment from 'moment';
import 'antd/dist/antd.css';

/**
 * TimeInputWidget component, this will appear in content edit pane, when Time type widget is selected.
 */
export default function TimeInputWidget({ widget, inputRef, handleTimeFieldChange, handleTimeWidgetFocus }) {
  /**
   * This func is to check for invalid date
   * @param {object} momenttime - has the moment time object
   * @returns {object} momenttime - if moment object is valid date else return empty string
   */
  function checkValidDate(momenttime) {
    if (momenttime._isValid) return momenttime;
    return '';
  }

  return (
    <Styles>
      <div className="default_values">
        <div className="input_group">
          <TimePicker
            //  ref={inputRef}
            value={checkValidDate(moment(widget.widgetAnswer, 'HH:mm'))}
            // value={checkValidDate(moment('08:00', 'HH:mm'))}
            format={'HH:mm'}
            onChange={(_, timeString) =>
              handleTimeFieldChange(timeString)
            }
            placeholder={widget?.defaultTimeValue || 'Type Here'}
            onFocus={handleTimeWidgetFocus}
          />
        </div>
      </div>
    </Styles>
  );
}

const Styles = styled.div`
  .default_values {
    .input_group {
      display: flex;
      align-items: center;
      padding-bottom: 5px;
      label {
        font-size: 14px;
        margin-bottom: 0;
        margin-right: 15px;
        width: 100px;
      }
      input {
        width: 100%;
        font-size: 15px;
        border: 0;
        outline: 0;
        height: 0;
        padding: 13px 5px;
      }
    }
  }
`;
