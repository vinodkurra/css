import React from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';

import Icons from '../../content-builder/components/Header/Icons';
import {
    saveProcessByAppointmentId,
    setHighlightRequiredfields,
    updateProcessByProcessId,
    setLoadingSpinner
} from '../../store/consultationProcess';
import GetActiveObject from '../component/GetActiveObject';

const ConsultationActionMenu = ({ handleUndoRestart, handlePreviewOutput }) => {
    const dispatch = useDispatch();
    const styles = useSelector((state) => state.ui.styles);
    const {
        selectedModuleId,
        processData,
        isHighlightRequiredFields
    } = useSelector((state) => state.consulationProcess);

    const activeObject = GetActiveObject(processData, selectedModuleId);
    let processTitle = activeObject.processTitle;
    const isContentModified = activeObject.isContentModified;
    const isRestartModule = activeObject.isRestartModule;
    let moduleTitle = activeObject?.title;
    let isRequiredQuestionExist = activeObject?.isRequiredQuestionExist;

    const handleSave = () => {
        dispatch(saveProcessByAppointmentId(processData, selectedModuleId));
    }

    const handleHighlightRequiredField = () => {
        dispatch(setHighlightRequiredfields(!isHighlightRequiredFields));
    }

    const handleProcessSubmit = () => {

    }

    return (
        <ConsultationActionMenuStyles>
            <div className="menuIconSection">
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_save}
                        title="SAVE"
                        triggerFunc={(e) => handleSave(e)}
                        isActive={isContentModified}
                    />
                    <p className={isContentModified ? 'active' : ''}>SAVE</p>
                </div>
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_undo}
                        title="UNDO"
                        triggerFunc={(e) => handleUndoRestart(e, 'UNDO', moduleTitle)}
                        isActive={isContentModified}
                    />
                    <p className={isContentModified ? 'active' : ''}>UNDO</p>
                </div>
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_restart_module}
                        title="RESTART MODULE"
                        triggerFunc={(e) => handleUndoRestart(e, 'RESTART MODULE', moduleTitle)}
                        isActive={(isContentModified || isRestartModule)}
                    />
                    <p className={(isContentModified || isRestartModule) ? 'active' : ''}>RESTART MODULE</p>
                </div>
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_highlight_r_field}
                        title="HIGHLIGHTER R.FIELDS"
                        triggerFunc={() => handleHighlightRequiredField()}
                        isActive={isRequiredQuestionExist}
                    />
                    <p className={(isRequiredQuestionExist) ? 'active' : ''}>HIGHLIGHTER FIELDS</p>
                </div>
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_preview_output}
                        title="PREVIEW OUTPUT"
                        triggerFunc={handlePreviewOutput}
                        isActive={isRestartModule}
                    />
                    <p className={(isRestartModule) ? 'active' : ''}>PREVIEW OUTPUT</p>
                </div>
                <div className="iconContainer">
                    <Icons
                        src={styles.icons.consultation_submit}
                        title="SUBMIT"
                        triggerFunc={() => handleProcessSubmit}
                        isActive={false}
                    />
                    <p>SUBMIT</p>
                </div>
            </div>
            <div className={isRestartModule ? 'txt_gry_clr' : 'txt_gry_clr disabled'} style={{ position: "relative" }}>
                <div className="vertical_lnbar_right"></div>
                <div className='cursor' style={{ marginTop: "10px" }}
                    onClick={(e) => handleUndoRestart(e, 'RESTART PROCESS', processTitle)}>RESTART PROCESS</div>
                <div className='cursor' style={{ marginTop: "5px" }}
                    onClick={(e) => handleUndoRestart(e, 'EXIT PROCESS', processTitle)}>EXIT PROCESS</div>
            </div>
        </ConsultationActionMenuStyles>
    )
}

export default ConsultationActionMenu;

const ConsultationActionMenuStyles = Styled.div`
.menuIconSection{
    display: flex;
    flex-direction: column;
    text-align: center;
    justify-content: center;
    height: calc(100vh - 165px);
}
.iconContainer{
    cursor: pointor;
    span{
        img{
            width: 5vh;
        }
    }
    .active{
        color: #80d6d7;
    }
    p{
        font-size: 12px;
        font-weight: 700;
        color: #dce9e6;
    }
}
.cursor{
    cursor:pointer;
}
.disabled {
    pointer-events: none;
    opacity: 0.7;
  }
`;