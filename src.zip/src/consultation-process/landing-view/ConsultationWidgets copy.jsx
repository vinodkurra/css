import React, { useEffect, useRef } from 'react';
import Styled from 'styled-components';
import { useSelector } from 'react-redux';

import WidgetByType from '../component/WidgetByType';
import {
    WARNING_INPUT_WIDGET,
    CALCULATION_WIDGET,
    NARRATIVE_WIDGET,
    BRANCH_CONTROL_WIDGET,
    BLANK_WIDGET,
    SKIP_WIDGET,
    EXECUTE_WIDGET,
    SWITCH_WIDGET,
    JUMP_WIDGET,
    MULTIPLE_EXECUTION
} from "../../content-builder/components/Constants";
import usePagination from '../component/usePagination';

const ConsultationWidgets = () => {
    const {
        processData,
        selectedModuleId
    } = useSelector((state) => state.consulationProcess);

    const modulesOrWidgets = processData?.componentList?.length > 0 ? processData?.componentList : [];
    let currentModuleOrWidget = modulesOrWidgets.find(module => module.moduleId === selectedModuleId);
    let moduleTitle = currentModuleOrWidget?.title;
    //const widgetList = GetWidgets();

    // const maximumPerPageLimit = 14;
    // const perPagePagination = currentModuleOrWidget?.widgetList?.length < maximumPerPageLimit ?
    //     currentModuleOrWidget?.widgetList?.length :
    //     maximumPerPageLimit;

    // const { next, prev, currentData, totalRecords, startPage, endPage, setEndPage, isNextEnable, isPrevEnable, setStartPage, setCurrentPage } =
    //     usePagination(currentModuleOrWidget?.widgetList || [], perPagePagination);

    // useEffect(() => {
    //     if (currentModuleOrWidget?.widgetList?.length > 0) {
    //         setCurrentPage(1);
    //         setStartPage(1);
    //         setEndPage(perPagePagination);
    //     }
    // }, [selectedModuleId]);

    // const widgetList = currentData();

    // function GetWidgets() {
    //     let modules = [];
    //     if (processData?.componentList?.length > 0) {
    //         processData.componentList.map((component) => {
    //             if (component.componentType === 'module') {
    //                 modules.push({moduleID})
    //                 component.widgetList.map((widget) => {
    //                     let currentWidget = Object.assign({}, widget, { moduleId: component.moduleId });
    //                     widgets.push(currentWidget);
    //                 })
    //             }
    //         })
    //         console.log('allwidgets:', widgets);
    //     }

    //     return widgets;
    // }

    const handleMouseRoller = (e) => {
        const el = document.querySelector('.widgetFormContainer');

    }

    return (
        <ConsultationWidgetsStyles>
            <div className="bx_shdwdiv"></div>
            <h4 className="moduleTitle">{moduleTitle}</h4>
            <div className="widgetFormContainer input_flds" style={{ padding: "0px" }}
                onWheel={handleMouseRoller}>
                {
                    // currentModule?.widgetList?.length > 0 ?
                    //     currentModule.widgetList.map((widget, index) => (
                    widgetList?.length > 0 ?
                        widgetList.map((widget, index) => (
                            !widget.hide &&
                                widget.type !== WARNING_INPUT_WIDGET &&
                                widget.type !== CALCULATION_WIDGET &&
                                widget.type !== NARRATIVE_WIDGET &&
                                widget.type !== BRANCH_CONTROL_WIDGET &&
                                widget.type !== BLANK_WIDGET &&
                                widget.type !== SKIP_WIDGET &&
                                widget.type !== EXECUTE_WIDGET &&
                                widget.type !== JUMP_WIDGET &&
                                widget.type !== MULTIPLE_EXECUTION &&
                                widget.type !== SWITCH_WIDGET ? (
                                    (index > 0 && widget.moduleId !== widgetList[index - 1]?.moduleId) ?
                                        <>
                                            <div key={index + '-' + widget.moduleId}>
                                                ------------------------------------------------------------------------
                                            </div>
                                            <div id={widget.moduleId} key={index} className="widgetForm sarath" >
                                                <WidgetByType widget={widget} />
                                            </div>
                                        </>
                                        :
                                        <div id={index === 0 ? widget.moduleId : ''} key={index} className={index === 0 ? 'widgetForm sarth' : 'widgetForm'}>
                                            <WidgetByType widget={widget} />
                                        </div>

                                )
                                : ('')
                        )) : ''
                }
                <div id="6729244880147632128"></div>
            </div>
            {/* {
                totalRecords > maximumPerPageLimit ?
                    <div className="page_indx">
                        <div className="vertical_lnbar"></div>
                        <div>{startPage} - {endPage} of {totalRecords}
                            <span className={!isPrevEnable ? 'disabled incDec' : 'incDec'} onClick={() => { prev(); }}>&lt;</span>
                            <span className={!isNextEnable ? 'disabled incDec' : 'incDec'} onClick={() => { next(); }}>&gt;</span> </div>
                    </div> : ''
            } */}
        </ConsultationWidgetsStyles>
    )
}

export default ConsultationWidgets;

// const ConsultationWidgetsStyles = Styled.div`
// `;
const ConsultationWidgetsStyles = Styled.div`
// seperate css

.incDec{
    padding-left: 14px;
    cursor:pointer;
}
.disabled {
    pointer-events: none;
    opacity: 0.7;
  }
.moduleTitle{
    padding: 12px 8px;
}

// end seperate css


    .QuestionFields{
        font-weight:600;
        margin-left: 17px;
        width: 90%;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        width: 210px;
    }

    i{
        position:absolute;
        right:0px;  
    }
    

    i.inptfld_filled{
        color:#8bc34a;
    }
    .sub_txt{
        font-size:10px;
        margin-left:17px;
    }
    .QuestionFields{}
    label{
        font-size: 16px !important;
        color: #d6d6d6 !important;
        font-weight: 400 !important;
    }
    input[type='text'], input[type='radio'], input[type='check'], select, .default_values .input_group input{
        border:none;
        border-bottom:solid 1px lightgray;
        width:87%;
        margin-left:17px;
        position: relative;
        top: 4px;
        box-shadow: none;
        border-radius: 0;
        outline: 0;
        option{
            width: 200px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
    }
    // .labelInputContainer, .binaryLabelInputContainer, .singleChoiseLabelInputContainer{
    //     input[type='radio']:checked, input[type='checkbox']:checked{
    //         &:after{
    //             border: 1px solid #3d534e;
    //             background: #3d534e;
    //         }
    //         &:before{
    //             border: 1px solid #3d534e;
    //             background: #fff;
    //         }
    //     }
    //     input[type='radio'], input[type='checkbox']{
    //         height: 20px;
    //         position: relative;
    //         bottom: 2px;
    //         &:after {
    //             content: "";
    //             opacity: 1;
    //             width: 14px;
    //             height: 14px;
    //             position: absolute;
    //             left: 9px;
    //             top: 5px;
    //             z-index: 2;
    //             border: 1px solid #d6d6d6;
    //             background: #d6d6d6;
    //         }
    //         &:before {
    //             content: "";
    //             opacity: 1;
    //             width: 22px;
    //             height: 22px;
    //             position: absolute;
    //             left: 5px;
    //             border: 1px solid #d6d6d6;
    //             z-index: 1;
    //             background: #fff;
    //         }
    //     }
    //     label{
    //         color: #cfcfcf;
    //     }

    // }
    input[type='radio']:checked + label, input[type='checkbox']:checked + label{
        color: #3d534e !important;
    }
    .defaultAnswer{
        label{
            color: darkgrey !important;
            font-weight: 600 !important;
        }
    }
    // .defaultAnswer{
    //     input[type='radio'], input[type='checkbox']{
    //         height: 20px;
    //         position: relative;
    //         bottom: 2px;
    //         &:after {
    //             content: "";
    //             opacity: 1;
    //             width: 14px;
    //             height: 14px;
    //             position: absolute;
    //             left: 9px;
    //             top: 5px;
    //             z-index: 2;
    //             border: 1px solid #3d534e;
    //             COLOR: #3d534e;
    //         }
    //         &:before {
    //             content: "";
    //             opacity: 1;
    //             width: 22px;
    //             height: 22px;
    //             position: absolute;
    //             left: 5px;
    //             border: 1px solid #3d534e;
    //             z-index: 1;
    //             background: #fff;
    //         }
    //     }
    //     label{
    //         color: #cfcfcf;
    //     }

    // }
    .datefield > span > svg{
        opacity: 0.2;
        font-size: 18px;
        padding-bottom: 3px;
        margin-right: 12px;
    }
    .ant-picker, .datefield{
        border: none;
        width: 100%;
    }
    .ant-picker-suffix{
        position: absolute;
        right: 8px;
    }
    .widgetFormContainer{
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;        
    }
    .widgetForm{
        width: 50%;
        padding: 0 2%;
    }
`;