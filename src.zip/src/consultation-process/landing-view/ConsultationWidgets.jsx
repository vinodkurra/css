import React, { useEffect, useRef, useState } from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import PerfectScrollbar from 'react-perfect-scrollbar'
import 'react-perfect-scrollbar/dist/css/styles.css';

import WidgetByType from '../component/WidgetByType';
import {
    WARNING_INPUT_WIDGET,
    CALCULATION_WIDGET,
    NARRATIVE_WIDGET,
    BRANCH_CONTROL_WIDGET,
    BLANK_WIDGET,
    SKIP_WIDGET,
    EXECUTE_WIDGET,
    SWITCH_WIDGET,
    JUMP_WIDGET,
    MULTIPLE_EXECUTION
} from "../../content-builder/components/Constants";
import usePagination from '../component/usePagination';
import {
    setSelectedModuleId,
    setModuleNewPaginationDetails,
    setKeySelectedModuleId
} from '../../store/consultationProcess';
//import { $ } from 'jquery';

const ConsultationWidgets = () => {
    const dispatch = useDispatch();
    const {
        processData,
        selectedModuleId,
        selectedModuleIdStatus,
        modulesPaginationDetails,
        isModuleClicked
    } = useSelector((state) => state.consulationProcess);
    const [modulesWidgetScrollPositions, setModulesWidgetScrollPositions] = useState([]);

    const modulesOrWidgets = processData?.componentList?.length > 0 ? processData?.componentList : [];
    let currentModuleOrWidget = modulesOrWidgets.find(module => module.moduleId === selectedModuleId);
    let moduleTitle = currentModuleOrWidget?.title;
    //need to enable for pagination

    // const maximumPerPageLimit = 14;
    // const perPagePagination = currentModuleOrWidget?.widgetList?.length < maximumPerPageLimit ?
    //     currentModuleOrWidget?.widgetList?.length :
    //     maximumPerPageLimit;

    // const { next, prev, currentData, totalRecords, startPage, endPage, setEndPage, isNextEnable, isPrevEnable, setStartPage, setCurrentPage } =
    //     usePagination(currentModuleOrWidget?.widgetList || [], perPagePagination);

    // useEffect(() => {
    //     if (currentModuleOrWidget?.widgetList?.length > 0) {
    //         setCurrentPage(1);
    //         setStartPage(1);
    //         setEndPage(perPagePagination);
    //     }
    // }, [selectedModuleId]);

    // const widgetList = currentData();

    /**
     * maintain all modules scroll position
     */
    useEffect(() => {
        if (modulesWidgetScrollPositions?.length === 0 && processData?.componentList?.length > 0) {
            let modulesWidgetPositions = [];
            const sections = document.querySelectorAll("section[id]");
            sections.forEach(current => {
                const moduleId = current.getAttribute("id");
                const position = current.getBoundingClientRect().y;
                let obj = {
                    moduleId: moduleId,
                    position: position
                }
                modulesWidgetPositions.push(obj);
            });
            console.log('modulesWidgetScrollPosition', modulesWidgetPositions);
            setModulesWidgetScrollPositions(modulesWidgetPositions);
            dispatch(setSelectedModuleId(modulesWidgetPositions[0].moduleId));
            //pagination();
        }
    }, [processData?.componentList?.length > 0])

    /**
     * widget pane scroll and need to select corresponding module
     */
    const handleonScrollY = (e, flag) => {

        if (selectedModuleIdStatus) {
            dispatch(setKeySelectedModuleId(false));
        }
        const currentModule = modulesWidgetScrollPositions.sort(
            (a, b) => Math.abs((e.scrollTop - 0) - a.position) -
                Math.abs((e.scrollTop - 0) - b.position)
        )[0];
        // const currentModule = modulesWidgetScrollPositions.sort(
        //     (a, b) => Math.abs((e.scrollTop + 100) - a.position) -
        //         Math.abs((e.scrollTop + 40) - b.position)
        // )[0];
        if (!selectedModuleIdStatus && currentModule !== undefined && currentModule?.moduleId && currentModule?.moduleId !== selectedModuleId) {
            console.log('currentModule:', currentModule);
            const moduleId = currentModule?.moduleId;
            if (processData?.modulesPaginationList?.length > 0) {
                //modulesPaginationDetails
                let modulesPaginationList = processData?.modulesPaginationList;
                modulesPaginationList.map((module) => {
                    if (module.pageLimitModuleIds.indexOf(moduleId) > -1) {
                        if (module.startPage !== modulesPaginationDetails.startPage) {
                            let currentPagination = { startPage: module.startPage, endPage: module.endPage };
                            dispatch(setModuleNewPaginationDetails(currentPagination));
                        }
                    }
                })
            }
            dispatch(setSelectedModuleId(moduleId));
        }
    }

    function pagination() {
        let pageBreakPositions = [
            { index: 4, moduleId: 0, type: 'module' },
            { index: 1, moduleId: 0, type: 'widget' },
            { index: 2, moduleId: 0, type: 'module' },
            { index: 4, moduleId: 0, type: 'widget' }
        ];
        let totalWidgetCount = 0;
        let startCount = 0;
        let endCount = 0;
        debugger;
        pageBreakPositions.map((pageBreak, pageBreakIndex) => {
            processData.componentList.map((module, moduleIndex) => {
                module.widgetList.map((widget, widgetIndex) => {
                    totalWidgetCount++;
                    if (!startCount)
                        startCount++;
                    let index = (pageBreak.type === 'module') ? widgetIndex : moduleIndex;
                    if (pageBreak.index === index) {
                        pageBreak.totalWidgetCount = totalWidgetCount;
                        pageBreak.startCount = startCount;
                        pageBreak.endCount = widgetIndex + 1;
                        startCount++;
                        totalWidgetCount = 0;
                    }
                })
            })
        })
    }

    return (
        <ConsultationWidgetsStyles>
            <div className="bx_shdwdiv"></div>
            <h4 className="moduleTitle">{moduleTitle}</h4>
            <div className="widgetFormContainer input_flds" style={{ padding: "0px" }}>
                <PerfectScrollbar component="div"
                    onScrollY={(e) => handleonScrollY(e, true)}
                >
                    {
                        // currentModule?.widgetList?.length > 0 ?
                        //     currentModule.widgetList.map((widget, index) => (
                        processData.componentList?.length > 0 ?
                            processData.componentList.map((moduelOrWidget) => (
                                <section id={moduelOrWidget.moduleId}>
                                    {
                                        moduelOrWidget.widgetList.map((widget, index) => (
                                            !widget.hide &&
                                                widget.type !== WARNING_INPUT_WIDGET &&
                                                widget.type !== CALCULATION_WIDGET &&
                                                widget.type !== NARRATIVE_WIDGET &&
                                                widget.type !== BRANCH_CONTROL_WIDGET &&
                                                widget.type !== BLANK_WIDGET &&
                                                widget.type !== SKIP_WIDGET &&
                                                widget.type !== EXECUTE_WIDGET &&
                                                widget.type !== JUMP_WIDGET &&
                                                widget.type !== MULTIPLE_EXECUTION &&
                                                widget.type !== SWITCH_WIDGET ? (
                                                    <div key={index} className="widgetForm" >
                                                        <WidgetByType widget={widget} />
                                                    </div>

                                                )
                                                : ('')
                                        ))
                                    }
                                    <div className="moduleEndLine">
                                        <span>{'End of ' + moduelOrWidget.title}</span>

                                    </div>
                                    <div className="endLine"></div>

                                </section>

                            ))
                            : ''
                    }
                </PerfectScrollbar>
            </div>

            {/* need to enable for pagination
             {
                totalRecords > maximumPerPageLimit ?
                    <div className="page_indx">
                        <div className="vertical_lnbar"></div>
                        <div>{startPage} - {endPage} of {totalRecords}
                            <span className={!isPrevEnable ? 'disabled incDec' : 'incDec'} onClick={() => { prev(); }}>&lt;</span>
                            <span className={!isNextEnable ? 'disabled incDec' : 'incDec'} onClick={() => { next(); }}>&gt;</span> </div>
                    </div> : ''
            } */}
        </ConsultationWidgetsStyles>
    )
}

export default ConsultationWidgets;

const ConsultationWidgetsStyles = Styled.div`
.scrollbar-container{
    width: 100%;
    section{
        display: flex;
    flex-wrap: wrap;
    align-content: flex-start;  
    }
}
.moduleEndLine{
    display: flex;
    flex-direction: row-reverse;
    width: 542px;
    height: 25px;
    align-items: center;
    margin: 0 auto;
    span{
        color: #bfbfbf;
        font-size: 12px;
        position: relative;
        right: 2px;
    }
    }
    .endLine{
        height: 2px;
        background: #0e8a8b;
        width: 91%;
        margin: 0 auto;
    }

.incDec{
    padding-left: 14px;
    cursor:pointer;
}
.disabled {
    pointer-events: none;
    opacity: 0.7;
  }
.moduleTitle{
    padding: 12px 8px;
}

// end seperate css


    .QuestionFields{
        font-weight:600;
        margin-left: 17px;
        width: 90%;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        width: 210px;
    }

    i{
        position:absolute;
        right:0px;  
    }
    

    i.inptfld_filled{
        color:#8bc34a;
    }
    .sub_txt{
        font-size:10px;
        margin-left:17px;
    }
    .QuestionFields{}
    label{
        font-size: 16px !important;
        color: #d6d6d6 !important;
        font-weight: 400 !important;
    }
    input[type='text'], input[type='radio'], input[type='check'], select, .default_values .input_group input{
        border:none;
        border-bottom:solid 1px lightgray;
        width:87%;
        margin-left:17px;
        position: relative;
        top: 4px;
        box-shadow: none;
        border-radius: 0;
        outline: 0;
        option{
            width: 200px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
    }
    // .labelInputContainer, .binaryLabelInputContainer, .singleChoiseLabelInputContainer{
    //     input[type='radio']:checked, input[type='checkbox']:checked{
    //         &:after{
    //             border: 1px solid #3d534e;
    //             background: #3d534e;
    //         }
    //         &:before{
    //             border: 1px solid #3d534e;
    //             background: #fff;
    //         }
    //     }
    //     input[type='radio'], input[type='checkbox']{
    //         height: 20px;
    //         position: relative;
    //         bottom: 2px;
    //         &:after {
    //             content: "";
    //             opacity: 1;
    //             width: 14px;
    //             height: 14px;
    //             position: absolute;
    //             left: 9px;
    //             top: 5px;
    //             z-index: 2;
    //             border: 1px solid #d6d6d6;
    //             background: #d6d6d6;
    //         }
    //         &:before {
    //             content: "";
    //             opacity: 1;
    //             width: 22px;
    //             height: 22px;
    //             position: absolute;
    //             left: 5px;
    //             border: 1px solid #d6d6d6;
    //             z-index: 1;
    //             background: #fff;
    //         }
    //     }
    //     label{
    //         color: #cfcfcf;
    //     }

    // }
    input[type='radio']:checked + label, input[type='checkbox']:checked + label{
        //color: #3d534e !important;
    }
    .defaultAnswer{
        label{
            color: #9f9f9f !important;          
        }
        input[type='radio']:checked , input[type='checkbox']:checked{
            opacity: 0.5;
          }
    }
    .focusAnswer{
        label{
            color: darkgrey !important;
            font-weight: 600 !important;
        }
        input[type='radio']:checked + label, input[type='checkbox']:checked + label{
            color: #3d534e !important;
          }
    }
    // .defaultAnswer{
    //     input[type='radio'], input[type='checkbox']{
    //         height: 20px;
    //         position: relative;
    //         bottom: 2px;
    //         &:after {
    //             content: "";
    //             opacity: 1;
    //             width: 14px;
    //             height: 14px;
    //             position: absolute;
    //             left: 9px;
    //             top: 5px;
    //             z-index: 2;
    //             border: 1px solid #3d534e;
    //             COLOR: #3d534e;
    //         }
    //         &:before {
    //             content: "";
    //             opacity: 1;
    //             width: 22px;
    //             height: 22px;
    //             position: absolute;
    //             left: 5px;
    //             border: 1px solid #3d534e;
    //             z-index: 1;
    //             background: #fff;
    //         }
    //     }
    //     label{
    //         color: #cfcfcf;
    //     }

    // }
    .datefield > span > svg{
        opacity: 0.2;
        font-size: 18px;
        padding-bottom: 3px;
        margin-right: 12px;
    }
    .ant-picker, .datefield{
        border: none;
        width: 100%;
    }
    .ant-picker-suffix{
        position: absolute;
        right: 8px;
    }
    .widgetFormContainer{
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;        
    }
    .widgetForm{
        width: 50%;
        padding: 0 2%;
    }
`;