import React, { useEffect } from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';

import {
    setSelectedModuleId,
    setModulePaginationDetails,
    setModuleNewPaginationDetails,
    setKeySelectedModuleId,
    setModuleClicked
} from '../../store/consultationProcess';
import usePagination from '../component/usePagination';
import {
    requiredQuestions,
    optionalQuestions,
    requiredQuestionsPercentage,
    optionalQuestionsPercentage,
    totalQuestions,
    totalQuestionsPercentage
} from '../component/GetPercentage';
import Icons from '../../content-builder/components/Header/Icons';


const ConsultationModules = () => {
    const styles = useSelector((state) => state.ui.styles);
    const dispatch = useDispatch();
    const {
        processData,
        selectedModuleId,
        selectedModuleIdStatus,
        modulesNewPaginationDetails,
        modulesPaginationDetails,
        isModuleClicked
    } = useSelector((state) => state.consulationProcess);
    const maximumPerPageLimit = 14;
    const perPagePagination = processData?.componentList?.length < maximumPerPageLimit ? processData?.componentList?.length : maximumPerPageLimit;

    const { next, prev, currentData, totalRecords, startPage, endPage, setEndPage, isNextEnable, isPrevEnable } =
        usePagination(processData?.componentList || [], perPagePagination);

    useEffect(() => {
        if (processData?.componentList?.length > 0) {

            setEndPage(perPagePagination);
            dispatch(setModulePaginationDetails({ startPage: startPage, endPage: startPage }));
        }
    }, [perPagePagination]);

    useEffect(() => {
        if (startPage && endPage) {
            dispatch(setModulePaginationDetails({ startPage: startPage, endPage: endPage }));
        }
    }, [startPage, endPage]);

    useEffect(() => {
        if (modulesNewPaginationDetails != undefined && Object.values(modulesNewPaginationDetails)?.length > 0) {
            if (modulesPaginationDetails.startPage > modulesNewPaginationDetails.startPage) {
                prev();
            }
            else {
                next();
            }
            dispatch(setModuleNewPaginationDetails({}));
        }
    }, [modulesNewPaginationDetails != undefined && Object.values(modulesNewPaginationDetails)?.length > 0])

    const modulesOrWidgets = currentData();

    const processTitle = processData ? processData.title : '';

    /**
     * select module
     */
    const handleSetSelectedModule = (module) => {
        dispatch(setSelectedModuleId(module.moduleId));
        dispatch(setKeySelectedModuleId(true));
        if (!isModuleClicked) {
            dispatch(setModuleClicked(true));
        }
    }

    const checkModuleCompleted = (module) => {
        let isRequiredCompleted = false;
        if (module.requiredQuestionCount > 0) {
            isRequiredCompleted = module.requiredQuestionCount === module.requiredQuestionAnsweredCount;
        }
        if (module.optionalQuestionCount > 0) {
            isRequiredCompleted = module.optionalQuestionCount === module.optionalQuestionAnsweredCount;
        }
        return isRequiredCompleted;
    }

    const resetWidgetPane = () => {
        dispatch(setSelectedModuleId(null));
    }
    return (
        <ConsultationModuelsStyles>
            <div className="bx_shdwdiv"></div>
            <h4 title={processTitle} className="processTitle">{processTitle}</h4>
            <div className="tab1_fld">
                {
                    modulesOrWidgets.map((module, index) =>
                        <>
                            {
                                (module.componentType === 'widget' && selectedModuleId !== module.moduleId) ?
                                    <div className="outSideModuleLine"></div> : ''
                            }
                            <a href={'#' + module.moduleId} key={index} className={
                                (selectedModuleId === module.moduleId ? 'header_fld Fld_active' : 'header_fld')
                            } onClick={() => handleSetSelectedModule(module)}>
                                {
                                    module.componentType === 'module' ?
                                        <input type="radio" name="group1"
                                            checked={selectedModuleId === module.moduleId ? true : false}
                                            className={
                                                (checkModuleCompleted(module) ? 'module_completed' : '')
                                            }
                                        /> :
                                        (
                                            checkModuleCompleted(module) ?
                                                <Icons
                                                    className="asideIcon"
                                                    src={styles.icons.consultation_Outside_Widget_Complete}
                                                    title="Additonal Widgets"
                                                    triggerFunc={() => { }}
                                                    isActive={true}
                                                /> :
                                                <Icons
                                                    className="asideIcon"
                                                    src={styles.icons.consultation_Outside_Widget}
                                                    title="Additonal Widgets"
                                                    triggerFunc={() => { }}
                                                    isActive={true}
                                                />
                                        )

                                }

                                <div>
                                    <div onClick={() => handleSetSelectedModule(module)}>{module.title}</div>
                                    <div className="sub_txt">
                                        <span>{totalQuestions(module)} | {totalQuestionsPercentage(module)}</span>
                                        <div>Required {requiredQuestions(module)} | {requiredQuestionsPercentage(module)}</div>
                                    </div>
                                </div>
                            </a>
                            {
                                (module.componentType === 'widget' && selectedModuleId !== module.moduleId) ?
                                    <div className="outSideModuleLine"></div> : ''
                            }
                        </>

                    )
                }
            </div>
            {
                totalRecords > maximumPerPageLimit ?
                    <div className="page_indx">
                        <div className="vertical_lnbar"></div>
                        <div>{startPage} - {endPage} of {totalRecords}
                            <span className={!isPrevEnable ? 'disabled incDec' : 'incDec'} onClick={() => { prev(); resetWidgetPane() }}>&lt;</span>
                            <span className={!isNextEnable ? 'disabled incDec' : 'incDec'} onClick={() => { next(); resetWidgetPane() }}>&gt;</span> </div>
                    </div> : ''
            }
        </ConsultationModuelsStyles>
    )
}

export default ConsultationModules;

const ConsultationModuelsStyles = Styled.div`
// seperate css
.incDec{
    padding-left: 14px;
    cursor:pointer;
}
.outSideModuleLine{
    height: 2px;
    width: 100%;
    background: #f2f2f2;
}
.processTitle{
    color: #7e9591;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    padding: 12px 8px;
}

// end seperate css


color:#c7c7c7;

.header_fld{
    color: #c7c7c7;
    span{
        margin: 0;
        padding: 3px;
        height: 16px;
        width: 16px;
        img{
            width: 14px;
            height: 16px;
            position: relative;
            right: 3px;
        }
    }
}
    .header_fld{
        display: flex;
        padding:5px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        input[type='radio']{
            float: left;
            height: 58px;
            margin-top: -17px;
            margin-right: 5px;
        }

        // input[type='radio']:checked {
        //     background-color: #93e026 !important;
        //     border:solid 1px black;
        //   }
    }
    .Fld_active{
        background-color: #00897B !important;
        color: #fff;
        
    }

    .sub_txt{
        font-size: xx-small; 
    }
    .module_completed{
        
    }
    input[type='radio']{
        visibility: hidden;
        position: relative;
        top: 27px;
      }
      
          input[type='radio']:before{
              content: '';
              height: 12px;
              width: 12px;
              border-radius: 50%;
              background-color: #fff;
            border: 2px solid #c4c4c4;
              position: absolute;
              visibility: visible;
          }
      
       .module_completed:before {
              content: '';
              height: 12px !important;
              width: 12px !important;
              border-radius: 50%;
              background-color: #c4c4c4 !important;
              border:none !important;
              position: absolute;
              visibility: visible;
          }
      
      
          input[type='radio']:checked:before {
              content: '';
              height: 12px;
              width: 12px;
              border-radius: 50%;
              background-color: #fff;
              position: absolute;
            border: none;
              visibility: visible;
          }
      input[type='radio']:checked:after {
              content: '';
              height: 12px;
              width: 12px;
              border-radius: 50%;
              border: 2px solid black;
              position: absolute;
              visibility: visible;
          }
   .disabled {
        pointer-events: none;
        opacity: 0.7;
      }
`;
// const Tabfielderstyle = Styled.section`

//     color:#738c87;
//     .header_fld{
//         padding:5px;
//         font-size: 13px;
//         font-weight: 600;

//         input[type='radio']{
//             float: left;
//             height: 58px;
//             margin-top: -17px;
//             margin-right: 5px;
//         }

//         // input[type='radio']:checked {
//         //     background-color: #93e026 !important;
//         //     border:solid 1px black;
//         //   }
//     }
//     .Fld_active{
//         background-color: #00897B !important;
//         color: #fff;

//     }

//     .sub_txt{
//         font-size: xx-small; 
//     }

// `;