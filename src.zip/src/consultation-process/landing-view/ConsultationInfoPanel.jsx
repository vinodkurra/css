import React from 'react';
import Styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { requiredQuestions, totalQuestions } from '../component/GetPercentage';

const ConsultationInfoPanel = () => {
    const {
        processData,
        selectedModuleId
    } = useSelector((state) => state.consulationProcess);
    const processTitle = processData ? processData.title : '';

    const currentModuleOrWidgets = processData?.componentList?.length > 0 ? processData?.componentList : [];
    let totalModules = currentModuleOrWidgets?.length || 0;
    let currentModuleOrWidget = currentModuleOrWidgets.find(module => module.moduleId === selectedModuleId);
    let moduleTitle = currentModuleOrWidget?.title;

    return (
        <ConsultationInfoPanelStyles>
            <h4>Info</h4>
            <div className="patientBottomSpace">
                <p className="header_txt">Patient</p>
                <table>
                    <thead></thead>
                    <tbody>
                        <tr>
                            <td>Patient Name:</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Patient Course:</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Course Timeline:</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Previous Record:</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div className="processBottomSpace">
                <p className="header_txt">Process</p>
                <table>
                    <thead></thead>
                    <tbody>
                        <tr>
                            <td>Current Process:</td>
                            <td title={processTitle}>{processTitle}</td>
                        </tr>
                        <tr>
                            <td>Process Status:</td>
                            <td className="txt_blue_clr">Live</td>
                        </tr>
                        <tr>
                            <td>Related Process:</td>
                            <td>None</td>
                        </tr>
                        <tr>
                            <td>Total Modules:</td>
                            <td>{totalModules}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div>
                <p className="header_txt">Modules</p>
                <table>
                    <thead></thead>
                    <tbody>
                        <tr>
                            <td>Current Module:</td>
                            <td>{moduleTitle}</td>
                        </tr>
                        <tr>
                            <td>Fields:</td>
                            {
                                selectedModuleId ?
                                    <td>{totalQuestions(currentModuleOrWidget)} completed</td> :
                                    <td></td>
                            }

                        </tr>
                        <tr>
                            <td>Required Fields:</td>
                            {
                                selectedModuleId ?
                                    <td className="required">{requiredQuestions(currentModuleOrWidget)} completed</td> :
                                    <td></td>
                            }

                        </tr>

                    </tbody>
                </table>
            </div>
        </ConsultationInfoPanelStyles>
    )
}

export default ConsultationInfoPanel;

const ConsultationInfoPanelStyles = Styled.div`
.patientBottomSpace{
    margin-bottom: 50px;
}
.processBottomSpace{
    margin-bottom: 24px;
}

`;