import React, { useState, useEffect, Fragment } from 'react';
import { useSelector, useDispatch } from "react-redux";
import styled from 'styled-components';

import {
  ConsultationModules,
  ConsultationWidgets,
  ConsultationActionMenu,
  ConsultationInfoPanel
} from './landing-view';

import {
  setUndo,
  setRestartModule, saveProcessByAppointmentId, findAppointmentData,
  getOutputDetailsById,
  setActiveOutputId,
  updateProcessByProcessId,
  setLoadingSpinner,
  setRestartProcess
} from '../store/consultationProcess';
import * as mytheme from "../exportables/Colors";
import PopupComponent from '../content-builder/components/PopupCompontnet';

const ConsultationProcess = () => {
  const dispatch = useDispatch();
  const styles = useSelector((state) => state.ui.styles);
  const {
    selectedModuleId,
    activeOutputId,
    processData,
    appointmentId,
    isModuleClicked
  } = useSelector((state) => state.consulationProcess);
  const [popupHeader, setPopupHeader] = useState('Warning!');
  const [popupMessage, setPopupMessage] = useState('');
  const [isWarningPopupVisible, setIsWarningPopupVisible] = useState(false);
  const [isPreviewOutputPopupvisible, setIsPreviewOutputPopupvisible] = useState(false);
  const [eventType, setEventType] = useState('');

  const outputs = processData?.outputs;
  /**
   * get process data based on 
   */
  useEffect(() => {
    //dispatch(getConsultationData());
    // dispatch(getConsultationProcessData());
    // dispatch(getAppointmentDetailsById())
    dispatch(findAppointmentData());
  }, []);

  /**
   * Undo and restart warning popup
   */
  const handleUndoRestart = (e, eventType, moduleTitle) => {
    setEventType(eventType);
    const message = (
      <Fragment>
        <span>
          Want to {eventType} your changes in {moduleTitle}
        </span>
        <br />
        <span>
          If you click "OK" current changes won't be available in this {moduleTitle}
        </span>
        <br />
        <span>Do you really want to Continue then click "OK" ?</span>
        <br />
      </Fragment>
    );
    setPopupMessage(message);
    setIsWarningPopupVisible(true);
    return;
  }

  const warningWithSavePopup = () => {
    return (
      <Fragment>
        <p className="text-align popMsg">{popupMessage}</p>

        <div className="align-button">
          <input
            type="button"
            className="close-button ml5 okBtn"
            value="OK"
            onClick={handleOk}
          />
          <input
            type="button"
            className="close-button ml5"
            value="Close"
            onClick={handleClose}
          />
        </div>
      </Fragment>
    );
  }

  const handleOk = () => {
    if (eventType === 'UNDO') {
      dispatch(setUndo());
    }
    else if (eventType === 'RESTART MODULE') {
      dispatch(setRestartModule());
      dispatch(saveProcessByAppointmentId(processData, selectedModuleId));
    }
    else if (eventType === 'RESTART PROCESS') {
      dispatch(setLoadingSpinner(true));
      const appointmentId = localStorage.getItem('local_consultation_process_AppointmentId');
      const request = {
        processId: processData.processId,
        formData: null,
        id: appointmentId
      }
      dispatch(setRestartProcess());
      dispatch(updateProcessByProcessId(request, selectedModuleId));
      //window.location.assign("/dashboard/content");
    }
    else if (eventType === 'EXIT PROCESS') {
      dispatch(setLoadingSpinner(true));
      const appointmentId = localStorage.getItem('local_consultation_process_AppointmentId');
      const request = {
        processId: processData.processId,
        formData: null,
        id: appointmentId
      }
      dispatch(setRestartProcess());
      dispatch(updateProcessByProcessId(request, selectedModuleId));
      setTimeout(() => {
        window.location.assign("/dashboard/scheduler");
      }, 1000);
    }
    setEventType('');
    setIsWarningPopupVisible(false);
  }

  const handleClose = () => {
    setIsWarningPopupVisible(false);
    setIsPreviewOutputPopupvisible(false);
  }

  /**
   * preview output
   */
  const handlePreviewOutput = (e) => {
    setPopupHeader('Preview Output');
    //setPopupMessage(message);
    dispatch(getOutputDetailsById(appointmentId));
    setIsPreviewOutputPopupvisible(true);
    return;
  }

  const handleOuput = (e, output) => {
    dispatch(setActiveOutputId(output.id));
  }

  const previewOutputPopup = () => {

    let currentOutput = processData?.outputData?.find(output => output.id === activeOutputId);
    return (
      <Fragment>
        <p className="text-align popMsg" dangerouslySetInnerHTML={{
          __html: currentOutput?.output,
        }}></p>
        <ul className="popFooterOptions">
          {
            outputs?.map((output, index) =>
              <li key={index} className={(output.id === activeOutputId) ? 'active' : ''}>
                <span onClick={(e) => handleOuput(e, output)}>
                  {output.title}
                </span>
              </li>
            )
          }
        </ul>
      </Fragment>
    );
  }

  return (
    <ConsultationProcessStyles theme={mytheme}>
      <div className="mainConsultationContainer">
        <div className="consultationContainer">
          <div className={isModuleClicked ? 'moduleSection alignTopSec' : 'moduleSection'}>
            <ConsultationModules />
          </div>
          <div className={isModuleClicked ? 'widgetSection alignTopSec' : 'widgetSection'}>
            <ConsultationWidgets />
          </div>
          <div className={isModuleClicked ? 'actionMenuSection alignTopSec' : 'actionMenuSection'}>
            <ConsultationActionMenu handleUndoRestart={handleUndoRestart} handlePreviewOutput={handlePreviewOutput} />
          </div>
        </div>
      </div>
      <div className="infoSec">
        <ConsultationInfoPanel />
      </div>
      <PopupComponent
        width="500px"
        visible={isWarningPopupVisible}
        styles={styles}
        header={popupHeader}
        children={warningWithSavePopup()}
        close={() => {
          setIsWarningPopupVisible(false);
        }}
      />
      <PopupComponent
        previewClass="previewPopup"
        width="500px"
        visible={isPreviewOutputPopupvisible}
        styles={styles}
        header={popupHeader}
        children={previewOutputPopup()}
        close={() => {
          setIsPreviewOutputPopupvisible(false);
        }}
      />
    </ConsultationProcessStyles>
  );
  // return (
  //     <ConsultationProcessStyles>
  //         <ConsultationModules />
  //         <ConsultationWidgets />
  //         <ConsultationActionMenu />
  //         <ConsultationInfoPanel />
  //     </ConsultationProcessStyles>
  // )
}

export default ConsultationProcess;

const ConsultationProcessStyles = styled.section`

 .alignTopSec{
   margin-top: 28px;
 }
.mainConsultationContainer{
  display: flex;
  
}
.infoSec{
  width: 285px;
  background: #fff;
  height: calc(100vh - 120px);
  // margin-left: 20px;

  margin-bottom:30px;
  padding: 8px;
  border-radius: 15px;
}
// seperate css
.popMsg{
  font-size: 14px;
}
.okBtn{
  margin: 14px;
}
background: #e8ebe9;
.consultationContainer{
  border-radius: 15px;
  font-size: 16px;
  display: flex;
  margin-bottom:20px;
  height: calc(100vh - 120px);
  overflow-y: auto;
  overflow-x: hidden;
  // temp for dep
    // width: 80vw;
    width: 970px;
    background: #fff;
    position: relative;
    // margin-left: 10vw;
    overflow: hidden;
  // temp for dep
  .moduleSection{
    width: 200px;
    // position: fixed;
    height: calc(100vh - 120px);
    overflow: hidden;
    position: relative;
    box-shadow: 6px -2px 7px -3px rgba(74,74,74,0.37);
    z-index: 1;
  }
  .widgetSection{
    width: 600px;
    // position: fixed;
    // left: 31%;
    // width: 40%;
    box-shadow: 6px -2px 7px -3px rgba(74,74,74,0.37);
  }
  .actionMenuSection{
    width: 130px;
    // position: absolute;
    // right: 0px;
  }
}

// end seperate css

    //background-color: ${(props) => props.theme.DashboardContentThreeColors.backgroundColor};
    margin-top: 30px;
    border-radius: 10px;

    h4,.header_txt{
        font-size:16px !important;
    }

    .txt_blue_clr{
        color:#80d7d8;
    }
    .required{
        color:#c62828;
    }
    .col-md-3{
        padding-left:0px;
    }
    .vertical_lnbar{
        position: absolute;
        width: 109%;
        border-top: solid 2px lightgray;
        top: 0px;
        right: 0px;
    }
    .vertical_lnbar_right{
        position: absolute;
        top: -15px;
        width: 100%;
        border-bottom: solid 2px lightgray;
    }
    .bordr_top{
        border-top: solid 2px #738c87;
    }

    .tab1_fld{
      height: calc(100vh - 215px);
      overflow: hidden;
      overflow-y: auto;
    }

    .input_flds{
        height: calc(100vh - 170px);
        // height: calc(100vh - 212px);
        // overflow-y: auto;
        overflow-x: hidden;
    }
    .header_txt{
        margin-top:10px;
        font-weight:600;
    }
    .page_indx{
      display: flex;
      justify-content: flex-end;
      padding-right: 10px;
      border-top: 1px solid #00000026;
      align-items: center;
      width: 100%;
      font-size: 13px;
      color: #738c87;
      font-weight: 800;
      min-height: 20px;
    }

    .bx_shdw{
        box-shadow: 6px 2px 6px -9px;
    }

    .bx_shdwdiv{
        position: absolute;
        right: 0px;
        color: lightblue;
        top: -11px;
        /* border-right: solid 1px lightgray; */
        width: 0.5px;
        box-shadow: 3px 2px 4px 0px;
        height: 107%;
    }

    i{
        color:#80d7d8;
        font-size:18px !important;
    }
    .txt_gry_clr{
        color: #738c87;
        font-size:10px;
        font-weight:600; 
        text-align: center;
    }
    .icontxt_colr{
        color:#80d7d8;
        padding-right:0px;
        text-align:center;

        ul li{
            list-style: none;
            margin-top:20px;
        }

        ul li p{
            font-size: 10px !important;
            font-weight: 600;
            margin-top: 5px;
        }
    }
    .e-radio:checked + .e-success:hover::after { /* csslint allow: adjoining-classes */
        background-color: #449d44;
        border-color: #449d44;
      }
      table{
        font-size:12px;
         margin-top:10px;
        tr td:nth-child(odd){
            vertical-align: top;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            max-width: 116px;
        }
        tr td:nth-child(even){
            font-weight:600;
            padding-left: 5px;
            vertical-align: bottom;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            max-width: 116px;
        }
      }
.previewPopup{
  color: #13312b;
  box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
  border-radius: 15px;
  .popup-header{
    background: #fff;
    border: none;
    border-radius: 15px 15px 0 0;
    height: 40px;
    h3{
      color: #13312b !important;
      font-weight: 700;
      font-size: 16px;
    }
    .close-popup{
      color: grey !important;
      font-weight: 700;
      font-size: 14px;
    }
  }
  .popup-body{
    border: none;
    border-radius: 0 0 15px 15px;
    .popMsg{
      min-height: 25vh;
      max-height: 60vh;
      overflow: auto;
      color: #71827f;
    }
    .popFooterOptions{
      display: flex;
      justify-content: space-around;
      padding: 8px;
      border-top: 1px solid #f3f3f3;
      margin-bottom: 0;
      font-size: 14px;
      font-weight: 800;
      color: #dadada;
      li.active{
        font-weight: 800;
        color: #71827f;
      }
    }
  }
}
.react-datepicker-popper{
  transform: translate3d(99px, 35px, 0px) !important;
  }
  .react-datepicker__month-select, .react-datepicker__year-select{
    margin-left: 0;
  }
`;

