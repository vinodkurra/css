import React, { useState, useEffect, Fragment } from 'react';
import { useSelector, useDispatch } from "react-redux";
import styled from 'styled-components';

import {
    ConsultationModules,
    ConsultationWidgets,
    ConsultationActionMenu,
    ConsultationInfoPanel
} from './landing-view';

import {
    getConsultationData, getConsultationProcessData, getAppointmentDetailsById, setUndo,
    setRestartModule, saveProcessByAppointmentId
} from '../store/consultationProcess';
import * as mytheme from "../exportables/Colors";
import PopupComponent from '../content-builder/components/PopupCompontnet';

const ConsultationProcess = () => {
    const dispatch = useDispatch();
    const styles = useSelector((state) => state.ui.styles);
    const {
        selectedModuleId,
        processData
    } = useSelector((state) => state.consulationProcess);
    const [popupHeader, setPopupHeader] = useState('Warning!');
    const [popupMessage, setPopupMessage] = useState('');
    const [isWarningPopupVisible, setIsWarningPopupVisible] = useState(false);
    const [eventType, setEventType] = useState('');
    /**
     * get process data based on 
     */
    useEffect(() => {
        //dispatch(getConsultationData());
        // dispatch(getConsultationProcessData());
        dispatch(getAppointmentDetailsById())
    }, []);

    const handleUndoRestart = (e, eventType, moduleTitle) => {
        setEventType(eventType);
        const message = (
            <Fragment>
                <span>
                    Want to {eventType} your changes in {moduleTitle}
                </span>
                <br />
                <span>
                    If you click "OK" current changes won't be available in this
                    {moduleTitle}
                </span>
                <br />
                <span>Do you really want to Continue then click "OK" ?</span>
                <br />
            </Fragment>
        );
        setPopupMessage(message);
        setIsWarningPopupVisible(true);
        return;
    }
    const handleOk = () => {

        if (eventType === 'UNDO') {
            dispatch(setUndo());
        }
        else if (eventType === 'RESTART MODULE') {
            dispatch(setRestartModule());
            dispatch(saveProcessByAppointmentId(processData, selectedModuleId));
        }
        setEventType('');
        setIsWarningPopupVisible(false);
    }

    const handleClose = () => {
        setIsWarningPopupVisible(false);
    }

    const warningWithSavePopup = () => {
        return (
            <Fragment>
                <p className="text-align">{popupMessage}</p>

                <div className="align-button">
                    <input
                        type="button"
                        className="close-button ml5"
                        value="OK"
                        onClick={handleOk}
                    />
                    <input
                        type="button"
                        className="close-button ml5"
                        value="Close"
                        onClick={handleClose}
                    />
                </div>
            </Fragment>
        );
    };

    return (
        <ConsultationProcessStyles theme={mytheme}>
            <div className="container" style={{ padding: "0px", minHeight: "81.3vh" }} >
                <div className="row" style={{ padding: "0px" }}>
                    <div className="col-md-9" style={{ padding: "0px" }}>
                        <div className="container" style={{ minHeight: "fit-content" }}>
                            <div className="row" style={{ height: "100%" }} >
                                <div className="col-md-3">
                                    <ConsultationModules />
                                </div>
                                <div className="col-md-7">
                                    <ConsultationWidgets />
                                </div>
                                <div className="col-md-2 icontxt_colr">
                                    <ConsultationActionMenu handleUndoRestart={handleUndoRestart} />
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* need to enable in future. Kindly dont remove the below code */}
                    {/* <div className="col-md-3" >
                        <div className="container" style={{ minHeight: "fit-content" }}>
                            <div className="row" >
                                <div className="col-md-12" style={{ padding: "0px" }}>
                                    <ConsultationInfoPanel />
                                </div>
                            </div>
                        </div>
                    </div> */}
                </div>
            </div>
            <PopupComponent
                width="500px"
                visible={isWarningPopupVisible}
                styles={styles}
                header={popupHeader}
                children={warningWithSavePopup()}
                close={() => {
                    setIsWarningPopupVisible(false);
                }}
            />
        </ConsultationProcessStyles>
    );
    // return (
    //     <ConsultationProcessStyles>
    //         <ConsultationModules />
    //         <ConsultationWidgets />
    //         <ConsultationActionMenu />
    //         <ConsultationInfoPanel />
    //     </ConsultationProcessStyles>
    // )
}

export default ConsultationProcess;

const ConsultationProcessStyles = styled.section`
    background-color: ${(props) => props.theme.DashboardContentThreeColors.backgroundColor};
    padding: 10px 15px;
    margin-top: 30px;
    border-radius: 10px;

    h4,.header_txt{
        font-size:16px !important;
    }

    .txt_blue_clr{
        color:#80d7d8;
    }
    .required{
        color:#c62828;
    }
    .col-md-3{
        padding-left:0px;
    }
    .vertical_lnbar{
        position: absolute;
        width: 109%;
        border-top: solid 2px lightgray;
        top: 0px;
        right: 0px;
    }
    .vertical_lnbar_right{
        position: absolute;
        top: -9px;
        width: 126%;
        left: -10px;
        border-bottom: solid 2px lightgray;
    }
    .bordr_top{
        border-top: solid 2px #738c87;
    }

    .tab1_fld{
        min-height: 40vh;
        max-height: 49vh;
        overflow-y: auto;
    }

    .input_flds{
        max-height: 49vh;
        overflow-y: auto;
        overflow-x: hidden;
    }
    .header_txt{
        margin-top:10px;
        font-weight:600;
    }
    .page_indx{
        position:absolute;
        bottom:0px;
        text-align:center;
        width:100%;
        padding: 12px;
        margin: 0px;
        font-size: 13px;
        color:#738c87;
        margin-top:20px;
        font-weight: 600;
        min-height: 47px;
    }

    .bx_shdw{
        box-shadow: 6px 2px 6px -9px;
    }

    .bx_shdwdiv{
        position: absolute;
        right: 0px;
        color: lightblue;
        top: -11px;
        /* border-right: solid 1px lightgray; */
        width: 0.5px;
        box-shadow: 3px 2px 4px 0px;
        height: 107%;
    }

    i{
        color:#80d7d8;
        font-size:18px !important;
    }
    .txt_gry_clr{
        color: #738c87;
        font-size:10px;
        font-weight:600; 
    }
    .icontxt_colr{
        color:#80d7d8;
        padding-right:0px;
        text-align:center;

        ul li{
            list-style: none;
            margin-top:20px;
        }

        ul li p{
            font-size: 10px !important;
            font-weight: 600;
            margin-top: 5px;
        }
    }
    .e-radio:checked + .e-success:hover::after { /* csslint allow: adjoining-classes */
        background-color: #449d44;
        border-color: #449d44;
      }
      table{
        font-size:12px;
         margin-top:10px;
        tr td:nth-child(odd){
            vertical-align: top;
        }
        tr td:nth-child(even){
            font-weight:600;
            padding-left: 5px;
            vertical-align: bottom;
        }
      }
      
      

`;

const SubMenu = styled.div`
  div {
    img {
      width: 80px;
      height: 80px;
      border-radius: 40px;
      margin-top: 20px;
    }
    h2 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne
            .h2_color} !important;
      font-size: 20px !important;
      font-weight: 700 !important;
    }
    h5 {
      color: ${(props) =>
        props.theme.DashboardContentOneColors.DashboardContentOne.h5_color};

      font-size: 18px !important;
    }
    padding: 10px 30px;
  }
`;

const LatestPost = styled.div`


    padding: 10px 15px;
    margin-top: 30px;
    border-radius: 10px;
  background-color: #fff;
  input {
    float: right;
  }
`;

const Header = styled.div`
  display: table;
  width: 100%;
  div {
    display: table-cell;
    vertical-align: middle;
    :nth-child(1) {
      width: 80%;
    }
    :nth-child(2) input {
      background-color: #dae7e4;
      border-radius: 50px;
      padding: 5px;
      border: none;
      margin: 10px;
    }
  }
`;

const Firstschedule = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
  margin-bottom: 10px;
`;

const GridText2 = styled.div`
  padding-left: 10px;
  padding-right: 0px;
  h3 {
    font-size: 16px;
    color: #7f00ab;
    margin-bottom: 0px;
  }
  p {
    margin-bottom: 5px;
    font-size: 11px;
  }
`;

const GridText3 = styled.div`
  p {
    color: #738c87;
    font-size: 11px;
  }
`;

const OwnNetwotk = styled.div`
  padding: 10px;
`;

const OwnNetwotkHeader = styled.div`
  background-color: #7f00ab;
  padding: 0px 10px 0px 10px;
`;

const OwnNetwotkBg = styled.div`
  background-color: #f3fffd;
  margin-top: -10px;
  h4 {
    color: #7f00ab;
    font-weight: 600;
    padding: 10px 12px 0px 12px;
  }
  .gridtext3 {
    p {
      padding: 0px 12px;
    }
  }
  ul {
    list-style: none;
    margin: 0px;
    li {
      display: inline-block;
      padding: 5px 10px;
      :nth-child(2) {
        float: right;
      }
    }
  }
`;

const History = styled.div`
  border-bottom: 1.5px solid #c4c4c4;
`;

const Readhistory = styled.div`
  ul {
    display: flex;
    margin: 0;
    list-style: none;
    li {
      margin-right: 5px;
      h1 {
        color: #e5ccee;
        font-size: 45px;
      }
    }
  }
`;

const Trends = styled.div`
  padding: 0px;
`;

const Checklib = styled.div`
  p {
    text-align: right;
    padding: 0px 10px;
    color: #0e8a8b;
    font-size: 13px;
    font-weight: 600;
  }
`;