const UPDATE_BREADCRUMB = 'content/breadcrumb_updated';
const INITIALIZE_CONTENT = 'INITIALIZE_CONTENT';
const ADD_CONTENT = 'ADD_CONTENT';
const UPDATE_CONTENT = 'UPDATE_CONTENT';
const ACTIVE_CONTENT_ID = 'ACTIVE_CONTENT_ID';
const ADD_MODULE = 'ADD_MODULE';
const ACTIVE_MODULE_ID = 'ACTIVE_MODULE_ID';
const DELETE_MODULE = 'DELETE_MODULE';
const ADD_WIDGET = "ADD_WIDGET";

export const addContent = (content) => ({
    type: ADD_CONTENT,
    payload: content,
});

export const updateContent = (content) => ({
    type: UPDATE_CONTENT,
    payload: content,
});

export const setContentId = (contentId) => ({
    type: ACTIVE_CONTENT_ID,
    payload: contentId,
});

export const addModule = (module) => ({
    type: ADD_MODULE,
    payload: module,
});

export const setActiveModuleId = (moduleId) => ({
    type: ACTIVE_MODULE_ID,
    payload: moduleId
});

export const deleteModule = (contentModuleId) => ({
    type: DELETE_MODULE,
    payload: contentModuleId
});

export const updateBreadCrumb = (breadcrumb) => ({
    type: UPDATE_BREADCRUMB,
    payload: breadcrumb,
});

export const addWidget = (Widget) => ({
    type: ADD_WIDGET,
    payload: Widget,
});

const initialContentstate = {
    contentId: 1,
    contentName: '',
    modules: [],
    widgets : []
    // modules: [
    //     {
    //         moduleId: '',
    //         moduleName: '',
    //         widgetList: [],
    //         widgetDetails: []
    //     }
    // ]
};
export default function (state = {}, action) {
    let contents = [];
    switch (action.type) {
        case ADD_CONTENT:
            return {
                ...state,
                contents:
                    [
                        ...state.contents, action.payload
                    ]
            };
        case UPDATE_CONTENT:
            return state;
        case ACTIVE_CONTENT_ID:
            return {
                ...state,
                activeContentId: action.payload
            };
        case ACTIVE_MODULE_ID:
            return {
                ...state,
                activeModuleId: action.payload
            };
        case ADD_MODULE:
            contents = state.contents.slice();
            contents.map(content => {
                const currentContent = { ...content }
                if (currentContent.contentId === state.activeContentId) {
                    currentContent.moduleList.push(action.payload)
                }
            });
            return {
                ...state, contents
            };
        case DELETE_MODULE:
            contents = state.contents.slice();
            contents.map(content => {
                const currentContent = { ...content }
                if (currentContent.contentId === state.activeContentId) {
                    let index = currentContent.moduleList.findIndex(x => x.id === state.activeModuleId);
                    currentContent.moduleList.splice(index, 1);
                }
                return currentContent;
            });
            return {
                ...state, contents
            };
        case UPDATE_BREADCRUMB:
            return { ...state, breadcrumb: action.payload };
        case ADD_WIDGET:
            contents = state.contents.slice();
            const newContents = contents.map(content => {
                const currentContent = { ...content }
                if (currentContent.contentId === state.activeContentId) {
                    currentContent.moduleList.map(currentModule => {
                        if (currentModule.id === state.activeModuleId) {
                            currentModule.widgetList.push(action.payload)
                        } return currentModule;
                    });
                }
                return currentContent;
            });
            return {
                ...state, contents
            };
        default:
            return {
                contents: [initialContentstate],
                activeContentId: initialContentstate.contentId,
                activeModuleId: 0,
                breadcrumb: {
                    accountType: 'Private',
                    content: '',
                    module: '',
                    inputOutput: '-Input',
                }
            };
    }
}
