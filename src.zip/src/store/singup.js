export default function(state, action) {
  return {signup: true}
}