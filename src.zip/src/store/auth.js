import { apiUrlWithToken } from '../calls/apis';

let email = localStorage.getItem('email');
let refreshtoken = localStorage.getItem('refreshtoken');

// Define all action type constants here
const SAVE_TOKEN_CREDENTIALS = 'auth/saved_tokens';
const REFRESH_TOKEN_CREDENTIALS = 'auth/refreshed_tokens';

// Define all actions here
export const refreshToken = (time) => {
  console.log('refreshToken', time);
  return (dispatch) => {
  console.log('refreshToken inside ', time);

    return apiUrlWithToken
      .post('/auth/gettoken', { email, refreshtoken })
      .then(console.log)
      // .then((res) => dispatch(refreshTokenCredentials(res.data)))
      .catch(console.error);
  };
};

export const saveTokenCredentials = (credentials) => {
  return (dispatch) => {
    dispatch({
      type: SAVE_TOKEN_CREDENTIALS,
      payload: credentials,
    });
    // let timeinms = credentials.expiresin * 1000;
    // setInterval(() => refreshToken(credentials.expiresin), 1000);
  };
};



export const refreshTokenCredentials = (credentials) => {  
  return {
    type: REFRESH_TOKEN_CREDENTIALS,
    payload: credentials,
  };
};

export default function (state = {}, action) {
  switch (action.type) {
    case SAVE_TOKEN_CREDENTIALS:
      return action.payload;
    default:
      return state;
  }
}
