import { act } from 'react-dom/test-utils';
import {
    checkSumId, apiConsultationUrlWithToken,
    apiContentUrlWithToken,
} from '../calls/apis';
import {
    SUCCESS,
    CREATED_SUCCESS,
    TEXT_INPUT_WIDGET,
    BINARY_INPUT_WIDGET,
    TIME_INPUT_WIDGET,
    SINGLE_CHOICE_WIDGET,
    MULTI_CHOICE_WIDGET,
    DATE_WIDGET,
    DROPDOWNLIST_WIDGET,
    NUMBER_WIDGET,
    WARNING_INPUT_WIDGET,
    CALCULATION_WIDGET,
    NARRATIVE_WIDGET,
    BRANCH_CONTROL_WIDGET,
    BLANK_WIDGET,
    SKIP_WIDGET,
    EXECUTE_WIDGET,
    SWITCH_WIDGET,
    JUMP_WIDGET,
    MULTIPLE_EXECUTION
} from "../content-builder/components/Constants";
const moment = require('moment')
const loggedEmail = localStorage.getItem("email");
/**
 * consultation process constants
 */
const SET_lOADING_SPINNER = "SET_lOADING_SPINNER";
const SET_UPDATE_PROCESS_DATA = 'SET_UPDATE_PROCESS_DATA';
const SET_SELECTED_MODULE_ID = 'SET_SELECTED_MODULE_ID';
const SET_CONTENT_MODIFIFIED_STATUS = 'SET_CONTENT_MODIFIFIED_STATUS';
const SET_PROCESS_SAVE = 'SET_PROCESS_SAVE';
const SET_UNDO = 'SET_UNDO';
const SET_RESTART_MODULE = 'SET_RESTART_MODULE';
const SET_RESTART_PROCESS = 'SET_RESTART_PROCESS';
const UPDATE_REQUIRED_QUESTION_ANSWERED_PERCENTAGE = 'UPDATE_REQUIRED_QUESTION_ANSWERED_PERCENTAGE';
const SET_APPOINTMENT_ID = 'SET_APPOINTMENT_ID';
const SET_ACTIVE_OUTPUT_ID = 'SET_ACTIVE_OUTPUT_ID';
const SET_UPDATE_OUTPUT_DATA = 'SET_UPDATE_OUTPUT_DATA';
const SET_HIGHLIGHT_REQUIRED_FIELDS = 'SET_HIGHLIGHT_REQUIRED_FIELDS';
const SET_ALL_WIDGET_LIST = 'SET_WIDGET_LIST';
const SET_APPEND_NEW_WIDGETS = 'SET_APPEND_NEW_WIDGETS';
const SET_UPDATE_BRANCH_WIDGET_STATUS = 'SET_UPDATE_BRANCH_WIDGET_STATUS';
const SET_MODULE_PAGINATION_DETAILS = 'SET_MODULE_PAGINATION_DETAILS';
const SET_NEW_MODULE_PAGINATION_DETAILS = 'SET_NEW_MODULE_PAGINATION_DETAILS';
const SET_KEY_SELECTED_MODULE_ID = 'SET_KEY_SELECTED_MODULE_ID';
const SET_MODULE_CLICKED = 'SET_MODULE_CLICKED';

export const setUpdatePrcoessData = (processData, appointmentId) => ({
    type: SET_UPDATE_PROCESS_DATA,
    payload: processData,
    appointmentId
})

export const setSelectedModuleId = (moduleId) => ({
    type: SET_SELECTED_MODULE_ID,
    payload: moduleId
});

// export const setContentModifiedStatus = (status) => ({
//     type: SET_CONTENT_MODIFIFIED_STATUS,
//     payload: status
// });
export const setContentModifiedStatus = (status, widget) => {
    return (dispatch) => {
        dispatch({
            type: SET_CONTENT_MODIFIFIED_STATUS,
            payload: status,
            widget
        });
        dispatch(setAllWidgetList());
    }
};

export const setProcessSave = (moduleId) => ({
    type: SET_PROCESS_SAVE,
    payload: moduleId
});

export const setUndo = (moduleId) => ({
    type: SET_UNDO,
    payload: moduleId
});

export const setRestartModule = (moduleId) => ({
    type: SET_RESTART_MODULE,
    payload: moduleId
});

export const setRestartProcess = () => ({
    type: SET_RESTART_PROCESS,
    payload: null
});

export const updateRequiredQuestionAnsweredPercentage = (widget) => ({
    type: UPDATE_REQUIRED_QUESTION_ANSWERED_PERCENTAGE,
    payload: widget
});

export const setLoadingSpinner = (status) => ({
    type: SET_lOADING_SPINNER,
    payload: status,
});

export const setAppointmentId = (appointmentId) => ({
    type: SET_APPOINTMENT_ID,
    payload: appointmentId
});

export const setActiveOutputId = (outputId) => ({
    type: SET_ACTIVE_OUTPUT_ID,
    payload: outputId
});

export const setUpdateOutputData = (outputData) => ({
    type: SET_UPDATE_OUTPUT_DATA,
    payload: outputData
});

export const setHighlightRequiredfields = (status) => ({
    type: SET_HIGHLIGHT_REQUIRED_FIELDS,
    payload: status
});

export const setAllWidgetList = () => ({
    type: SET_ALL_WIDGET_LIST,
    payload: null
});

export const setAppendNewWidgets = (
    widgets,
    branchWidget,
    currentInsertIndex,
    moduleId,
    isInsertWidget = true,
    branchType = null
) => {
    return (dispatch) => {
        dispatch({
            type: SET_APPEND_NEW_WIDGETS,
            payload: widgets,
            branchWidget,
            currentInsertIndex,
            moduleId,
            isInsertWidget,
            branchType
        });
        dispatch(updateRequiredQuestionAnsweredPercentage(null));
        dispatch(setAllWidgetList());
    }
}

export const setUpdateBranchWidgetIndex = (branchWidget, status) => ({
    type: SET_UPDATE_BRANCH_WIDGET_STATUS,
    payload: branchWidget,
    status
})

export const setModulePaginationDetails = (object) => ({
    type: SET_MODULE_PAGINATION_DETAILS,
    payload: object
})

export const setModuleNewPaginationDetails = (object) => ({
    type: SET_NEW_MODULE_PAGINATION_DETAILS,
    payload: object
});

export const setKeySelectedModuleId = (status) => ({
    type: SET_KEY_SELECTED_MODULE_ID,
    payload: status
});

export const setModuleClicked = (status) => ({
    type: SET_MODULE_CLICKED,
    payload: status
});


//dispatch(updateRequiredQuestionAnsweredPercentage(widget));

// export const getConsultationData = (processId) => {
//     return (dispatch) => {
//         let temp_processData = getStoredData();
//         if (temp_processData) {
//             let newProcessData = buildConstulationData(temp_processData);

//             if (!localStorage.getItem('local_consultation_process')) {
//                 let processBaseData = { processData: newProcessData }
//                 localStorage.setItem('local_consultation_process', JSON.stringify(processBaseData));
//             }

//             dispatch(setUpdatePrcoessData(newProcessData));
//         }
//     }
// }

function getStoredData() {

    let temp_processData = {};
    const localSavedData = localStorage.getItem('local_consultation_process_save');
    const local_processData = localStorage.getItem('local_contentBuilder');
    if (localSavedData) {
        let parsedData = JSON.parse(localSavedData);
        temp_processData = parsedData ? parsedData.processData : {};
    }
    else if (local_processData) {
        let parsedData = JSON.parse(local_processData);
        temp_processData = parsedData?.length > 0 ?
            parsedData[0] : {}
    }
    return temp_processData;
}

//don't remove this method, used for reference
function buildConstulationData(temp_processData) {

    let modules = [];
    if (temp_processData?.moduleList?.length > 0) {
        temp_processData.moduleList.map((module, index) => {
            let widgets = [];
            module.widgetList.map((widget) => {
                let widgetForm = {
                    id: widget?.id,
                    title: widget?.title,
                    widgetQuestion: widget?.comment || widget?.widgetQuestion,
                    widgetAnswer: (widget?.defaultText || widget?.widgetAnswer) || '',
                    type: widget?.type,
                    hide: widget?.hide,
                    bookmark: widget?.bookmark,
                    required: widget?.required,
                    widgetSubText: widget?.widgetSubText || 'Subtext Goes here',
                    options: [{ defaultStatus: false, value: '', option: '' }]
                }
                widgets.push(widgetForm)
            });
            modules.push({
                moduleId: module?.id,
                title: module?.title,
                requiredQuestionCount: 0,
                requiredQuestionAnsweredCount: 0,
                optionalQuestionCount: 0,
                optionalQuestionAnsweredCount: 0,
                widgetList: widgets,
                isRestartModule: false,
                isContentModified: false,
            })
        });
    }

    let widgets = [];
    if (temp_processData?.widgetList?.length > 0) {
        temp_processData.widgetList.map((widget) => {
            let widgetForm = {
                widgetId: widget?.id,
                title: widget?.title,
                widgetQuestion: widget?.comment || widget?.widgetQuestion,
                widgetAnswer: widget?.defaultText || widget?.widgetAnswer,
                type: widget?.type,
                hide: widget?.hide,
                bookmark: widget?.bookmark,
                required: widget?.required,
                options: [{ defaultStatus: false, value: '', option: '' }]
            }
            widgets.push(widgetForm)
        });
    }

    const modulesWithPercentage = getPercentageByModule(modules);
    let processDataState = {
        processId: temp_processData?.contentId || temp_processData?.processId,
        title: temp_processData?.title,
        moduleList: modulesWithPercentage,
        widgetList: widgets
    }
    return processDataState;
}

function getPercentageByModule(modules) {
    modules.map((module) => {
        let requiredQuestionCount = 0;
        let requiredQuestionAnsweredCount = 0;
        let optionalQuestionCount = 0;
        let optionalQuestionAnsweredCount = 0;

        module.widgetList.map((widget) => {
            if (widget.required) {
                requiredQuestionCount += 1
                requiredQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            }
            else {
                optionalQuestionCount += 1
                optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            }
        });
        module.requiredQuestionCount = requiredQuestionCount;
        module.requiredQuestionAnsweredCount = requiredQuestionAnsweredCount;
        module.optionalQuestionCount = optionalQuestionCount;
        module.optionalQuestionAnsweredCount = optionalQuestionAnsweredCount;
        module.isRestartModule = (!requiredQuestionAnsweredCount && !optionalQuestionAnsweredCount) ? false : true;
    });
    return modules;
}

/**
 * consultation api
 */

// export const getConsultationProcessData = (processId) => {
//     return (dispatch) => {
//         let temp_processData = {};
//         const localSavedData = localStorage.getItem('local_consultation_process_save');
//         const local_processData = localStorage.getItem('local_contentBuilder');
//         if (localSavedData) {
//             let parsedData = JSON.parse(localSavedData);
//             temp_processData = parsedData ? parsedData.processData : {};
//             dispatch(setUpdatePrcoessData(temp_processData));
//         }
//         else if (local_processData) {
//             let parsedData = JSON.parse(local_processData);
//             temp_processData = parsedData?.length > 0 ?
//                 parsedData[0] : {}
//             dispatch(publishContent(temp_processData));
//         }
//     }
// }

export const getAppointmentDetailsById = (appointmentId) => {
    //appointmentId = '2343433253465835'
    return async (dispatch) => {
        dispatch(setLoadingSpinner(true));

        await apiConsultationUrlWithToken.get(`appointment?appointmentId=${appointmentId}`)
            .then((res) => {
                if (
                    (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                    res.data != null
                ) {

                    const appointmentData = res.data.formData;
                    const processId = res.data.processId;
                    dispatch(setAppointmentId(res.data.id));
                    if (appointmentData) {
                        dispatch(setUpdatePrcoessData(appointmentData));
                        dispatch(setLoadingSpinner(false));

                    } else {
                        //dispatch(publishContent());
                        dispatch(getConsultationDetailsByProcessId(processId));
                    }
                }
            })
            .catch((error) => {
                console.log('publish api', error);
                dispatch(setLoadingSpinner(false));
            })

    }
}

// export const publishContent = (temp_processData = {}) => {
//     return async (dispatch) => {
//         //  let temp_processData = {};
//         const local_processData = localStorage.getItem('local_contentBuilder');
//         if (local_processData) {
//             let parsedData = JSON.parse(local_processData);
//             temp_processData = parsedData?.length > 0 ?
//                 parsedData[0] : {}
//         }

//         dispatch(setLoadingSpinner(true));
//         if (temp_processData) {
//             const contentId = temp_processData?.contentId;
//             const publishVersion = Math.floor(Date.now() / 1000);
//             await apiConsultationUrlWithToken.get(`content/publish/process?contentId=${contentId}&version=${publishVersion}`)
//                 .then((res) => {
//                     if (
//                         (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
//                         res.data != null && res?.data?.id
//                     ) {

//                         const processId = res.data.id;
//                         const appointmentId = res.data.tempId;
//                         localStorage.setItem('local_consultation_process_AppointmentId',
//                             appointmentId);
//                         dispatch(getConsultationDetailsByProcessId(processId));
//                     }
//                 })
//                 .catch((error) => {
//                     console.log('publish api', error);
//                     dispatch(setLoadingSpinner(false));
//                 })
//         }
//     }
// }
export const publishContent = (contentId) => {
    return async (dispatch) => {

        if (contentId) {
            // const contentId = temp_processData?.contentId;
            const publishVersion = Math.floor(Date.now() / 1000);
            await apiConsultationUrlWithToken.get(`content/publish/process?contentId=${contentId}&version=${publishVersion}`)
                .then((res) => {

                    if (
                        (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                        res.data != null && res?.data?.id
                    ) {

                        const processId = res.data.id;
                        const appointmentId = res.data.tempId;
                        localStorage.setItem('local_consultation_process_AppointmentId',
                            appointmentId);
                        dispatch(setAppointmentId(appointmentId));
                        dispatch(getConsultationDetailsByProcessId(processId));
                    }
                })
                .catch((error) => {
                    console.log('publish api', error);
                    dispatch(setLoadingSpinner(false));
                })
        }
    }
}

export const getConsultationDetailsByProcessId = (processId) => {
    return async (dispatch) => {
        await apiConsultationUrlWithToken.get(`process?processId=${processId}`)
            .then((res) => {
                if (
                    (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                    res.data != null &&
                    res?.data?.processId
                ) {
                    //                    res.data.moduleList.map((module) => {
                    res.data.componentList.map((module) => {
                        // if (module.componentType === 'module') {
                        let requiredQuestionCount = 0;
                        let requiredQuestionAnsweredCount = 0;
                        let optionalQuestionCount = 0;
                        let optionalQuestionAnsweredCount = 0;
                        module.widgetList.map((widget) => {
                            const percentage = getPercentage(widget);
                            requiredQuestionCount += percentage.requiredQuestionCount;
                            requiredQuestionAnsweredCount += percentage.requiredQuestionAnsweredCount;
                            optionalQuestionCount += percentage.optionalQuestionCount;
                            optionalQuestionAnsweredCount += percentage.optionalQuestionAnsweredCount;
                            //  widget.widgetAnswer = percentage.widgetAnswer;
                            widget.widgetSubText = widget?.widgetSubText || 'Subtext Goes here';
                            widget.componentType = module.componentType;

                            widget.defaultDateValue = widget?.type === DATE_WIDGET && widget?.defaultDateValue ?
                                moment(new Date(widget?.defaultDateValue.month +
                                    '/' + widget?.defaultDateValue.day +
                                    '/' + widget?.defaultDateValue.year)).toISOString()
                                : widget?.defaultDateValue

                            widget.maximumDateValue = widget?.type === DATE_WIDGET && widget?.maximumDateValue ?
                                moment(new Date(widget?.maximumDateValue.month +
                                    '/' + widget?.maximumDateValue.day +
                                    '/' + widget?.maximumDateValue.year)).toISOString()
                                : widget?.maximumDateValue

                            widget.minimumDateValue = widget?.type === DATE_WIDGET && widget?.minimumDateValue ?
                                moment(new Date(widget?.minimumDateValue.month +
                                    '/' + widget?.minimumDateValue.day +
                                    '/' + widget?.minimumDateValue.year)).toISOString()
                                : widget?.minimumDateValue

                            if (widget?.type === TIME_INPUT_WIDGET && widget?.defaultTimeValue) {
                                let hour = widget?.defaultTimeValue.hour > 9 ? widget?.defaultTimeValue.hour : '0' + widget?.defaultTimeValue.hour;
                                let minute = widget?.defaultTimeValue.minute > 9 ? widget?.defaultTimeValue.minute : '0' + widget?.defaultTimeValue.minute;
                                widget.defaultTimeValue = hour + ':' + minute;
                            }
                            // widget.defaultTimeValue = widget?.type === TIME_INPUT_WIDGET && widget?.defaultTimeValue ?
                            //     widget?.defaultTimeValue.hour > 9 ? widget?.defaultTimeValue.hour : '0' + widget?.defaultTimeValue.hour +
                            //         ':' + widget?.defaultTimeValue.minute > 0 ? widget?.defaultTimeValue.minute : '0' + widget?.defaultTimeValue.minute
                            //     : widget?.minimumDateValue

                        });
                        module.requiredQuestionCount = requiredQuestionCount;
                        module.requiredQuestionAnsweredCount = requiredQuestionAnsweredCount;
                        module.optionalQuestionCount = optionalQuestionCount;
                        module.optionalQuestionAnsweredCount = optionalQuestionAnsweredCount;
                        module.isRestartModule = (!requiredQuestionAnsweredCount && !optionalQuestionAnsweredCount) ? false : true;
                        module.isContentModified = false;
                        //}
                    });

                    let branchWidgetDetails = findBranchWidgets(res.data.componentList);
                    let modulesPaginationList = findModulesPaginationDetails(res.data.componentList);
                    //this needs to be change when integrate outside widget
                    //let modulesOnly = res.data.componentList.filter(x => x.componentType != 'widget');
                    //res.data.componentList = modulesOnly;
                    let newProcessData = Object.assign(
                        {},
                        res.data,
                        { branchWidgetDetails: branchWidgetDetails },
                        { modulesPaginationList: modulesPaginationList }
                    );
                    // if (!localStorage.getItem('local_consultation_process')) {
                    let processBaseData = { processData: newProcessData }
                    localStorage.setItem('local_consultation_process', JSON.stringify(processBaseData));
                    localStorage.removeItem('local_consultation_process_save');
                    //}
                    dispatch(setUpdatePrcoessData(newProcessData));
                    dispatch(setLoadingSpinner(false));
                }
            })
            .catch((error) => {
                console.log('consultation process detail get api', error);
                dispatch(setLoadingSpinner(false));
            })
    }
}

export const saveProcessByAppointmentId = (processData, selectedModuleId) => {
    return async (dispatch) => {
        dispatch(setLoadingSpinner(true));

        let localData = JSON.parse(localStorage.getItem('local_consultation_process'));
        let localSavedData = JSON.parse(localStorage.getItem('local_consultation_process_save'));

        let tempData = { ...processData };
        let currModule = processData.componentList.filter(
            (module) => module.moduleId === selectedModuleId
        );
        if (currModule?.length > 0)
            currModule[0].isContentModified = false;
        let oldModuels = [];
        if (localSavedData)
            oldModuels = localSavedData ? localSavedData?.processData?.componentList : [];
        else
            oldModuels = localData ? localData?.processData?.componentList : [];
        oldModuels = [...oldModuels, processData.componentList];
        const uniqBy = (arr, predicate) => {
            const cb =
                typeof predicate === 'function' ? predicate : (o) => o[predicate];
            return [
                ...arr
                    .reduce((map, item) => {
                        const key = item === null || item === undefined ? item : cb(item);
                        map.has(key) || map.set(key, item);
                        return map;
                    }, new Map())
                    .values(),
            ];
        };
        oldModuels = oldModuels.filter(
            (cont) => cont.moduleId !== currModule.moduleId
        );
        oldModuels = uniqBy([...currModule, ...oldModuels], 'moduleId');
        oldModuels = oldModuels.sort((a, b) => a.moduleId - b.moduleId);

        let forStorageData = { ...processData, componentList: [...oldModuels] };
        const appointmentId = localStorage.getItem('local_consultation_process_AppointmentId');
        const request = {
            processId: processData.processId,
            formData: forStorageData,
            id: appointmentId
        }
        dispatch(updateProcessByProcessId(request, selectedModuleId));
        // await apiConsultationUrlWithToken.put(`appointment`, request)
        //     .then((res) => {
        //         if (
        //             (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        //             res.data != null
        //         ) {
        //             dispatch(setProcessSave(selectedModuleId));
        //             dispatch(setLoadingSpinner(false));
        //         }
        //     })
        //     .catch((error) => {
        //         console.log('publish api', error);
        //         dispatch(setLoadingSpinner(false));
        //     })
    }
}

export const updateProcessByProcessId = (request, selectedModuleId) => {
    return async (dispatch) => {
        await apiConsultationUrlWithToken.put(`appointment`, request)
            .then((res) => {
                if (
                    (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                    res.data != null
                ) {
                    dispatch(setProcessSave(selectedModuleId));
                    dispatch(setLoadingSpinner(false));
                }
            })
            .catch((error) => {
                console.log('publish api', error);
                dispatch(setLoadingSpinner(false));
            })
    }
}

export const findAppointmentData = () => (dispatch) => {

    const appointmentId = localStorage.getItem('local_consultation_process_AppointmentId');
    if (appointmentId && appointmentId !== undefined) {
        dispatch(getAppointmentDetailsById(appointmentId))
    }
    else {
        //dispatch(publishContent());
        dispatch(getAllContents());
    }
}

// export const createAppointment = (processId) => {
//     return async (dispatch) => {
//         await apiConsultationUrlWithToken.post(``)
//             .then((res) => {
//                 if (
//                     (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
//                     res.data != null && res?.data?.id
//                 ) {
//                     const appointmentId = res?.data?.id;
//                     localStorage.setItem('local_consultation_process_AppointmentId',
//                         appointmentId);
//                     dispatch(getConsultationDetailsByProcessId(processId));
//                 }
//             })
//             .catch((error) => {
//                 console.log('publish api', error);
//                 dispatch(setLoadingSpinner(false));
//             });
//     }
// }

export const getAllContents = () => {
    return async (dispatch) => {
        dispatch(setLoadingSpinner(true));
        await apiContentUrlWithToken
            .get(`content/list?checksumid=${await checkSumId}`)
            .then((res) => {
                if (
                    (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                    res.data != null &&
                    res.data.length > 0
                ) {

                    const contentId = res.data[0].contentId;
                    dispatch(publishContent(contentId));
                }
            })
            .catch((error) => {
                dispatch(setLoadingSpinner(false));
                console.log("Get all content Api:", error);
            });
    };
};

function getPercentage(widget) {
    let requiredQuestionCount = 0;
    let requiredQuestionAnsweredCount = 0;
    let optionalQuestionCount = 0;
    let optionalQuestionAnsweredCount = 0;
    let widgetAnswer = null;
    if (
        !widget.hide &&
        widget.type !== WARNING_INPUT_WIDGET &&
        widget.type !== CALCULATION_WIDGET &&
        widget.type !== NARRATIVE_WIDGET &&
        widget.type !== BRANCH_CONTROL_WIDGET &&
        widget.type !== BLANK_WIDGET &&
        widget.type !== SKIP_WIDGET &&
        widget.type !== EXECUTE_WIDGET &&
        widget.type !== JUMP_WIDGET &&
        widget.type !== MULTIPLE_EXECUTION &&
        widget.type !== SWITCH_WIDGET
    ) {

        // BRANCH_CONTROL_WIDGET,
        // BLANK_WIDGET,
        // SKIP_WIDGET,
        // EXECUTE_WIDGET,
        // SWITCH_WIDGET,
        // JUMP_WIDGET,
        // MULTIPLE_EXECUTION

        if (widget.required) {
            requiredQuestionCount += 1
            requiredQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            // if (widget.type === BINARY_INPUT_WIDGET || widget.type === SINGLE_CHOICE_WIDGET || widget.type === MULTI_CHOICE_WIDGET) {
            //     let widgetAnswerCount = 0;
            //     widget.options.map((option, index) => {
            //         if (option.defaultStatus) {
            //             widgetAnswerCount = 1;
            //             widgetAnswer = option.value;
            //         }

            //     })
            //     requiredQuestionAnsweredCount += widgetAnswerCount;
            // }
            // else {
            //     requiredQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            //     widgetAnswer = widget.widgetAnswer;
            // }
        }
        else {
            optionalQuestionCount += 1
            optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            // if (widget.type === BINARY_INPUT_WIDGET || widget.type === SINGLE_CHOICE_WIDGET || widget.type === MULTI_CHOICE_WIDGET) {
            //     let widgetAnswerCount = 0;
            //     widget.options.map((option, index) => {
            //         if (option.defaultStatus) {
            //             widgetAnswerCount = 1;
            //             widgetAnswer = option.value;
            //         }
            //     })
            //     optionalQuestionAnsweredCount += widgetAnswerCount;
            // }
            // else {
            //     optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
            //     widgetAnswer = widget.widgetAnswer;
            // }
            //optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
        }
    }

    return {
        requiredQuestionCount: requiredQuestionCount,
        requiredQuestionAnsweredCount: requiredQuestionAnsweredCount,
        optionalQuestionCount: optionalQuestionCount,
        optionalQuestionAnsweredCount: optionalQuestionAnsweredCount,
        widgetAnswer: widgetAnswer
    }
}

/**
 * output details by output id
 */
export const getOutputDetailsById = (appointmentId) => {
    return async (dispatch) => {
        dispatch(setLoadingSpinner(true));

        await apiConsultationUrlWithToken.get(`output?appointmentId=${appointmentId}`)
            //await apiConsultationUrlWithToken.get(`output?appointmentId=6724270650850082816`)
            .then((res) => {
                if (
                    (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                    res.data != null
                ) {

                    let outputList = res.data;
                    dispatch(setUpdateOutputData(outputList));
                    if (outputList?.length > 0)
                        dispatch(setActiveOutputId(outputList[0].id));
                    dispatch(setLoadingSpinner(false));
                }
            })
            .catch((error) => {
                console.log('output details api', error);
                dispatch(setLoadingSpinner(false));
            })
    }
}

function findBranchWidgets(componentList) {
    let branchWidgets = [];

    componentList.map((moduleOrWidget, parentIndex) => {
        // if (moduleOrWidget.componentType === 'module') {
        moduleOrWidget.widgetList.map((widget, widgetIndex) => {
            if (widget.type === 'branch') {
                branchWidgets.push(getBranchObject(moduleOrWidget.widgetList, widget, widgetIndex, 'module', moduleOrWidget.moduleId));
                if (widget.widgetList.length > 0) {
                    widget.widgetList.map((childWidget, childIndex) => {
                        if (childWidget.type === 'branch') {
                            branchWidgets.push(getBranchObject(widget.widgetList, childWidget, widgetIndex, 'module', moduleOrWidget.moduleId, widget.widgetId, widget.hide));
                        }
                    })
                }
            }
        })
        // }
        // else {
        //     if (moduleOrWidget.type === 'branch') {
        //         branchWidgets.push(getBranchObject(moduleOrWidget, parentIndex, 'outSideWidget', 0));
        //         // if (moduleOrWidget.widgetList.length > 0) {
        //         //     moduleOrWidget.widgetList.map((childWidget, childIndex) => {
        //         //         if (childWidget.type === 'branch') {
        //         //             branchWidgets.push(getBranchObject(childWidget, parentIndex));
        //         //         }
        //         //     })
        //         // }
        //     }
        // }
    })
    return branchWidgets;
}

function getBranchObject(widgetList, branchWidget, branchIndex, moduleAndOutsideWidget, moduleId, parentBranchId = null, parentBranchHide = false) {
    let beforeJumpWidgets = [];
    let afterJumpWidgets = [];
    let isJumpWidget = false;
    let jumpWidgetParentId = null;
    let jumpChildWidgets = [];

    if (widgetList.length > 0) {
        widgetList.filter((widget) => widget.parentBranchWidgetId);
        let jumpWidgetIndexes = [];
        widgetList.map((widget, idx) => {
            if (widget?.branchControlType === "jump") {
                jumpWidgetIndexes.push(idx);
            }
        });

        for (let i = 0; i < jumpWidgetIndexes.length; i++) {
            jumpChildWidgets.push({
                widgetId: widgetList[jumpWidgetIndexes[i]].widgetId,
                widgets: widgetList.slice(
                    jumpWidgetIndexes[i],
                    jumpWidgetIndexes[i + 1]
                ),
            });
        }
    }

    branchWidget.widgetList.map((widget) => {//check child widgets have jump widget or not
        if (widget.type === 'branch' && widget?.branchControlType === 'jump') {
            isJumpWidget = true;
            jumpWidgetParentId = widget.widgetId
        }

        if (isJumpWidget) {
            if (widget.type === 'execution_frame' && widget.widgetList?.length > 0) {
                widget.widgetList.map((exeWidget) => {
                    exeWidget.jumpParentId = jumpWidgetParentId;
                })
                afterJumpWidgets = afterJumpWidgets.concat(widget.widgetList);
            }
            else {
                if (widget?.branchControlType !== 'jump')
                    widget.jumpParentId = jumpWidgetParentId;
                afterJumpWidgets.push(widget);
            }

        }
        else {
            if (widget.type === 'execution_frame' && widget.widgetList?.length > 0) {
                beforeJumpWidgets = beforeJumpWidgets.concat(widget.widgetList);
            }
            else
                beforeJumpWidgets.push(widget);
        }

    });
    let allChildWidgets = [];
    branchWidget.widgetList.map((widget, index) => {//check child widgets have jump widget or not
        if (branchWidget.branchControlType === 'switch')
            widget.branchSwitchIndex = index;

        if (widget.type === 'execution_frame' && widget.widgetList?.length > 0) {
            widget.widgetList.map((exeWidget) => {
                exeWidget.parentBranchWidgetId = branchWidget.widgetId;
            })
            allChildWidgets = allChildWidgets.concat(widget.widgetList);
        }
        else {
            allChildWidgets.push(widget);
        }
    });

    let newBranchObj = {
        branchId: branchWidget.widgetId,
        branchWidget: branchWidget,
        branchIndex: branchIndex,
        referredWidgetIds: branchWidget.referedWidgetIds,
        branchChildWidgetList: branchWidget.widgetList,
        branchChildWidgets: allChildWidgets,
        branchControlType: branchWidget.branchControlType,
        moduleAndOutsideWidget: moduleAndOutsideWidget,
        moduleId: moduleId,
        isJumpWidget: isJumpWidget,
        beforeJumpWidgets: beforeJumpWidgets,
        afterJumpWidgets: afterJumpWidgets,
        parentBranchId: parentBranchId,
        jumpWidgetParentId: jumpWidgetParentId || null,
        currentBranchHide: branchWidget.hide,
        parentBranchHide: parentBranchHide,
        jumpChildWidgets
    }

    return newBranchObj
}

function findModulesPaginationDetails(componentList) {
    ;
    let modulesPaginationList = [];
    let pageLimit = 14;
    let pageLimitModuleIds = [];
    let startPage = 1;
    let totalCount = componentList.length;
    componentList.map((moduleOrWidget, index) => {
        pageLimitModuleIds.push(moduleOrWidget.moduleId);
        if (index === (pageLimit - 1)) {
            modulesPaginationList.push({
                startPage: startPage,
                endPage: index + 1,
                pageLimitModuleIds: pageLimitModuleIds
            });
            pageLimitModuleIds = [];
            startPage = pageLimit + 1;
            let remainingCount = componentList.length - 14;
            pageLimit = (pageLimit + 14) > totalCount ? totalCount : (pageLimit + 14);
        }
    })
    if (totalCount <= 14) {
        modulesPaginationList.push({
            startPage: startPage,
            endPage: totalCount,
            pageLimitModuleIds: pageLimitModuleIds
        });
    }
    return modulesPaginationList;
}

/**
* default initial state values defined here
*/
const initialState = {
    selectedModuleId: 0,
    selectedModuleIdStatus: false,
    activeOutputId: 0,
    appointmentId: 0,
    isHighlightRequiredFields: false,
    processData: {},
    // isContentModified: false,
    isConsultationSubmit: false,
    consultationAllWidgets: [],
    modulesPaginationDetails: {},
    modulesNewPaginationDetails: {},
    isModuleClicked: false
    // isRestartModule: false
};
const outputs = [
    { id: 1, title: 'output1' },
    { id: 2, title: 'output2' },
    { id: 3, title: 'output3' },
];
const outputData = [
    { id: 1, data: 'output1' },
    { id: 2, data: 'output2' },
    { id: 3, data: 'output3' },
]

/**
 * action creater
 */
export default function (state = initialState, action) {
    let localData = JSON.parse(localStorage.getItem('local_consultation_process'));
    let localSavedData = JSON.parse(localStorage.getItem('local_consultation_process_save'));

    let processData = state.processData;
    // let modules = processData?.moduleList?.slice();
    let componentList = processData?.componentList?.slice();
    // if (localData != undefined)
    //     localData = localData[0];
    switch (action.type) {
        case SET_lOADING_SPINNER:
            return {
                ...state,
                isLoading: action.payload,
            };
        case SET_APPOINTMENT_ID:
            return {
                ...state,
                appointmentId: action.payload
            }
        case SET_UPDATE_PROCESS_DATA:
            //let storageData = { ...state, processData: action.payload };
            // localStorage.setItem('local_consultation_process', JSON.stringify(storageData));

            return {
                ...state,
                processData: Object.assign({}, action.payload,
                    { outputData: action?.payload?.outputData || [] }),
                selectedModuleId: 0,
                activeOutputId: 0,
                isHighlightRequiredFields: false,
            }
        case SET_SELECTED_MODULE_ID:
            return {
                ...state,
                selectedModuleId: action.payload
            }
        case SET_CONTENT_MODIFIFIED_STATUS:
            componentList.map((module, index) => {
                // if (module.moduleId === state.selectedModuleId) {
                //     module.isContentModified = action.payload;
                // }
                if (module.moduleId === action.widget.moduleId) {
                    module.isContentModified = action.payload;
                }

                return module;
            });
            processData.componentList = componentList;
            return {
                ...state,
                processData: processData
            }
        // return {
        //     ...state,
        //     isContentModified: action.payload
        // }
        case SET_PROCESS_SAVE:
            {

                let tempData = { ...state, isContentModified: false };
                let currModule = tempData.processData.componentList.filter(
                    (module) => module.moduleId === state.selectedModuleId
                );
                if (currModule?.length > 0)
                    currModule[0].isContentModified = false;
                let oldModuels = [];
                if (localSavedData)
                    oldModuels = localSavedData ? localSavedData?.processData?.componentList : [];
                else
                    oldModuels = localData ? localData?.processData?.componentList : [];
                oldModuels = [...oldModuels, ...state.processData.componentList];
                const uniqBy = (arr, predicate) => {
                    const cb =
                        typeof predicate === 'function' ? predicate : (o) => o[predicate];
                    return [
                        ...arr
                            .reduce((map, item) => {
                                const key = item === null || item === undefined ? item : cb(item);
                                map.has(key) || map.set(key, item);
                                return map;
                            }, new Map())
                            .values(),
                    ];
                };
                oldModuels = oldModuels.filter(
                    (cont) => cont.moduleId !== currModule.moduleId
                );
                oldModuels = uniqBy([...currModule, ...oldModuels], 'moduleId');
                oldModuels = oldModuels.sort((a, b) => a.moduleId - b.moduleId);

                let forStorageData = { ...tempData, processData: { ...processData, componentList: [...oldModuels] } };

                localStorage.setItem(
                    'local_consultation_process_save',
                    JSON.stringify(forStorageData)
                );
                return { ...state, isContentModified: false };
            }
        case SET_UNDO:

            //  let processData = state.processData;
            if (processData?.componentList?.length > 0) {
                let modules = processData.componentList.slice();
                let previousModuleWidgets = [];
                let previousModule = {};

                if (localSavedData) {
                    previousModuleWidgets = localSavedData?.processData?.componentList.find(
                        prevModule => prevModule.moduleId === state.selectedModuleId
                    )?.widgetList;
                    previousModule = localSavedData?.processData?.componentList.find(
                        prevModule => prevModule.moduleId === state.selectedModuleId
                    );
                } else {
                    previousModuleWidgets = localData?.processData?.componentList.find(
                        prevModule => prevModule.moduleId === state.selectedModuleId
                    )?.widgetList;
                    previousModule = localData?.processData?.componentList.find(
                        prevModule => prevModule.moduleId === state.selectedModuleId
                    );
                }
                componentList.map((module, index) => {
                    if (module.moduleId === state.selectedModuleId) {
                        module.widgetList = previousModuleWidgets;
                        module.requiredQuestionCount = previousModule?.requiredQuestionCount;
                        module.requiredQuestionAnsweredCount = previousModule?.requiredQuestionAnsweredCount;
                        module.optionalQuestionCount = previousModule?.optionalQuestionCount;
                        module.optionalQuestionAnsweredCount = previousModule?.optionalQuestionAnsweredCount;
                        module.isRestartModule = (!module?.requiredQuestionAnsweredCount && !module?.optionalQuestionAnsweredCount) ? false : true;
                        module.isContentModified = false;
                    }
                    return module;
                });
                processData.componentList = componentList;
            }
            return {
                ...state,
                processData: processData,
                isHighlightRequiredFields: false
            }
        case UPDATE_REQUIRED_QUESTION_ANSWERED_PERCENTAGE:
            // let processData = state.processData;
            // let existingModules = processData.moduleList.slice();
            let isConsultationSubmit = false;
            componentList.map((module, index) => {
                // if (module.moduleId === state.selectedModuleId) {
                //  module.requiredQuestionCount += module.requiredQuestionCount;
                // module.requiredQuestionAnsweredCount += 1;

                let requiredQuestionCount = 0;
                let requiredQuestionAnsweredCount = 0;
                let optionalQuestionCount = 0;
                let optionalQuestionAnsweredCount = 0;
                module.widgetList.map((widget) => {
                    // if (!widget.hide) {

                    //     if (widget.required) {
                    //         requiredQuestionCount += 1
                    //         if (widget.type === 'binary') {
                    //             let widgetAnswer = 0;
                    //             widget.options.map((option, index) => {
                    //                 if (option.defaultStatus)
                    //                     widgetAnswer = 1;
                    //             })
                    //             requiredQuestionAnsweredCount += widgetAnswer;
                    //         }
                    //         else {
                    //             requiredQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
                    //         }
                    //     }
                    //     else {
                    //         optionalQuestionCount += 1
                    //         if (widget.type === 'binary') {
                    //             let widgetAnswer = 0;
                    //             widget.options.map((option, index) => {
                    //                 widgetAnswer = option.defaultStatus ? 1 : 0;
                    //             })
                    //             optionalQuestionAnsweredCount += widgetAnswer;
                    //         }
                    //         else {
                    //             optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
                    //         }
                    //         //optionalQuestionAnsweredCount += widget.widgetAnswer ? 1 : 0;
                    //     }
                    // }
                    const percentage = getPercentage(widget);
                    requiredQuestionCount += percentage.requiredQuestionCount;
                    requiredQuestionAnsweredCount += percentage.requiredQuestionAnsweredCount;
                    optionalQuestionCount += percentage.optionalQuestionCount;
                    optionalQuestionAnsweredCount += percentage.optionalQuestionAnsweredCount;
                    // widget.widgetAnswer = percentage.widgetAnswer;
                });
                module.requiredQuestionCount = requiredQuestionCount;
                module.requiredQuestionAnsweredCount = requiredQuestionAnsweredCount;
                module.optionalQuestionCount = optionalQuestionCount;
                module.optionalQuestionAnsweredCount = optionalQuestionAnsweredCount;
                module.isRestartModule = (!module.requiredQuestionAnsweredCount && !module.optionalQuestionAnsweredCount) ? false : true;
                // }
                return module;
            });
            processData.componentList = componentList;
            /**
             * find whether all the questions answered or not, if yes then submit button need to enable 
             */
            const totalRequiredQuestionCount = componentList.reduce((sum, a) => {
                return sum + a.requiredQuestionCount;
            }, 0);
            const totalRequiredQuestionAnsweredCount = componentList.reduce((sum, a) => {
                return sum + a.requiredQuestionAnsweredCount;
            }, 0);
            const totalOptionalQuestionCount = componentList.reduce((sum, a) => {
                return sum + a.optionalQuestionCount;
            }, 0);
            const totalOptionalQuestionAnsweredCount = componentList.reduce((sum, a) => {
                return sum + a.optionalQuestionAnsweredCount;
            }, 0);
            isConsultationSubmit = (totalRequiredQuestionCount === totalRequiredQuestionAnsweredCount) &&
                (totalOptionalQuestionCount === totalOptionalQuestionAnsweredCount);

            return {
                ...state,
                processData: processData,
                isConsultationSubmit: isConsultationSubmit
            }
        case SET_RESTART_MODULE:
            //let preModules = processData.moduleList.slice();
            // let previousModuleWidgets = [];
            // let previousModule = {};

            let previousModuleWidgets = localData?.processData?.componentList.find(
                prevModule => prevModule.moduleId === state.selectedModuleId
            )?.widgetList;
            let previousModule = localData?.processData?.componentList.find(
                prevModule => prevModule.moduleId === state.selectedModuleId
            );
            componentList.map((module, index) => {
                if (module.moduleId === state.selectedModuleId) {
                    module.widgetList = previousModuleWidgets;
                    module.requiredQuestionCount = previousModule?.requiredQuestionCount;
                    module.requiredQuestionAnsweredCount = previousModule?.requiredQuestionAnsweredCount;
                    module.optionalQuestionCount = previousModule?.optionalQuestionCount;
                    module.optionalQuestionAnsweredCount = previousModule?.optionalQuestionAnsweredCount;
                    module.isContentModified = true;
                    module.isRestartModule = false;
                }
                return module;
            });
            processData.componentList = componentList;
            return {
                ...state,
                processData: processData,
                isHighlightRequiredFields: false
            }
        case SET_RESTART_PROCESS:
            componentList.map((module, index) => {
                let previousModuleWidgets = localData?.processData?.componentList.find(
                    prevModule => prevModule.moduleId === module.moduleId
                )?.widgetList;
                let previousModule = localData?.processData?.componentList.find(
                    prevModule => prevModule.moduleId === module.moduleId
                );
                // if (module.moduleId === state.selectedModuleId) {
                module.widgetList = previousModuleWidgets;
                module.requiredQuestionCount = previousModule?.requiredQuestionCount;
                module.requiredQuestionAnsweredCount = previousModule?.requiredQuestionAnsweredCount;
                module.optionalQuestionCount = previousModule?.optionalQuestionCount;
                module.optionalQuestionAnsweredCount = previousModule?.optionalQuestionAnsweredCount;
                module.isContentModified = true;
                module.isRestartModule = false;
                //    }
                return module;
            });
            processData.componentList = componentList;
            return {
                ...state,
                processData: processData,
                isHighlightRequiredFields: false
            }
        case SET_ACTIVE_OUTPUT_ID:
            return {
                ...state,
                activeOutputId: action.payload
            }
        case SET_UPDATE_OUTPUT_DATA:

            // let index = processData.outputData.findIndex(
            //     (x) => x.id === state.activeOutputId
            // );
            // if (index > -1) {
            //     processData.outputData.map((output) => {
            //         if (output.id === state.activeOutputId) {
            //             output.data = action.payload;
            //         }
            //     })
            // }
            // else {
            //     processData.outputData.push(action.payload);
            // }
            processData.outputData = [];
            //            processData.outputData.push(action.payload);
            processData.outputData = action.payload;
            return {
                ...state,
                processData: processData
            }
        case SET_HIGHLIGHT_REQUIRED_FIELDS:
            return {
                ...state,
                isHighlightRequiredFields: action.payload
            }
        case SET_ALL_WIDGET_LIST:

            let data = state.processData;
            let consultationAllWidgets = [];
            data.componentList.map((component) => {
                // if (component.componentType === 'module') {
                consultationAllWidgets = consultationAllWidgets.concat(component.widgetList);
                // }
                // else {
                //     consultationAllWidgets.push(component.widgetList);
                // }
            })
            return {
                ...state,
                consultationAllWidgets: consultationAllWidgets
            }
        case SET_APPEND_NEW_WIDGETS:

            let currentBranchWidget = action.branchWidget;//get current branch widget
            let moduleId = action.moduleId;// get moduleid if branch exist inside module
            let isInsertWidget = action.isInsertWidget;//to know whether need to insert child widgets or not
            let componentData = state.processData;
            let branchType = action.branchType;

            componentData.componentList.map((component) => {
                // if (component.componentType === 'module') {
                if (moduleId === component.moduleId) {
                    //find existing branch child widgets index

                    let removeWidgetIds = [];
                    let removeParentBranchIds = [];
                    component.widgetList.map((widget, index) => {

                        if (branchType === 'jump') {
                            if (currentBranchWidget?.widgetId === widget?.jumpParentId) {
                                removeWidgetIds.push(widget?.widgetId);
                                if (removeParentBranchIds.indexOf(widget?.jumpParentId) < 0)
                                    removeParentBranchIds.push(widget?.jumpParentId)
                            }
                        }
                        else {
                            if (currentBranchWidget?.widgetId === widget?.parentBranchWidgetId) {
                                removeWidgetIds.push(widget?.widgetId);
                                if (removeParentBranchIds.indexOf(widget?.parentBranchWidgetId) < 0)
                                    removeParentBranchIds.push(widget?.parentBranchWidgetId)
                            }
                        }
                    });

                    if (removeWidgetIds?.length > 0) {
                        component.widgetList = component.widgetList.filter(widget => !removeWidgetIds.includes(widget.widgetId));
                    }

                    if (removeParentBranchIds?.length > 0) {
                        componentData.branchWidgetsExecuteStatus = componentData.branchWidgetsExecuteStatus.filter(widget => !removeParentBranchIds.includes(widget.branchId));
                    }

                    // if (branchType === 'jump') {
                    //     
                    //     let widgetIds = action.payload.map(widget => widget.id);
                    //     component.widgetList = component.widgetList.filter(widget => !widgetIds.includes(widget.widgetId));
                    //     componentData.branchWidgetsExecuteStatus =
                    //         componentData.branchWidgetsExecuteStatus.
                    //             filter(widget => !removeParentBranchIds.includes(widget.branchId));
                    // }
                    //insert branch child widgets into main array
                    if (isInsertWidget) {
                        let parentIndex = action.currentInsertIndex;
                        action.payload.map((widget, index) => {
                            insertAt(
                                component.widgetList,
                                parentIndex,
                                action.payload[index]
                            );
                            parentIndex += 1;
                            // insertAt(
                            //     component.widgetList,
                            //     action.currentInsertIndex,
                            //     action.payload
                            // );
                        });
                        function insertAt(array, index, ...elements) {
                            array.splice(index, 0, ...elements);
                        }
                    }
                }
                // }
                // else {
                //     //find existing branch child widgets index
                //     let widgetRemoveIndex = [];
                //     componentData.componentList.map((widget, index) => {
                //         if (currentBranchWidget.widgetId === widget.branchId) {
                //             widgetRemoveIndex.push(index);
                //         }
                //     });
                //     //remove all existing branch child widgets from main array
                //     widgetRemoveIndex.map((removeIndex) => {
                //         componentData.componentList.splice(removeIndex, 1);
                //     });

                //     //insert branch child widgets into main array
                //     let parentIndex = action.currentInsertIndex;
                //     action.payload.map((widget, index) => {
                //         insertAt(
                //             component.widgetList,
                //             parentIndex,
                //             action.payload[index]
                //         );
                //         parentIndex += 1;
                //         // insertAt(
                //         //     component.widgetList,
                //         //     action.currentInsertIndex,
                //         //     action.payload
                //         // );
                //     });
                //     function insertAt(array, index, ...elements) {
                //         array.splice(index, 0, ...elements);
                //     }
                // }
            });
            processData.componentList = componentData.componentList;
            processData.branchWidgetsExecuteStatus = componentData.branchWidgetsExecuteStatus;
            return {
                ...state,
                processData: processData
            }
        case SET_UPDATE_BRANCH_WIDGET_STATUS:
            let branchWidget = action.payload;
            let branchWidgetsExecuteStatus = state.processData.branchWidgetsExecuteStatus || [];
            let currentBranchIndex = branchWidgetsExecuteStatus.findIndex(
                (widget) => widget.branchId == branchWidget.widgetId
            );
            if (currentBranchIndex > -1) {
                branchWidgetsExecuteStatus.map((widget) => {
                    if (widget.branchId === branchWidget.widgetId) {
                        widget.status = action.status;
                    }
                })
            }
            else {
                branchWidgetsExecuteStatus.push({
                    branchId: branchWidget.widgetId,
                    type: branchWidget.branchControlType,
                    status: action.status
                })
            }
            processData.branchWidgetsExecuteStatus = branchWidgetsExecuteStatus;
            return {
                ...state,
                processData: processData
            }
        case SET_MODULE_PAGINATION_DETAILS:
            return {
                ...state,
                modulesPaginationDetails: action.payload
            }
        case SET_NEW_MODULE_PAGINATION_DETAILS:
            return {
                ...state,
                modulesNewPaginationDetails: action.payload
            }
        case SET_KEY_SELECTED_MODULE_ID:
            return {
                ...state,
                selectedModuleIdStatus: action.payload
            }
        case SET_MODULE_CLICKED:
            return {
                ...state,
                isModuleClicked: action.payload
            }
        default:
            return state;
    }

}