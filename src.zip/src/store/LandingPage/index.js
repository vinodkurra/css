import { notification, mail, latestPosts, scheduler } from '../../json/sitedata';
import { useSelector, useDispatch, batch } from "react-redux";
import Axios from 'axios';
import { MdNature } from 'react-icons/md';
import { checkSumId } from '../../calls/apis';
import moment from 'moment'
import { min } from 'lodash';

const READ_NOTIFICATION = 'READ_NOTIFICATION'
const SWAP_POST = 'SWAP_POST'
const ADD_NEW_POST = 'ADD_NEW_POST'
const DELETE_MAIL = 'DELETE_MAIL'
const ADD_TO_STARRED = 'ADD_TO_STARRED'
const READ_ALL_MAIL = 'READ_ALL_MAIL'
const READ_ALL_NOTIFICATION = 'READ_ALL_NOTIFICATION'
const READ_MAIL = 'READ_MAIL'
const CHANGE_MAIL_SLICER = 'CHANGE_MAIL_SLICER'
const VIEW_LATESTPOST_FULLSCREEN = 'VIEW_LATESTPOST_FULLSCREEN'
const ADD_REMINDER_APPOINTMENT = 'ADD_REMINDER_APPOINTMENT'
const VIEW_MAIL_FULLSCREEN = 'VIEW_MAIL_FULLSCREEN'
const VIEW_MAIL_EXPANDER = 'VIEW_MAIL_EXPANDER'
const ADD_NEW_APPOINTMENT = 'ADD_NEW_APPOINTMENT'

const GET_APPOINTMENTS = 'GET_APPOINTMENTS'
const SELECTED_APPOINTMENT = 'SELECTED_APPOINTMENT'

var img = require('../../assets/image1.png');

export const readNotification = (data) => {
    return (dispatch) => {
        dispatch({
            type: READ_NOTIFICATION,
            payload: data,
        });
    };
};

export const swapPost = (data) => {
    return (dispatch) => {
        dispatch({
            type: SWAP_POST,
            payload: data,
        });
    };
};

export const addNewPost = (data) => {
    return (dispatch) => {
        dispatch({
            type: ADD_NEW_POST,
            payload: data,
        });
    };
};

export const deleteMail = (data) => {
    return (dispatch) => {
        dispatch({
            type: DELETE_MAIL,
            payload: data,
        });
    };
};

export const addToStarred = (data) => {
    return (dispatch) => {
        dispatch({
            type: ADD_TO_STARRED,
            payload: data,
        });
    };
};

export const readAllNotification = () => {
    return (dispatch) => {
        dispatch({
            type: READ_ALL_NOTIFICATION,
        });
    };
};

export const readAllMail = (data) => {
    return (dispatch) => {
        dispatch({
            type: READ_ALL_MAIL,
            payload: data,
        });
    };
};

export const readMail = (data) => {
    return (dispatch) => {
        dispatch({
            type: READ_MAIL,
            payload: data,
        });
    };
};

export const changeMailSlicer = (data) => {
    return (dispatch) => {
        dispatch({
            type: CHANGE_MAIL_SLICER,
            payload: data,
        });
    };
};

export const viewLatestpostFullscreen = () => {
    return (dispatch) => {
        dispatch({
            type: VIEW_LATESTPOST_FULLSCREEN,
            payload: null,
        });
    };
};

export const addReminderAppointment = (data) => {
    return (dispatch) => {
        dispatch({
            type: ADD_REMINDER_APPOINTMENT,
            payload: data,
        });
    };
};


export const viewMailFullscreen = () => {
    return (dispatch) => {
        dispatch({
            type: VIEW_MAIL_FULLSCREEN,
            payload: null,
        });
    };
};

export const viewMailExpander = () => {
    return (dispatch) => {
        dispatch({
            type: VIEW_MAIL_EXPANDER,
            payload: null,
        });
    };
};

export const addNewAppointment = (data) => {
    return (dispatch) => {
        dispatch({
            type: ADD_NEW_APPOINTMENT,
            payload: data,
        });
    };
};

export const getAppointments = (data) => {
    return (dispatch) => {
        dispatch({
            type: GET_APPOINTMENTS,
            payload: data,
        });
    };
};

export const selectedAppointments = (data) => {
    return (dispatch) => {
        dispatch({
            type: SELECTED_APPOINTMENT,
            payload: data,
        });
    };
};

export const addSearchItem = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'ADD_SEARCH_ITEM',
            payload: data,
        });
    };
};

export const setSelectedPatient = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SET_SELECTED_PATIENT',
            payload: data,
        });
    };
};

export const saveAppointments = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SAVE_APPOINTMENTS',
            payload: data,
        });
    };
};

export const manageslicerScheduler = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'CHANGE_SCHEDULER_SLICER',
            payload: data,
        });
    };
};

export const viewUserSearch = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'VIEW_USER_SEARCH',
            payload: data,
        });
    };
};


export const setSelectedUser = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SET_SELECTED_USER',
            payload: data,
        });
    };
};

export const getUserMails = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'GET_USERMAILS',
            payload: data,
        });
    };
};

export const selectedMailtoView = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SELECTED_MAILTOVIEW',
            payload: data,
        });
    };
};

export const saveSearchedMailUsers = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SAVE_SEARCHED_MAILUSERS',
            payload: data,
        });
    };
};


export const getUserLatestPosts = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'GET_USER_LATEST_POSTS',
            payload: data,
        });
    };
};

export const viewSpecificPost = () => {
    return (dispatch) => {
        dispatch({
            type: 'VIEW_SPECIFIC_POST',
            payload: null,
        });
    };
};

export const setSelectedPost = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SET_SELECTED_POST',
            payload: data,
        });
    };
};

export const setFileError = () => {
    return (dispatch) => {
        dispatch({
            type: 'SET_FILE_ERROR',
            payload: null,
        });
    };
};


export const switchGroupAccount = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SWITCH_GROUP_ACCOUNT',
            payload: data,
        });
    };
};

export const setCreatePostSelectedTaggedUsers = (data) => {

    return (dispatch) => {
        dispatch({
            type: 'SET_CREATEPOST_SELECTED_TAGGED_USERS',
            payload: data,
        });
    };
};

export const viewNewsExpander = () => {
    return (dispatch) => {
        dispatch({
            type: 'VIEW_NEWS_EXPANDER',
            payload: null,
        });
    };
};

export const viewSpecificNews = () => {
    return (dispatch) => {
        dispatch({
            type: 'VIEW_SPECIFIC_NEWS',
            payload: null,
        });
    };
};

export const setSelectedNews = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SET_SELECTED_NEWS',
            payload: data,
        });
    };
};

export const getAllNews = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'GET_ALL_NEWS',
            payload: data,
        });
    };
};

export const startConsutationClearTimer = () => {
    return (dispatch) => {
        dispatch({
            type: 'START_CONSULTATION_CLEAR_TIMER',
            payload: null,
        });
    };
};

export const editTimerAppointment = () => {
    return (dispatch) => {
        dispatch({
            type: 'EDIT_TIMER_APPOINTMENT',
            payload: null,
        });
    };
};

export const getAllNotifications = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'GET_ALL_NOTIFICATIONS',
            payload: data,
        });
    };
};

export const viewProcessPopup = () => {
    return (dispatch) => {
        dispatch({
            type: 'VIEW_PROCESS_POPUP',
            payload: null,
        });
    };
};

export const setSelectedProcess = (data) => {
    return (dispatch) => {
        dispatch({
            type: 'SET_SELECTED_PROCESS',
            payload: data,
        });
    };
};


// Defined Landingpage reducer here 
export default function (state, { type, payload }) {
    switch (type) {

        case 'SET_SELECTED_PROCESS':
            return {
                ...state,
                selectedProcess: payload
            }
        case 'VIEW_PROCESS_POPUP':
            return {
                ...state,
                viewSpecificPost: false,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestPostScreen: false,
                newsBoxExpander: false,
                newsFullScreen: false,
                processPopup: !state.processPopup
            }
        case 'GET_ALL_NOTIFICATIONS':
            return {
                ...state,
                notification: payload
            }
        case 'EDIT_TIMER_APPOINTMENT':
            return {
                ...state,
                editTimerData: !state.editTimerData
            }
        case 'START_CONSULTATION_CLEAR_TIMER':
            return {
                ...state,
                timerAppointment: []
            }
        case 'GET_ALL_NEWS':
            return {
                ...state,
                news: payload.map((t) => {
                    return { ...t, entry_time: timeDifferMail(new Date(t.createdOn)) }
                })
            }
        case 'SET_SELECTED_NEWS':
            return {
                ...state,
                selectedNews: payload
            }
        case 'VIEW_SPECIFIC_NEWS':
            return {
                ...state,
                viewSpecificPost: false,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestPostScreen: false,
                newsBoxExpander: false,
                newsFullScreen: !state.newsFullScreen
            }
        case 'VIEW_NEWS_EXPANDER':
            return {
                ...state,
                viewSpecificPost: false,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestPostScreen: false,
                newsBoxExpander: !state.newsBoxExpander,
                newsFullScreen: false
            }
        case 'SET_CREATEPOST_SELECTED_TAGGED_USERS':
            return {
                ...state,
                createPostSelectedTaggedUsers: payload
            }
        case 'SWITCH_GROUP_ACCOUNT':
            return {
                ...state,
                userGroup: payload
            }
        case 'SET_FILE_ERROR':
            return {
                ...state,
                fileError: !state.fileError
            }
        case 'SET_SELECTED_POST':
            return {
                ...state,
                selectedPost: payload
            }
        case 'VIEW_SPECIFIC_POST':
            return {
                ...state,
                viewSpecificPost: !state.viewSpecificPost,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestPostScreen: false
            }
        case 'GET_USER_LATEST_POSTS':
            return {
                ...state,
                latestposts: payload
            }
        case 'SAVE_SEARCHED_MAILUSERS':
            return {
                ...state,
                searchedMailUsers: payload
            }
        case 'SAVE_APPOINTMENTS':
            return {
                ...state,
                appointments: payload
            }
        case 'SELECTED_MAILTOVIEW':
            return {
                ...state,
                selectedMailtoView: { ...payload, entry_time: timeDifferMail(new Date(payload.sentDate)) }
            }
        case 'GET_USERMAILS':
            return {
                ...state,
                userMails: {
                    totalMailCount: payload.totalMailCount,
                    startingMailIndex: payload.startingMailIndex,
                    endingMailIndex: payload.endingMailIndex,
                    emailList: payload.emailList.map((t) => {
                        return { ...t, entry_time: timeDifferMail(new Date(t.sentDate)) }
                    })
                }
            }
        case 'VIEW_USER_SEARCH':
            return {
                ...state,
                viewUserSearch: payload
            }
        case 'SET_SELECTED_USER':
            return {
                ...state,
                selectedUser: payload
            }
        case 'SET_SELECTED_PATIENT':
            return {
                ...state,
                selectedPatient: payload
            }
        case 'ADD_SEARCH_ITEM':
            return {
                ...state,
                searchItems: payload
            }
        case SELECTED_APPOINTMENT:
            return {
                ...state,
                selectedAppointment: payload
            }
        case GET_APPOINTMENTS:
            let timerData = [];
            if (payload !== null)
                if (payload.length > 0) {
                    payload.map(t => {
                        const today = moment().format('YYYY-MM-DD') + 'T' + moment().format('HH:mm:ss');
                        const sche_date = t.scheduler_date.split('-')[2] + '-' + t.scheduler_date.split('-')[1] + '-' + t.scheduler_date.split('-')[0];
                        const sche_time = t.scheduler_time + ':00';
                        const sche_datetime = sche_date + 'T' + sche_time;
                        var startDate = moment(today);
                        var endDate = moment(sche_datetime);
                        var min_diff = Math.round(endDate.diff(startDate, 'minutes', true));
                        if (min_diff <= 10 && min_diff >= 0) {
                            t['seconds'] = parseInt(Math.round(endDate.diff(startDate, 'seconds', true)) + '000');
                            timerData.push(t)
                        }
                    });

                    if (timerData.length === 0) {
                        payload.map(t => {
                            const today = moment().format('YYYY-MM-DD') + 'T' + moment().format('HH:mm:ss');
                            const sche_date = t.scheduler_date.split('-')[2] + '-' + t.scheduler_date.split('-')[1] + '-' + t.scheduler_date.split('-')[0];
                            const sche_time = t.scheduler_time + ':00';
                            const sche_datetime = sche_date + 'T' + sche_time;
                            var startDate = moment(today);
                            var endDate = moment(sche_datetime);
                            var min_diff = Math.round(endDate.diff(startDate, 'minutes', true));
                            if (min_diff <= 10) {
                                t['seconds'] = parseInt(Math.round(endDate.diff(startDate, 'seconds', true)) + '000');
                                timerData.push(t)
                            }
                        });
                        if (timerData.length > 0) {
                            timerData = [timerData.reduce((p, c) => Math.abs(p.seconds) < Math.abs(c.seconds) ? p : c)];
                        }
                    }
                }
            return {
                ...state,
                appointments: payload,
                timerAppointment: timerData
            }
        case READ_NOTIFICATION:
            return {
                ...state, notification: state.notification.map(data =>
                    (data.id === payload) ? { ...data, read: true } : data),
            };
        case SWAP_POST:
            let currentIndex = state.latestposts.posts.findIndex(el => el.id === payload.id);
            var alteredArray = swapData(state.latestposts.posts, currentIndex, 0)
            // window.scrollTo(0, 0)
            return {
                ...state, latestposts: { ...state.latestposts, posts: alteredArray },
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
            }
        case ADD_NEW_POST:
            let newData = state.latestposts.posts || [];
            newData.push(payload)
            return {
                ...state, latestposts: { ...state.latestposts, posts: newData },
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
            }
        case DELETE_MAIL:
            let obj = []
            const myArrays = [state.mail, payload]
            myArrays.reduce((a, arr) => {
                a.filter(el => {
                    if (!arr.includes(el.id)) {
                        if (obj.length === 0) {
                            obj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                        else if (obj.filter(t => t.id === el.id).length === 0) {
                            obj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                    }
                })
            });

            return {
                ...state, mail: obj,
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
                mailSlicer: manageMailSlicer(obj.length, state.mailSlicer)
            };
        case ADD_TO_STARRED:
            var starAllObj = [];
            let myStarArrays = [state.mail, payload]
            myStarArrays.reduce((a, arr) => {
                a.filter(el => {
                    if (arr.includes(el.id)) {
                        if (starAllObj.length === 0) {
                            starAllObj.push({ ...el, starred: !el.starred, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                        else if (starAllObj.filter(t => t.id === el.id).length === 0) {
                            starAllObj.push({ ...el, starred: !el.starred, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                    }
                    else {
                        if (starAllObj.length === 0) {
                            starAllObj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                        else if (starAllObj.filter(t => t.id === el.id).length === 0) {
                            starAllObj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                    }
                })
            });
            return {
                ...state, mail: starAllObj,
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
            };
        case READ_ALL_MAIL:
            var starObj = [];
            let myAllStarArrays = [state.mail, payload]
            myAllStarArrays.reduce((a, arr) => {
                a.filter(el => {
                    if (arr.includes(el.id)) {
                        if (starObj.length === 0) {
                            starObj.push({ ...el, read: 1, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                        else if (starObj.filter(t => t.id === el.id).length === 0) {
                            starObj.push({ ...el, read: 1, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                    }
                    else {
                        if (starObj.length === 0) {
                            starObj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                        else if (starObj.filter(t => t.id === el.id).length === 0) {
                            starObj.push({ ...el, entry_time: timeDifferMail(new Date(el.time)) })
                        }
                    }
                })
            });
            return {
                ...state, mail: starObj,
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
            };
        case READ_ALL_NOTIFICATION:
            return {
                ...state, notification: state.notification.map(data =>
                    (data) ? { ...data, read: true, entry_time: timeDiffer(new Date(data.time)) } : { ...data, read: true, entry_time: timeDiffer(new Date(data.time)) }),

            }
        case READ_MAIL:
            return {
                ...state,
                mail: state.mail.map(data =>
                    (data.id === payload) ? { ...data, read: 1, entry_time: timeDifferMail(new Date(data.time)) } : { ...data, entry_time: timeDifferMail(new Date(data.time)) }),
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
            }
        case CHANGE_MAIL_SLICER:
            let start = payload.start;
            let end = payload.end;
            let std_length = state.mailSlicer.length;

            if (start < 0) start = 0;
            if (start >= state.mail.filter(el => el.status === 1).length)
                start = start - state.mailSlicer.length;
            if (end <= 0)
                end = state.mailSlicer.length;
            if (end > state.mail.filter(el => el.status === 1).length)
                end = state.mail.filter(el => el.status === 1).length
            if (state.mail.filter(el => el.status === 1).length < state.mailSlicer.length)
                std_length = state.mail.filter(el => el.status === 1).length
            return {
                ...state, mailSlicer: { start: start, end: end, length: std_length },
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
                mail: state.mail.map((t) => {
                    return { ...t, entry_time: timeDifferMail(new Date(t.time)) }
                })
            }
        case 'CHANGE_SCHEDULER_SLICER':
            let sl_start = payload.start;
            let sl_end = payload.end;
            let sl_std_length = state.schedulerSlicer.length;

            if (sl_start < 0) sl_start = 0;
            if (sl_start >= state.appointments.length)
                sl_start = sl_start - state.schedulerSlicer.length;
            if (sl_end <= 0)
                sl_end = state.schedulerSlicer.length;
            if (sl_end > state.appointments.length)
                sl_end = state.appointments.length
            if (state.appointments.length < state.schedulerSlicer.length)
                sl_std_length = state.appointments.length
            return {
                ...state, schedulerSlicer: { start: sl_start, end: sl_end, length: sl_std_length },
                notification: state.notification.map((t) => {
                    return { ...t, entry_time: timeDiffer(new Date(t.time)) }
                }),
                mail: state.mail.map((t) => {
                    return { ...t, entry_time: timeDifferMail(new Date(t.time)) }
                })
            }
        case VIEW_LATESTPOST_FULLSCREEN:
            return {
                ...state,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestPostScreen: !state.latestPostScreen,
                viewSpecificPost: false
            }
        case ADD_REMINDER_APPOINTMENT:

            let timeSet = payload.map((t) => {
                return { ...t, entry_time: timeDiffer(new Date(t.time)) }
            });

            return {
                ...state,
                notification: timeSet,
                mail: state.mail.map((t) => {
                    return { ...t, entry_time: timeDifferMail(new Date(t.time)) }
                })
            }
        case VIEW_MAIL_FULLSCREEN:
            return {
                ...state,
                latestPostScreen: false,
                mailBoxExpander: false,
                mailFullScreen: !state.mailFullScreen,
                viewSpecificPost: false
            }
        case VIEW_MAIL_EXPANDER:
            return {
                ...state,
                latestPostScreen: false,
                mailFullScreen: false,
                mailBoxExpander: !state.mailBoxExpander,
                viewSpecificPost: false
            }
        default:
            var length = 15;
            return {
                ...state,
                notification: [],
                mail: mail.filter(el => el.status === 1).sort((a, b) => {
                    return new Date(b.time) - new Date(a.time)
                }).map((t) => {
                    return { ...t, entry_time: timeDifferMail(new Date(t.time)) }
                }),
                mailSlicer: {
                    start: 0, end: length, length: length
                },
                schedulerSlicer: {
                    start: 0, end: 8, length: 8
                },
                latestPostScreen: false,
                mailFullScreen: false,
                mailBoxExpander: false,
                latestposts: [],
                forwardMail: false,
                // appointments: localStorage.getItem('appointments') ?
                //     JSON.parse(localStorage.getItem('appointments'))
                //     : null,
                appointments: [],
                selectedAppointment: [],
                searchItems: [],
                selectedPatient: { id: "", name: "" },
                selectedUser: {
                    userId: checkSumId,
                    name: "",
                    isSet: false
                    // userId: () => localStorage.getItem('account') !== undefined ? JSON.parse(localStorage.getItem('account')).userid : '',
                    // name: () => localStorage.getItem('account') !== undefined ? JSON.parse(localStorage.getItem('account')).firstname : ''
                },
                viewUserSearch: false,
                searchedMailUsers: [],
                viewSpecificPost: false,
                selectedPost: [],
                fileError: false,
                userGroup: [],
                createPostSelectedTaggedUsers: [],
                newsFullScreen: false,
                newsBoxExpander: false,
                news: [],
                selectedNews: [],
                // timerAppointment: [],
                editTimerData: false,
                processPopup: false,
                selectedProcess: null
            };
    }
}


// swap position to view latest posts
function swapData(arr, old_index, new_index) {
    while (old_index < 0) {
        old_index += arr.length;
    }
    while (new_index < 0) {
        new_index += arr.length;
    }
    if (new_index >= arr.length) {
        var k = new_index - arr.length;
        while ((k--) + 1) {
            arr.push(undefined);
        }
    }
    arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
    return arr;
};

// Convert Elapsed Time
function timeDiffer(date) {
    var diff = (new Date().getTime() - date.getTime()) / 1000;
    diff /= (60 * 60);
    let a = Math.abs(Math.round(diff));
    if (a >= 24) {
        if (Math.round(a / 24) >= 2)
            return `${Math.round(a / 24)} days ago`
        else
            return `${Math.round(a / 24)} day ago`
    }
    else {
        var min = (new Date().getTime() - date.getTime()) / 1000;
        min /= 60;
        var Minutes = Math.abs(Math.round(min));
        if (Minutes >= 60) {
            if (Math.floor(Minutes / 60) >= 2)
                return `${Math.floor(Minutes / 60)} hours ago`
            else
                return `${Math.floor(Minutes / 60)} hour ago`
        }
        else {
            if (Minutes === 0)
                return `now`
            else
                if (Minutes === 1)
                    return `${Minutes} minute ago`
                else
                    return `${Minutes} minutes ago`
        }
    }
}

function manageMailSlicer(meildataLength, mailSlicer) {

    let ex_start = mailSlicer.start;
    let ex_end = mailSlicer.end;
    let ex_std_length = mailSlicer.length;
    if (ex_start < 0) ex_start = 0;
    if (ex_start >= meildataLength)
        ex_start = ex_start - mailSlicer.length;
    if (ex_end <= 0)
        ex_end = mailSlicer.length;
    if (ex_end > meildataLength)
        ex_end = meildataLength
    if (meildataLength < mailSlicer.length)
        ex_std_length = meildataLength;

    return {
        start: ex_start, end: ex_end, length: ex_std_length
    }
}

function timeDifferMail(date) {
    let hh = date.getHours();
    let mm = date.getMinutes();
    if (hh.toString().length === 1)
        hh = '0' + hh;
    if (mm.toString().length === 1)
        mm = '0' + mm;
    let time = hh + ':' + mm;
    var diff = (new Date().getTime() - date.getTime()) / 1000;
    diff /= (60 * 60);
    let a = Math.abs(Math.round(diff));
    if (a >= 24) {
        if (Math.round(a / 24) >= 2)
            return `${Math.round(a / 24)}d`
        else
            return `${Math.round(a / 24)}d`
    }
    else {
        var min = (new Date().getTime() - date.getTime()) / 1000;
        min /= 60;
        var Minutes = Math.abs(Math.round(min));
        if (Minutes >= 60) {
            if (Math.floor(Minutes / 60) >= 2)
                return time
            else
                return time
        }
        else {
            if (Minutes === 0)
                return `now`
            else
                if (Minutes === 1)
                    return time
                else
                    return time
        }
    }
}


function schedulerSlicer(schedulerDataLength, slicer) {
    console.log(schedulerDataLength, slicer)
    let ex_start = slicer.start;
    let ex_end = slicer.end;
    let ex_std_length = slicer.length;
    if (ex_start < 0) ex_start = 0;
    if (ex_start >= schedulerDataLength)
        ex_start = ex_start - slicer.length;
    if (ex_end <= 0)
        ex_end = slicer.length;
    if (ex_end > schedulerDataLength)
        ex_end = schedulerDataLength
    if (schedulerDataLength < slicer.length)
        ex_std_length = schedulerDataLength;
    console.log({ start: ex_start, end: ex_end, length: ex_std_length })
    return {
        start: ex_start, end: ex_end, length: ex_std_length
    }
}

