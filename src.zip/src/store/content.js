import {
  checkSumId,
  apiContentUrlWithToken,
  apiUrlWithToken,
} from "../calls/apis";

import {
  SUCCESS,
  FORBIDDEN,
  INTERNEL_SERVER_ERROR,
  CREATED_SUCCESS,
  COMPRESSED_VIEW,
  STANDARD_VIEW,
  BINARY_INPUT_WIDGET,
  SINGLE_CHOICE_WIDGET,
  MULTI_CHOICE_WIDGET,
  DROPDOWNLIST_WIDGET,
  BRANCH_CONTROL_WIDGET,
  INPUT_TAB,
  TIME_INPUT_WIDGET,
  DATE_WIDGET,
  NARRATIVE_WIDGET,
  NUMBER_WIDGET,
  TEXT_INPUT_WIDGET,
  CALCULATION_WIDGET,
  WARNING_INPUT_WIDGET,
} from "../content-builder/components/Constants";
import getNewWidgetByType from "../content-builder/components/WidgetLabelGenerate/UniqueWidgetLabelGeneration";
import BranchControlWidget from "../content-builder/components/BranchControlWidget";
import currentContentObjects from "../content-builder/components/GetCurrentContentObjects";
import { staticSecondaryTabs } from "../exportables/exportables";
import { act } from "react-dom/test-utils";
//import moment from "moment";
const moment = require("moment");

const loggedEmail = localStorage.getItem("email");
// All content builder CONSTANTS stays here.
const UPDATE_BREADCRUMB = "content/breadcrumb_updated";
const ADD_CONTENT = "ADD_CONTENT";
const SET_TAB_CHANGE = "SET_TAB_CHANGE";
const UPDATE_CONTENT = "UPDATE_CONTENT";
const ABORT_CONTENT = "content/content_aborted";
const SAVE_CONTENT = "content/content_saved";
const SET_MODIFIED_FLAG = "content/content_modified";
const ACTIVE_CONTENT_ID = "ACTIVE_CONTENT_ID";
const ADD_MODULE = "ADD_MODULE";
const ACTIVE_MODULE_ID = "ACTIVE_MODULE_ID";
const DELETE_MODULE = "DELETE_MODULE";
const ADD_WIDGET = "ADD_WIDGET";
const ADD_BRANCH_WIDGET = "ADD_BRANCH_WIDGET";
const DUPLICATE_WIDGET = "DUPLICATE_WIDGET";
const ADD_OUTSIDE_BRANCH_WIDGET = "ADD_OUTSIDE_BRANCH_WIDGET";
const UPDATE_CONTENT_NAME = "UPDATE_CONTENT_NAME";
const DELETE_CONTENT = "DELETE_CONTENT";
const ACTIVE_WIDGET_ID = "ACTIVE_WIDGET_ID";
const DELETE_WIDGET = "DELETE_WIDGET";
const DELETE_REFERENCE = "DELETE_REFERENCE";
const DELETE_ATTACHMENT = "DELETE_ATTACHMENT";
const EXPANDED_MODULE_IDS = "EXPANDED_MODULE_IDS";
const ADVANCED_VIEW_BY_WIDGET_IDS = "ADVANCED_VIEW_BY_WIDGET_IDS";
const COMPRESSED_VIEW_BY_WIDGET_IDS = "COMPRESSED_VIEW_BY_WIDGET_IDS";
const STANDARD_VIEW_BY_WIDGET_IDS = "STANDARD_VIEW_BY_WIDGET_IDS";
const SELECTED_MODULE_IDS = "SELECTED_MODULE_IDS";
const SET_ACTIVE_CURSOR_MODULE_ID = "SET_ACTIVE_CURSOR_MODULE_ID";
const SET_ACTIVE_CURSOR_WIDGET_ID = "SET_ACTIVE_CURSOR_WIDGET_ID";
const SET_PROPERTIES = "SET_PROPERTIES";
const SET_PROCESS_AND_MODULE = "SET_PROCESS_AND_MODULE";
const SET_CURSOR_SELECTED_STATUS = "SET_CURSOR_SELECTED_STATUS";
const SET_ALL_WIDGET_MODE = "SET_ALL_WIDGET_MODE";
const SET_CURRENT_VIEW_MODE = "SET_CURRENT_VIEW_MODE";
const ACTIVE_REFERENCE_ID = "ACTIVE_REFERENCE_ID";
const ACTIVE_ATTACHMENT_ID = "ACTIVE_ATTACHMENT_ID";
const SET_SELECTED_PROPERTIES_MODULE_ID = "SET_SELECTED_PROPERTIES_MODULE_ID";
const SET_WIDGET_FORM_TEXT_ENTERED_STATUS =
  "SET_WIDGET_FORM_TEXT_ENTERED_STATUS";
const SET_WIDGET_DEFAULT_NAME_SHOWED_STATUS =
  "SET_WIDGET_DEFAULT_NAME_SHOWED_STATUS";
const SAVE_DATA_IN_BROWSER = "SAVE_DATA_IN_BROWSER";
const DELETE_OUTSIDE_WIDGET = "DELETE_OUTSIDE_WIDGET";
const ADD_OUTSIDE_WIDGET = "ADD_OUTSIDE_WIDGET";
const DUPLICATE_OUTSIDE_WIDGET = "DUPLICATE_OUTSIDE_WIDGET";
const SET_SELECTED_OUTER_WIDGET_ID = "SET_SELECTED_OUTER_WIDGET_ID";
const SET_IS_GLOBAL_LOGO_POPUP_VISIBLE = "SET_IS_GLOBAL_LOGO_POPUP_VISIBLE";
const TOGGLE_WIDGET_TYPE = "content/widget_type_changed";
const SET_ALL_CONTENTS = "SET_ALL_CONTENTS";
const SET_lOADING_SPINNER = "SET_lOADING_SPINNER";
const SAVE_OUTPUT_EDITOR_VALUES = "SAVE_OUTPUT_EDITOR_VALUES";
const GLOBAL_LOGO_SELECTED_WIDGETS = "GLOBAL_LOGO_SELECTED_WIDGETS";
const SET_REF_ATTACHMENT = "SET_REF_ATTACHMENT";
const ACTIVE_ATTACHMENT_URL = "ACTIVE_ATTACHMENT_URL";
const COPY_DATA = "COPY_DATA";
const PASTE_DATA = "PASTE_DATA";
const RESET_TO_STANDARD_VIEW = "content/reseted_to_standard_mode";
const EMIT_REF_ATTACHMENT = "EMIT_REF_ATTACHMENT";
const RENAME_MODULE_FLAG = "RENAME_MODULE_FLAG";
const SET_NEW_MODULE_NAME = "SET_NEW_MODULE_NAME";
const SET_IMPORT_PICTURE = "SET_IMPORT_PICTURE";
const ADD_PAGE_BREAK = "ADD_PAGE_BREAK";
const SELECT_PAGE_BREAK = "SELECT_PAGE_BREAK";
const DELETE_PAGE_BREAK = "DELETE_PAGE_BREAK";
const SET_WIDGET_DUPLICATE_STATUS = "SET_WIDGET_DUPLICATE_STATUS";
const SET_CONTENT_WIDGET_LABELS = "SET_CONTENT_WIDGET_LABELS";
const SET_RECENT_ADDED_WIDGET = "SET_RECENT_ADDED_WIDGET";
const ACTIVE_OUTPUT_ID = "ACTIVE_OUTPUT_ID";
const SET_CONTENT_OUTPUT = "SET_CONTENT_OUTPUT";
const SET_ACTIVE_BRANCH_CURSOR_ID = "SET_ACTIVE_BRANCH_CURSOR_ID";
const SET_ACTIVE_NESTED_BRANCH_CURSOR_ID = "SET_ACTIVE_NESTED_BRANCH_CURSOR_ID";
const SET_ACTIVE_EXECUTION_CURSOR_ID = "SET_ACTIVE_EXECUTION_CURSOR_ID";
const SET_ACTIVE_NESTED_WIDGET_ID = "SET_ACTIVE_NESTED_WIDGET_ID";
const SET_ACTIVE_NESTED_EXECUTION_ID = "SET_ACTIVE_NESTED_EXECUTION_ID";
const ADD_WIDGET_INSIDE_BRANCH_WIDGET = "ADD_WIDGET_INSIDE_BRANCH_WIDGET";
const ADD_WIDGET_OUTSIDE_BRANCH_WIDGET = "ADD_WIDGET_OUTSIDE_BRANCH_WIDGET";
const ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET =
  "ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET";
const ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET =
  "ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET";
const ADD_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION =
  "ADD_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION";
const ADD_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION =
  "ADD_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION";
const ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION =
  "ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION";
const ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION =
  "ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION";
const ADD_WIDGET_INSIDE_EXECUTION_FRAME = "ADD_WIDGET_INSIDE_EXECUTION_FRAME";
const ADD_WIDGET_INSIDE_NESTED_EXECUTION_FRAME =
  "ADD_WIDGET_INSIDE_NESTED_EXECUTION_FRAME";
const ADD_WIDGET_OUTSIDE_EXECUTION_FRAME = "ADD_WIDGET_OUTSIDE_EXECUTION_FRAME";
const SET_ACTIVE_FORMBAR_TAB = "SET_ACTIVE_FORMBAR_TAB";
const SET_OUTPUT_CONTENT_MODIFIED_FLAG = "SET_OUTPUT_CONTENT_MODIFIED_FLAG";
const SET_COMMON_ACTIVE_FORMBAR_TAB = "SET_COMMON_ACTIVE_FORMBAR_TAB";
const SET_OUTPUT_CURSOT_POSITION = "SET_OUTPUT_CURSOT_POSITION";
const SET_MODULE_WIDGET_POSITION = "SET_MODULE_WIDGET_POSITION";
const VERTICAL_SPINNER = "content/vertical_spinner_toggled";
const HOLD_CURSOR = "content/to_hold_cursor_movement_by_key";
const CREATE_OUTPUT_EDITOR = "content/output_editor_created";
const GET_OUTPUTS_DATA = "content/all_outputs_fetched_by_contentId";
const SET_SELECTED_PROPERTIES_PROCESS = "SET_SELECTED_PROPERTIES_PROCESS";
const SET_SECONDARY_TABS = "content/secondary_tab_placed";
const SET_GLOBAL_REF_WIDGET = "SET_GLOBAL_REF_WIDGET";
const SET_OUTPUTS = "content/output_data_added";
const DELETE_OUTPUT = "content/output_deleted";
const CLEAR_WIDGET = "CLEAR_WIDGET";
const UPDATE_OUTPUT = "content/output_updated";
const UPDATE_AUTHOR = "UPDATE_AUTHOR";
const SET_CONTENT_AUTHOR = "SET_CONTENT_AUTHOR";

const getWidgetDefaultProps = {
  body: null,
  bookmark: false,
  comment: null,
  export: false,
  help: null,
  hide: false,
  required: false,
  answerRequired: "Never",
  answerRequiredValue: null,
  defaultText: null,
  formatValidationStatus: null,
  formatValidationValue: null,
  hintText: null,
  hintTextValue: null,
  indent: null,
  note: null,
  showDefaultAnswer: null,
  showDefaultAnswerValue: null,
  size: null,
  useDefaultAnswerValue: null,
  useDefaultValue: null,
  layout: null,
  decimalValue: null,
  defaultValue: null,
  maximumValue: null,
  minimumValue: null,
  defaultOptions: [
    { value: "", option: "", defaultStatus: false },
    { value: "", option: "", defaultStatus: false },
    { value: "", option: "", defaultStatus: false },
  ],
};

// All content builder ACTION CREATORS stays here
export const addContent = (content, api) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(false));
    dispatch({
      type: ADD_CONTENT,
      payload: content,
    });
    if (!api) {
      dispatch(saveContentDatainBrowser());
    }
  };
};

export const setGlobalLogoWidget = (payload) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(false));
    dispatch({
      type: SET_GLOBAL_REF_WIDGET,
      payload: payload,
    });
  };
};
export const setTabChange = (payload) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(false));
    dispatch({
      type: SET_TAB_CHANGE,
      payload: payload,
    });
  };
};
export const createNewOuputTab = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    dispatch(setContentModifiedFlag(true));
    await apiContentUrlWithToken
      .post(`output/${contentId}/create`)
      .then(async (res) => {
        const id = await res.data.id;
        dispatch(setActiveOutputId(id));
        dispatch({
          type: CREATE_OUTPUT_EDITOR,
          payload: {
            secondaryTabs: {
              id,
              label: null,
              isDisabled: false,
              isOutput: true,
            },
            output: {
              outputId: id,
              contentId: contentId,
              title: "",
              outputData: "",
            },
          },
        });
      })
      .finally((res) => {
        dispatch(setLoadingSpinner(false));
        dispatch(saveContentDatainBrowser());
      });
  };
};

export const deleteOutputAsync = (contentId, outputId) => {
  return (dispatch) => {
    dispatch(setLoadingSpinner(true));
    apiContentUrlWithToken
      .delete(`output/${contentId}/delete?outputId=${outputId}`)
      .then((res) => {
        dispatch(setActiveOutputId(3));
        dispatch({
          type: DELETE_OUTPUT,
          payload: {
            contentId,
            outputId,
          },
        });
      })
      .catch((err) => {
        console.log(err);
        alert("Error: Output not deleted");
      })
      .finally((res) => {
        dispatch(setLoadingSpinner(false));
        // dispatch(saveContentDatainBrowser());
      });
  };
};

export const setOutputs = (payload) => ({
  type: SET_OUTPUTS,
  payload,
});

export const fetchOuputsByContentIdAsync = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .get(`output/${contentId}/list`)
      .then(async (res) => {
        let resData = await res.data;
        dispatch(setOutputs({ contentId, data: resData }));
        // dispatch({ type: GET_OUTPUTS_DATA });
        const data = [...staticSecondaryTabs];
        resData.map((item) =>
          data.push({
            id: item.outputId,
            label: item.title,
            isDisabled: false,
            isOutput: true,
          })
        );
        dispatch(
          setSecondaryTabs({
            contentId,
            data,
          })
        );
      })
      .catch((err) => {
        console.log(err);
        dispatch(setSecondaryTabs({ contentId, data: staticSecondaryTabs }));
      })
      .finally(() => {
        dispatch(setLoadingSpinner(false));
        dispatch(saveContentDatainBrowser());
      });
  };
};

export const setSecondaryTabs = (payload) => ({
  type: SET_SECONDARY_TABS,
  payload,
});

export const updateOutputAsync = (payload) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    const { title, outputData, contentId, outputId } = payload;
    var formData = new FormData();
    formData.append("outputData", outputData);
    formData.append("title", title);
    await apiContentUrlWithToken
      .put(`output/${contentId}/update?outputId=${outputId}`, formData)
      .then((res) => {
        dispatch({ type: UPDATE_OUTPUT, payload });
      })
      .catch((error) => {
        console.log("Update Content Output Api:", error);
      })
      .finally(() => dispatch(setLoadingSpinner(false)));
  };
};

export const holdCursor = (payload) => ({
  type: HOLD_CURSOR,
  payload,
});

export const toggleVerticalSpinner = (payload) => ({
  type: VERTICAL_SPINNER,
  payload,
});

export const updateContent = (content, api, test = false) => {
  return (dispatch) => {
    //dispatch(setContentModifiedFlag(true));
    dispatch({
      type: UPDATE_CONTENT,
      payload: content,
    });
    if (!api) {
      dispatch(saveContentDatainBrowser());
    }
  };
};

export const saveContent = (contentID) => {
  return (dispatch) => {
    dispatch({
      type: SAVE_CONTENT,
      payload: contentID,
    });
    dispatch(saveContentDatainBrowser());
    dispatch(setOutputContentModifiedFlag(false));
    dispatch(setContentModifiedFlag(false));
  };
};

export const saveContentAsync = () => {
  return (dispatch) => {
    dispatch({
      type: SAVE_CONTENT,
    });
    // })
  };
};

// export const abortContent = (contentId) => ({
//   type: ABORT_CONTENT,
//   payload: contentId,
// });
export const abortContent = (contentId) => {
  return (dispatch) => {
    dispatch({
      type: ABORT_CONTENT,
      payload: contentId,
    });
    dispatch(setOutputContentModifiedFlag(false));
    dispatch(setContentModifiedFlag(false));
  };
};

export const setContentModifiedFlag = (flag) => ({
  type: SET_MODIFIED_FLAG,
  payload: flag,
});

export const setContentId = (contentId, api) => {
  return (dispatch) => {
    dispatch({
      type: ACTIVE_CONTENT_ID,
      payload: contentId,
    });
    dispatch(setActiveOutputId(3));
    if (!api) {
      dispatch(saveContentDatainBrowser());
    }
  };
};

export const addModule = (module) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: ADD_MODULE, payload: module });
    dispatch(saveContentDatainBrowser());
    dispatch(setProcessAndModule(module.id));
  };
};

export const saveContentDatainBrowser = () => ({
  type: SAVE_DATA_IN_BROWSER,
});

export const setActiveModuleId = (moduleId, api) => {
  return (dispatch) => {
    dispatch({
      type: ACTIVE_MODULE_ID,
      payload: moduleId,
    });

    if (!api) {
      dispatch(saveContentDatainBrowser());
    }
  };
};

export const setActiveReferenceId = (referenceId) => ({
  type: ACTIVE_REFERENCE_ID,
  payload: referenceId,
});

export const setActiveAttachmentId = (attachmentId) => ({
  type: ACTIVE_ATTACHMENT_ID,
  payload: attachmentId,
});

export const setSelectedPropertiesModuleId = (moduleId) => ({
  type: SET_SELECTED_PROPERTIES_MODULE_ID,
  payload: moduleId,
});

export const setExpandedModuleIds = (moduleId) => {
  return (dispatch) => {
    dispatch({
      type: EXPANDED_MODULE_IDS,
      payload: moduleId,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const deleteModule = (contentModuleId) => {
  return (dispatch) => {
    //dispatch(setContentModifiedFlag(true));
    dispatch({
      type: DELETE_MODULE,
      payload: contentModuleId,
    });

    dispatch(saveContentDatainBrowser());
    dispatch(setProcessAndModule(contentModuleId));
  };
};

export const addWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: ADD_WIDGET, payload: widget });
    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: ADD_BRANCH_WIDGET, payload: widget });
    dispatch(saveContentDatainBrowser());
  };
};

export const duplicateWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: DUPLICATE_WIDGET, payload: widget });
    dispatch(saveContentDatainBrowser());
  };
};
export const updateContentName = (contentName) => {
  return (dispatch) => {
    dispatch({
      type: UPDATE_CONTENT_NAME,
      payload: contentName,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const deleteContent = (contentId) => {
  return (dispatch) => {
    dispatch({
      type: DELETE_CONTENT,
      payload: contentId,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const updateBreadCrumb = (breadcrumb) => ({
  type: UPDATE_BREADCRUMB,
  payload: breadcrumb,
});

export const setActiveWidgetId = (widgetId, clickType, moduleId) => {
  return (dispatch) => {
    dispatch({
      type: ACTIVE_WIDGET_ID,
      payload: widgetId,
      clickType,
      moduleId,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const deleteWidget = (widgetId) => {
  return (dispatch) => {
    dispatch({
      type: DELETE_WIDGET,
      payload: widgetId,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const setAdvancedViewByWidgetIds = (widgetId) => ({
  type: ADVANCED_VIEW_BY_WIDGET_IDS,
  payload: widgetId,
});

export const setCompressedViewByWidgetIds = (widgetId) => ({
  type: COMPRESSED_VIEW_BY_WIDGET_IDS,
  payload: widgetId,
});

export const setStandardViewByWidgetIds = (widgetId) => ({
  type: STANDARD_VIEW_BY_WIDGET_IDS,
  payload: widgetId,
});

export const resetWidgetMode = (widgetId) => ({
  type: RESET_TO_STANDARD_VIEW,
  payload: widgetId,
});

export const setWidgetFormTextEnteredStatus = (widgetId) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: SET_WIDGET_FORM_TEXT_ENTERED_STATUS, payload: widgetId });
    dispatch(saveContentDatainBrowser());
  };
};

export const setWidgetDefaultNameShowedStatus = (widgetId) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: SET_WIDGET_DEFAULT_NAME_SHOWED_STATUS,
      payload: widgetId,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const setSelectedOuterWidgetId = (widgetId) => {
  return (dispatch) => {
    dispatch({
      type: SET_SELECTED_OUTER_WIDGET_ID,
      payload: widgetId,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const setSelectedModuleIds = (
  moduleId,
  clickType,
  activeModuleIndex
) => {
  return (dispatch) => {
    dispatch({
      type: SELECTED_MODULE_IDS,
      payload: moduleId,
      clickType,
      activeModuleIndex,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const setActiveCursorModuleId = (moduleIndex, moduleId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_CURSOR_MODULE_ID,
      payload: moduleIndex,
      moduleId,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const setActiveCursorWidgetId = (widgetId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_CURSOR_WIDGET_ID,
      payload: widgetId,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const setContentModuleProperties = (content) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: SET_PROPERTIES, payload: content });
  };
};

export const setProcessAndModule = (moduleId, isSave = false) => ({
  type: SET_PROCESS_AND_MODULE,
  payload: moduleId,
  isSave,
});

export const setCursorSelectedStatus = (status) => {
  return (dispatch) => {
    dispatch({
      type: SET_CURSOR_SELECTED_STATUS,
      payload: status,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const setAllWidgetMode = (viewMode) => ({
  type: SET_ALL_WIDGET_MODE,
  payload: viewMode,
});

export const setCurrentViewMode = (viewMode) => ({
  type: SET_CURRENT_VIEW_MODE,
  payload: viewMode,
});

export const setIsGlobalLogoPopupVisible = (status) => ({
  type: SET_IS_GLOBAL_LOGO_POPUP_VISIBLE,
  payload: status,
});

export const deleteOutsideWidget = () => {
  return (dispatch) => {
    dispatch({
      type: DELETE_OUTSIDE_WIDGET,
    });

    dispatch(saveContentDatainBrowser());
    dispatch(setProcessAndModule(""));
  };
};

export const addOutsideWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_OUTSIDE_WIDGET,
      payload: widget,
    });

    dispatch(saveContentDatainBrowser());
    dispatch(setProcessAndModule(widget.id));
  };
};
export const duplicateOutsideWidget = (widget) => {
  return (dispatch) => {
    dispatch({
      type: DUPLICATE_OUTSIDE_WIDGET,
      payload: widget,
    });
  };
};
export const addOutsideBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_OUTSIDE_BRANCH_WIDGET,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
    dispatch(setProcessAndModule(widget.id));
  };
};

export const toggleWidget = (widget) => {
  return (dispatch) => {
    dispatch(resetWidgetMode(widget.id));
    dispatch({
      type: TOGGLE_WIDGET_TYPE,
      payload: widget,
    });
  };
};
export const setAllContents = (contents) => ({
  type: SET_ALL_CONTENTS,
  payload: contents,
});

export const setLoadingSpinner = (status) => ({
  type: SET_lOADING_SPINNER,
  payload: status,
});

export const saveOutputEditorValues = ({
  contentId,
  outputContent,
  outputId,
  title,
}) => {
  return async (dispatch) => {
    var formData = new FormData();
    formData.append("outputData", outputContent);
    formData.append("title", title);
    await apiContentUrlWithToken
      .put(`output/${contentId}/update?outputId=${outputId}`, formData)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
          dispatch({
            type: SAVE_OUTPUT_EDITOR_VALUES,
            payload: { contentId, outputContent, outputId },
          });
        }
      })
      .catch((error) => {
        alert("Error occured while saving ouput");
        console.log("Update Content Output Api:", error);
      });

    dispatch(saveContentDatainBrowser());
  };
};

export const setGlobalLogoSelectedWidgets = (widget) => ({
  type: GLOBAL_LOGO_SELECTED_WIDGETS,
  payload: widget,
});

export const copyData = () => {
  return (dispatch) => {
    dispatch({
      type: COPY_DATA,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const pasteData = () => {
  return (dispatch) => {
    dispatch({
      type: PASTE_DATA,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const setDeleteReferenceAttachment = (attachmentUrl) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: DELETE_ATTACHMENT,
      payload: attachmentUrl,
    });
  };
};

export const setReferenceAttachment = (refAttach) => {
  return (dispatch) => {
    dispatch({
      type: SET_REF_ATTACHMENT,
      payload: refAttach,
    });
  };
};

export const setImportPicture = (imageName) => {
  return (dispatch) => {
    dispatch({
      type: SET_IMPORT_PICTURE,
      payload: imageName,
    });
  };
};

export const setActiveAttachmentUrl = (attachmentUrl) => ({
  type: ACTIVE_ATTACHMENT_URL,
  payload: attachmentUrl,
});

export const setRenameModuleFlag = (status) => ({
  type: RENAME_MODULE_FLAG,
  payload: status,
});

export const addPageBreak = (modulePoint, widgetPoint) => {
  return (dispatch) => {
    dispatch({
      type: ADD_PAGE_BREAK,
      payload: modulePoint,
      widgetPoint,
    });
    dispatch(toggleVerticalSpinner(false));
    dispatch(saveContentDatainBrowser());
  };
};

export const selectPageBreak = (index, widgetIndex, moduleId) => {
  return (dispatch) => {
    dispatch({
      type: SELECT_PAGE_BREAK,
      payload: index,
      widgetIndex,
      moduleId,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const deletePageBreak = () => {
  return (dispatch) => {
    dispatch({
      type: DELETE_PAGE_BREAK,
    });
    dispatch(saveContentDatainBrowser());
  };
};

export const setWidgetDuplicateStatus = (widgetId, status = false) => ({
  type: SET_WIDGET_DUPLICATE_STATUS,
  payload: widgetId,
  status,
});

export const setContentWidgetLabels = (data) => ({
  type: SET_CONTENT_WIDGET_LABELS,
  payload: data,
});

export const setRecentAddedWidget = (data) => ({
  type: SET_RECENT_ADDED_WIDGET,
  payload: data,
});

export const setActiveOutputId = (outputId) => ({
  type: ACTIVE_OUTPUT_ID,
  payload: outputId,
});

export const setContentOutput = (contentOutput) => ({
  type: SET_CONTENT_OUTPUT,
  payload: contentOutput,
});

export const setSelectedPropertiesProcess = (process) => ({
  type: SET_SELECTED_PROPERTIES_PROCESS,
  payload: process,
});

export const setContentAuthor = (author) => ({
  type: SET_CONTENT_AUTHOR,
  payload: author,
});

/**
 * this function will set New module name with renaming
 */
export const setNewModuleName = (module, activeContentId) => (dispatch) => {
  apiContentUrlWithToken
    .put(`module/${module.id}/update`, module)
    .then((moduleRes) => {
      if (
        moduleRes.status === SUCCESS ||
        moduleRes.status === CREATED_SUCCESS
      ) {
        dispatch(setRenameModuleFlag(false));
        let isWidgetsExist = module.widgetList.length > 0 ? true : false;
        if (!isWidgetsExist) {
          dispatch(saveContent(activeContentId));
          dispatch(setLoadingSpinner(false));
          dispatch(setContentModifiedFlag(false));
          return;
        }
        /**
         * module widgets update
         */

        module.widgetList.map((widget, index) => {
          let widgetRequest = setUpdateWidgetRequest(
            widget,
            activeContentId,
            module.id
          );
          apiContentUrlWithToken
            .put(`widget/update`, widgetRequest)
            .then((moduleRes) => {
              if (
                moduleRes.status === SUCCESS ||
                moduleRes.status === CREATED_SUCCESS
              ) {
                if (module.widgetList.length - 1 === index) {
                  dispatch(saveContent(activeContentId));
                  dispatch(setLoadingSpinner(false));
                  dispatch(setRenameModuleFlag(false));
                  dispatch(setContentModifiedFlag(false));
                }
              }
            })
            .catch((error) => {
              dispatch(setLoadingSpinner(false));
              dispatch(setRenameModuleFlag(false));
              console.log("Module widgets update api:", error);
            });
        });
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Renaming and updating AI error:", error);
    });
};

export const setIsEmitRefAttachmentFlag = (isEmitRefAttachmentFlag) => ({
  type: EMIT_REF_ATTACHMENT,
  payload: isEmitRefAttachmentFlag,
});

export const setActiveBranchCursorId = (branchId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_BRANCH_CURSOR_ID,
      payload: branchId,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const setActiveNestedBranchCursorId = (branchId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_NESTED_BRANCH_CURSOR_ID,
      payload: branchId,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const setActiveNestedExecutionFrameCursorId = (branchId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_NESTED_EXECUTION_ID,
      payload: branchId,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const setActiveNestedWidgetCursorId = (branchId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_NESTED_WIDGET_ID,
      payload: branchId,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const setActiveExecutionFrameCursorId = (executionId) => {
  return (dispatch) => {
    dispatch({
      type: SET_ACTIVE_EXECUTION_CURSOR_ID,
      payload: executionId,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addBranchWidget = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  content
) => {
  return (dispatch) => {
    dispatch(
      createNewBranchWidgetByWidget(
        widgetCreateData,
        widget,
        activeCursorWidgetId,
        content
      )
    );
  };
};
export const createNewBranchWidgetByWidget = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  content
) => {
  return (dispatch) => {
    let widgetRequest = setUpdateWidgetRequest(
      widget,
      widgetCreateData.contentId,
      widgetCreateData.moduleId
    );
    apiContentUrlWithToken
      .post(`widget/create`, widgetCreateData)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.id
        ) {
          res.data.title = widget.title || widget.widgetName;
          const widgetType = res.data.type;
          res.data.widgetType = res.data.type;
          res.data.new = widgetCreateData.new;
          if (
            widgetType === BINARY_INPUT_WIDGET ||
            widgetType === SINGLE_CHOICE_WIDGET ||
            widgetType === MULTI_CHOICE_WIDGET ||
            widgetType === DROPDOWNLIST_WIDGET
          ) {
            res.data.defaultOptions = setDefaultOptionsForWidget(widgetType);
          }
          if (widgetType === BRANCH_CONTROL_WIDGET) {
            if (
              content.currentContent.nestedBranchWidgetCursorIndex === undefined
            ) {
              res.data.branchConditions = [
                {
                  conditions: [
                    {
                      field: "",
                      expression: "<",
                      value: "",
                    },
                  ],
                },
              ];
            }
          }
        }

        let widgetDefaultStateProperties = getWidgetDefaultStateProperties(
          {},
          res.data
        );

        const newWidget = Object.assign(
          {},
          res.data,
          widgetDefaultStateProperties
        );

        if (activeCursorWidgetId === undefined) {
          if (content.currentContent.executionFrameCursorId !== undefined) {
            dispatch(addWidgetBy_outsideExecutionFrame(newWidget));
          } else if (
            content.currentContent.nestedBranchWidgetCursorIndex !== undefined
          ) {
            dispatch(addNestedWidgetBy_outsideBranchWidget(newWidget));
          } else {
            dispatch(addWidgetBy_outsideBranchWidget(newWidget));
          }
        } else {
          if (
            content.currentContent.nestedExecutionFrameCursorId !== undefined
          ) {
            dispatch(addWidgetBy_insideNestedExecutionFrame(newWidget));
          } else if (
            content.currentContent.executionFrameCursorId !== undefined
          ) {
            dispatch(addWidgetBy_insideExecutionFrame(newWidget));
          } else if (
            content.currentContent.nestedBranchWidgetCursorIndex !== undefined
          ) {
            dispatch(addNestedWidgetBy_insideBranchWidget(newWidget));
          } else {
            dispatch(addWidgetBy_insideBranchWidget(newWidget));
          }
        }

        dispatch(
          storeRedis(content.currentContent, widget.widgetName, newWidget.type)
        );
        dispatch(toggleVerticalSpinner(false));
      })
      .catch((err) => {
        dispatch(toggleVerticalSpinner(false));
      });
  };
};
export const createNewBranchWidgetByWidgetWithoutCondition = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  content
) => {
  return (dispatch) => {
    let widgetRequest = setUpdateWidgetRequest(
      widget,
      widgetCreateData.contentId,
      widgetCreateData.moduleId
    );
    apiContentUrlWithToken
      .post(`widget/create`, widgetCreateData)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.id
        ) {
          res.data.title = widget.title || widget.widgetName;
          const widgetType = res.data.type;
          res.data.widgetType = res.data.type;
          res.data.new = widgetCreateData.new;
          if (
            widgetType === BINARY_INPUT_WIDGET ||
            widgetType === SINGLE_CHOICE_WIDGET ||
            widgetType === MULTI_CHOICE_WIDGET ||
            widgetType === DROPDOWNLIST_WIDGET
          ) {
            res.data.defaultOptions = setDefaultOptionsForWidget(widgetType);
          }
          if (widgetType === BRANCH_CONTROL_WIDGET) {
            if (
              content.currentContent.nestedBranchWidgetCursorIndex === undefined
            ) {
              res.data.branchDonditions = [
                {
                  conditions: [
                    {
                      field: "",
                      expression: "<",
                      value: "",
                    },
                  ],
                },
              ];
            }
          }
        }
        if (activeCursorWidgetId === undefined) {
          if (content.currentContent.executionFrameCursorId !== undefined) {
            dispatch(addWidgetBy_outsideExecutionFrame(res.data));
          } else if (
            content.currentContent.nestedBranchWidgetCursorIndex !== undefined
          ) {
            dispatch(addNestedWidgetBy_outsideBranchWidgetCondition(res.data));
          } else {
            dispatch(addWidgetBy_outsideBranchWidgetCondition(res.data));
          }
        } else {
          if (content.currentContent.executionFrameCursorId !== undefined) {
            dispatch(addWidgetBy_insideExecutionFrame(res.data));
          } else if (
            content.currentContent.nestedBranchWidgetCursorIndex !== undefined
          ) {
            dispatch(addNestedWidgetBy_insideBranchWidgetCondition(res.data));
          } else {
            dispatch(addWidgetBy_insideBranchWidgetCondition(res.data));
          }
        }
        dispatch(
          storeRedis(content.currentContent, widget.widgetName, res.data.type)
        );
      });

    dispatch(toggleVerticalSpinner(false));
  };
};
export const addWidgetBy_insideBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_INSIDE_BRANCH_WIDGET,
      payload: widget,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBy_insideBranchWidgetCondition = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION,
      payload: widget,
    });

    dispatch(saveContentDatainBrowser());
  };
};

export const addWidgetBy_outsideBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_OUTSIDE_BRANCH_WIDGET,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBy_outsideBranchWidgetCondition = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBy_insideExecutionFrame = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_INSIDE_EXECUTION_FRAME,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBy_outsideExecutionFrame = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_OUTSIDE_EXECUTION_FRAME,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addWidgetBy_insideNestedExecutionFrame = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_WIDGET_INSIDE_NESTED_EXECUTION_FRAME,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const createNewNestedBranchWidgetByWidget = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  content
) => {
  return (dispatch) => {
    let widgetRequest = setUpdateWidgetRequest(
      widget,
      widgetCreateData.contentId,
      widgetCreateData.moduleId
    );
    apiContentUrlWithToken
      .post(`widget/create`, widgetCreateData)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.id
        ) {
          res.data.title = widget.title || widget.widgetName;
          const widgetType = res.data.type;
          res.data.widgetType = res.data.type;
          res.data.new = widgetCreateData.new;
          if (
            widgetType === BINARY_INPUT_WIDGET ||
            widgetType === SINGLE_CHOICE_WIDGET ||
            widgetType === MULTI_CHOICE_WIDGET ||
            widgetType === DROPDOWNLIST_WIDGET
          ) {
            res.data.defaultOptions = setDefaultOptionsForWidget(widgetType);
          }
          if (widgetType === BRANCH_CONTROL_WIDGET) {
            res.data.branchDonditions = [
              {
                conditions: [
                  {
                    field: "",
                    expression: "<",
                    value: "",
                  },
                ],
              },
            ];
          }
        }
        if (activeCursorWidgetId === undefined) {
          dispatch(addNestedWidgetBy_outsideBranchWidgetCondition(res.data));
        } else {
          dispatch(addNestedWidgetBy_insideBranchWidgetCondition(res.data));
        }
      });
  };
};
export const addNestedWidgetBy_insideBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET,
      payload: widget,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const addNestedWidgetBy_insideBranchWidgetCondition = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION,
      payload: widget,
    });

    dispatch(saveContentDatainBrowser());
  };
};
export const addNestedWidgetBy_outsideBranchWidget = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const addNestedWidgetBy_outsideBranchWidgetCondition = (widget) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({
      type: ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION,
      payload: widget,
    });
    dispatch(saveContentDatainBrowser());
  };
};
export const setActiveFormBarTab = (currentTab) => ({
  type: SET_ACTIVE_FORMBAR_TAB,
  payload: currentTab,
});

export const setOutputContentModifiedFlag = (flag) => ({
  type: SET_OUTPUT_CONTENT_MODIFIED_FLAG,
  payload: flag,
});

export const setCommonActiveFormBarTab = (currentTab) => ({
  type: SET_COMMON_ACTIVE_FORMBAR_TAB,
  payload: currentTab,
});

export const setOutputCursorPosition = (cursor) => ({
  type: SET_OUTPUT_CURSOT_POSITION,
  payload: cursor,
});
export const setModuleWidgetPosition = (
  activeContentId,
  modulesAndOutsideWidgetsPositions,
  modulesWidgetsPositions
) => ({
  type: SET_MODULE_WIDGET_POSITION,
  payload: activeContentId,
  modulesAndOutsideWidgetsPositions,
  modulesWidgetsPositions,
});

export const setClearWidgetData = () => ({
  type: CLEAR_WIDGET,
  payload: "",
});

/**
 * Get all the stored contents
 */
export const getAllContents = () => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(false));
    await apiContentUrlWithToken
      .get(`content/list?checksumid=${await checkSumId}`)
      .then((res) => {
        debugger;
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.length > 0
        ) {
          let contentList = [];
          let localData = JSON.parse(
            localStorage.getItem("local_contentBuilder")
          );
          res.data.map((content) => {
            content.moduleList = content.moduleList || [];
            content.widgetList = content.widgetList || [];
            let contentState = localData?.find(
              (localContent) => localContent.contentId === content.contentId
            );
            console.log("contentState ", contentState);
            let contentDefaultStateProperty = getContentDefaultStateProperties(
              contentState
            );
            const contentWithStateProperty = Object.assign(
              {},
              contentDefaultStateProperty,
              content
            );
            contentList.push(contentWithStateProperty);
          });
          dispatch(setAllContents(contentList));
          // if (isAbort && activeContentId)
          //   dispatch(setContentId(activeContentId, 'api'));
          // else
          dispatch(setContentId(contentList[0].contentId, "api"));
          dispatch(setActiveModuleId(contentList[0].activeModuleId, "api"));
          //dispatch(setLoadingSpinner(false));
          dispatch(
            getContentDetailsByContentId(contentList[0].contentId, false, true)
          );
        } else {
          dispatch(createNewContent());
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Get all content Api:", error);
      });
  };
};

/**
 * Create new content
 */
export const createNewContent = (isNewContent) => {
  return async (dispatch) => {
    let checksumId = await checkSumId;
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .post("content/create", { checksumId: checksumId })
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
          const newContentId = res.data.contentId;
          res.data.widgetList = res.data.widgetList || [];
          let contentDefaultStateProperty = getContentDefaultStateProperties(
            {}
          );

          const newContentData = Object.assign(
            {},
            res.data,
            contentDefaultStateProperty
          );

          dispatch(addContent(newContentData));
          dispatch(setContentId(newContentId));
          //dispatch(createNewContentOutput(activeContentId));
          dispatch(setLoadingSpinner(false));

          // create author for content owner.
          let account = localStorage.getItem("account");
          if (account) {
            let email = localStorage.getItem("email");
            let userName =
              account.firstname || account.lastname
                ? `${account.firstname} ${account.lastname}`
                : email.split("@")[0];
            var data = {
              request: [
                {
                  authorId: 0,
                  authorStatus: true,
                  checkSumId: checksumId,
                  commentPermissions: {
                    read: true,
                    write: true,
                  },
                  contentPermissions: {
                    read: true,
                    write: true,
                  },
                  contentRole: "ContentOwner",
                  propertiesPermissions: {
                    read: true,
                    write: true,
                  },
                  userName: userName,
                  workGroupId: localStorage.getItem("groupId"),
                },
              ],
            };
            // createNewContentAuthor(newContentId, data);
            apiContentUrlWithToken
              .post(`author/${newContentId}/create`, data)
              .then((res) => {
                if (
                  (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
                  res.data != null
                ) {
                  if (res.data.response && res.data.response.length > 0) {
                    dispatch(setContentAuthor(res.data.response));
                  }
                }
              })
              .catch((error) => {
                dispatch(setLoadingSpinner(false));
                console.log("Create New Content Output Api:", error);
              });
          }
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Create New Content Api:", error);
      });
  };
};

/**
 * Get content details by active content id
 */
export const getContentDetailsByContentId = (
  contentId,
  isNewContent = false,
  isUpdateContent = false
) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .get(`content/${contentId}/detail`)
    .then((chlRes) => {
      if (
        (chlRes.status === SUCCESS || chlRes.status === CREATED_SUCCESS) &&
        chlRes.data
      ) {
        let localData = JSON.parse(
          localStorage.getItem("local_contentBuilder")
        );
        let contentModuleList = localData?.find(
          (localContent) => localContent.contentId === contentId
        )?.moduleList;
        chlRes.data.moduleList = chlRes.data.moduleList || [];
        chlRes.data.widgetList = chlRes.data.widgetList || [];
        /**
         * outside widgets maintain the state property
         */

        let contentWidgetList = localData?.find(
          (localContent) => localContent.contentId === contentId
        )?.widgetList;
        chlRes.data.widgetList.map((widget, index) => {
          let contentWidget = contentWidgetList?.find(
            (contentWidget) => contentWidget?.id === widget.id
          );
          widget.defaultValue =
                widget.type === DATE_WIDGET && widget.defaultValue
                  ? moment(
                      new Date(
                        widget?.defaultValue.month +
                          "/" +
                          widget?.defaultValue.day +
                          "/" +
                          widget?.defaultValue.year
                      )
                    ).toISOString()
                  : widget?.defaultValue;
                  widget.maximumValue =
                  widget.type === DATE_WIDGET && widget?.maximumValue
                    ? moment(
                        new Date(
                          widget?.maximumValue.month +
                            "/" +
                            widget?.maximumValue.day +
                            "/" +
                            widget?.maximumValue.year
                        )
                      ).toISOString()
                    : widget?.maximumValue
                    
                widget.minimumValue =
                  widget?.type === DATE_WIDGET && widget?.minimumValue
                    ? moment(
                        new Date(
                          widget?.minimumValue.month +
                            "/" +
                            widget?.minimumValue.day +
                            "/" +
                            widget?.minimumValue.year
                        )
                      ).toISOString()
                    : widget?.minimumValue
                   

                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.defaultValue
                ) {
                  let hour =
                    widget?.defaultValue.hour > 9
                      ? widget?.defaultValue.hour
                      : "0" + widget?.defaultValue.hour;
                  let minute =
                    widget?.defaultValue.minute > 0
                      ? widget?.defaultValue.minute
                      : "0" + widget?.defaultValue.minute;
                  widget.defaultValue = hour + ":" + minute;
                }
                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.maximumValue
                ) {
                  let hour =
                    widget?.maximumValue.hour > 9
                      ? widget?.maximumValue.hour
                      : "0" + widget?.maximumValue.hour;
                  let minute =
                    widget?.maximumValue.minute > 0
                      ? widget?.maximumValue.minute
                      : "0" + widget?.maximumValue.minute;
                  widget.maximumValue = hour + ":" + minute;
                }
                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.minimumValue
                ) {
                  let hour =
                    widget?.minimumValue.hour > 9
                      ? widget?.minimumValue.hour
                      : "0" + widget?.minimumValue.hour;
                  let minute =
                    widget?.minimumValue.minute > 0
                      ? widget?.minimumValue.minute
                      : "0" + widget?.minimumValue.minute;
                  widget.minimumValue = hour + ":" + minute;
                }
          if (
            contentWidget &&
            contentWidget !== undefined &&
            widget &&
            widget !== undefined
          ) {
            widget.title = widget.title || contentWidget?.title;
            widget.answerRequired =
              widget.answerRequired || contentWidget?.answerRequired;
            widget.answerRequiredValue =
              widget.answerRequiredValue || contentWidget?.answerRequiredValue;
            widget.defaultText =
              widget.defaultText || contentWidget?.defaultText;
            // widget.date_defaultValue =
            //   widget.date_defaultValue || contentWidget?.date_defaultValue;
            // widget.date_maxValue =
            //   widget.date_maxValue || contentWidget?.date_maxValue;
            // widget.date_minValue =
            //   widget.date_minValue || contentWidget?.date_minValue;
            widget.value = widget.value || contentWidget?.value;
            // widget.time_minValue =
            //   widget.time_minValue || contentWidget?.time_minValue;
            // widget.time_maxValue =
            //   widget.time_maxValue || contentWidget?.time_maxValue;
            // widget.time_defaultValue =
            //   widget.time_defaultValue || contentWidget?.time_defaultValue;
            widget.formatValidationStatus =
              widget.formatValidationStatus ||
              contentWidget?.formatValidationStatus;
            widget.formatValidationValue =
              widget.formatValidationValue ||
              contentWidget?.formatValidationValue;
            widget.hintText = contentWidget?.hintText;
            widget.hintTextValue = contentWidget?.hintTextValue;
            widget.indent = contentWidget?.indent;
            widget.note = contentWidget?.note;
            widget.showDefaultAnswer = contentWidget?.showDefaultAnswer;
            widget.showDefaultAnswerValue =
              contentWidget?.showDefaultAnswerValue;
            widget.size = contentWidget?.size;
            widget.useDefaultAnswerValue = contentWidget?.useDefaultAnswerValue;
            widget.useDefaultValue = contentWidget?.useDefaultValue;
            widget.layout = contentWidget?.layout;
            widget.decimalValue = contentWidget?.decimalValue;

            // widget.defaultValue = widget?.type === 'date' && contentWidget?.defaultValue ?
            //   moment(new Date(contentWidget?.defaultValue.split('/')[1] + '/' + contentWidget?.defaultValue.split('/')[0] + '/' + contentWidget?.defaultValue.split('/')[2])).toISOString() : contentWidget?.defaultValue;
            // widget.maximumValue = widget?.type === 'date' && contentWidget?.maximumValue ?
            //   moment(new Date(contentWidget?.maximumValue.split('/')[1] + '/' + contentWidget?.maximumValue.split('/')[0] + '/' + contentWidget?.maximumValue.split('/')[2])).toISOString() : contentWidget?.maximumValue;
            // widget.minimumValue = widget?.type === 'date' && contentWidget?.minimumValue ?
            //   moment(new Date(contentWidget?.minimumValue.split('/')[1] + '/' + contentWidget?.defaultValue.split('/')[0] + '/' + contentWidget?.minimumValue.split('/')[2])).toISOString() : contentWidget?.minimumValue;

            widget.defaultValue =
              widget?.type === DATE_WIDGET && widget?.defaultValue
                ? moment(
                    new Date(
                      widget?.defaultValue.month +
                        "/" +
                        widget?.defaultValue.day +
                        "/" +
                        widget?.defaultValue.year
                    )
                  ).toISOString()
                : widget?.defaultValue
                ? widget?.defaultValue
                : contentWidget?.defaultValue;

            widget.maximumValue =
              widget?.type === DATE_WIDGET && widget?.maximumValue
                ? moment(
                    new Date(
                      widget?.maximumValue.month +
                        "/" +
                        widget?.maximumValue.day +
                        "/" +
                        widget?.maximumValue.year
                    )
                  ).toISOString()
                : widget?.maximumValue
                ? widget?.maximumValue
                : contentWidget?.maximumValue;

            widget.minimumValue =
              widget?.type === DATE_WIDGET && widget?.minimumValue
                ? moment(
                    new Date(
                      widget?.minimumValue.month +
                        "/" +
                        widget?.minimumValue.day +
                        "/" +
                        widget?.minimumValue.year
                    )
                  ).toISOString()
                : widget?.minimumValue
                ? widget?.minimumValue
                : contentWidget?.minimumValue;

            if (widget?.type === TIME_INPUT_WIDGET && widget?.defaultValue) {
              let hour =
                widget?.defaultValue.hour > 9
                  ? widget?.defaultValue.hour
                  : "0" + widget?.defaultValue.hour;
              let minute =
                widget?.defaultValue.minute > 0
                  ? widget?.defaultValue.minute
                  : "0" + widget?.defaultValue.minute;
              widget.defaultValue = hour + ":" + minute;
            }
            if (widget?.type === TIME_INPUT_WIDGET && widget?.maximumValue) {
              let hour =
                widget?.maximumValue.hour > 9
                  ? widget?.maximumValue.hour
                  : "0" + widget?.maximumValue.hour;
              let minute =
                widget?.maximumValue.minute > 0
                  ? widget?.maximumValue.minute
                  : "0" + widget?.maximumValue.minute;
              widget.maximumValue = hour + ":" + minute;
            }
            if (widget?.type === TIME_INPUT_WIDGET && widget?.minimumValue) {
              let hour =
                widget?.minimumValue.hour > 9
                  ? widget?.minimumValue.hour
                  : "0" + widget?.minimumValue.hour;
              let minute =
                widget?.minimumValue.minute > 0
                  ? widget?.minimumValue.minute
                  : "0" + widget?.minimumValue.minute;
              widget.minimumValue = hour + ":" + minute;
            }

            widget.hide = contentWidget?.hide || false;
            widget.bookmark = contentWidget?.bookmark || false;
            widget.export = contentWidget?.export || false;
            widget.required = contentWidget?.required || false;
            widget.widgetList =
              (contentWidget?.widgetList?.length > 0 &&
                contentWidget?.widgetList) ||
              (widget.widgetList.length > 0 && widget.widgetList) ||
              [];
            //    widget.widgetCursorIndex = contentWidget?.widgetCursorIndex !== undefined ? contentWidget?.widgetCursorIndex  : undefined;
            widget.defaultOptions = contentWidget?.defaultOptions || [
              { value: "", option: "", defaultStatus: false },
              { value: "", option: "", defaultStatus: false },
              { value: "", option: "", defaultStatus: false },
            ];

            if (contentWidget.type === BRANCH_CONTROL_WIDGET) {
              widget.branchControlType =
                contentWidget.branchControlType || "skip";
              widget.branchConditions = contentWidget.branchConditions || [
                { conditions: [{ field: "", expression: "<", value: "" }] },
              ];
            }

            let widgetDefaultStateProperties = getWidgetDefaultStateProperties(
              contentWidget,
              widget
            );
            chlRes.data.widgetList[index] = Object.assign(
              {},
              widgetDefaultStateProperties,
              widget
            );
          }
        });

        let modulesAndOutsideWidgetsPositions =
          chlRes.data?.modulesAndOutsideWidgetsPositions;
        if (modulesAndOutsideWidgetsPositions?.length === 0) {
          modulesAndOutsideWidgetsPositions = localData?.find(
            (localContent) => localContent.contentId === contentId
          )?.modulesAndOutsideWidgetsPositions;
        }

        let modulesOrder = modulesAndOutsideWidgetsPositions?.filter(
          (x) => x.type === "module"
        );

        let modulesOrderList = [];
        if (modulesOrder !== undefined && modulesOrder.length > 0) {
          modulesOrder.map((moduleOrder) => {
            let moduleIndex = chlRes.data.moduleList.findIndex(
              (module) => module.id == moduleOrder.id
            );
            if (moduleIndex > -1) {
              insertAt(
                modulesOrderList,
                moduleOrder.index,
                chlRes.data.moduleList[moduleIndex]
              );
            }
          });
          chlRes.data.moduleList = modulesOrderList;
        }
        let outSideWidgetsOrder = modulesAndOutsideWidgetsPositions?.filter(
          (x) => x.type === "widget"
        );

        let outSideWidgetsOrderList = [];
        if (
          outSideWidgetsOrder !== undefined &&
          outSideWidgetsOrder.length > 0
        ) {
          outSideWidgetsOrder.map((outsideOrder) => {
            let widgetIndex = chlRes.data.widgetList.findIndex(
              (widget) => widget.id == outsideOrder.id
            );
            if (widgetIndex > -1) {
              insertAt(
                outSideWidgetsOrderList,
                outsideOrder.index,
                chlRes.data.widgetList[widgetIndex]
              );
            }
          });
          chlRes.data.widgetList = outSideWidgetsOrderList;
        }

        function insertAt(array, index, ...elements) {
          array.splice(index, 0, ...elements);
        }

        chlRes.data.moduleList.map((module) => {
          // let contentModuleWidgets = contentModuleList.moduleList?.find(
          //   (contentModule) => contentModule.id === module.id
          // )?.widgetList;
          let contentModuleWidgets = contentModuleList?.find(
            (contentModule) => contentModule?.id === module?.id
          )?.widgetList;
          let moduleWidgetsOrder = chlRes.data?.modulesWidgetsPositions;
          if (moduleWidgetsOrder?.length === 0) {
            let modulesWidgetsPositions = localData?.find(
              (localContent) => localContent.contentId === contentId
            )?.modulesWidgetsPositions;
            moduleWidgetsOrder = modulesWidgetsPositions?.filter(
              (x) => x.moduleId === module?.id
            );
          }

          let pageBreakPosition = contentModuleList?.find(
            (contentModule) => contentModule?.id === module?.id
          )?.pageBreakPosition;

          if (pageBreakPosition?.length > 0) {
            module.pageBreakPosition = [
              ...module.pageBreakPosition,
              ...pageBreakPosition,
            ];
          }

          /**
           * maintain the widgets order based on cursor position
           */
          let widgetsOrderList = [];
          if (
            moduleWidgetsOrder !== undefined &&
            moduleWidgetsOrder.length > 0
          ) {
            moduleWidgetsOrder.map((widgetOrder) => {
              let widgetIndex = module?.widgetList.findIndex(
                (widget) => widget.id == widgetOrder.id
              );
              if (widgetIndex > -1) {
                insertAt(
                  widgetsOrderList,
                  widgetOrder.index,
                  module.widgetList[widgetIndex]
                );
              }
            });
            module.widgetList = widgetsOrderList;
          }
          function insertAt(array, index, ...elements) {
            array.splice(index, 0, ...elements);
          }

          /**
           * widgets state maintain property included into widget response
           */
          if (module && module?.widgetList && module?.widgetList.length > 0) {
            module.widgetList.map((widget, index) => {
              let contentModuleWidget = contentModuleWidgets?.find(
                (contentModuleWidget) => contentModuleWidget?.id === widget?.id
              );
              // widget.defaultValue =
              //   widget.type === DATE_WIDGET && widget.defaultValue
              //     ? moment(
              //         new Date(
              //           widget?.defaultValue.month +
              //             "/" +
              //             widget?.defaultValue.day +
              //             "/" +
              //             widget?.defaultValue.year
              //         )
              //       ).toISOString()
              //     : widget?.defaultValue;
              //     widget.maximumValue =
              //     widget.type === DATE_WIDGET && widget?.maximumValue
              //       ? moment(
              //           new Date(
              //             widget?.maximumValue.month +
              //               "/" +
              //               widget?.maximumValue.day +
              //               "/" +
              //               widget?.maximumValue.year
              //           )
              //         ).toISOString()
              //       : widget?.maximumValue
                    
              //   widget.minimumValue =
              //     widget?.type === DATE_WIDGET && widget?.minimumValue
              //       ? moment(
              //           new Date(
              //             widget?.minimumValue.month +
              //               "/" +
              //               widget?.minimumValue.day +
              //               "/" +
              //               widget?.minimumValue.year
              //           )
              //         ).toISOString()
              //       : widget?.minimumValue
                   

              //   if (
              //     widget?.type === TIME_INPUT_WIDGET &&
              //     widget?.defaultValue
              //   ) {
              //     let hour =
              //       widget?.defaultValue.hour > 9
              //         ? widget?.defaultValue.hour
              //         : "0" + widget?.defaultValue.hour;
              //     let minute =
              //       widget?.defaultValue.minute > 0
              //         ? widget?.defaultValue.minute
              //         : "0" + widget?.defaultValue.minute;
              //     widget.defaultValue = hour + ":" + minute;
              //   }
              //   if (
              //     widget?.type === TIME_INPUT_WIDGET &&
              //     widget?.maximumValue
              //   ) {
              //     let hour =
              //       widget?.maximumValue.hour > 9
              //         ? widget?.maximumValue.hour
              //         : "0" + widget?.maximumValue.hour;
              //     let minute =
              //       widget?.maximumValue.minute > 0
              //         ? widget?.maximumValue.minute
              //         : "0" + widget?.maximumValue.minute;
              //     widget.maximumValue = hour + ":" + minute;
              //   }
              //   if (
              //     widget?.type === TIME_INPUT_WIDGET &&
              //     widget?.minimumValue
              //   ) {
              //     let hour =
              //       widget?.minimumValue.hour > 9
              //         ? widget?.minimumValue.hour
              //         : "0" + widget?.minimumValue.hour;
              //     let minute =
              //       widget?.minimumValue.minute > 0
              //         ? widget?.minimumValue.minute
              //         : "0" + widget?.minimumValue.minute;
              //     widget.minimumValue = hour + ":" + minute;
              //   }

              if (
                contentModuleWidget &&
                contentModuleWidget !== undefined &&
                widget &&
                widget !== undefined
              ) {
                console.log("in", contentModuleWidget);
                widget.title = widget?.title || contentModuleWidget?.title;
                widget.answerRequired =
                  widget.answerRequired || contentModuleWidget?.answerRequired;
                widget.answerRequiredValue =
                  widget.answerRequiredValue ||
                  contentModuleWidget?.answerRequiredValue;
                widget.defaultText =
                  widget.defaultText || contentModuleWidget?.defaultText;
                widget.date_defaultValue =
                  widget.date_defaultValue ||
                  contentModuleWidget?.date_defaultValue;
                widget.date_maxValue =
                  widget.date_maxValue || contentModuleWidget?.date_maxValue;
                widget.date_minValue =
                  widget.date_minValue || contentModuleWidget?.date_minValue;
                widget.value = widget.value || contentModuleWidget?.value;
                widget.time_minValue =
                  widget.time_minValue || contentModuleWidget?.time_minValue;
                widget.time_maxValue =
                  widget.time_maxValue || contentModuleWidget?.time_maxValue;
                widget.time_defaultValue =
                  widget.time_defaultValue ||
                  contentModuleWidget?.time_defaultValue;
                widget.formatValidationStatus =
                  widget.formatValidationStatus ||
                  contentModuleWidget?.formatValidationStatus;
                widget.formatValidationValue =
                  widget.formatValidationValue ||
                  contentModuleWidget?.formatValidationValue;
                widget.hintText = contentModuleWidget?.hintText;
                widget.hintTextValue = contentModuleWidget?.hintTextValue;
                widget.indent = contentModuleWidget?.indent;
                widget.note = contentModuleWidget?.note;
                widget.showDefaultAnswer =
                  contentModuleWidget?.showDefaultAnswer;
                widget.showDefaultAnswerValue =
                  contentModuleWidget?.showDefaultAnswerValue;
                widget.size = contentModuleWidget?.size;
                widget.useDefaultAnswerValue =
                  contentModuleWidget?.useDefaultAnswerValue;
                widget.useDefaultValue = contentModuleWidget?.useDefaultValue;
                widget.layout = contentModuleWidget?.layout;
                widget.decimalValue = contentModuleWidget?.decimalValue;
                // widget.defaultValue = contentModuleWidget?.defaultValue;
                // widget.maximumValue = contentModuleWidget?.maximumValue;
                // widget.minimumValue = contentModuleWidget?.minimumValue;

                widget.defaultValue =
                  widget.type === DATE_WIDGET && widget.defaultValue
                    ? moment(
                        new Date(
                          widget?.defaultValue.month +
                            "/" +
                            widget?.defaultValue.day +
                            "/" +
                            widget?.defaultValue.year
                        )
                      ).toISOString()
                    : widget?.defaultValue
                    ? widget?.defaultValue
                    : contentModuleWidget?.defaultValue;

                widget.maximumValue =
                  widget.type === DATE_WIDGET && widget?.maximumValue
                    ? moment(
                        new Date(
                          widget?.maximumValue.month +
                            "/" +
                            widget?.maximumValue.day +
                            "/" +
                            widget?.maximumValue.year
                        )
                      ).toISOString()
                    : widget?.maximumValue
                    ? widget?.maximumValue
                    : contentModuleWidget?.maximumValue;

                widget.minimumValue =
                  widget?.type === DATE_WIDGET && widget?.minimumValue
                    ? moment(
                        new Date(
                          widget?.minimumValue.month +
                            "/" +
                            widget?.minimumValue.day +
                            "/" +
                            widget?.minimumValue.year
                        )
                      ).toISOString()
                    : widget?.minimumValue
                    ? widget?.minimumValue
                    : contentModuleWidget?.minimumValue;

                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.defaultValue
                ) {
                  let hour =
                    widget?.defaultValue.hour > 9
                      ? widget?.defaultValue.hour
                      : "0" + widget?.defaultValue.hour;
                  let minute =
                    widget?.defaultValue.minute > 0
                      ? widget?.defaultValue.minute
                      : "0" + widget?.defaultValue.minute;
                  widget.defaultValue = hour + ":" + minute;
                }
                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.maximumValue
                ) {
                  let hour =
                    widget?.maximumValue.hour > 9
                      ? widget?.maximumValue.hour
                      : "0" + widget?.maximumValue.hour;
                  let minute =
                    widget?.maximumValue.minute > 0
                      ? widget?.maximumValue.minute
                      : "0" + widget?.maximumValue.minute;
                  widget.maximumValue = hour + ":" + minute;
                }
                if (
                  widget?.type === TIME_INPUT_WIDGET &&
                  widget?.minimumValue
                ) {
                  let hour =
                    widget?.minimumValue.hour > 9
                      ? widget?.minimumValue.hour
                      : "0" + widget?.minimumValue.hour;
                  let minute =
                    widget?.minimumValue.minute > 0
                      ? widget?.minimumValue.minute
                      : "0" + widget?.minimumValue.minute;
                  widget.minimumValue = hour + ":" + minute;
                }

                widget.hide = contentModuleWidget?.hide || false;
                widget.bookmark = contentModuleWidget?.bookmark || false;
                widget.export = contentModuleWidget?.export || false;
                widget.required = contentModuleWidget?.required || false;
                widget.widgetList =
                  (contentModuleWidget?.widgetList?.length > 0 &&
                    contentModuleWidget?.widgetList) ||
                  (widget.widgetList.length > 0 && widget.widgetList) ||
                  [];

                //   widget.widgetCursorIndex = contentModuleWidget?.widgetCursorIndex !== undefined ? contentModuleWidget?.widgetCursorIndex  : undefined;
                widget.defaultOptions = contentModuleWidget?.defaultOptions || [
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                ];
              }

              if (contentModuleWidget?.type === BRANCH_CONTROL_WIDGET) {
                widget.branchControlType =
                  contentModuleWidget.branchControlType || "skip";
                widget.branchConditions = contentModuleWidget.branchConditions || [
                  { conditions: [{ field: "", expression: "<", value: "" }] },
                ];
              }
              let widgetDefaultStateProperties = getWidgetDefaultStateProperties(
                contentModuleWidget,
                widget
              );
              module.widgetList[index] = Object.assign(
                {},
                widgetDefaultStateProperties,
                widget
              );
            });
          }
        });

        let contentState = localData?.find(
          (localContent) => localContent.contentId === contentId
        );
        if (!contentState?.activeOutputId) {
          contentState.activeOutputId = 3;
          // chlRes.data.outputs?.length > 0
          //   ? chlRes.data.outputs[0].outputId
          //   : "";
        }

        let contentDefaultStateProperty = getContentDefaultStateProperties(
          contentState
        );
        contentDefaultStateProperty.activeOutputId = 3; // to select input tab

        const newContentData = Object.assign(
          {},
          chlRes.data,
          contentDefaultStateProperty
        );

        dispatch(getContentWidgetLabels(contentId));
        dispatch(setContentId(contentId, "api"));
        if (isUpdateContent)
          dispatch(updateContent(newContentData, "api", true));
        if (isNewContent) dispatch(addContent(newContentData));
        else if (!isUpdateContent) dispatch(setAllContents([newContentData]));
        dispatch(setActiveModuleId(newContentData.activeModuleId, "api"));

        // dispatch(getContentOutputDetail(contentId,contentState.activeOutputId));
      }
    })
    .catch((error) => {
      console.log("Get content details Api:", error);
    })
    .finally(() => {
      dispatch(setLoadingSpinner(false));
      dispatch(setContentModifiedFlag(false));
    });
};

/**
 * delete content by active content id
 */
export const deleteContentByContentId = (activeContentId, checksumId) => (
  dispatch
) => {
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .delete(`content/${activeContentId}/${checksumId}/delete`)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        dispatch(deleteContent());
        dispatch(setLoadingSpinner(false));
      }
    })
    .catch((error) => {
      alert("Content cann't be deleted by contributor");
      dispatch(setLoadingSpinner(false));
      console.log("Content delete Api:", error);
    });
};

/**
 * Get Modules by active content id
 */
export const getModulesByContentId = (activeContentId) => (dispatch) => {
  apiContentUrlWithToken
    .get(`/module/${activeContentId}/list`)
    .then((res) => {
      if (
        (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        res.data != null &&
        res.data.length > 0
      ) {
        const currentModules = res.data;
        let localData = JSON.parse(
          localStorage.getItem("local_contentBuilder")
        );
        let contentState = localData.find(
          (localContent) => localContent.contentId === activeContentId
        );
        currentModules.map((module) => {
          module.widgetList = module.widgetList || [];

          console.log("module.widgetList:", module.widgetList);

          let savedWidgets = contentState?.moduleList?.find(
            (savedModule) => savedModule.id == module.id
          )?.widgetList;
          //get widget list from local storage and assign, this is needs to be change when widget detail api completed
          if (savedWidgets?.length > 0) {
            //module.widgetList.splice();
            module.widgetList = savedWidgets;
          }
          dispatch(addModule(module));
        });
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Get ModuleList by active contentid Api:", error);
    });
};

/**
 * Update content,Modules,Widgets & Outside widgets also
 */
// export const saveContentByContentId = (
//   contents,
//   activeContentId,
//   newContentName
// ) => (dispatch) => {
//   dispatch(setLoadingSpinner(true));
//   let currentContent = contents.find(
//     (content) => content.contentId === activeContentId
//   );
//   let contentRequest = setUpdateContentRequest(currentContent, newContentName);

//   let isModulesExist = currentContent.moduleList.length > 0 ? true : false;
//   let isContentwidgesExist =
//     currentContent.widgetList.length > 0 ? true : false;
//   /**
//    * content update
//    */
//   apiContentUrlWithToken
//     .put(`content/${activeContentId}/update`, contentRequest)
//     .then((res) => {
//       if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
//         //if content has no modules
//         if (!isModulesExist && !isContentwidgesExist) {
//           dispatch(saveContent(activeContentId));
//           dispatch(setLoadingSpinner(false));
//           dispatch(setContentModifiedFlag(false));
//           return;
//         }

//         //if content has modules then need to update each modules and widgets
//         currentContent.moduleList.map((module) => {
//           let isWidgetsExist = module.widgetList.length > 0 ? true : false;
//           if (!isWidgetsExist) {
//             dispatch(saveContent(activeContentId));
//             dispatch(setLoadingSpinner(false));
//             dispatch(setContentModifiedFlag(false));
//             return;
//           }
//           /**
//            * module widgets update
//            */
//           module.widgetList.map((widget, index) => {
//             let widgetRequest = setUpdateWidgetRequest(
//               widget,
//               activeContentId,
//               module.id
//             );

//             console.log('widgetDataSave:', widgetRequest);
//             apiContentUrlWithToken
//               .put(`widget/update`, widgetRequest)
//               .then((moduleRes) => {
//                 if (
//                   moduleRes.status === SUCCESS ||
//                   moduleRes.status === CREATED_SUCCESS
//                 ) {
//                   if (module.widgetList.length - 1 === index) {
//                     dispatch(saveContent(activeContentId));
//                     dispatch(setLoadingSpinner(false));
//                     dispatch(setContentModifiedFlag(false));
//                   }
//                 }
//               })
//               .catch((error) => {
//                 dispatch(setLoadingSpinner(false));
//                 console.log('Module widgets update api:', error);
//               });
//           });

//           // apiContentUrlWithToken.put(`module/${module.id}/update`, moduleData).
//           //   then(moduleRes => {
//           //     if (moduleRes.status === SUCCESS || moduleRes.status === CREATED_SUCCESS) {
//           //       if (!isWidgetsExist) {
//           //         dispatch(saveContent(activeContentId));
//           //         dispatch(updateBreadCrumb({ ...breadcrumb, content: newContentName }));
//           //         setIsPopupVisible(false);
//           //       }
//           //       //widget update
//           //       //apiContentUrlWithToken.put('')
//           //     }
//           //   });
//         });
//         /**
//          * outside widgets update
//          */
//         currentContent.widgetList.map((widget, index) => {
//           let widgetRequest = setUpdateWidgetRequest(
//             widget,
//             activeContentId,
//             null
//           );

//           console.log('widgetDataSave:', widgetRequest);
//           apiContentUrlWithToken
//             .put(`widget/update`, widgetRequest)
//             .then((moduleRes) => {
//               if (
//                 moduleRes.status === SUCCESS ||
//                 moduleRes.status === CREATED_SUCCESS
//               ) {
//                 if (currentContent.widgetList.length - 1 === index) {
//                   dispatch(saveContent(activeContentId));
//                   dispatch(setLoadingSpinner(false));
//                   dispatch(setContentModifiedFlag(false));
//                 }
//               }
//             })
//             .catch((error) => {
//               dispatch(setLoadingSpinner(false));
//               console.log('content widgets update api:', error);
//             });
//         });
//       }
//     })
//     .catch((error) => {
//       dispatch(setLoadingSpinner(false));
//       console.log('Content save Api: ', error);
//     });
// };

export const saveContentByContentId = (
  contents,
  activeContentId,
  newContentName
) => (dispatch) => {
  // dispatch(setLoadingSpinner(true));

  let currentContent = contents.find(
    (content) => content.contentId === activeContentId
  );

  let contentRequest = setUpdateContentRequest(currentContent, newContentName);
  // let isModulesExist = currentContent.moduleList.length > 0 ? true : false;
  // let isContentwidgesExist = currentContent.widgetList.length > 0 ? true : false;
  /**
   * content update
   */
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .put(`content/${activeContentId}/update`, contentRequest)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        let checksumId = JSON.parse(localStorage.getItem("account")).userid;
        var authorData = { request: currentContent.authors };
        apiContentUrlWithToken
          .put(`author/${activeContentId}/${checksumId}/update`, authorData)
          .then((authorRes) => {
            if (
              (authorRes.status === SUCCESS ||
                authorRes.status === CREATED_SUCCESS) &&
              authorRes.data != null
            ) {
            }
          })
          .catch((error) => {
            console.log("Update Content Author Api:", error);
          });

        currentContent.moduleList.map((module) => {
          let widgetPosition = [];
          currentContent.modulesWidgetsPositions.map((x) => {
            if (module.id === x.moduleId) {
              widgetPosition.push(x);
            }
          });
          let moduleData = {
            contentId: activeContentId,
            title: module.title,
            description: module.description,
            draft: module.draft,
            locked: module.locked,
            minutesSaved: module.minutesSaved,
            moneySaved: module.moneySaved,
            readOnly: module.readOnly,
            refLinks: module.refLinks?.filter((x) => x != ""),
            searchTerm: module.searchTerm,
            tripsSaved: module.tripsSaved,
            useCaseDescription: module.useCaseDescription,
            snoMedTerms: module.snoMedTerms,
            widgetPosition,
            pageBreakPosition: module?.pageBreakPosition || [],
          };
          apiContentUrlWithToken
            .put(`module/${module.id}/update`, moduleData)
            .then((moduleRes) => {
              if (
                moduleRes.status === SUCCESS ||
                moduleRes.status === CREATED_SUCCESS
              ) {
                let isWidgetsExist =
                  module.widgetList.length > 0 ? true : false;
                if (!isWidgetsExist) {
                  dispatch(saveContent(activeContentId));
                  dispatch(setLoadingSpinner(false));
                  dispatch(setContentModifiedFlag(false));
                  return;
                }
                /**
                 * module widgets update
                 */

                module.widgetList.map((widget, index) => {
                  let widgetRequest = setUpdateWidgetRequest(
                    widget,
                    activeContentId,
                    module.id
                  );
                  console.log("widgetRequest:", widgetRequest);
                  apiContentUrlWithToken
                    .put(`widget/update`, widgetRequest)
                    .then((moduleRes) => {
                      if (
                        moduleRes.status === SUCCESS ||
                        moduleRes.status === CREATED_SUCCESS
                      ) {
                        /**
                         * branch widget update
                         */ if (widget.widgetList) {
                          widget.widgetList.map((insidewidget) => {
                            let insideWidgetRequest = setUpdateWidgetRequest(
                              insidewidget,
                              activeContentId,
                              module.id
                            );
                            console.log("widgetRequest:", insideWidgetRequest);
                            apiContentUrlWithToken
                              .put(`widget/update`, insideWidgetRequest)
                              .then((insidemoduleRes) => {
                                if (
                                  insidemoduleRes.status === SUCCESS ||
                                  insidemoduleRes.status === CREATED_SUCCESS
                                ) {
                                  if (insidewidget.widgetList) {
                                    insidewidget.widgetList.map(
                                      (secondInside) => {
                                        let secondInsideRequest = setUpdateWidgetRequest(
                                          secondInside,
                                          activeContentId,
                                          module.id
                                        );
                                        console.log(
                                          "widgetRequest:",
                                          secondInsideRequest
                                        );
                                        apiContentUrlWithToken
                                          .put(
                                            `widget/update`,
                                            secondInsideRequest
                                          )
                                          .then((secondInsidemoduleRes) => {
                                            dispatch(setLoadingSpinner(false));
                                            if (
                                              secondInsidemoduleRes.status ===
                                                SUCCESS ||
                                              SUCCESS ||
                                              secondInsidemoduleRes.status ===
                                                CREATED_SUCCESS
                                            ) {
                                            }
                                          })
                                          .catch((error) => {
                                            dispatch(setLoadingSpinner(false));
                                            console.log(
                                              "Module widgets update api:",
                                              error.response
                                            );
                                          });
                                      }
                                    );
                                  }
                                }
                              })
                              .catch((error) => {
                                dispatch(setLoadingSpinner(false));
                                console.log(
                                  "Module widgets update api:",
                                  error.response
                                );
                              });
                          });
                        }
                        if (module.widgetList.length - 1 === index) {
                          console.log("update", widget.widgetList);
                          dispatch(saveContent(activeContentId));
                          dispatch(setLoadingSpinner(false));
                          dispatch(setContentModifiedFlag(false));
                        }
                      }
                    })
                    .catch((error) => {
                      dispatch(setLoadingSpinner(false));
                      console.log("Module widgets update api:", error.response);
                    });
                });
              }
            })
            .catch((error) => {
              dispatch(setLoadingSpinner(false));
              console.log("Module  update api:", error);
            });
        });

        // outside widgets update

        currentContent.widgetList.map((widget, index) => {
          let widgetRequest = setUpdateWidgetRequest(
            widget,
            activeContentId,
            null
          );

          apiContentUrlWithToken
            .put(`widget/update`, widgetRequest)
            .then((moduleRes) => {
              if (
                moduleRes.status === SUCCESS ||
                moduleRes.status === CREATED_SUCCESS
              ) {
                /**
                 * branch widget update
                 */ if (widget.widgetList) {
                  widget.widgetList.map((insidewidget) => {
                    let insideWidgetRequest = setUpdateWidgetRequest(
                      insidewidget,
                      activeContentId,
                      null
                    );
                    console.log("joel", insidewidget);
                    console.log("joel", insideWidgetRequest);
                    console.log("widgetRequest:", insideWidgetRequest);
                    apiContentUrlWithToken
                      .put(`widget/update`, insideWidgetRequest)
                      .then((insidemoduleRes) => {
                        if (
                          insidemoduleRes.status === SUCCESS ||
                          insidemoduleRes.status === CREATED_SUCCESS
                        ) {
                          if (insidewidget.widgetList) {
                            insidewidget.widgetList.map((secondInside) => {
                              let secondInsideRequest = setUpdateWidgetRequest(
                                secondInside,
                                activeContentId,
                                null
                              );
                              console.log(
                                "widgetRequest:",
                                secondInsideRequest
                              );
                              apiContentUrlWithToken
                                .put(`widget/update`, secondInsideRequest)
                                .then((secondInsidemoduleRes) => {
                                  if (
                                    secondInsidemoduleRes.status === SUCCESS ||
                                    secondInsidemoduleRes.status ===
                                      CREATED_SUCCESS
                                  ) {
                                  }
                                })
                                .catch((error) => {
                                  dispatch(setLoadingSpinner(false));
                                  console.log(
                                    "Module widgets update api:",
                                    error.response
                                  );
                                });
                            });
                          }
                        }
                      })
                      .catch((error) => {
                        dispatch(setLoadingSpinner(false));
                        console.log(
                          "Module widgets update api:",
                          error.response
                        );
                      });
                  });
                }
                if (currentContent.widgetList.length - 1 === index) {
                  dispatch(saveContent(activeContentId));
                  dispatch(setLoadingSpinner(false));
                  dispatch(setContentModifiedFlag(false));
                }
              }
            })
            .catch((error) => {
              dispatch(setLoadingSpinner(false));
              console.log("content widgets update api:", error);
            });
        });
      }
      // Output Editor.. /// we are getting currentContent.activeOutputId as 3 thats the issue now
      // if (currentContent.activeOutputId) {
      //   let outputEditorData = currentContent.outputs?.filter(
      //     (x) => x.outputId === currentContent.activeOutputId
      //   );
      //   if (outputEditorData?.length > 0)
      //     dispatch(
      //       UpdateContentOutput(
      //         activeContentId,
      //         currentContent.activeOutputId,
      //         outputEditorData[0].outputData,
      //         outputEditorData[0].title
      //       )
      //     );
      // }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Content update api:", error);
    });
};

export const updateModulesAndWidgetPosition = (
  activeContentId,
  modulesAndOutsideWidgetsPositions,
  modulesWidgetsPositions
) => (dispatch) => {
  let contentRequest = {
    modulesWidgetsPositions: modulesWidgetsPositions || [],
    modulesAndOutsideWidgetsPositions: modulesAndOutsideWidgetsPositions || [],
  };
  apiContentUrlWithToken
    .put(`content/${activeContentId}/update`, contentRequest)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        dispatch(
          setModuleWidgetPosition(
            activeContentId,
            modulesAndOutsideWidgetsPositions,
            modulesWidgetsPositions
          )
        );
      }
    })
    .catch((error) => {
      console.log("Content updateModulesAndWidgetPosition api:", error);
    });
};
/**
 * Create new module by active content id
 */
export const createNewModuleByContentId = (activeContentId) => (dispatch) => {
  apiContentUrlWithToken
    .post(`module/${activeContentId}/create`, {})
    .then((res) => {
      if (
        (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        res.data != null &&
        res.data.id
      ) {
        const newModuleId = res.data.id;
        res.data.widgetList = res.data.widgetList || [];
        const newModule = Object.assign({}, res.data, {
          // description: [],
          // properties: {},
          widgetCurrentViewMode: STANDARD_VIEW,
        });

        dispatch(addModule(newModule));
        dispatch(setActiveModuleId(newModuleId));
        dispatch(setExpandedModuleIds(newModuleId));
        dispatch(setActiveCursorWidgetId(-1));
        // apiContentUrlWithToken.get(`/module/${newModuleId}/details`).
        //   then(chlRes => {
        //     if ((chlRes.status === SUCCESS || chlRes.status === CREATED_SUCCESS) && chlRes.data != null) {
        //       const newModule = Object.assign({}, chlRes.data, {
        //         description: [],
        //         properties: {},
        //         widgetCurrentViewMode: STANDARD_VIEW
        //       });

        //       dispatch(addModule(newModule));
        //       dispatch(setActiveModuleId(newModuleId));
        //       dispatch(setExpandedModuleIds(newModuleId));
        //       dispatch(setActiveCursorWidgetId(-1));
        //     }
        //   });
      }
      dispatch(toggleVerticalSpinner(false));
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      dispatch(toggleVerticalSpinner(false));
      console.log("Create New module Api: ", error);
    });
};

/**
 * create new widget within module/outside module also
 */
export const createNewWidgetByContentModule = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  currentContent,
  isWidgetCreateByOutputEditor = false
) => (dispatch) => {
  /**
   * this request for only outside modules widget creation
   */
  if (activeCursorWidgetId === undefined) widgetCreateData.moduleId = null;
  // if(widgetCreateData.widgetType===BranchControlWidget)
  apiContentUrlWithToken
    .post(`widget/create`, widgetCreateData)
    .then((res) => {
      if (
        (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        res.data != null &&
        res.data.id
      ) {
        res.data.title = widget.title || widget.widgetName;
        const widgetType = res.data.type;
        res.data.bookmark = isWidgetCreateByOutputEditor
          ? true
          : res.data.bookmark;
        if (
          widgetType === BINARY_INPUT_WIDGET ||
          widgetType === SINGLE_CHOICE_WIDGET ||
          widgetType === MULTI_CHOICE_WIDGET ||
          widgetType === DROPDOWNLIST_WIDGET
        ) {
          res.data.defaultOptions = setDefaultOptionsForWidget(widgetType);
        }
        if (widgetType === BRANCH_CONTROL_WIDGET) {
          res.data.branchConditions = [
            {
              conditions: [
                {
                  field: "",
                  expression: "<",
                  value: "",
                },
              ],
            },
          ];
        }

        let widgetDefaultStateProperties = getWidgetDefaultStateProperties(
          {},
          res.data
        );

        const newWidget = Object.assign(
          {},
          widgetDefaultStateProperties,
          res.data
        );

        if (activeCursorWidgetId === undefined) {
          currentContent.activeModuleId = 0;
          dispatch(addOutsideWidget(newWidget));
        } else {
          dispatch(addWidget(newWidget));
        }
        dispatch(storeRedis(currentContent, widget.widgetName, widgetType));
        if (isWidgetCreateByOutputEditor) {
          dispatch(widgetUpdate(newWidget));
        }
      } else {
        dispatch(toggleVerticalSpinner(false));
      }
    })
    .catch((error) => {
      dispatch(toggleVerticalSpinner(false));
      dispatch(setLoadingSpinner(false));
      console.log("Create New widget Api: ", error);
    });
};

export const widgetUpdate = (widget) => (dispatch) => {
  // module.widgetList.map((widget, index) => {
  // let widgetRequest = {
  //   widget,
  //   activeContentId,
  //   module.id
  // };
  apiContentUrlWithToken
    .put(`widget/update`, widget)
    .then((moduleRes) => {
      if (
        moduleRes.status === SUCCESS ||
        moduleRes.status === CREATED_SUCCESS
      ) {
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      dispatch(setRenameModuleFlag(false));
      console.log("Module widgets update api:", error);
    });
};

/**
 * delete module by selected module id
 */
export const deleteModuleById = (deleteModuleId) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .delete(`module/${deleteModuleId}/delete`)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        dispatch(deleteModule());

        dispatch(setLoadingSpinner(false));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Module delete : ", error);
    });
};

/**
 * updating content after deleting a module
 */
export const updateContentWithPositions = (
  modulesAndOutsideWidgetsPositions,
  activeContentId
) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  let data = {
    modulesAndOutsideWidgetsPositions: modulesAndOutsideWidgetsPositions,
  };
  apiContentUrlWithToken
    .put(`content/${activeContentId}/update`, data)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        dispatch(setLoadingSpinner(false));
        dispatch(setLoadingSpinner(false));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("module positions update : ", error);
    });
};

/**
 * delete widget by selected widget id(both within module/outside module)
 */
export const deleteWidgetById = (deleteWidgetId, isOutsideWidget = false) => (
  dispatch
) => {
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .delete(`widget/${deleteWidgetId}/delete`)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        // if (isOutsideWidget) dispatch(deleteOutsideWidget());
        dispatch(deleteWidget(deleteWidgetId));
        dispatch(setLoadingSpinner(false));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Widget delete : ", error);
    });
};

export const deleteReference = (
  activeReferenceId,
  selectedPropertiesModuleId,
  currentContent
) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  if (selectedPropertiesModuleId > 0) {
    if (
      currentContent.moduleList.filter(
        (x) => x.id == selectedPropertiesModuleId
      )?.length > 0
    ) {
      let reference = currentContent.moduleList.filter(
        (x) => x.id == selectedPropertiesModuleId
      )[0].refLinks;
      if (reference != null && reference.length > 0)
        currentContent.moduleList
          .filter((x) => x.id == selectedPropertiesModuleId)[0]
          .refLinks.splice(activeReferenceId, 1);
    }
  } else currentContent.refLinks.splice(activeReferenceId, 1);

  let data = {
    refLinks: currentContent.refLinks?.filter((x) => x != ""),
  };
  apiContentUrlWithToken
    .put(`content/${currentContent.contentId}/update`, data)
    .then((res) => {
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        dispatch(setLoadingSpinner(false));
        dispatch(setLoadingSpinner(false));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Reference delete : ", error);
    });
};

/**
 * this request will create new module and widgets while copy & paste & duplicate actions
 */

export const createNewModuleByCopyModules = (
  copiedData,
  currentContent,
  copiedContent
) => (dispatch) => {
  if (
    copiedData.moduleIds.length > 0 &&
    currentContent.activeCursorWidgetId === undefined
  ) {
    copiedData.moduleIds.map((item, index) => {
      apiContentUrlWithToken
        .post(`module/${currentContent.contentId}/create`, {})
        .then((res) => {
          if (
            (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
            res.data != null &&
            res.data.id
          ) {
            const newModuleId = res.data.id;
            res.data.widgetList = res.data.widgetList || [];
            const newModule = Object.assign({}, res.data, {
              description: [],
              properties: {},
              widgetCurrentViewMode: STANDARD_VIEW,
            });

            dispatch(addModule(newModule));
            let copiedModule = copiedContent?.moduleList.find(
              (module) => module.id === item
            );
            if (copiedModule?.widgetList.length > 0) {
              let copyWidgets = [];
              copiedModule.widgetList.map((widget, i) => {
                // let newWidget = getDefaultWidgetData(widget, currentContent);
                let newWidget = getNewWidgetByType(
                  currentContent,
                  widget.type,
                  true,
                  copyWidgets
                );

                let widgetCreateData = {
                  contentId: currentContent.contentId,
                  moduleId: newModuleId,
                  type: newWidget.widgetType,
                };
                widget.title = newWidget.widgetName;
                widget.widgetDefaultName = newWidget.widgetName;
                copyWidgets.push(widget);

                currentContent.activeModuleId = newModuleId;
                // dispatch(storeRedis(currentContent, newWidget.widgetName, newWidget.widgetType, content));
                dispatch(
                  createNewWidgetByCopyModule(
                    widgetCreateData,
                    newWidget,
                    i - 1,
                    currentContent,
                    widget
                  )
                );
              });
            }
            dispatch(setExpandedModuleIds(newModuleId));
            if (index === copiedData?.moduleIds?.length - 1) {
              dispatch(setActiveModuleId(newModuleId));
              dispatch(setActiveCursorWidgetId(-1));
            }
          }
        })
        .catch((error) => {
          dispatch(setLoadingSpinner(false));
          console.log("Create New module Api: ", error);
        });
    });
  } else {
    alert("Could not copied a module inside a module, please try again");
  }
};

/**
 * this function will create new widget while copy & paste & duplicate actions
 */
export const createNewWidgetByCopyWidget = (
  currentContent,
  copiedWidgetsData,
  copiedContent
) => (dispatch) => {
  copiedWidgetsData.widgetIds.map(async (copyId) => {
    let allWidgets = copiedContent.moduleList.reduce(
      (data, obj) => [...data, ...obj.widgetList],
      []
    );
    let innerWidget = allWidgets.findIndex((x) => x.id === copyId);
    let outerWidget = copiedContent.widgetList.findIndex(
      (x) => x.id === copyId
    );
    if (innerWidget > -1) {
      let widget = allWidgets[innerWidget];
      if (widget) {
        let newWidget = await getNewWidgetByType(currentContent, widget.type);
        let widgetCreateData = {
          contentId: currentContent.contentId,
          moduleId: widget.moduleId,
          type: newWidget.widgetType,
        };

        currentContent.activeModuleId = widget.moduleId;
        dispatch(
          createNewWidgetByCopyModule(
            widgetCreateData,
            newWidget,
            currentContent.activeCursorWidgetId,
            currentContent,
            widget
          )
        );
      } else {
        alert(
          "Could not find the widget, This is no longer located in original path, Please verify and try again "
        );
      }
    } else if (outerWidget > -1) {
      let widget = copiedContent.widgetList.find((x) => x.id === copyId);
      if (widget) {
        let newWidget = getNewWidgetByType(currentContent, widget.type);
        let widgetCreateData = {
          contentId: currentContent.contentId,
          moduleId: null,
          type: newWidget.widgetType,
        };
        currentContent.activeModuleId = 0;
        dispatch(
          createNewWidgetByCopyModule(
            widgetCreateData,
            newWidget,
            currentContent.activeCursorWidgetId,
            currentContent,
            widget
          )
        );
      } else {
        alert(
          "Could not find the widget, This is no longer located in original path, Please verify and try again "
        );
      }
    }
  });
};

/**
 * this function will create new outside widget while copy & paste & duplicate actions
 */
export const createNewWidgetByCopyOutsideWidget = (
  currentContent,
  copiedOutsideWidgetsData,
  copiedContent,
  content
) => (dispatch) => {
  copiedOutsideWidgetsData.map((copyId) => {
    let widget = copiedContent.widgetList.find((x) => x.id === copyId);
    if (widget) {
      let newWidget = getNewWidgetByType(currentContent, widget.type);
      let widgetCreateData = {
        contentId: currentContent.contentId,
        moduleId: null,
        type: newWidget.widgetType,
      };
      currentContent.activeModuleId = 0;
      dispatch(
        createNewWidgetByCopyModule(
          widgetCreateData,
          newWidget,
          currentContent.activeCursorWidgetId,
          currentContent
        )
      );
    } else {
      alert(
        "Could not find the widget, This is no longer located in original path, Please verify and try again "
      );
    }
  });
};

/**
 * create new widget within module/outside module also
 */
export const createNewWidgetByCopyModule = (
  widgetCreateData,
  widget,
  activeCursorWidgetId,
  currentContent,
  widgetData
) => (dispatch) => {
  /**
   * this request for only outside modules widget creation
   */
  if (activeCursorWidgetId === undefined) widgetCreateData.moduleId = null;

  apiContentUrlWithToken
    .post(`widget/create`, widgetCreateData)
    .then((res) => {
      if (
        (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        res.data != null &&
        res.data.id
      ) {
        if (
          !res.errors ||
          res.status === SUCCESS ||
          (res.data != null && res.data.id)
        ) {
          widget.id = res.data.id;
          widget.type = res.data.type;
          widget.title = widget.title || widget.widgetName;
          if (widgetData !== undefined) {
            widget.widgetType = widgetData.widgetType;
            if (
              widget.widgetType === BINARY_INPUT_WIDGET ||
              widget.widgetType === SINGLE_CHOICE_WIDGET ||
              widget.widgetType === MULTI_CHOICE_WIDGET ||
              widget.widgetType === DROPDOWNLIST_WIDGET
            ) {
              widget.defaultOptions =
                widgetData?.defaultOptions.length > 0
                  ? widgetData?.defaultOptions
                  : setDefaultOptionsForWidget(widgetData.widgetType);
            }
            if (widget.widgetType === BRANCH_CONTROL_WIDGET) {
              widget.branchControlType =
                widgetData?.branchControlType || "skip";
              widget.branchConditions =
                widgetData?.branchConditions.length > 0
                  ? widgetData?.branchConditions
                  : [
                      {
                        conditions: [
                          {
                            field: "",
                            expression: "<",
                            value: "",
                          },
                        ],
                      },
                    ];
            }
            widget.bookmark = widgetData?.bookmark || false;
            widget.export = widgetData?.export || false;
            widget.hide = widgetData?.hide || false;
            widget.required = widgetData?.required || false;
          }
          if (widgetCreateData.moduleId === null)
            currentContent.activeModuleId = 0;
          if (activeCursorWidgetId === undefined) {
            dispatch(addOutsideWidget(widget));
          } else {
            dispatch(addWidget(widget));
          }
          dispatch(storeRedis(currentContent, widget.widgetName, widget.type));
          return res;
        }
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("Create New widget Api: ", error);
    });
};

/**
 * this function will create sequence widget name while copy & paste & duplicate actions
 */
export function getDefaultWidgetData(payload, currentContent) {
  let allWidgets = currentContent.moduleList.reduce(
    (data, obj) => [...data, ...obj.widgetList],
    []
  );
  allWidgets = [...allWidgets, ...currentContent.widgetList];
  allWidgets.sort((a, b) => a.id - b.id);
  let widgetName = payload.title.slice(0, 3);
  if (allWidgets.length > 0) {
    let widgetsBasedOnType = allWidgets.filter((widget) =>
      widget?.widgetDefaultName?.includes(widgetName)
    );
    if (widgetsBasedOnType.length > 0) {
      let lastWidgetName =
        widgetsBasedOnType[widgetsBasedOnType.length - 1].widgetDefaultName;
      let lastLength = parseInt(lastWidgetName.slice(-3)) + 1;
      let numberOfZeros =
        parseInt(lastLength) <= 9
          ? "00"
          : parseInt(lastLength) <= 99
          ? "0"
          : "000";
      let newWidgetName = widgetName + numberOfZeros + parseInt(lastLength);
      payload = {
        ...payload,
        id: parseInt(allWidgets[allWidgets.length - 1].id) + 1,
        title: newWidgetName,
        widgetDefaultName: newWidgetName,
      };
      return payload;
    } else {
      payload = {
        ...payload,
        id: parseInt(allWidgets[allWidgets.length - 1].id) + 1,
        title: `${widgetName}001`,
        widgetDefaultName: `${widgetName}001`,
      };
      return payload;
    }
  } else {
    payload = {
      ...payload,
      id: 1,
      title: `${widgetName}001`,
      widgetDefaultName: `${widgetName}001`,
    };
    return payload;
  }
}

export const deleteAttachment = (attachmentUrl) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  apiContentUrlWithToken
    .delete(attachmentUrl)
    .then((res) => {
      dispatch(setLoadingSpinner(false));
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        if (attachmentUrl.includes("?"))
          dispatch(setDeleteReferenceAttachment(attachmentUrl.split("?")[0]));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("delete reference attachment api error:", error);
    });
};

export const importPicture = (contentId, moduleId, file, type) => (
  dispatch
) => {
  dispatch(setLoadingSpinner(true));
  var formData = new FormData();
  formData.append("image", file);
  let uploadUrl =
    moduleId == null || moduleId == "" || moduleId == undefined
      ? `content/${type}/${contentId}`
      : `module/${moduleId}`;
  apiContentUrlWithToken
    .post(`${uploadUrl}/image/upload`, formData)
    .then((res) => {
      dispatch(setLoadingSpinner(false));
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        if (type == "process")
          dispatch(setImportPicture(res.data?.processProperties?.imageName));
        else dispatch(setImportPicture(res.data?.imageName));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("import picture Api error:", error);
    });
};

export const importReference = (
  contentId,
  moduleId,
  refAttachmentList,
  type
) => (dispatch) => {
  dispatch(setLoadingSpinner(true));
  var formData = new FormData();
  formData.append("file", refAttachmentList);
  let uploadUrl =
    moduleId == null || moduleId == "" || moduleId == undefined || moduleId == 0
      ? `content/${type}/${contentId}`
      : `module/${moduleId}`;
  apiContentUrlWithToken
    .post(`${uploadUrl}/reference/upload`, formData)
    .then((res) => {
      dispatch(setLoadingSpinner(false));
      if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
        if (type == "process")
          dispatch(
            setReferenceAttachment(
              res.data?.processProperties?.refAttachmentList
            )
          );
        else dispatch(setReferenceAttachment(res.data?.refAttachmentList));
      }
    })
    .catch((error) => {
      dispatch(setLoadingSpinner(false));
      console.log("import reference Api error:", error);
    });
};

/**
 * get default content state properties from local storage
 */
export function getContentDefaultStateProperties(contentState) {
  let contentStateProperties = {
    activeModuleId: contentState?.activeModuleId || 0,
    activeWidgetId: contentState?.activeWidgetId || 0,
    activeCursorModuleId:
      contentState?.activeCursorModuleId !== undefined
        ? contentState?.activeCursorModuleId
        : undefined,
    activeCursorWidgetId:
      contentState?.activeCursorWidgetId !== undefined
        ? contentState?.activeCursorWidgetId
        : undefined,
    activeModuleIds: contentState?.activeModuleIds || [],
    advancedViewWidgetIds: contentState?.advancedViewWidgetIds || [],
    selectedModuleId: contentState?.selectedModuleId,
    selectedModuleIds: contentState?.selectedModuleIds || [],
    compressedViewWidgetIds: contentState?.compressedViewWidgetIds || [],
    standardViewWidgetIds: contentState?.standardViewWidgetIds || [],
    selectedWidgetIds: contentState?.selectedWidgetIds || [],
    cursorSelectedStatus: contentState?.cursorSelectedStatus,
    currentViewMode: contentState?.currentViewMode,
    activeReferenceId: contentState?.activeReferenceId,
    activeAttachmentId: contentState?.activeAttachmentId,
    selectedPropertiesModuleId: contentState?.selectedPropertiesModuleId || 0,
    selectedOuterWidgetIds: contentState?.selectedOuterWidgetIds || [],
    processModule: contentState?.processModule || "",
    isProcessAssigned: contentState?.isProcessAssigned || false,
    isProcessModuleManuallySelected:
      contentState?.isProcessModuleManuallySelected || "",
    outputEditor: contentState?.outputEditor || "",
    globalLogoSelectedWidgets: contentState?.globalLogoSelectedWidgets || [],
    widgetDuplicateStatus: contentState?.widgetDuplicateStatus || [],
    contentWidgetLabels: contentState?.contentWidgetLabels || [],
    activeOutputId: contentState?.activeOutputId || 3, // to select input tab
    //pageBreakPosition: contentState?.pageBreakPosition || [],
    selectedOuterPagebreakIndex:
      contentState?.selectedOuterPagebreakIndex || undefined,
    selectedInnerPagebreakDetails: {
      moduleIndex: undefined,
      widgetIndex: undefined,
    },
    branchWidgetCursorIndex:
      contentState?.branchWidgetCursorIndex !== undefined
        ? contentState?.branchWidgetCursorIndex
        : undefined,
    nestedBranchWidgetCursorIndex:
      contentState?.nestedBranchWidgetCursorIndex !== undefined
        ? contentState?.nestedBranchWidgetCursorIndex
        : undefined,
    activeFormBarTab: contentState?.activeFormBarTab
      ? contentState?.activeFormBarTab
      : INPUT_TAB,
    isOutputContentModified: false,
    selectedWidgetsData:
      contentState?.selectedWidgetsData !== undefined
        ? contentState?.selectedWidgetsData
        : { moduleIds: [], widgetIds: [] },
    outputCursorPosition: contentState?.outputCursorPosition
      ? contentState?.outputCursorPosition
      : {
          start: 0,
          end: 0,
        },
    outputs: contentState?.outputs?.length > 0 ? contentState?.outputs : [],
    secondaryTabs:
      contentState?.secondaryTabs?.length > 0 &&
      !contentState.secondaryTabs.some((x) => !x)
        ? contentState.secondaryTabs
        : staticSecondaryTabs,
  };
  return contentStateProperties;
}

/**
 * get widget default state properties from local storage
 */
export function getWidgetDefaultStateProperties(contentModuleWidget, widget) {
  let widgetStateProperties = {
    widgetDefaultName: contentModuleWidget?.widgetDefaultName || widget?.title,
    widgetType: contentModuleWidget?.widgetType || widget?.type,
    // widgetFormText: contentModuleWidget?.widgetFormText || '',
    // defaultText: contentModuleWidget?.defaultText || '',
    maximumchar: contentModuleWidget?.maximumchar || "",
    widgetViewMode: contentModuleWidget?.widgetViewMode || STANDARD_VIEW,
    widgetCurrentViewMode:
      contentModuleWidget?.widgetCurrentViewMode || STANDARD_VIEW,
    isWidgetFormTextEntered:
      contentModuleWidget?.isWidgetFormTextEntered || false,
    isWidgetDefaultNameShowed:
      contentModuleWidget?.isWidgetDefaultNameShowed || false,
    isWidgetFieldLabelExist: false,
    widgetColor: "",
    // ** defaultOptions props added for toggleWidget tasks
    defaultOptions: [
      { value: "", option: "", defaultStatus: false },
      { value: "", option: "", defaultStatus: false },
      { value: "", option: "", defaultStatus: false },
    ],
    maximumValue: widget?.maximumValue || "",
  };
  return widgetStateProperties;
}

/**
 * set default value into defaultOptions property when create binary,single,multiple and dropdownlist widget
 */
export function setDefaultOptionsForWidget(widgetType) {
  switch (widgetType) {
    case BINARY_INPUT_WIDGET:
    case SINGLE_CHOICE_WIDGET:
    case MULTI_CHOICE_WIDGET:
    case DROPDOWNLIST_WIDGET:
      return [
        // { value: '', option: '', defaultStatus: true },
        //  set default value false..
        { value: "", option: "", defaultStatus: false },
        { value: "", option: "", defaultStatus: false },
        { value: "", option: "", defaultStatus: false },
      ];
  }
}

/**
 * get widget request object by current widget
 */
export function setUpdateWidgetRequest(widget, contentId, moduleId) {
  // let list = widget.widgetList?.map((x) => {
  //   let y = x[0];
  //   return [{ id: y.id, type: y.type }];
  // });
  let list = widget.widgetList;
  let widgetRequest = {
    body: "",
    bookmark: widget?.bookmark || false,
    comment: widget?.comment,
    contentId: contentId,
    export: widget?.export || false,
    help: "",
    hide: widget?.hide || false,
    id: widget?.id,
    moduleId: moduleId ? moduleId : null,
    //  parentId: string
    required: widget?.required || false,
    title: widget?.title,
    type: widget?.type,
    answerRequired: widget?.answerRequired,
    answerRequiredValue: widget?.answerRequiredValue,
    defaultText: widget?.defaultText,
    // date_defaultValue: widget?.date_defaultValue,
    // date_maxValue: widget?.date_maxValue,
    // date_minValue: widget?.date_minValue,
    value: widget?.value,
    // time_minValue: widget?.time_minValue,
    // time_maxValue: widget?.time_maxValue,
    // time_defaultValue: widget?.time_defaultValue,
    formatValidationStatus: widget?.formatValidationStatus,
    formatValidationValue: widget?.formatValidationValue,
    hintText: widget?.hintText,
    hintTextValue: widget?.hintTextValue,
    indent: widget?.indent,
    note: widget?.note,
    showDefaultAnswer: widget?.showDefaultAnswer,
    showDefaultAnswerValue: widget?.showDefaultAnswerValue,
    size: widget?.size,
    useDefaultAnswerValue: widget?.useDefaultAnswerValue,
    useDefaultValue: widget?.useDefaultValue,
    layout: widget?.layout,
    decimalValue: widget?.decimalValue,
    defaultValue:
      widget?.type === "date"
        ? getFromatDate(widget?.defaultValue)
        : widget?.defaultValue,
    maximumValue:
      widget?.type === "date"
        ? getFromatDate(widget?.maximumValue)
        : widget?.maximumValue,
    minimumValue:
      widget?.type === "date"
        ? getFromatDate(widget?.minimumValue)
        : widget?.minimumValue,
    defaultOptions: widget?.defaultOptions,
    branchConditions: widget?.branchConditions,
    branchControlType: widget?.branchControlType,
    widgetList: list || [],
    outputCount: widget.outputCount,
    outputList: widget?.outputList || [],
  };

  return widgetRequest;
}

function getFromatDate(widgetDate) {
  if (!widgetDate) return null;
  let formatDate = moment(new Date(widgetDate)).format("DD/MM/YYYY");
  return formatDate;
}

/**
 * get content request object by current content
 */
export function setUpdateContentRequest(currentContent, newContentName) {
  let moduleList = [];
  let widgetList = [];
  currentContent.moduleList.map((x) => {
    let id = x.id;
    moduleList.push(id);
  });
  currentContent.widgetList.map((y) => {
    let id1 = y.id;
    widgetList.push(id1);
  });

  let processProperties = currentContent.processProperties;
  processProperties.refLinks = processProperties.refLinks?.filter(
    (x) => x != ""
  );
  processProperties.refAttachmentList = processProperties.refAttachmentList?.filter(
    (x) => x != ""
  );

  let contentRequest = {
    title: newContentName || currentContent.title,
    description: currentContent.description,
    draft: currentContent.draft,
    locked: currentContent.locked,
    minutesSaved: currentContent.minutesSaved,
    moneySaved: currentContent.moneySaved,
    readOnly: currentContent.readOnly,
    refLinks: currentContent.refLinks?.filter((x) => x != ""),
    searchTerm: currentContent.searchTerm,
    snoMedTerms: currentContent.snoMedTerms,
    tripsSaved: currentContent.tripsSaved,
    useCaseDescription: currentContent.useCaseDescription,
    processProperties: processProperties,
    modulesWidgetsPositions: currentContent.modulesWidgetsPositions || [],
    modulesAndOutsideWidgetsPositions:
      currentContent.modulesAndOutsideWidgetsPositions || [],
    pageBreakPosition: currentContent?.pageBreakPosition || [],
    moduleList: moduleList,
    widgetList: widgetList,
  };
  return contentRequest;
}

export const getContentWidgetLabels = (contentId) => {
  return async (dispatch) => {
    await apiUrlWithToken
      .get(`/content/get/${await checkSumId}/${contentId}`)
      .then((res) => {
        if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
          const data = res.data.data || [];
          dispatch(setContentWidgetLabels(data));
        }
      })
      .catch((error) => {
        console.log("content widget label api:", error);
      });
  };
};

export const updateContentWidgetLabels = (widgetLabels, contentId) => {
  return async (dispatch) => {
    let request = {
      key: contentId,
      data: widgetLabels,
      userid: await checkSumId,
    };
    await apiUrlWithToken
      .post(`/content/save`, request)
      .then((res) => {
        if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
          dispatch(setContentWidgetLabels(widgetLabels));
          dispatch(toggleVerticalSpinner(false));
        }
      })
      .catch((error) => {
        console.log("content widget label api:", error);
        dispatch(toggleVerticalSpinner(false));
      });
  };
};

export const deleteContentWidgetLabelsByContentId = (contentId) => {
  return async (dispatch) => {
    await apiUrlWithToken
      .delete(`/content/delete/${await checkSumId}/${contentId}`)
      .then((res) => {
        if (res.status === SUCCESS || res.status === CREATED_SUCCESS) {
          dispatch(setContentWidgetLabels([]));
        }
      })
      .catch((error) => {
        console.log("content widget label api:", error);
      });
  };
};

export const storeRedis = (currentContent, newWidgetName, widgetType) => (
  dispatch
) => {
  let existingWidgetLabels = currentContent?.contentWidgetLabels;
  let contentId = currentContent?.activeContentId || currentContent?.contentId;
  let moduleId = currentContent.activeModuleId;
  let isContentExist = -1;
  let widgetInputTypes = [
    "text",
    "binary",
    "time",
    "single_choice",
    "multiple_choice",
    "date",
    "drop_down",
    "number",
  ];
  let widgetOtherTypes = ["warning", "calculation", "narrative"];

  let findWidgetType = widgetInputTypes.includes(widgetType)
    ? "input"
    : widgetType;

  if (existingWidgetLabels?.length > 0) {
    isContentExist = existingWidgetLabels.findIndex(
      (x) =>
        x.contentId === contentId &&
        x.moduleId === moduleId &&
        x.type === findWidgetType
    );
  }

  if (isContentExist > -1) {
    existingWidgetLabels.map((widget, index) => {
      if (
        contentId === widget.contentId &&
        widget.moduleId === moduleId &&
        widget.type === findWidgetType
      ) {
        widget.widgetDefaultName = newWidgetName;
      }
    });
  } else {
    let widget = {
      contentId: contentId,
      moduleId: moduleId,
      widgetDefaultName: newWidgetName,
      type: findWidgetType,
    };
    existingWidgetLabels.push(widget);
  }
  dispatch(updateContentWidgetLabels(existingWidgetLabels, contentId));
  dispatch(setContentWidgetLabels(existingWidgetLabels));
};

export const deleteStoredWidgetLables = (
  contentId,
  moduleId,
  contentWidgetLabels,
  isContentDelete = false
) => (dispatch) => {
  if (contentWidgetLabels?.length > 0) {
    let widgetLabels = [];
    if (!isContentDelete)
      widgetLabels = contentWidgetLabels.filter(function (widget) {
        return widget.moduleId !== moduleId;
      });
    else
      widgetLabels = contentWidgetLabels.filter(function (widget) {
        return widget.contentId !== contentId;
      });
    if (!isContentDelete)
      dispatch(updateContentWidgetLabels(widgetLabels, contentId));
    dispatch(setContentWidgetLabels(widgetLabels));
  }
};

// Content Output Editor Api Integration... //
/**
 * Get all content output list
 */
export const getAllContentOutput = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(false));
    await apiContentUrlWithToken
      .get(`output/${contentId}/list`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.length > 0
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Get All Content Output List Api:", error);
      });
  };
};

/**
 * Get content output data
 */
export const getContentOutputData = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(false));
    await apiContentUrlWithToken
      .get(`output/${contentId}/data`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.length > 0
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Get Content Output Data Api:", error);
      });
  };
};

/**
 * Get content output detail
 */
export const getContentOutputDetail = (contentId, outputId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(false));
    await apiContentUrlWithToken
      //.get(`output/${contentId}/detail`)
      .get(`output/${contentId}/detail?outputId=${outputId}`)
      .then((res) => {
        // if (
        //   (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
        //   res.data != null && res.data.length > 0) {
        //
        // };
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
          dispatch(setContentOutput(res.data));
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Get Content Output Detail Api:", error);
      });
  };
};

/**
 * Create new content output
 */
export const createNewContentOutput = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .post(`output/${contentId}/create`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
          dispatch(setActiveOutputId(res.data.id));
          // get output details.
          apiContentUrlWithToken
            .get(`output/${contentId}/detail?outputId=${res.data.id}`)
            .then((fetchRes) => {
              if (
                (fetchRes.status === SUCCESS ||
                  fetchRes.status === CREATED_SUCCESS) &&
                fetchRes.data != null
              ) {
                dispatch(setContentOutput(fetchRes.data));
              }
              dispatch(setLoadingSpinner(false));
            })
            .catch((error) => {
              dispatch(setLoadingSpinner(false));
              console.log("Get Content Output Detail Api:", error);
            });
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Create New Content Output Api:", error);
      });
  };
};

/**
 * Update the content output details
 */
export const UpdateContentOutput = (
  contentId,
  outputId,
  outputEditorData,
  outputTitle
) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    var formData = new FormData();
    formData.append("outputData", outputEditorData);
    formData.append("title", outputTitle);
    await apiContentUrlWithToken
      .put(`output/${contentId}/update?outputId=${outputId}`, formData)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
        }
      })
      .catch((error) => {
        console.log("Update Content Output Api:", error);
      })
      .finally(() => dispatch(setLoadingSpinner(false)));
  };
};

/**
 * Delete the content output details
 */
export const DeleteContentOutput = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .put(`output/${contentId}/delete`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Delete Content Output Api:", error);
      });
  };
};

/**
 * Get content author data
 */
export const getContenAuthorData = (contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(false));
    await apiContentUrlWithToken
      .get(`author/${contentId}`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null &&
          res.data.length > 0
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Get Content Author Data Api:", error);
      });
  };
};

/**
 * Create new content author
 */
export const createNewContentAuthor = (contentId, data) => {
  return (dispatch) => {
    dispatch(setLoadingSpinner(true));
    apiContentUrlWithToken
      .post(`author/${contentId}/create`, data)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Create New Content Output Api:", error);
      });
  };
};

/**
 * Update the content author details
 */
export const UpdateContentAuthor = (contentId, checkSumId, data) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .put(`author/${contentId}/${checkSumId}/update`, data)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
        }
      })
      .catch((error) => {
        console.log("Update Content Author Api:", error);
      })
      .finally(() => dispatch(setLoadingSpinner(false)));
  };
};

/**
 * Delete the content author details
 */
export const DeleteContentAuthor = (authorId, checksumId, contentId) => {
  return async (dispatch) => {
    dispatch(setLoadingSpinner(true));
    await apiContentUrlWithToken
      .delete(`author/${authorId}/${checksumId}/${contentId}/delete`)
      .then((res) => {
        if (
          (res.status === SUCCESS || res.status === CREATED_SUCCESS) &&
          res.data != null
        ) {
        }
      })
      .catch((error) => {
        dispatch(setLoadingSpinner(false));
        console.log("Delete Content Author Api:", error);
      });
  };
};

/**
 * switch consultation view mode in content pane
 */
export const viewConsultation = () => {
  return (dispatch) => {
    dispatch({
      type: "VIEW_CONSULTATION_MODE",
      payload: null,
    });
  };
};

/**
 * switch label edit view mode in content pane
 */
export const viewLabel = () => {
  return (dispatch) => {
    dispatch({
      type: "VIEW_LABEL_MODE",
      payload: null,
    });
  };
};

/**
 * switch details view mode in content pane
 */
export const viewDetails = () => {
  return (dispatch) => {
    dispatch({
      type: "VIEW_DETAIL_MODE",
      payload: null,
    });
  };
};

/**
 * switch edit view mode in content pane
 */
export const viewEdit = () => {
  return (dispatch) => {
    dispatch({
      type: "VIEW_EDIT_MODE",
      payload: null,
    });
  };
};

/**
 * set modulelist for consultation view mode in content pane
 */
export const setModuleListForConsultatiionView = (data) => {
  return (dispatch) => {
    dispatch({
      type: "SET_MODULELIST_FOR_CONSULTATION",
      payload: data,
    });
  };
};

export const labelviewSetselectedWidgetId = (data) => {
  return (dispatch) => {
    dispatch({
      type: "LABELVIEW_SETSELECTED_WIDGETID",
      payload: data,
    });
  };
};

export const updateAuthor = (authors) => {
  return (dispatch) => {
    dispatch(setContentModifiedFlag(true));
    dispatch({ type: UPDATE_AUTHOR, payload: authors });
  };
};

let tmp_contents = [
  {
    contentId: 1,
    contentName: "",
    moduleList: [],
    properties: {},
    processModule: "",
    activeModuleId: 0,
    activeWidgetId: 0,
    activeCursorModuleId: undefined,
    activeCursorWidgetId: undefined,
    activeModuleIds: [],
    advancedViewWidgetIds: [],
    selectedModuleId: null,
    selectedModuleIds: [],
    compressedViewWidgetIds: [],
    standardViewWidgetIds: [],
    selectedWidgetIds: [],
    selectedOuterWidgetIds: [],
    cursorSelectedStatus: false,
    currentViewMode: "STANDARD_VIEW",
    activeReferenceId: null,
    activeAttachmentId: null,
    latestWidgetfieldLabel: "",
    widgets: [],
    modulesAndOutsideWidgetsPositions: [],
    pageBreakPosition: [],
  },
];

// this is not need for deynamic data.
// let contentData = localStorage.getItem('local_contentBuilder');
// let isContentModified = false;
// if (contentData) {
//   tmp_contents = JSON.parse(contentData);

const initialState = {
  //contents: tmp_contents, // this is not need for deynamic data.
  contents: [],
  copiedData: {
    contentId: 0,
    moduleIds: [],
    widgetsdata: { moduleId: 0, widgetIds: [] },
    outerWidgetIds: [],
  },
  activeCommonFormBarTab: INPUT_TAB,
  renameModuleFlag: false,
  // contentWidgetLabels: [],
  activeContentId: 0,
  activeContentIds: [],
  activeModuleId: 0,
  activeWidgetId: 0,
  activeCursorModuleId: undefined,
  activeCursorWidgetId: undefined,
  activeModuleIds: [],
  breadcrumb: {
    accountType: localStorage.getItem("groupId")
      ? localStorage.getItem("groupName")
      : "Private",
    content: "",
    module: "",
    inputOutput: "-Input",
  },
  // isContentModified: isContentModified,
  isContentModified: false,
  advancedViewWidgetIds: [],
  isCursorFreezedOnKeyChange: false,
  selectedModuleId: null,
  selectedModuleIds: [],
  compressedViewWidgetIds: [],
  standardViewWidgetIds: [],
  selectedWidgetIds: [],
  cursorSelectedStatus: false,
  currentViewMode: "STANDARD_VIEW",
  // properties: {}
  activeReferenceId: null,
  activeAttachmentId: null,
  selectedPropertiesModuleId: 0,
  isLoading: false,
  moduleWidgetsOrder: [],
  isEmitRefAttachmentFlag: false,
  isVerticalSpinner: false,
  recentAddedWidget: {},
  selectedPropertiesProcess: false,
  viewConsultation: false,
  viewLabel: false,
  viewDetails: true,
  viewEdit: false,
  isContentTabChange: false,
  moduleListForConsultation: [],
  lableviewSelectedWidgetId: "",
};

let savedContentData = localStorage.getItem("tmp_contentBuilder");
if (!savedContentData) {
  localStorage.setItem("tmp_contentBuilder", JSON.stringify(initialState));
}

const setState = (state) => {
  localStorage.setItem("tmp_contentBuilder", JSON.stringify(state));
  localStorage.setItem("local_contentBuilder", JSON.stringify(state.contents));
};

export default function (state = initialState, action) {
  let contents = [];
  let hasIndex = -1;
  let localData = JSON.parse(localStorage.getItem("tmp_contentBuilder"));
  const { payload } = action;
  switch (action.type) {
    case "LABELVIEW_SETSELECTED_WIDGETID":
      return {
        ...state,
        lableviewSelectedWidgetId: action.payload,
      };
    case "SET_MODULELIST_FOR_CONSULTATION":
      return {
        ...state,
        moduleListForConsultation: action.payload,
      };
    case "VIEW_CONSULTATION_MODE":
      return {
        ...state,
        viewLabel: false,
        viewConsultation: true,
        viewDetails: false,
        viewEdit: false,
      };
    case "VIEW_LABEL_MODE":
      return {
        ...state,
        viewLabel: true,
        viewConsultation: false,
        viewDetails: false,
        viewEdit: false,
      };
    case "VIEW_DETAIL_MODE":
      return {
        ...state,
        viewLabel: false,
        viewConsultation: false,
        viewDetails: true,
        viewEdit: false,
      };
    case "VIEW_EDIT_MODE":
      return {
        ...state,
        viewLabel: false,
        viewConsultation: false,
        viewDetails: false,
        viewEdit: true,
      };
    case ADD_CONTENT:
      return {
        ...state,
        contents: [...state.contents, action.payload],
      };
    case SET_OUTPUTS:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === payload.contentId) {
          content.outputs = payload.data;
        }
      });
      setState({ ...state, contents });
      return { ...state, contents };
    case DELETE_OUTPUT:
      const { contentId, outputId } = payload;
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === contentId) {
          content.outputs = content.outputs.filter(
            (output) => output.outputId !== outputId
          );
          content.secondaryTabs = content.secondaryTabs.filter(
            (tab) => tab.id !== outputId
          );
          // to make input tab selected as default
          content.activeOutputId = 3;
        }
      });
      setState({ ...state, contents });
      return { ...state, contents };
    case SET_SECONDARY_TABS:
      contents = state.contents.slice();
      contents.map((x) => {
        if (x.contentId === payload.contentId) {
          x.secondaryTabs = payload.data;
        }
      });
      setState({ ...state, contents });
      return { ...state, contents };
    case UPDATE_CONTENT_NAME:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          //content.contentName = action.payload;
          content.title = action.payload;
        }
      });
      return {
        ...state,
        contents,
      };
    case CREATE_OUTPUT_EDITOR:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.secondaryTabs.push(payload.secondaryTabs);
          content.outputs.push(payload.output);
        }
      });
      setState({ ...state, contents });
      return { ...state, contents };
    case UPDATE_OUTPUT:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === payload.contentId) {
          content.outputs.map((output) => {
            if (output.outputId === payload.outputId) {
              output.title = payload.title;
            }
          });
          content.secondaryTabs.map((tab) => {
            if (tab.id === payload.outputId) {
              tab.label = payload.title;
            }
          });
        }
      });
      setState({ ...state, contents });
      return { ...state, contents };
    case SAVE_OUTPUT_EDITOR_VALUES:
      let currentContent = [];
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === payload.contentId) {
          content.outputs.map((output) => {
            if (output.outputId === payload.outputId) {
              output.outputData = payload.outputContent;
            }
          });
        }
        content.isOutputContentModified = false;
        return content;
      });
      setState({ ...state, contents });
      return {
        ...state,
        contents,
      };
    case GET_OUTPUTS_DATA:
      return state;
    case SET_OUTPUT_CONTENT_MODIFIED_FLAG:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.isOutputContentModified = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case DELETE_CONTENT:
      contents = state.contents.slice();
      let index = contents.findIndex(
        (x) => x.contentId === state.activeContentId
      );
      contents.splice(index, 1);
      let previousContentId = index - 1 < 0 ? 0 : contents[index - 1].contentId;
      let result = {
        ...state,
        contents,
        copiedData: {
          contentId: 0,
          moduleIds: [],
          widgetsdata: { moduleId: 0, widgetIds: [] },
          outerWidgetIds: [],
        },
        activeContentId: previousContentId,
        activeModuleId: 0,
        compressedViewWidgetIds: [],
        activeModuleIds: [],
        selectedWidgetIds: [],
        advancedViewWidgetIds: [],
        standardViewWidgetIds: [],
        selectedModuleId: 0,
        selectedModuleIds: [],
        breadcrumb: {
          accountType: "Private",
          content: "",
          module: "",
          inputOutput: "-Input",
        },
      };
      localStorage.setItem("tmp_contentBuilder", JSON.stringify(result));
      return result;
    case ACTIVE_OUTPUT_ID:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId)
          currentContent.activeOutputId = payload;
        return currentContent;
      });

      return {
        ...state,
        contents,
      };
    case SET_CONTENT_OUTPUT:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (
            currentContent.outputs.filter(
              (x) => x.outputId == currentContent.activeOutputId
            )?.length == 0
          )
            currentContent.outputs.push(action.payload);
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SAVE_CONTENT: {
      let tempData = { ...state, isContentModified: false };
      let currContent = tempData.contents.filter(
        (content) => content.contentId === action.payload
      );
      let oldContents = localData ? localData.contents : [];
      oldContents = [...oldContents, ...state.contents];
      const uniqBy = (arr, predicate) => {
        const cb =
          typeof predicate === "function" ? predicate : (o) => o[predicate];
        return [
          ...arr
            .reduce((map, item) => {
              const key = item === null || item === undefined ? item : cb(item);
              map.has(key) || map.set(key, item);
              return map;
            }, new Map())
            .values(),
        ];
      };
      oldContents = oldContents.filter(
        (cont) => cont.contentId !== currContent.contentId
      );
      oldContents = uniqBy([...currContent, ...oldContents], "contentId");
      oldContents = oldContents.sort((a, b) => a.contentId - b.contentId);
      let forStorageData = { ...tempData, contents: [...oldContents] };
      forStorageData.isContentModified = false;
      localStorage.setItem(
        "tmp_contentBuilder",
        JSON.stringify(forStorageData)
      );
      return { ...state, isContentModified: false, isLoading: false };
    }
    case ABORT_CONTENT: {
      let storedData = { ...localData };
      return {
        ...storedData,
        activeContentId: action.payload,
        isContentModified: false,
      };
    }
    case SET_MODIFIED_FLAG:
      return { ...state, isContentModified: action.payload };
    case ACTIVE_CONTENT_ID:
      return {
        ...state,
        activeContentId: action.payload,
      };

    case ACTIVE_MODULE_ID:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.activeModuleId = action.payload;
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
      };
    case ACTIVE_REFERENCE_ID:
      return {
        ...state,
        activeReferenceId: action.payload,
      };
    case ACTIVE_ATTACHMENT_ID:
      return {
        ...state,
        activeAttachmentId: action.payload,
      };
    case SET_SELECTED_PROPERTIES_MODULE_ID:
      return {
        ...state,
        selectedPropertiesModuleId: action.payload,
      };
    case EXPANDED_MODULE_IDS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let isSelectedModule = currentContent.selectedModuleIds.findIndex(
            (x) => x === action.payload
          );
          let hasValue = currentContent.activeModuleIds.findIndex(
            (x) => x === action.payload
          );
          if (hasValue > -1) {
            currentContent.activeCursorWidgetId = undefined;
          } else {
            currentContent.activeCursorWidgetId = -1;
          }
          if (
            currentContent.selectedModuleIds.length > 1 &&
            isSelectedModule > -1
          ) {
            currentContent.selectedModuleIds.map((moduleId, i) => {
              let hasValue = currentContent.activeModuleIds.findIndex(
                (x) => x === moduleId
              );
              if (hasValue > -1) {
                currentContent.activeModuleIds.splice(hasValue, 1);
              } else {
                currentContent.activeModuleIds = [
                  ...currentContent.activeModuleIds,
                  moduleId,
                ];
              }
            });
          } else {
            let hasValue = currentContent.activeModuleIds.findIndex(
              (x) => x === action.payload
            );
            if (hasValue > -1) {
              currentContent.activeModuleIds.splice(hasValue, 1);
            } else {
              currentContent.activeModuleIds = [
                ...currentContent.activeModuleIds,
                action.payload,
              ];
            }
          }
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case ADD_MODULE:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.activeCursorModuleId =
            currentContent.activeCursorModuleId === undefined
              ? -1
              : currentContent.activeCursorModuleId;
          if (currentContent?.moduleList?.length > 0) {
            function insertAt(array, index, ...elements) {
              array.splice(index, 0, ...elements);
            }
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;

            insertAt(
              currentContent.moduleList,
              currentContent.activeCursorModuleId,
              action.payload
            );

            let index = currentContent.moduleList.findIndex(
              (x) => x.id === action.payload.id
            );

            let moduleData = {
              index,
              type: "module",
              id: action.payload.id,
            };

            let hasValue = currentContent.modulesAndOutsideWidgetsPositions?.filter(
              (x) => x.index === index
            );
            if (hasValue?.length > 0) {
              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "module" && combine.index >= index) {
                    combine.index = combine.index + 1;
                  }
                  return combine;
                }
              );
            }

            insertAt(
              currentContent.modulesAndOutsideWidgetsPositions,
              currentContent.activeCursorModuleId,
              moduleData
            );
          } else {
            currentContent.moduleList.push(action.payload);
            let index = currentContent.moduleList.findIndex(
              (x) => x.id === action.payload.id
            );
            let moduleData = {
              index,
              type: "module",
              id: action.payload.id,
            };
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;
            if (currentContent.modulesAndOutsideWidgetsPositions?.length > 0) {
              function insertAt(array, index, ...elements) {
                array.splice(index, 0, ...elements);
              }

              insertAt(
                currentContent.modulesAndOutsideWidgetsPositions,
                currentContent.activeCursorModuleId,
                moduleData
              );
            } else {
              currentContent.modulesAndOutsideWidgetsPositions.push(moduleData);
            }
          }
          currentContent.selectedOuterWidgetIds = [];
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case DELETE_MODULE:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (currentContent.selectedModuleIds.length > 0) {
            currentContent.selectedModuleIds.map((moduleId, i) => {
              let index = currentContent.moduleList.findIndex(
                (x) => x.id === moduleId
              );

              let pageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) => x.index === index && x.type === "module"
              );
              let otherPageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) => x.index === index - 1 && x.type === "module"
              );
              let pageBreakIndex = currentContent.pageBreakPosition.findIndex(
                (x) => x === pageBreak
              );
              let otherPageBreakIndex = currentContent.pageBreakPosition.findIndex(
                (x) => x === otherPageBreak
              );
              if (pageBreakIndex > -1 && otherPageBreakIndex > -1) {
                currentContent.pageBreakPosition.splice(pageBreakIndex, 1);
              }
              currentContent.pageBreakPosition.map((position, i) => {
                if (position >= pageBreak) {
                  currentContent.pageBreakPosition[i] = position - 1;
                }
              });

              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "module" && combine.index === index) {
                    currentContent.modulesAndOutsideWidgetsPositions.splice(
                      i,
                      1
                    );
                  }
                }
              );
              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "module" && combine.index > index) {
                    combine.index = combine.index - 1;
                  }
                  return combine;
                }
              );

              // if (currentContent.modulesAndOutsideWidgetsPositions.length === 0) {
              //   currentContent.pageBreakPosition = [];
              // }

              if (index > -1) {
                currentContent.moduleList.splice(index, 1);
                currentContent.activeModuleIds.splice(index, 1);
                currentContent.selectedModuleIds = [];
              }

              if (
                currentContent.modulesAndOutsideWidgetsPositions.length >=
                currentContent.activeCursorModuleId
              ) {
                if (currentContent.activeCursorModuleId !== 0) {
                  currentContent.activeCursorModuleId =
                    currentContent.activeCursorModuleId - 1;
                } else {
                  currentContent.activeCursorModuleId =
                    currentContent.modulesAndOutsideWidgetsPositions.length > 0
                      ? currentContent.activeCursorModuleId
                      : undefined;
                }
              } else {
                currentContent.activeCursorModuleId =
                  currentContent.modulesAndOutsideWidgetsPositions.length >= 0
                    ? currentContent.activeCursorModuleId
                    : undefined;
              }

              if (index - 1 < 0) {
                currentContent.activeModuleId =
                  currentContent.moduleList.length > 0
                    ? currentContent.moduleList[0].id
                    : 0;
              } else {
                currentContent.activeModuleId =
                  currentContent.moduleList[index - 1].id;
              }

              //remove widget positions when delete module
              if (currentContent?.modulesWidgetsPositions?.length > 0) {
                let temp_modulesWidgetsPositions = JSON.parse(
                  JSON.stringify(currentContent.modulesWidgetsPositions)
                );
                currentContent.modulesWidgetsPositions.map((labelModule) => {
                  let moduleHasIndex = temp_modulesWidgetsPositions.findIndex(
                    (x) => x.moduleId === moduleId
                  );
                  if (moduleHasIndex > -1)
                    temp_modulesWidgetsPositions.splice(moduleHasIndex, 1);
                });
                currentContent.modulesWidgetsPositions = temp_modulesWidgetsPositions;
              }
            });
          }
          currentContent.activeCursorWidgetId = undefined;
          currentContent.selectedWidgetsData.widgetIds = [];
          //currentContent.selectedWidgetIds = [];
          //currentContent.selectedOuterWidgetIds = [];
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
        copiedData: {
          contentId: 0,
          moduleIds: [],
          widgetsdata: { moduleId: 0, widgetIds: [] },
          outerWidgetIds: [],
        },
      };
    // case DELETE_REFERENCE:
    //   contents = state.contents.slice();
    //   contents.map((content) => {
    //     const currentContent = { ...content };
    //     if (currentContent.contentId === state.activeContentId) {
    //       if (state.selectedPropertiesModuleId > 0) {
    //         if (
    //           currentContent.moduleList.filter(
    //             (x) => x.id == state.selectedPropertiesModuleId
    //           )?.length > 0
    //         ) {
    //           let reference = currentContent.moduleList.filter(
    //             (x) => x.id == state.selectedPropertiesModuleId
    //           )[0].properties?.references;
    //           if (reference != null && reference.length > 0)
    //             currentContent.moduleList
    //               .filter((x) => x.id == state.selectedPropertiesModuleId)[0]
    //               .properties.references.splice(state.activeReferenceId, 1);
    //         }
    //       } else
    //         currentContent.properties.references.splice(
    //           state.activeReferenceId,
    //           1
    //         );
    //     }
    //     return currentContent;
    //   });
    //   return {
    //     ...state,
    //     contents,
    //     activeReferenceId: null,
    //   };
    case DELETE_ATTACHMENT:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          if (state.selectedPropertiesModuleId > 0) {
            content.moduleList.map((module) => {
              if (
                module.id == state.selectedPropertiesModuleId &&
                module.refAttachmentList?.length > 0
              ) {
                let index = module.refAttachmentList.findIndex(
                  (x) => x == action.payload
                );
                module.refAttachmentList.splice(index, 1);
              }
            });
          } else if (state.selectedPropertiesProcess) {
            let index = content.processProperties?.refAttachmentList?.findIndex(
              (x) => x == action.payload
            );
            content.processProperties.refAttachmentList.splice(index, 1);
          } else {
            let index = content.refAttachmentList.findIndex(
              (x) => x == action.payload
            );
            content.refAttachmentList.splice(index, 1);
          }
        }
      });
      return {
        ...state,
        contents,
        activeAttachmentUrl: null,
      };
    case UPDATE_BREADCRUMB:
      return { ...state, breadcrumb: action.payload };
    case ADD_WIDGET:
      contents = state.contents.slice();

      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              let widgetCursorPosition = currentContent.activeCursorWidgetId;
              let widgetCursorObj = {
                id: action.payload.id,
                widgetName: action.payload.title,
                moduleId: currentModule.id,
                index: widgetCursorPosition + 1,
              };

              if (currentModule.widgetList?.length > 0) {
                function insertAt(array, index, ...elements) {
                  array.splice(index, 0, ...elements);
                  currentContent.activeCursorWidgetId =
                    currentContent.activeCursorWidgetId + 1;
                }
                insertAt(
                  currentModule.widgetList,
                  currentContent.activeCursorWidgetId + 1,
                  action.payload
                );

                let currentWidgetIndx = currentModule.widgetList.findIndex(
                  (x) => x.id === action.payload.id
                );

                let isWidgetExist = currentContent.modulesWidgetsPositions.filter(
                  (x) =>
                    x.moduleId === activeModuleId &&
                    x.index === currentWidgetIndx
                );

                if (isWidgetExist !== undefined && isWidgetExist.length > 0) {
                  currentContent.modulesWidgetsPositions.map((combine, i) => {
                    if (
                      combine.moduleId === activeModuleId &&
                      combine.index >= currentWidgetIndx
                    ) {
                      combine.index = combine.index + 1;
                    }
                    return combine;
                  });
                }

                function insertAtWithCursor(array, index, ...elements) {
                  array.splice(index, 0, ...elements);
                }
                insertAtWithCursor(
                  currentContent.modulesWidgetsPositions,
                  widgetCursorPosition + 1,
                  widgetCursorObj
                );
              } else {
                currentModule.widgetList.push(action.payload);
                currentContent.activeCursorWidgetId =
                  currentContent.activeCursorWidgetId + 1;
                //widget cursor position
                currentContent.modulesWidgetsPositions.push(widgetCursorObj);
              }
            }
            return currentModule;
          });
          if (
            currentContent.selectedModuleIds.length > 0 &&
            currentContent.selectedModuleIds.indexOf(
              currentContent.activeModuleId
            ) > -1
          ) {
            currentContent.selectedWidgetsData.widgetIds = [
              ...currentContent.selectedWidgetsData.widgetIds,
              action.payload.id,
            ];
          }
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        let widgetDetails = action.payload;
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              /**
               * inside module
               */
              currentModule.widgetList.map((x, i) => {
                if (widgetDetails.branchId && widgetDetails.nestedId) {
                  if (widgetDetails.branchId === x.id) {
                    x.widgetList.map((y, j) => {
                      if (widgetDetails.nestedId === y.id) {
                        currentModule.widgetList[i].widgetList[
                          j
                        ].widgetList.push(widgetDetails);
                      }
                    });
                  }
                } else {
                  if (widgetDetails.branchId === x.id) {
                    currentModule.widgetList[i].widgetList.push(widgetDetails);
                  }
                  if (currentContent.branchWidgetCursorIndex !== undefined) {
                    currentContent.branchWidgetCursorIndex =
                      currentContent.branchWidgetCursorIndex + 1;
                  }
                }
              });
            }
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_OUTSIDE_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((widget, i) => {
            let widgetDetails = action.payload;
            if (widgetDetails.branchId && widgetDetails.nestedId) {
              if (widgetDetails.branchId === widget.id) {
                widget.widgetList.map((x, j) => {
                  if (widgetDetails.nestedId === x.id) {
                    currentContent.widgetList[i].widgetList[j].widgetList.push(
                      widgetDetails
                    );
                  }
                });
              }
            } else {
              if (widget.id === widgetDetails.branchId) {
                currentContent.widgetList[i].widgetList.push(widgetDetails);
                if (currentContent.branchWidgetCursorIndex !== undefined) {
                  currentContent.branchWidgetCursorIndex =
                    currentContent.branchWidgetCursorIndex + 1;
                }
              }
            }
          });
          currentContent.selectedWidgetsData.widgetIds = [];
          currentContent.selectedModuleIds = [];
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    // case DUPLICATE_WIDGET:
    //   contents = state.contents.slice();
    //   let duplicateWidget = action.payload;
    //   contents.map((currentContent) => {
    //     if (currentContent.contentId === state.activeContentId) {
    //       currentContent.moduleList.map((currentModule) => {
    //         let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
    //           (x, index) =>
    //             index === currentContent.activeCursorModuleId &&
    //             x.type === "module"
    //         )?.id;
    //         let allWidgets = currentContent.moduleList.reduce(
    //           (data, obj) => [...data, ...obj.widgetList],
    //           []
    //         );

    //         function insertAt(array, index, ...elements) {
    //           array.splice(index, 0, ...elements);
    //         }
    //         /**
    //          * inside and outside widgets
    //          */
    //         currentContent.moduleList.map((x) => {
    //           if (x.widgetList) {
    //             x.widgetList.map((y) => {
    //               if (y.widgetList) {
    //                 y.widgetList.map((z) => {
    //                   allWidgets.push(z);
    //                   if (z.widgetList) {
    //                     z.widgetList.map((z1) => {
    //                       allWidgets.push(z1);
    //                     });
    //                   }
    //                 });
    //               }
    //             });
    //           }
    //         });
    //         let allOuterWidgets = currentContent.widgetList;
    //         currentContent.widgetList.map((x) => {
    //           if (x.widgetList) {
    //             x.widgetList.map((y) => {
    //               allOuterWidgets.push(y);
    //               if (y.widgetList) {
    //                 y.widgetList.map((z) => {
    //                   allOuterWidgets.push(z);
    //                 });
    //               }
    //             });
    //           }
    //         });

    //         let innerWidget = allWidgets.findIndex(
    //           (x) => x.id === duplicateWidget.selectedId
    //         );
    //         let outerWidget = allOuterWidgets.findIndex(
    //           (x) => x.id === duplicateWidget.selectedId
    //         );
    //         let widget;
    //         if (innerWidget > -1) {
    //           widget = allWidgets[innerWidget];
    //           currentContent.moduleList.map((mod, modId) => {
    //             mod.widgetList.map((wid, widId) => {
    //               if (wid.id === duplicateWidget.id) {
    //                 insertAt(mod.widgetList, widId + 1, action.payload);
    //               }
    //               return wid;
    //             });
    //             if (mod.widgetList?.length > 0) {

    //               let currentWidgetIndx = mod.widgetList.findIndex(
    //                 (x) => x.id === action.payload.id
    //               );

    //               let isWidgetExist = currentContent.modulesWidgetsPositions.filter(
    //                 (x) =>
    //                   x.moduleId === activeModuleId &&
    //                   x.index === currentWidgetIndx
    //               );

    //               if (isWidgetExist !== undefined && isWidgetExist.length > 0) {
    //                 currentContent.modulesWidgetsPositions.map((combine, i) => {
    //                   if (
    //                     combine.moduleId === activeModuleId &&
    //                     combine.index >= currentWidgetIndx
    //                   ) {
    //                     combine.index = combine.index + 1;
    //                   }
    //                   return combine;
    //                 });
    //               }

    //               function insertAtWithCursor(array, index, ...elements) {
    //                 array.splice(index, 0, ...elements);
    //               }
    //               insertAtWithCursor(
    //                 currentContent.modulesWidgetsPositions,
    //                 widgetCursorPosition + 1,
    //                 widgetCursorObj
    //               );
    //             } else {
    //               currentModule.widgetList.push(action.payload);
    //               currentContent.activeCursorWidgetId =
    //                 currentContent.activeCursorWidgetId + 1;
    //               //widget cursor position
    //               currentContent.modulesWidgetsPositions.push(widgetCursorObj);
    //             }

    //             return mod;
    //           });
    //         }
    //         if (currentModule.id === activeModuleId) {
    //           let widgetCursorPosition = currentContent.activeCursorWidgetId;
    //           let widgetCursorObj = {
    //             id: action.payload.id,
    //             widgetName: action.payload.title,
    //             moduleId: currentModule.id,
    //             index: widgetCursorPosition + 1,
    //           };

    //           if (currentModule.widgetList?.length > 0) {
    //             currentModule.widgetList.map((x, i) => {
    //               if (x.id === action.payload.selectedId) {
    //                 insertAt(currentModule.widgetList, i + 1, action.payload);
    //               }
    //             });

    //             let currentWidgetIndx = currentModule.widgetList.findIndex(
    //               (x) => x.id === action.payload.id
    //             );

    //             let isWidgetExist = currentContent.modulesWidgetsPositions.filter(
    //               (x) =>
    //                 x.moduleId === activeModuleId &&
    //                 x.index === currentWidgetIndx
    //             );

    //             if (isWidgetExist !== undefined && isWidgetExist.length > 0) {
    //               currentContent.modulesWidgetsPositions.map((combine, i) => {
    //                 if (
    //                   combine.moduleId === activeModuleId &&
    //                   combine.index >= currentWidgetIndx
    //                 ) {
    //                   combine.index = combine.index + 1;
    //                 }
    //                 return combine;
    //               });
    //             }

    //             function insertAtWithCursor(array, index, ...elements) {
    //               array.splice(index, 0, ...elements);
    //             }
    //             insertAtWithCursor(
    //               currentContent.modulesWidgetsPositions,
    //               widgetCursorPosition + 1,
    //               widgetCursorObj
    //             );
    //           } else {
    //             currentModule.widgetList.push(action.payload);
    //             currentContent.activeCursorWidgetId =
    //               currentContent.activeCursorWidgetId + 1;
    //             //widget cursor position
    //             currentContent.modulesWidgetsPositions.push(widgetCursorObj);
    //           }
    //         }
    //         return currentModule;
    //       });
    //       if (
    //         currentContent.selectedModuleIds.length > 0 &&
    //         currentContent.selectedModuleIds.indexOf(
    //           currentContent.activeModuleId
    //         ) > -1
    //       ) {
    //         currentContent.selectedWidgetsData.widgetIds = [
    //           ...currentContent.selectedWidgetsData.widgetIds,
    //           action.payload.id,
    //         ];
    //       }
    //     }
    //     return currentContent;
    //   });

    //   return {
    //     ...state,
    //     contents,
    //     recentAddedWidget: action.payload,
    //   };
    case DUPLICATE_OUTSIDE_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.activeCursorModuleId =
            currentContent.activeCursorModuleId === undefined
              ? -1
              : currentContent.activeCursorModuleId;
          if (currentContent.widgetList?.length > 0) {
            let insertIndex = "";
            currentContent.widgetList.map((x, i) => {
              if (x.id === action.payload.selectedId) {
                insertIndex = i;
              }
            });
            function insertAt(array, index, ...elements) {
              array.splice(index, 0, ...elements);
            }
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;
            insertAt(
              currentContent.widgetList,
              insertIndex + 1,
              action.payload
            );
            let index = currentContent.widgetList.findIndex(
              (x) => x.id === action.payload.id
            );
            let hasValue = currentContent.modulesAndOutsideWidgetsPositions.filter(
              (x) => x.index === index
            );
            if (hasValue.length > 0) {
              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "widget" && combine.index >= index) {
                    combine.index = combine.index + 1;
                  }
                  return combine;
                }
              );
            }

            let widgetData = {
              index,
              type: "widget",
              id: action.payload.id,
            };

            insertAt(
              currentContent.modulesAndOutsideWidgetsPositions,
              currentContent.activeCursorModuleId,
              widgetData
            );
          } else {
            currentContent.widgetList.push(action.payload);
            let index = currentContent.widgetList.findIndex(
              (x) => x.id === action.payload.id
            );
            let widgetData = {
              index,
              type: "widget",
              id: action.payload.id,
            };
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;
            if (currentContent.modulesAndOutsideWidgetsPositions.length > 0) {
              function insertAt(array, index, ...elements) {
                array.splice(index, 0, ...elements);
              }
              insertAt(
                currentContent.modulesAndOutsideWidgetsPositions,
                currentContent.activeCursorModuleId,
                widgetData
              );
            } else {
              currentContent.modulesAndOutsideWidgetsPositions.push(widgetData);
            }
          }
          //  currentContent.selectedOuterWidgetIds = [];
          //currentContent.selectedWidgetIds = [];
          currentContent.selectedWidgetsData.widgetIds = [];
          currentContent.selectedModuleIds = [];
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ACTIVE_WIDGET_ID:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let modules = currentContent.moduleList;
          if (
            action.clickType === "ctrlClick" &&
            currentContent.selectedWidgetsData.widgetIds.length > 0
          ) {
            let hasIndex = currentContent.selectedWidgetsData.widgetIds.findIndex(
              (x) => x === action.payload
            );
            let hasModuleIndex = currentContent.selectedWidgetsData.moduleIds.findIndex(
              (x) => x === action.moduleId
            );
            if (hasIndex > -1) {
              currentContent.selectedWidgetsData.widgetIds.splice(hasIndex, 1);
            } else {
              currentContent.selectedWidgetsData.widgetIds = [
                ...currentContent.selectedWidgetsData.widgetIds,
                action.payload,
              ];
            }
            if (hasModuleIndex === -1) {
              currentContent.selectedWidgetsData.moduleIds = [
                ...currentContent.selectedWidgetsData.moduleIds,
                action.moduleId,
              ];
            }

            currentContent.selectedWidgetsData.moduleIds.map((moduleId, i) => {
              let index = modules.findIndex((x) => x.id === moduleId);
              //             let module = modules.filter((x)=>{
              //    if(x.widgetList.findIndex( x=> x.id === action.payload) > -1){
              //      return x
              //   }
              //  })
              let hasWidget = modules[index]?.widgetList?.filter((x) => {
                if (
                  currentContent.selectedWidgetsData.widgetIds.indexOf(x.id) >
                  -1
                ) {
                  return x;
                }
              });
              if (hasWidget?.length === 0) {
                let moduleIndex = currentContent.selectedWidgetsData.moduleIds.findIndex(
                  (x) => x === moduleId
                );
                currentContent.selectedWidgetsData.moduleIds.splice(
                  moduleIndex,
                  1
                );
              }
            });
          } else if (
            action.clickType === "shiftClick" &&
            currentContent.selectedWidgetsData.widgetIds.length > 0
          ) {
            let latestModuleIndex;
            let latestWidgetIndex;
            let firstModuleIndex;
            let firstWidgetIndex;
            let lastModuleIndex;
            let lastWidgetIndex;
            let haslatestWidgetIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
              (x) => x.id === action.payload && x.type === "widget"
            );
            if (haslatestWidgetIndex > -1) {
              latestModuleIndex = haslatestWidgetIndex;
            } else {
              let index = modules.findIndex((x) => x.id === action.moduleId);
              latestModuleIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) => x.id === action.moduleId && x.type === "module"
              );
              latestWidgetIndex = modules[index].widgetList.findIndex(
                (x) => x.id === action.payload
              );
            }

            let hasfirstWidgetIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
              (x) =>
                x.id === currentContent.selectedWidgetsData.widgetIds[0] &&
                x.type === "widget"
            );
            if (hasfirstWidgetIndex > -1) {
              firstModuleIndex = hasfirstWidgetIndex;
            } else {
              let index = modules.findIndex(
                (x) => x.id === currentContent.selectedWidgetsData.moduleIds[0]
              );
              firstModuleIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) =>
                  x.id === currentContent.selectedWidgetsData.moduleIds[0] &&
                  x.type === "module"
              );
              firstWidgetIndex = modules[index].widgetList.findIndex(
                (x) => x.id === currentContent.selectedWidgetsData.widgetIds[0]
              );
            }

            let haslastWidgetIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
              (x) =>
                x.id ===
                  currentContent.selectedWidgetsData.widgetIds[
                    currentContent.selectedWidgetsData.widgetIds.length - 1
                  ] && x.type === "widget"
            );
            if (haslastWidgetIndex > -1) {
              lastModuleIndex = haslastWidgetIndex;
            } else {
              let index = modules.findIndex(
                (x) =>
                  x.id ===
                  currentContent.selectedWidgetsData.moduleIds[
                    currentContent.selectedWidgetsData.moduleIds.length - 1
                  ]
              );
              lastModuleIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) =>
                  x.id ===
                    currentContent.selectedWidgetsData.moduleIds[
                      currentContent.selectedWidgetsData.moduleIds.length - 1
                    ] && x.type === "module"
              );
              lastWidgetIndex = modules[index].widgetList.findIndex(
                (x) =>
                  x.id ===
                  currentContent.selectedWidgetsData.widgetIds[
                    currentContent.selectedWidgetsData.widgetIds.length - 1
                  ]
              );
            }

            if (lastModuleIndex > latestModuleIndex) {
              lastModuleIndex = firstModuleIndex;
              lastWidgetIndex = firstWidgetIndex;
            }
            currentContent.selectedWidgetsData.moduleIds = [];
            currentContent.selectedWidgetsData.widgetIds = [];
            if (lastModuleIndex <= latestModuleIndex) {
              for (let i = latestModuleIndex; i >= lastModuleIndex; i--) {
                let data = currentContent.modulesAndOutsideWidgetsPositions[i];
                if (data.type === "module") {
                  currentContent.selectedWidgetsData.moduleIds.push(data.id);
                  let module = modules[data.index];
                  if (i === latestModuleIndex) {
                    for (let i = 0; i <= latestWidgetIndex; i++) {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        module.widgetList[i]?.id
                      );
                    }
                  } else if (i === lastModuleIndex) {
                    for (
                      let i = lastWidgetIndex;
                      i <= module.widgetList.length;
                      i++
                    ) {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        module.widgetList[i]?.id
                      );
                    }
                  } else {
                    module.widgetList.map((widget, i) => {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        widget.id
                      );
                    });
                  }
                }
                if (data.type === "widget") {
                  currentContent.selectedWidgetsData.widgetIds.push(data.id);
                }
              }
            } else if (lastModuleIndex >= latestModuleIndex) {
              for (let i = lastModuleIndex; i >= latestModuleIndex; i--) {
                let data = currentContent.modulesAndOutsideWidgetsPositions[i];
                if (data.type === "module") {
                  currentContent.selectedWidgetsData.moduleIds.push(data.id);
                  let module = modules[data.index];
                  if (i === latestModuleIndex) {
                    for (
                      let i = latestWidgetIndex;
                      i <= module.widgetList.length;
                      i++
                    ) {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        module.widgetList[i]?.id
                      );
                    }
                  } else if (i === lastModuleIndex) {
                    for (let i = 0; i <= lastWidgetIndex; i++) {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        module.widgetList[i]?.id
                      );
                    }
                  } else {
                    module.widgetList.map((widget, i) => {
                      currentContent.selectedWidgetsData.widgetIds.push(
                        widget.id
                      );
                    });
                  }
                }
                if (data.type === "widget") {
                  currentContent.selectedWidgetsData.widgetIds.push(data.id);
                }
              }
            }
          } else {
            if (
              currentContent.selectedWidgetsData.widgetIds.length === 1 &&
              currentContent.selectedWidgetsData.widgetIds[
                currentContent.selectedWidgetsData.widgetIds.length - 1
              ] === action.payload
            ) {
              currentContent.selectedWidgetsData.widgetIds = [];
              currentContent.selectedWidgetsData.moduleIds = [];
            } else {
              currentContent.selectedWidgetsData.widgetIds = [action.payload];
              currentContent.selectedWidgetsData.moduleIds =
                action.moduleId === undefined ? [] : [action.moduleId];
            }
          }
          currentContent.selectedModuleIds = [];
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case DELETE_WIDGET:
      contents = state.contents.slice();
      let content = currentContentObjects(contents, state.activeContentId);
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let modules = currentContent.moduleList;
          let widgets = currentContent.widgetList;
          /**
           * to delete widget inside branchwidget
           */

          if (currentContent.activeModuleId != undefined) {
            let mod =
              currentContent.modulesAndOutsideWidgetsPositions[
                currentContent.activeCursorModuleId
              ];
            let selmodule = currentContent.moduleList.filter((module, idx) => {
              return module.id === mod.id;
            });
            if (selmodule.length === 1) {
              currentContent.selectedWidgetsData.widgetIds.map((wid, idx) => {
                selmodule[0].widgetList[
                  currentContent.activeCursorWidgetId
                ].widgetList.map((x, i) => {
                  if (x.id === wid) {
                    /**
                     * branch widget delete
                     */
                    console.log(
                      "delete",
                      selmodule[0].widgetList[
                        currentContent.activeCursorWidgetId
                      ].widgetList[i]
                    );
                    if (
                      selmodule[0].widgetList[
                        currentContent.activeCursorWidgetId
                      ].widgetList.length === 1
                    ) {
                      if (
                        currentContent.moduleList[mod.index].widgetList[
                          currentContent.activeCursorWidgetId
                        ].branchControlType === "switch"
                      ) {
                        selmodule[0].widgetList[
                          currentContent.activeCursorWidgetId
                        ].widgetList[i].type = "blank";
                        selmodule[0].widgetList[
                          currentContent.activeCursorWidgetId
                        ].widgetList[i].widgetType = "blank";
                        selmodule.widgetList[
                          currentContent.activeCursorWidgetId
                        ].branchConditions = [
                          {
                            conditions: [
                              {
                                field: "",
                                expression: "<",
                                value: "",
                              },
                            ],
                          },
                        ];
                      } else {
                        currentContent.moduleList[mod.index].widgetList[
                          currentContent.activeCursorWidgetId
                        ].widgetList.splice(i, 1);
                      }
                    } else {
                      currentContent.moduleList[mod.index].widgetList[
                        currentContent.activeCursorWidgetId
                      ].widgetList.splice(i, 1);
                      if (
                        currentContent.moduleList[mod.index].widgetList[
                          currentContent.activeCursorWidgetId
                        ].branchControlType === "switch"
                      ) {
                        currentContent.moduleList[mod.index].widgetList[
                          currentContent.activeCursorWidgetId
                        ].branchConditions.splice(i, 1);
                      }
                    }
                  } else if (x.type === "execution_frame") {
                    /**
                     * execution widget list delete
                     */
                    currentContent.selectedWidgetsData.widgetIds.map((z) => {
                      x.widgetList.map((y, id) => {
                        if (y.id === z) {
                          currentContent.moduleList[mod.index].widgetList[
                            currentContent.activeCursorModuleId
                          ].widgetList[i].widgetList.splice(id, 1);
                        }
                      });
                    });
                  } else if (x.type === "branch") {
                    /**
                     * nested branch widgetlist delete
                     */
                    currentContent.selectedWidgetsData.widgetIds.map((z) => {
                      x.widgetList.map((y, id) => {
                        if (y.id === z) {
                          if (
                            currentContent.moduleList[mod.index].widgetList[
                              currentContent.activeCursorModuleId
                            ].widgetList[i].widgetList.length === 1
                          ) {
                            if (x.branchControlType === "switch") {
                              currentContent.moduleList[mod.index].widgetList[
                                currentContent.activeCursorModuleId
                              ].widgetList[i].widgetList[id].type = "blank";
                              currentContent.moduleList[mod.index].widgetList[
                                currentContent.activeCursorModuleId
                              ].widgetList[i].widgetList[id].widgetType =
                                "blank";
                              currentContent.moduleList[mod.index].widgetList[
                                currentContent.activeCursorModuleId
                              ].widgetList[i].branchConditions = [
                                {
                                  conditions: [
                                    {
                                      field: "",
                                      expression: "<",
                                      value: "",
                                    },
                                  ],
                                },
                              ];
                            } else {
                              currentContent.moduleList[mod.index].widgetList[
                                currentContent.activeCursorModuleId
                              ].widgetList[i].widgetList.splice(id, 1);
                            }
                          } else {
                            console.log("delete", id);
                            currentContent.moduleList[mod.index].widgetList[
                              currentContent.activeCursorModuleId
                            ].widgetList[i].widgetList.splice(id, 1);
                            if (x.branchControlType === "switch") {
                              currentContent.moduleList[mod.index].widgetList[
                                currentContent.activeCursorModuleId
                              ].widgetList[i].branchConditions.splice(id, 1);
                            }
                          }
                        }
                      });
                    });
                  }
                });
              });
            }
          }
          let haslatestWidgetIndex = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
            (x) => x.id === action.payload && x.type === "widget"
          );
          if (haslatestWidgetIndex > -1) {
            let index = currentContent.widgetList.findIndex(
              (x) => x.id === action.payload
            );

            let pageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
              (x) => x.index === index && x.type === "widget"
            );
            let otherPageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
              (x) => x.index === index - 1 && x.type === "widget"
            );
            let pageBreakIndex = currentContent.pageBreakPosition.findIndex(
              (x) => x === pageBreak
            );
            let otherPageBreakIndex = currentContent.pageBreakPosition.findIndex(
              (x) => x === otherPageBreak
            );
            if (pageBreakIndex > -1 && otherPageBreakIndex > -1) {
              currentContent.pageBreakPosition.splice(pageBreakIndex, 1);
            }
            currentContent.pageBreakPosition.map((position, i) => {
              if (position >= pageBreak) {
                currentContent.pageBreakPosition[i] = position - 1;
              }
            });

            currentContent.modulesAndOutsideWidgetsPositions.map(
              (combine, i) => {
                if (combine.type === "widget" && combine.index === index) {
                  currentContent.modulesAndOutsideWidgetsPositions.splice(i, 1);
                }
              }
            );

            currentContent.modulesAndOutsideWidgetsPositions.map(
              (combine, i) => {
                if (combine.type === "widget" && combine.index > index) {
                  combine.index = combine.index - 1;
                }
                return combine;
              }
            );
            if (index > -1) {
              currentContent.widgetList.splice(index, 1);
              let hasIndex = currentContent.selectedWidgetsData.widgetIds.findIndex(
                (x) => x === action.payload
              );
              currentContent.selectedWidgetsData.widgetIds.splice(hasIndex, 1);
            }
            if (
              currentContent.modulesAndOutsideWidgetsPositions.length >=
              currentContent.activeCursorModuleId
            ) {
              if (currentContent.activeCursorModuleId !== 0) {
                currentContent.activeCursorModuleId =
                  currentContent.activeCursorModuleId - 1;
              } else {
                currentContent.activeCursorModuleId =
                  currentContent.modulesAndOutsideWidgetsPositions.length > 0
                    ? currentContent.activeCursorModuleId
                    : undefined;
              }
            } else {
              currentContent.activeCursorModuleId =
                currentContent.modulesAndOutsideWidgetsPositions.length >= 0
                  ? currentContent.activeCursorModuleId
                  : undefined;
            }
            currentContent.activeCursorWidgetId = undefined;
          } else {
            let module = modules.filter((x) => {
              if (x.widgetList.findIndex((x) => x.id === action.payload) > -1) {
                return x;
              }
            });
            let currentModule = module[0];
            let currentWidgetIndx = currentModule?.widgetList.findIndex(
              (x) => x.id === action.payload
            );

            let isWidgetExist = currentContent.modulesWidgetsPositions.filter(
              (x) =>
                x.moduleId === currentModule?.id &&
                x.index === currentWidgetIndx
            );

            let currentWidgetCursorIndex = currentContent.modulesWidgetsPositions.findIndex(
              (x) => currentModule?.id === x.moduleId && x.id === action.payload
            );

            if (currentWidgetCursorIndex > -1) {
              currentContent.modulesWidgetsPositions.splice(
                currentWidgetCursorIndex,
                1
              );
            }

            if (isWidgetExist !== undefined && isWidgetExist.length > 0) {
              currentContent.modulesWidgetsPositions.map((combine, i) => {
                if (
                  combine.moduleId === currentModule.id &&
                  combine.index > currentWidgetIndx
                ) {
                  combine.index = combine.index - 1;
                }
                return combine;
              });
            }

            let index = currentModule?.widgetList.findIndex(
              (x) => x.id === action.payload
            );

            if (index > -1) {
              currentModule.widgetList.splice(index, 1);
              if (currentModule?.pageBreakPosition.indexOf(index - 1) > -1) {
                let pageBreakIndex = currentModule.pageBreakPosition.findIndex(
                  (x) => x === index
                );
                currentModule.pageBreakPosition.splice(pageBreakIndex, 1);
              }
              let hasIndex = currentContent.selectedWidgetsData.widgetIds.findIndex(
                (x) => x === action.payload
              );
              currentContent.selectedWidgetsData.widgetIds.splice(hasIndex, 1);
            }
            currentContent.activeCursorWidgetId =
              currentContent.activeCursorWidgetId === 0
                ? currentModule.widgetList.length > 0
                  ? currentContent.activeCursorWidgetId - 1
                  : -1
                : currentContent.activeCursorWidgetId === -1
                ? -1
                : currentContent.activeCursorWidgetId !== undefined
                ? currentContent.activeCursorWidgetId - 1
                : undefined;
          }

          currentContent.selectedWidgetsData.moduleIds.map((moduleId, i) => {
            let index = modules.findIndex((x) => x.id === moduleId);
            let hasWidget = modules[index].widgetList.filter((x) => {
              if (
                currentContent.selectedWidgetsData.widgetIds.indexOf(x.id) > -1
              ) {
                return x;
              }
            });

            if (hasWidget?.length === 0) {
              let moduleIndex = currentContent.selectedWidgetsData.moduleIds.findIndex(
                (x) => x === moduleId
              );
              currentContent.selectedWidgetsData.moduleIds.splice(
                moduleIndex,
                1
              );
            }
          });

          /**
           * for branch widget delete
           */
          currentContent.selectedWidgetsData.widgetIds.map((widget, i) => {
            widgets.filter((sel, idx) => {
              if (sel.type === "branch") {
                sel.widgetList.map((x, i) => {
                  if (x.id === widget) {
                    if (
                      currentContent.widgetList[idx].widgetList.length === 1
                    ) {
                      if (sel.branchControlType === "switch") {
                        currentContent.widgetList[idx].widgetList[i].type =
                          "blank";
                        currentContent.widgetList[idx].widgetList[
                          i
                        ].widgetType = "blank";
                        currentContent.widgetList[idx].branchConditions = [
                          {
                            conditions: [
                              {
                                field: "",
                                expression: "<",
                                value: "",
                              },
                            ],
                          },
                        ];
                      } else {
                        currentContent.widgetList[idx].widgetList.splice(i, 1);
                      }
                    } else {
                      currentContent.widgetList[idx].widgetList.splice(i, 1);
                      if (sel.branchControlType === "switch") {
                        currentContent.widgetList[idx].branchConditions.splice(
                          i,
                          1
                        );
                      }
                    }
                  } else if (x.type === "execution_frame") {
                    x.widgetList.map((y, j) => {
                      if (y.id === widget) {
                        currentContent.widgetList[idx].widgetList[
                          i
                        ].widgetList.splice(j, 1);
                      }
                    });
                  } else if (x.type === "branch") {
                    x.widgetList.map((y, j) => {
                      if (y.id === widget) {
                        if (
                          currentContent.widgetList[idx].widgetList[i]
                            .widgetList.length === 1
                        ) {
                          if (x.branchControlType === "switch") {
                            currentContent.widgetList[idx].widgetList[
                              i
                            ].widgetList[j].type = "blank";
                            currentContent.widgetList[idx].widgetList[
                              i
                            ].widgetList[j].widgetType = "blank";
                            currentContent.widgetList[idx].widgetList[
                              i
                            ].branchConditions = [
                              {
                                conditions: [
                                  {
                                    field: "",
                                    expression: "<",
                                    value: "",
                                  },
                                ],
                              },
                            ];
                          } else {
                            currentContent.widgetList[idx].widgetList[
                              i
                            ].widgetList.splice(j, 1);
                          }
                        } else {
                          currentContent.widgetList[idx].widgetList[
                            i
                          ].widgetList.splice(j, 1);
                          if (x.branchControlType === "switch") {
                            currentContent.widgetList[idx].widgetList[
                              i
                            ].branchConditions.splice(j, 1);
                          }
                        }
                      }
                    });
                  }
                });
              }
            });
          });
        }

        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case ADVANCED_VIEW_BY_WIDGET_IDS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let hasValue = currentContent.advancedViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (hasValue > -1 && action.payload != 0)
            currentContent.advancedViewWidgetIds.splice(hasValue, 1);
          else if (action.payload != 0)
            currentContent.advancedViewWidgetIds = [
              ...currentContent.advancedViewWidgetIds,
              action.payload,
            ];
          else currentContent.advancedViewWidgetIds = [];
        }
      });
      return {
        ...state,
        contents,
        //advancedViewWidgetIds: [...advancedViewWidgetIds],
      };
    case VERTICAL_SPINNER:
      return { ...state, isVerticalSpinner: action.payload };
    case SELECTED_MODULE_IDS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let modules = currentContent.moduleList;
          currentContent.activeCursorModuleId = action.activeModuleIndex;
          currentContent.activeModuleId = action.payload;
          currentContent.selectedOuterWidgetIds = [];
          if (action.clickType === "ctrlClick") {
            hasIndex = currentContent.selectedModuleIds.findIndex(
              (x) => x === action.payload
            );
            if (hasIndex > -1) {
              currentContent.selectedModuleIds.splice(hasIndex, 1);
            } else {
              currentContent.selectedModuleIds = [
                ...currentContent.selectedModuleIds,
                action.payload,
              ];
              currentContent.activeCursorWidgetId = undefined;
            }
            currentContent.activeModuleId = action.payload;
          } else if (
            action.clickType === "shiftClick" &&
            currentContent.selectedModuleIds.length > 0
          ) {
            let lastId =
              currentContent.selectedModuleIds[
                currentContent.selectedModuleIds.length - 1
              ];
            let firstId = currentContent.selectedModuleIds[0];

            let firstIndex = modules.findIndex((x) => x.id === lastId);
            let lastIndex = modules.findIndex((x) => x.id === action.payload);
            if (firstIndex > lastIndex) {
              firstIndex = modules.findIndex((x) => x.id === firstId);
            }
            currentContent.selectedModuleIds = [];
            if (firstIndex <= lastIndex) {
              for (let i = lastIndex; i >= firstIndex; i--) {
                currentContent.selectedModuleIds.push(modules[i].id);
              }
            }
            if (firstIndex >= lastIndex) {
              for (let i = firstIndex; i >= lastIndex; i--) {
                currentContent.selectedModuleIds.push(modules[i].id);
              }
            }
          } else {
            currentContent.selectedModuleIds =
              currentContent.selectedModuleIds.length === 1 &&
              currentContent.selectedModuleIds[
                currentContent.selectedModuleIds.length - 1
              ] === action.payload
                ? []
                : [action.payload];
          }
          if (currentContent.selectedModuleIds.length > 0) {
            currentContent.selectedWidgetsData.widgetIds = [];
            currentContent.selectedModuleIds.map((moduleId, ind) => {
              let index = modules.findIndex((x) => x.id === moduleId);
              if (index > -1 && modules[index].widgetList.length > 0) {
                currentContent.moduleList[index].widgetList.map((widget, i) => {
                  currentContent.selectedWidgetsData.widgetIds.push(widget.id);
                });
              }
            });
          } else {
            currentContent.selectedWidgetsData.widgetIds = [];
          }
          if (currentContent.selectedModuleIds.indexOf(action.payload) > -1) {
            currentContent.activeCursorWidgetId = undefined;
          } else {
            if (currentContent.activeModuleIds.indexOf(action.payload) > -1) {
              currentContent.activeCursorWidgetId = -1;
            } else {
              currentContent.activeCursorWidgetId = undefined;
            }
          }
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_CURSOR_WIDGET_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.activeCursorWidgetId = action.payload;
        }
        // content.branchWidgetCursorIndex = undefined;
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_CURSOR_MODULE_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          // content.activeCursorWidgetId =
          //   content.activeCursorModuleId === action.payload
          //     ? content.activeCursorWidgetId === undefined ? -1 : content.activeCursorWidgetId
          //     : -1
          // if(content.activeModuleIds.indexOf(action.payload) > -1 &&  content.selectedModuleIds.indexOf(action.payload) === -1 ){
          //   content.activeCursorWidgetId =   -1
          // }else if(content.activeModuleIds.indexOf(action.payload) > -1){
          //    content.activeCursorWidgetId =  -1
          // }else{
          //   content.activeCursorWidgetId =  undefined
          // }
          //content.activeCursorWidgetId =  undefined
          content.activeCursorModuleId = action.payload;
          // content.branchWidgetCursorIndex = undefined;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case COMPRESSED_VIEW_BY_WIDGET_IDS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let hasValue = currentContent.compressedViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (hasValue > -1 && action.payload !== 0)
            currentContent.compressedViewWidgetIds.splice(hasValue, 1);
          else if (action.payload !== 0)
            currentContent.compressedViewWidgetIds = [
              ...currentContent.compressedViewWidgetIds,
              action.payload,
            ];
          else currentContent.compressedViewWidgetIds = [];
        }
      });
      return {
        ...state,
        contents,
        //compressedViewWidgetIds: [...compressedViewWidgetIds],
      };
    case STANDARD_VIEW_BY_WIDGET_IDS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          //let standardViewWidgetIds = state.standardViewWidgetIds;
          let hasValue = currentContent.standardViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (hasValue > -1 && action.payload !== 0)
            currentContent.standardViewWidgetIds.splice(hasValue, 1);
          else if (action.payload !== 0)
            currentContent.standardViewWidgetIds = [
              ...currentContent.standardViewWidgetIds,
              action.payload,
            ];
          else currentContent.standardViewWidgetIds = [];
        }
      });
      return {
        ...state,
        contents,
        //standardViewWidgetIds: [...standardViewWidgetIds],
      };

    case RESET_TO_STANDARD_VIEW:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let widgetStandardModeIndex = currentContent.standardViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (widgetStandardModeIndex === -1 && action.payload) {
            currentContent.standardViewWidgetIds = [
              ...currentContent.standardViewWidgetIds,
              action.payload,
            ];
          }

          let widgetCompressedModeIndex = currentContent.compressedViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (widgetCompressedModeIndex > -1 && action.payload)
            currentContent.compressedViewWidgetIds.splice(
              widgetCompressedModeIndex,
              1
            );

          let widgetAdvancedModeIndex = currentContent.advancedViewWidgetIds.findIndex(
            (x) => x === action.payload
          );
          if (widgetAdvancedModeIndex > -1 && action.payload)
            currentContent.advancedViewWidgetIds.splice(
              widgetCompressedModeIndex,
              1
            );
        } else {
          console.log("outside");
        }
      });
      return {
        ...state,
        contents,
      };

    case SET_PROPERTIES:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          // content = Object.assign({}, action.payload);
          content.title = action.payload.title;
          content.searchTerm = action.payload.searchTerm;
          content.snoMedTerms = action.payload.snoMedTerms;
          content.description = action.payload.description;
          content.useCaseDescription = action.payload.useCaseDescription;
          content.refLinks = action.payload.refLinks;
          content.refAttachmentList = action.payload.refAttachmentList;
          content.locked = action.payload.locked;
          content.readOnly = action.payload.readOnly;
          content.draft = action.payload.draft;
          content.minutesSaved = action.payload.minutesSaved;
          content.tripsSaved = action.payload.tripsSaved;
          content.moneySaved = action.payload.moneySaved;
          content.imageName = action.payload.imageName;
          content.moduleList = action.payload.moduleList;
          let processProperties = action.payload.processProperties;
          processProperties.refAttachmentList = processProperties?.refAttachmentList?.filter(
            (x) => x != ""
          );
          processProperties.refLinks = processProperties?.refLinks?.filter(
            (x) => x != ""
          );
          content.processProperties = processProperties;
        }
      });
      return {
        ...state,
        contents,
      };
    case SET_PROCESS_AND_MODULE:
      contents = state.contents.slice();

      if (action.payload === "PROCESS" || action.payload === "MODULE") {
        contents.map((content) => {
          if (content.contentId === state.activeContentId) {
            content.processModule = action.payload;
            if (action.isSave) content.isProcessAssigned = true;
            content.isProcessModuleManuallySelected = action.payload;
          }
        });
      } else {
        contents.map((content) => {
          if (content.contentId === state.activeContentId) {
            const outsideWidgetsLength = content?.widgetList?.length || 0;
            const modulesLength = content?.moduleList?.length || 0;
            if (modulesLength > 0 && outsideWidgetsLength > 0) {
              content.processModule = "PROCESS";
              content.isProcessAssigned = true;
            } else if (modulesLength > 1) {
              content.processModule = "PROCESS";
              content.isProcessAssigned = true;
            }
            // else {
            //
            //   if (!content.isProcessModuleManuallySelected)
            //     content.processModule = "";
            //   content.isProcessAssigned = false;
            // }

            // else {
            //   //const moduleLength = content.moduleList.length;
            //   content.processModule =
            //     moduleLength > 0 && moduleLength === 1
            //       ? 'MODULE'
            //       : moduleLength > 0 && moduleLength > 1
            //         ? "PROCESS"
            //         : "";
            // }
          }
        });
      }
      return {
        ...state,
        contents,
      };
    case SET_CURSOR_SELECTED_STATUS:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.cursorSelectedStatus = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
        //cursorSelectedStatus: action.payload
      };
    case SET_ALL_WIDGET_MODE:
      contents = state.contents.slice();
      let viewMode = action.payload;
      //state.currentViewMode === 'STANDARD_VIEW' ? 'COMPRESSED_VIEW' : 'STANDARD_VIEW';

      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          if (
            content.selectedModuleIds.length <= 0 &&
            content.selectedWidgetsData.widgetIds.length > 0
          ) {
            content.moduleList.map((module) => {
              if (content.activeModuleIds.indexOf(module.id) > -1) {
                module.widgetList.map((widget) => {
                  if (
                    content.selectedWidgetsData.widgetIds.indexOf(widget.id) >
                    -1
                  ) {
                    let hasValue = content.advancedViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.advancedViewWidgetIds.splice(hasValue, 1);

                    hasValue = content.standardViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.standardViewWidgetIds.splice(hasValue, 1);

                    hasValue = content.compressedViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.compressedViewWidgetIds.splice(hasValue, 1);

                    // viewMode =
                    //   widget.widgetCurrentViewMode === 'STANDARD_VIEW'
                    //     ? 'COMPRESSED_VIEW'
                    //     : 'STANDARD_VIEW';

                    switch (viewMode) {
                      case "STANDARD_VIEW":
                        content.standardViewWidgetIds = [
                          ...content.standardViewWidgetIds,
                          widget.id,
                        ];
                        break;
                      case "COMPRESSED_VIEW":
                        content.compressedViewWidgetIds = [
                          ...content.compressedViewWidgetIds,
                          widget.id,
                        ];
                        break;
                    }
                    widget.widgetCurrentViewMode = viewMode;
                  }
                });
              }
            });
          } else if (content.selectedModuleIds.length > 0) {
            content.moduleList.map((module) => {
              content.selectedModuleIds.map((moduleId) => {
                if (module.id === moduleId) {
                  module.widgetList.map((widget) => {
                    let hasValue = content.advancedViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.advancedViewWidgetIds.splice(hasValue, 1);

                    hasValue = content.standardViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.standardViewWidgetIds.splice(hasValue, 1);

                    hasValue = content.compressedViewWidgetIds.findIndex(
                      (x) => x === widget.id
                    );
                    if (hasValue > -1)
                      content.compressedViewWidgetIds.splice(hasValue, 1);

                    // viewMode =
                    //   widget.widgetCurrentViewMode === 'STANDARD_VIEW'
                    //     ? 'COMPRESSED_VIEW'
                    //     : 'STANDARD_VIEW';

                    switch (viewMode) {
                      case "STANDARD_VIEW":
                        content.standardViewWidgetIds = [
                          ...content.standardViewWidgetIds,
                          widget.id,
                        ];
                        break;
                      case "COMPRESSED_VIEW":
                        content.compressedViewWidgetIds = [
                          ...content.compressedViewWidgetIds,
                          widget.id,
                        ];
                        break;
                    }
                    widget.widgetCurrentViewMode = viewMode;
                  });
                }
              });
            });
          } else if (content.selectedWidgetsData.widgetIds.length <= 0) {
            content.moduleList.map((module) => {
              module.widgetList.map((widget) => {
                let hasValue = content.advancedViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.advancedViewWidgetIds.splice(hasValue, 1);

                hasValue = content.standardViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.standardViewWidgetIds.splice(hasValue, 1);

                hasValue = content.compressedViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.compressedViewWidgetIds.splice(hasValue, 1);
                // viewMode =
                //   widget.widgetCurrentViewMode === 'STANDARD_VIEW'
                //     ? 'COMPRESSED_VIEW'
                //     : 'STANDARD_VIEW';
                widget.widgetCurrentViewMode = viewMode;
                switch (viewMode) {
                  case "STANDARD_VIEW":
                    content.standardViewWidgetIds = [
                      ...content.standardViewWidgetIds,
                      widget.id,
                    ];
                    break;
                  case "COMPRESSED_VIEW":
                    content.compressedViewWidgetIds = [
                      ...content.compressedViewWidgetIds,
                      widget.id,
                    ];
                    break;
                }
                widget.widgetCurrentViewMode = viewMode;
              });
            });
            //outside widgets
            content.widgetList.map((widget) => {
              let hasValue = content.advancedViewWidgetIds.findIndex(
                (x) => x === widget.id
              );
              if (hasValue > -1)
                content.advancedViewWidgetIds.splice(hasValue, 1);

              hasValue = content.standardViewWidgetIds.findIndex(
                (x) => x === widget.id
              );
              if (hasValue > -1)
                content.standardViewWidgetIds.splice(hasValue, 1);

              hasValue = content.compressedViewWidgetIds.findIndex(
                (x) => x === widget.id
              );
              if (hasValue > -1)
                content.compressedViewWidgetIds.splice(hasValue, 1);
              // viewMode =
              //   widget.widgetCurrentViewMode === 'STANDARD_VIEW'
              //     ? 'COMPRESSED_VIEW'
              //     : 'STANDARD_VIEW';
              widget.widgetCurrentViewMode = viewMode;
              switch (viewMode) {
                case "STANDARD_VIEW":
                  content.standardViewWidgetIds = [
                    ...content.standardViewWidgetIds,
                    widget.id,
                  ];
                  break;
                case "COMPRESSED_VIEW":
                  content.compressedViewWidgetIds = [
                    ...content.compressedViewWidgetIds,
                    widget.id,
                  ];
                  break;
              }
              widget.widgetCurrentViewMode = viewMode;
            });
          } else {
            //outside widgets
            content.widgetList.map((widget) => {
              if (
                content.selectedWidgetsData.widgetIds.indexOf(widget.id) > -1
              ) {
                let hasValue = content.advancedViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.advancedViewWidgetIds.splice(hasValue, 1);

                hasValue = content.standardViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.standardViewWidgetIds.splice(hasValue, 1);

                hasValue = content.compressedViewWidgetIds.findIndex(
                  (x) => x === widget.id
                );
                if (hasValue > -1)
                  content.compressedViewWidgetIds.splice(hasValue, 1);
                // viewMode =
                //   widget.widgetCurrentViewMode === 'STANDARD_VIEW'
                //     ? 'COMPRESSED_VIEW'
                //     : 'STANDARD_VIEW';
                widget.widgetCurrentViewMode = viewMode;
                switch (viewMode) {
                  case "STANDARD_VIEW":
                    content.standardViewWidgetIds = [
                      ...content.standardViewWidgetIds,
                      widget.id,
                    ];
                    break;
                  case "COMPRESSED_VIEW":
                    content.compressedViewWidgetIds = [
                      ...content.compressedViewWidgetIds,
                      widget.id,
                    ];
                    break;
                }
                widget.widgetCurrentViewMode = viewMode;
              }
            });
          }
        }
      });

      return {
        ...state,
        contents,
        // advancedViewWidgetIds,
        // standardViewWidgetIds,
        // compressedViewWidgetIds,
        currentViewMode: viewMode,
      };
    case SET_CURRENT_VIEW_MODE:
      return {
        ...state,
        currentViewMode: action.payload,
      };

    case SET_WIDGET_FORM_TEXT_ENTERED_STATUS:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          let widgetIndex = content.widgetList.findIndex(
            (x) => x.id === action.payload
          );
          if (widgetIndex > -1) {
            content.widgetList.map((widget) => {
              if (widget.id === action.payload) {
                widget.isWidgetFormTextEntered = !widget.isWidgetFormTextEntered;
              }
            });
          } else {
            content.moduleList.map((module) => {
              if (module.id === content.activeModuleId) {
                module.widgetList.map((widget) => {
                  if (widget.id === action.payload) {
                    widget.isWidgetFormTextEntered = !widget.isWidgetFormTextEntered;
                  }
                });
              }
            });
          }
        }
      });
      return {
        ...state,
        contents,
      };
    case SET_WIDGET_DEFAULT_NAME_SHOWED_STATUS:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          let widgetIndex = content?.widgetList?.findIndex(
            (x) => x?.id === action.payload
          );
          if (widgetIndex > -1) {
            content.widgetList.map((widget) => {
              if (widget !== undefined && widget?.id === action.payload) {
                widget.isWidgetDefaultNameShowed = !widget?.isWidgetDefaultNameShowed;
              }
            });
          } else {
            content.moduleList.map((module) => {
              if (module.id === content.activeModuleId) {
                module.widgetList.map((widget) => {
                  if (widget !== undefined && widget?.id === action.payload) {
                    widget.isWidgetDefaultNameShowed = !widget?.isWidgetDefaultNameShowed;
                  }
                });
              }
            });
          }
        }
      });
      return {
        ...state,
        contents,
      };
    case SAVE_DATA_IN_BROWSER: {
      var cache = [];
      localStorage.setItem(
        "local_contentBuilder",
        JSON.stringify(state.contents, (key, value) => {
          if (typeof value === "object" && value !== null) {
            if (cache.includes(value)) return;
            cache.push(value);
          }
          return value;
        })
      );
      cache = null;

      return { ...state };
    }
    case ADD_OUTSIDE_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.activeCursorModuleId =
            currentContent.activeCursorModuleId === undefined
              ? -1
              : currentContent.activeCursorModuleId;
          if (currentContent.widgetList?.length > 0) {
            function insertAt(array, index, ...elements) {
              array.splice(index, 0, ...elements);
            }
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;
            insertAt(
              currentContent.widgetList,
              currentContent.activeCursorModuleId,
              action.payload
            );
            let index = currentContent.widgetList.findIndex(
              (x) => x.id === action.payload.id
            );
            let hasValue = currentContent.modulesAndOutsideWidgetsPositions.filter(
              (x) => x.index === index
            );
            if (hasValue.length > 0) {
              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "widget" && combine.index >= index) {
                    combine.index = combine.index + 1;
                  }
                  return combine;
                }
              );
            }

            let widgetData = {
              index,
              type: "widget",
              id: action.payload.id,
            };

            insertAt(
              currentContent.modulesAndOutsideWidgetsPositions,
              currentContent.activeCursorModuleId,
              widgetData
            );
          } else {
            currentContent.widgetList.push(action.payload);
            let index = currentContent.widgetList.findIndex(
              (x) => x.id === action.payload.id
            );
            let widgetData = {
              index,
              type: "widget",
              id: action.payload.id,
            };
            currentContent.activeCursorModuleId =
              currentContent.activeCursorModuleId + 1;
            if (currentContent.modulesAndOutsideWidgetsPositions.length > 0) {
              function insertAt(array, index, ...elements) {
                array.splice(index, 0, ...elements);
              }
              insertAt(
                currentContent.modulesAndOutsideWidgetsPositions,
                currentContent.activeCursorModuleId,
                widgetData
              );
            } else {
              currentContent.modulesAndOutsideWidgetsPositions.push(widgetData);
            }
          }
          //  currentContent.selectedOuterWidgetIds = [];
          //currentContent.selectedWidgetIds = [];
          currentContent.selectedWidgetsData.widgetIds = [];
          currentContent.selectedModuleIds = [];
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case SET_SELECTED_OUTER_WIDGET_ID:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.selectedOuterWidgetIds =
            currentContent.selectedOuterWidgetIds.length === 1 &&
            currentContent.selectedOuterWidgetIds[
              currentContent.selectedOuterWidgetIds.length - 1
            ] === action.payload
              ? []
              : [action.payload];
          currentContent.selectedModuleIds = [];
          //currentContent.selectedWidgetIds = [];
          currentContent.selectedWidgetsData.widgetIds = [];
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case DELETE_OUTSIDE_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (currentContent.selectedOuterWidgetIds.length > 0) {
            currentContent.selectedOuterWidgetIds.map((widgetId, ind) => {
              let index = currentContent.widgetList.findIndex(
                (x) => x.id === widgetId
              );

              let pageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) => x.index === index && x.type === "widget"
              );
              let otherPageBreak = currentContent.modulesAndOutsideWidgetsPositions.findIndex(
                (x) => x.index === index - 1 && x.type === "widget"
              );
              let pageBreakIndex = currentContent.pageBreakPosition.findIndex(
                (x) => x === pageBreak
              );
              let otherPageBreakIndex = currentContent.pageBreakPosition.findIndex(
                (x) => x === otherPageBreak
              );
              if (pageBreakIndex > -1 && otherPageBreakIndex > -1) {
                currentContent.pageBreakPosition.splice(pageBreakIndex, 1);
              }
              currentContent.pageBreakPosition.map((position, i) => {
                if (position >= pageBreak) {
                  currentContent.pageBreakPosition[i] = position - 1;
                }
              });

              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "widget" && combine.index === index) {
                    currentContent.modulesAndOutsideWidgetsPositions.splice(
                      i,
                      1
                    );
                  }
                }
              );

              currentContent.modulesAndOutsideWidgetsPositions.map(
                (combine, i) => {
                  if (combine.type === "widget" && combine.index > index) {
                    combine.index = combine.index - 1;
                  }
                  return combine;
                }
              );

              // if (currentContent.modulesAndOutsideWidgetsPositions.length === 0) {
              //   currentContent.pageBreakPosition = [];
              // }

              if (index > -1) {
                currentContent.widgetList.splice(index, 1);
                currentContent.selectedOuterWidgetIds = [];
              }
              if (
                currentContent.modulesAndOutsideWidgetsPositions.length >=
                currentContent.activeCursorModuleId
              ) {
                if (currentContent.activeCursorModuleId !== 0) {
                  currentContent.activeCursorModuleId =
                    currentContent.activeCursorModuleId - 1;
                } else {
                  currentContent.activeCursorModuleId =
                    currentContent.modulesAndOutsideWidgetsPositions.length > 0
                      ? currentContent.activeCursorModuleId
                      : undefined;
                }
              } else {
                currentContent.activeCursorModuleId =
                  currentContent.modulesAndOutsideWidgetsPositions.length >= 0
                    ? currentContent.activeCursorModuleId
                    : undefined;
              }
            });
            currentContent.activeCursorWidgetId = undefined;
          }
          currentContent.selectedWidgetsData.widgetIds = [];
          //currentContent.selectedWidgetIds = [];
          currentContent.selectedModuleIds = [];
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case COPY_DATA:
      let copiedData = {
        contentId: state.activeContentId,
        moduleIds: [],
        widgetsdata: {},
        outerWidgetIds: [],
      };
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (currentContent.selectedModuleIds.length > 0) {
            copiedData.moduleIds = [...currentContent.selectedModuleIds];
          } else if (currentContent.selectedWidgetsData?.widgetIds.length > 0) {
            copiedData.widgetsdata = {
              moduleIds: [...currentContent.selectedWidgetsData?.moduleIds],
              widgetIds: [...currentContent.selectedWidgetsData?.widgetIds],
            };
          }
        }
      });
      return {
        ...state,
        copiedData,
      };
    case PASTE_DATA:
      copiedData = state.copiedData;
      contents = state.contents.slice();
      contents.map((copiedDataContent) => {
        if (copiedDataContent.contentId === copiedData.contentId) {
          if (copiedData.moduleIds.length > 0) {
            copiedData.moduleIds.map((copyId, i) => {
              let payload = copiedDataContent.moduleList.find(
                (x) => x.id === copyId
              );
              if (payload) {
                contents.map((currentContent) => {
                  if (currentContent.contentId === state.activeContentId) {
                    currentContent.activeCursorModuleId =
                      currentContent.activeCursorModuleId === undefined
                        ? -1
                        : currentContent.activeCursorModuleId;

                    let lastModuleName = "";
                    let lastModuleNumber = 1;
                    if (currentContent.moduleList.length > 0) {
                      let sortedModules = JSON.parse(
                        JSON.stringify(currentContent.moduleList)
                      );
                      sortedModules.sort((a, b) => a.id - b.id);
                      let lastModuleIndex =
                        Object.values(sortedModules).length - 1;
                      lastModuleName = sortedModules[lastModuleIndex].title;
                      lastModuleNumber = parseInt(
                        lastModuleName
                          .replace(/Module/g, "")
                          .replace(/\b0+/g, "")
                      );
                      lastModuleNumber++;
                    }

                    let numberOfZeros =
                      parseInt(lastModuleNumber) <= 9
                        ? "00"
                        : parseInt(lastModuleNumber) <= 99
                        ? "0"
                        : "000";

                    let newModuleName =
                      "Module" + numberOfZeros + lastModuleNumber;

                    payload = {
                      ...payload,
                      id: lastModuleNumber,
                      moduleName: newModuleName,
                    };

                    if (currentContent.moduleList?.length > 0) {
                      function insertAt(array, index, ...elements) {
                        array.splice(index, 0, ...elements);
                      }
                      currentContent.activeCursorModuleId =
                        currentContent.activeCursorModuleId + 1;
                      insertAt(
                        currentContent.moduleList,
                        currentContent.activeCursorModuleId,
                        payload
                      );

                      let index = currentContent.moduleList.findIndex(
                        (x) => x.id === payload.id
                      );

                      let moduleData = {
                        index,
                        type: "module",
                        id: payload.id,
                      };

                      let hasValue = currentContent.modulesAndOutsideWidgetsPositions.filter(
                        (x) => x.index === index
                      );
                      if (hasValue.length > 0) {
                        currentContent.modulesAndOutsideWidgetsPositions.map(
                          (combine, i) => {
                            if (
                              combine.type === "module" &&
                              combine.index >= index
                            ) {
                              combine.index = combine.index + 1;
                            }
                            return combine;
                          }
                        );
                      }

                      insertAt(
                        currentContent.modulesAndOutsideWidgetsPositions,
                        currentContent.activeCursorModuleId,
                        moduleData
                      );
                    } else {
                      currentContent.moduleList.push(payload);
                      let index = currentContent.moduleList.findIndex(
                        (x) => x.id === payload.id
                      );
                      let moduleData = {
                        index,
                        type: "module",
                        id: payload.id,
                      };
                      currentContent.activeCursorModuleId =
                        currentContent.activeCursorModuleId + 1;
                      if (
                        currentContent.modulesAndOutsideWidgetsPositions
                          .length > 0
                      ) {
                        function insertAt(array, index, ...elements) {
                          array.splice(index, 0, ...elements);
                        }
                        insertAt(
                          currentContent.modulesAndOutsideWidgetsPositions,
                          currentContent.activeCursorModuleId,
                          moduleData
                        );
                      } else {
                        currentContent.modulesAndOutsideWidgetsPositions.push(
                          moduleData
                        );
                      }
                    }
                    currentContent.selectedOuterWidgetIds = [];
                    currentContent.selectedWidgetsData.widgetIds = [];
                    // currentContent.selectedModuleIds = [];
                    //currentContent.selectedWidgetIds = [];
                    currentContent.activeCursorWidgetId = undefined;
                  }

                  return currentContent;
                });
              } else {
                alert(
                  "Could not find the module, This module with Module ID - " +
                    copyId +
                    " is no longer located in original path, Please verify the module's location "
                );
              }
            });
          } else if (copiedData.widgetsdata?.widgetIds?.length > 0) {
            copiedData.widgetsdata.widgetIds.map((copyId, i) => {
              let module = copiedDataContent.moduleList.find(
                (x) => x.id === copiedData.widgetsdata.moduleId
              );
              let payload = module.widgetList.find((x) => x.id === copyId);
              if (payload) {
                contents.map((currentContent) => {
                  if (currentContent.contentId === state.activeContentId) {
                    let allWidgets = currentContent.moduleList.reduce(
                      (data, obj) => [...data, ...obj.widgetList],
                      []
                    );
                    allWidgets = [...allWidgets, ...currentContent.widgetList];
                    allWidgets.sort((a, b) => a.id - b.id);
                    let widgetName = payload.widgetName.slice(0, 3);
                    if (allWidgets.length > 0) {
                      //let widgetName = parseInt(payload.widgetName.slice(-3) > 1)
                      let widgetsBasedOnType = allWidgets.filter((widget) =>
                        widget.widgetDefaultName.includes(widgetName)
                      );
                      if (widgetsBasedOnType.length > 0) {
                        let lastWidgetName =
                          widgetsBasedOnType[widgetsBasedOnType.length - 1]
                            .widgetDefaultName;
                        let lastLength = parseInt(lastWidgetName.slice(-3)) + 1;
                        let numberOfZeros =
                          parseInt(lastLength) <= 9
                            ? "00"
                            : parseInt(lastLength) <= 99
                            ? "0"
                            : "000";
                        let newWidgetName =
                          widgetName + numberOfZeros + parseInt(lastLength);
                        payload = {
                          ...payload,
                          id:
                            parseInt(allWidgets[allWidgets.length - 1].id) + 1,
                          widgetName: newWidgetName,
                          widgetDefaultName: newWidgetName,
                        };
                      } else {
                        payload = {
                          ...payload,
                          id:
                            parseInt(allWidgets[allWidgets.length - 1].id) + 1,
                          widgetName: `${widgetName}001`,
                          widgetDefaultName: `${widgetName}001`,
                        };
                      }
                    } else {
                      payload = {
                        ...payload,
                        id: 1,
                        widgetName: `${widgetName}001`,
                        widgetDefaultName: `${widgetName}001`,
                      };
                    }

                    if (currentContent.activeCursorWidgetId !== undefined) {
                      currentContent.moduleList.map((currentModule) => {
                        let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
                          (x, index) =>
                            index === currentContent.activeCursorModuleId &&
                            x.type === "module"
                        ).id;

                        if (currentModule.id === activeModuleId) {
                          function insertAt(array, index, ...elements) {
                            array.splice(index, 0, ...elements);
                            currentContent.activeCursorWidgetId =
                              currentContent.activeCursorWidgetId + 1;
                          }
                          insertAt(
                            currentModule.widgetList,
                            currentContent.activeCursorWidgetId + 1,
                            payload
                          );
                        }
                        return currentModule;
                      });
                      if (
                        currentContent.selectedModuleIds.length > 0 &&
                        currentContent.selectedModuleIds.indexOf(
                          currentContent.activeModuleId
                        ) > -1
                      ) {
                        currentContent.selectedWidgetsData.widgetIds = [
                          ...currentContent.selectedWidgetsData.widgetIds,
                          payload.id,
                        ];
                      }
                    } else {
                      currentContent.activeCursorModuleId =
                        currentContent.activeCursorModuleId === undefined
                          ? -1
                          : currentContent.activeCursorModuleId;
                      if (currentContent.widgetList?.length > 0) {
                        function insertAt(array, index, ...elements) {
                          array.splice(index, 0, ...elements);
                        }
                        currentContent.activeCursorModuleId =
                          currentContent.activeCursorModuleId + 1;
                        insertAt(
                          currentContent.widgetList,
                          currentContent.activeCursorModuleId,
                          payload
                        );
                        let index = currentContent.widgetList.findIndex(
                          (x) => x.id === payload.id
                        );
                        let widgetData = {
                          index,
                          type: "widget",
                          id: payload.id,
                        };

                        let hasValue = currentContent.modulesAndOutsideWidgetsPositions.filter(
                          (x) => x.index === index
                        );
                        if (hasValue.length > 0) {
                          currentContent.modulesAndOutsideWidgetsPositions.map(
                            (combine, i) => {
                              if (
                                combine.type === "widget" &&
                                combine.index >= index
                              ) {
                                combine.index = combine.index + 1;
                              }
                              return combine;
                            }
                          );
                        }

                        insertAt(
                          currentContent.modulesAndOutsideWidgetsPositions,
                          currentContent.activeCursorModuleId,
                          widgetData
                        );
                      } else {
                        currentContent.widgetList.push(payload);
                        let index = currentContent.widgetList.findIndex(
                          (x) => x.id === payload.id
                        );
                        let widgetData = {
                          index,
                          type: "widget",
                          id: payload.id,
                        };
                        currentContent.activeCursorModuleId =
                          currentContent.activeCursorModuleId + 1;
                        if (
                          currentContent.modulesAndOutsideWidgetsPositions
                            .length > 0
                        ) {
                          function insertAt(array, index, ...elements) {
                            array.splice(index, 0, ...elements);
                          }
                          insertAt(
                            currentContent.modulesAndOutsideWidgetsPositions,
                            currentContent.activeCursorModuleId,
                            widgetData
                          );
                        } else {
                          currentContent.modulesAndOutsideWidgetsPositions.push(
                            widgetData
                          );
                        }
                      }
                    }
                    currentContent.selectedOuterWidgetIds = [];
                    currentContent.selectedModuleIds = [];
                  }
                  return currentContent;
                });
              } else {
                alert(
                  "Could not find the widget, This widget with Widget ID - " +
                    copyId +
                    " is no longer located in original path, Please verify the widget's location "
                );
              }
            });
          }
        }
      });
      return {
        ...state,
        copiedData,
      };
    case SET_IS_GLOBAL_LOGO_POPUP_VISIBLE:
      return {
        ...state,
        isGlobalLogoPopupVisible: action.payload,
      };
    case TOGGLE_WIDGET_TYPE:
      contents = state.contents.slice();
      const { type } = action.payload;
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            currentModule.widgetList.map((widget) => {
              if (currentModule.id === widget.moduleId) {
                if (widget.id === action.payload.id) {
                  if (
                    widget.toggledWidgets &&
                    Object.keys(widget.toggledWidgets).length > 0 &&
                    widget.toggledWidgets.hasOwnProperty(type)
                  ) {
                    // let respectiveWidgetProps = {};
                    // ** Creating empty obj for current widget if not exist in toggledWidgets
                    if (!widget.toggledWidgets.hasOwnProperty(widget.type))
                      widget.toggledWidgets[widget.type] = {};
                    // ** to store current modified widget in toggledWidgets
                    // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                    if (
                      widget.type === NUMBER_WIDGET ||
                      widget.type === TIME_INPUT_WIDGET ||
                      widget.type === DATE_WIDGET
                    ) {
                      widget.toggledWidgets[widget.type].minimumValue =
                        widget.minimumValue;
                      widget.toggledWidgets[widget.type].maximumValue =
                        widget.maximumValue;
                      widget.toggledWidgets[widget.type].defaultValue =
                        widget.defaultValue;
                      if (widget.type === NUMBER_WIDGET) {
                        widget.toggledWidgets[widget.type].decimalValue =
                          widget.decimalValue;
                      }
                    } else if (
                      widget.type === TEXT_INPUT_WIDGET ||
                      widget.type === CALCULATION_WIDGET ||
                      widget.type === NARRATIVE_WIDGET ||
                      widget.type === WARNING_INPUT_WIDGET
                    ) {
                      widget.toggledWidgets[widget.type].defaultText =
                        widget.defaultText;
                    }

                    // ** To copy toggled properties for selected widget
                    // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                    if (
                      type === NUMBER_WIDGET ||
                      type === TIME_INPUT_WIDGET ||
                      type === DATE_WIDGET
                    ) {
                      widget.minimumValue =
                        widget.toggledWidgets[type].minimumValue;
                      widget.maximumValue =
                        widget.toggledWidgets[type].maximumValue;
                      widget.defaultValue =
                        widget.toggledWidgets[type].defaultValue;
                      if (type === NUMBER_WIDGET)
                        widget.decimalValue =
                          widget.toggledWidgets[type].decimalValue;
                    } else if (
                      type === TEXT_INPUT_WIDGET ||
                      type === CALCULATION_WIDGET ||
                      type === NARRATIVE_WIDGET ||
                      type === WARNING_INPUT_WIDGET
                    ) {
                      // ** text/calc/narr/warn -  defaultText properties
                      widget.defaultText =
                        widget.toggledWidgets[type].defaultText;
                    }
                  } else {
                    let respectiveWidgetProps = {};
                    if (!widget.toggledWidgets) widget.toggledWidgets = {};
                    // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                    if (
                      widget.type === NUMBER_WIDGET ||
                      widget.type === TIME_INPUT_WIDGET ||
                      widget.type === DATE_WIDGET
                    ) {
                      respectiveWidgetProps.minimumValue = widget.minimumValue;
                      respectiveWidgetProps.maximumValue = widget.maximumValue;
                      respectiveWidgetProps.defaultValue = widget.defaultValue;
                      widget.minimumValue = null;
                      widget.maximumValue = null;
                      widget.defaultValue = null;
                      if (widget.type === NUMBER_WIDGET) {
                        respectiveWidgetProps.decimalValue =
                          widget.decimalValue;
                        widget.decimalValue = null;
                      }
                    } else if (
                      widget.type === TEXT_INPUT_WIDGET ||
                      widget.type === CALCULATION_WIDGET ||
                      widget.type === NARRATIVE_WIDGET ||
                      widget.type === WARNING_INPUT_WIDGET
                    ) {
                      respectiveWidgetProps.defaultText = widget.defaultText;
                      widget.defaultText = "";
                    }
                    widget.toggledWidgets[widget.type] = Object.assign(
                      {},
                      respectiveWidgetProps
                    );
                  }

                  // ** Other default properties included when switched.
                  widget.branchConditions =
                    widget.branchConditions?.length > 0
                      ? widget.branchConditions
                      : [
                          {
                            conditions: [
                              {
                                field: "",
                                expression: "<",
                                value: "",
                              },
                            ],
                          },
                        ];
                  widget.branchControlType = "skip";
                  widget.widgetType = type;
                  widget.type = type;
                }
                return widget;
              }
            });
            return currentModule;
          });
          currentContent.widgetList.map((widget) => {
            if (widget.id === action.payload.id) {
              if (
                widget.toggledWidgets &&
                Object.keys(widget.toggledWidgets).length > 0 &&
                widget.toggledWidgets.hasOwnProperty(type)
              ) {
                // let respectiveWidgetProps = {};
                // ** Creating empty obj for current widget if not exist in toggledWidgets
                if (!widget.toggledWidgets.hasOwnProperty(widget.type))
                  widget.toggledWidgets[widget.type] = {};
                // ** to store current modified widget in toggledWidgets
                // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                if (
                  widget.type === NUMBER_WIDGET ||
                  widget.type === TIME_INPUT_WIDGET ||
                  widget.type === DATE_WIDGET
                ) {
                  widget.toggledWidgets[widget.type].minimumValue =
                    widget.minimumValue;
                  widget.toggledWidgets[widget.type].maximumValue =
                    widget.maximumValue;
                  widget.toggledWidgets[widget.type].defaultValue =
                    widget.defaultValue;
                  if (widget.type === NUMBER_WIDGET) {
                    widget.toggledWidgets[widget.type].decimalValue =
                      widget.decimalValue;
                  }
                } else if (
                  widget.type === TEXT_INPUT_WIDGET ||
                  widget.type === CALCULATION_WIDGET ||
                  widget.type === NARRATIVE_WIDGET ||
                  widget.type === WARNING_INPUT_WIDGET
                ) {
                  widget.toggledWidgets[widget.type].defaultText =
                    widget.defaultText;
                }

                // ** To copy toggled properties for selected widget
                // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                if (
                  type === NUMBER_WIDGET ||
                  type === TIME_INPUT_WIDGET ||
                  type === DATE_WIDGET
                ) {
                  widget.minimumValue =
                    widget.toggledWidgets[type].minimumValue;
                  widget.maximumValue =
                    widget.toggledWidgets[type].maximumValue;
                  widget.defaultValue =
                    widget.toggledWidgets[type].defaultValue;
                  if (type === NUMBER_WIDGET)
                    widget.decimalValue =
                      widget.toggledWidgets[type].decimalValue;
                } else if (
                  type === TEXT_INPUT_WIDGET ||
                  type === CALCULATION_WIDGET ||
                  type === NARRATIVE_WIDGET ||
                  type === WARNING_INPUT_WIDGET
                ) {
                  // ** text/calc/narr/warn -  defaultText properties
                  widget.defaultText = widget.toggledWidgets[type].defaultText;
                }
              } else {
                let respectiveWidgetProps = {};
                if (!widget.toggledWidgets) widget.toggledWidgets = {};
                // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
                if (
                  widget.type === NUMBER_WIDGET ||
                  widget.type === TIME_INPUT_WIDGET ||
                  widget.type === DATE_WIDGET
                ) {
                  respectiveWidgetProps.minimumValue = widget.minimumValue;
                  respectiveWidgetProps.maximumValue = widget.maximumValue;
                  respectiveWidgetProps.defaultValue = widget.defaultValue;
                  widget.minimumValue = null;
                  widget.maximumValue = null;
                  widget.defaultValue = null;
                  if (widget.type === NUMBER_WIDGET) {
                    respectiveWidgetProps.decimalValue = widget.decimalValue;
                    widget.decimalValue = null;
                  }
                } else if (
                  widget.type === TEXT_INPUT_WIDGET ||
                  widget.type === CALCULATION_WIDGET ||
                  widget.type === NARRATIVE_WIDGET ||
                  widget.type === WARNING_INPUT_WIDGET
                ) {
                  respectiveWidgetProps.defaultText = widget.defaultText;
                  widget.defaultText = "";
                }
                widget.toggledWidgets[widget.type] = Object.assign(
                  {},
                  respectiveWidgetProps
                );
              }

              // ** Other default properties included when switched.
              widget.branchConditions =
                widget.branchConditions?.length > 0
                  ? widget.branchConditions
                  : [
                      {
                        conditions: [
                          {
                            field: "",
                            expression: "<",
                            value: "",
                          },
                        ],
                      },
                    ];
              widget.branchControlType = "skip";
              widget.widgetType = type;
              widget.type = type;
            }
            return widget;
          });
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SET_ALL_CONTENTS:
      return {
        ...state,
        contents: action.payload,
      };
    case UPDATE_CONTENT:
      contents = state.contents.slice();
      index = contents.findIndex((x) => x.contentId === state.activeContentId);
      if (index > -1) contents[index] = action.payload;
      return {
        ...state,
        contents,
      };
    case SET_lOADING_SPINNER:
      return {
        ...state,
        isLoading: action.payload,
      };
    case GLOBAL_LOGO_SELECTED_WIDGETS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (action.payload.length === 0)
            currentContent.globalLogoSelectedWidgets = [];
          else currentContent.globalLogoSelectedWidgets.push(action.payload);
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SET_REF_ATTACHMENT:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          if (state.selectedPropertiesModuleId != "") {
            if (content.moduleList?.length > 0) {
              content.moduleList.map((module) => {
                if (module.id == state.selectedPropertiesModuleId) {
                  module.refAttachmentList = action.payload;
                  state.isEmitRefAttachmentFlag = true;
                }
              });
            }
          } else if (state.selectedPropertiesProcess) {
            content.processProperties.refAttachmentList = action.payload;
            state.isEmitRefAttachmentFlag = true;
          } else {
            content.refAttachmentList = action.payload;
            state.isEmitRefAttachmentFlag = true;
          }
        }
      });
      return {
        ...state,
        contents,
      };
    case SET_IMPORT_PICTURE:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          if (state.selectedPropertiesModuleId != "") {
            if (content.moduleList?.length > 0) {
              content.moduleList.map((module) => {
                if (module.id == state.selectedPropertiesModuleId) {
                  module.imageName = action.payload;
                  state.isEmitRefAttachmentFlag = true;
                }
              });
            }
          } else if (state.selectedPropertiesProcess) {
            content.processProperties.imageName = action.payload;
            state.isEmitRefAttachmentFlag = true;
          } else content.imageName = action.payload;
        }
      });
      return {
        ...state,
        contents,
      };
    case ACTIVE_ATTACHMENT_URL:
      return {
        ...state,
        activeAttachmentUrl: action.payload,
      };
    case RENAME_MODULE_FLAG:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (action.payload === false) {
            currentContent.selectedModuleIds = [];
          }
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
        renameModuleFlag: action.payload,
      };
    case EMIT_REF_ATTACHMENT:
      return {
        ...state,
        isEmitRefAttachmentFlag: action.payload,
      };
    case ADD_PAGE_BREAK:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (action.widgetPoint !== undefined) {
            currentContent.moduleList.map((currentModule) => {
              let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
                (x, index) =>
                  index === currentContent.activeCursorModuleId &&
                  x.type === "module"
              )?.id;
              if (currentModule.id === activeModuleId) {
                if (
                  currentModule.pageBreakPosition.indexOf(
                    action.widgetPoint
                  ) === -1
                ) {
                  currentModule.pageBreakPosition = [
                    ...currentModule.pageBreakPosition,
                    action.widgetPoint,
                  ];
                }
              }
              return currentModule;
            });
          } else {
            if (
              currentContent.pageBreakPosition.indexOf(action.payload) === -1
            ) {
              action.payload =
                action.payload === undefined ? -1 : action.payload;
              currentContent.pageBreakPosition = [
                ...currentContent.pageBreakPosition,
                action.payload,
              ];
            }
          }
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SELECT_PAGE_BREAK:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (action.widgetIndex !== undefined) {
            if (
              currentContent.selectedInnerPagebreakDetails.moduleId ===
                action.moduleId &&
              currentContent.selectedInnerPagebreakDetails.widgetIndex ===
                action.widgetIndex
            ) {
              currentContent.selectedInnerPagebreakDetails.widgetIndex = undefined;
              currentContent.selectedInnerPagebreakDetails.moduleId = undefined;
            } else {
              currentContent.selectedInnerPagebreakDetails.widgetIndex =
                action.widgetIndex;
              currentContent.selectedInnerPagebreakDetails.moduleId =
                action.moduleId;
            }
            currentContent.selectedOuterPagebreakIndex = undefined;
          } else {
            if (currentContent.selectedOuterPagebreakIndex === action.payload) {
              currentContent.selectedOuterPagebreakIndex = undefined;
            } else {
              currentContent.selectedOuterPagebreakIndex = action.payload;
            }
            currentContent.selectedInnerPagebreakDetails.widgetIndex = undefined;
            currentContent.selectedInnerPagebreakDetails.moduleId = undefined;
          }
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case DELETE_PAGE_BREAK:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          if (currentContent.selectedOuterPagebreakIndex !== undefined) {
            //currentContent.selectedOuterPagebreakIndex = currentContent.selectedOuterPagebreakIndex === -1 ? currentContent.pageBreakPosition.findIndex(x => x === currentContent.selectedOuterPagebreakIndex) : currentContent.selectedOuterPagebreakIndex;
            let index = currentContent.pageBreakPosition.findIndex(
              (x) => x === currentContent.selectedOuterPagebreakIndex
            );
            currentContent.pageBreakPosition.splice(index, 1);
            currentContent.selectedOuterPagebreakIndex = undefined;
          } else {
            currentContent.moduleList.map((currentModule) => {
              if (
                currentModule.id ===
                currentContent.selectedInnerPagebreakDetails.moduleId
              ) {
                // currentContent.selectedInnerPagebreakDetails.widgetIndex = currentContent.selectedInnerPagebreakDetails.widgetIndex === -1 ? currentContent.pageBreakPosition.findIndex(x => x === currentContent.selectedInnerPagebreakDetails.widgetIndex) : currentContent.selectedInnerPagebreakDetails.widgetIndex;
                let index = currentModule.pageBreakPosition.findIndex(
                  (x) =>
                    x ===
                    currentContent.selectedInnerPagebreakDetails.widgetIndex
                );
                currentModule.pageBreakPosition.splice(index, 1);
                currentContent.selectedInnerPagebreakDetails.widgetIndex = undefined;
                currentContent.selectedInnerPagebreakDetails.moduleId = undefined;
              }
            });
          }
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SET_WIDGET_DUPLICATE_STATUS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          let index = currentContent.widgetDuplicateStatus.findIndex(
            (x) => x.id === action.payload
          );
          if (index > -1) currentContent.widgetDuplicateStatus.splice(index, 1);
          if (action.status)
            currentContent.widgetDuplicateStatus.push({
              id: action.payload,
              status: action.status,
            });
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SET_CONTENT_WIDGET_LABELS:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.contentWidgetLabels = action.payload;
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case SET_RECENT_ADDED_WIDGET:
      return {
        ...state,
        recentAddedWidget: {},
      };
    case SET_ACTIVE_BRANCH_CURSOR_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.branchWidgetCursorIndex = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_NESTED_BRANCH_CURSOR_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.nestedBranchWidgetCursorIndex = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_EXECUTION_CURSOR_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.executionFrameCursorId = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_NESTED_WIDGET_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.activeNestedWidgetId = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_ACTIVE_NESTED_EXECUTION_ID:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.nestedExecutionFrameCursorId = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case ADD_WIDGET_INSIDE_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  function insertAt(array, index, ...elements) {
                    array.splice(index, 0, ...elements);
                    if (currentContent.branchWidgetCursorIndex !== undefined) {
                      currentContent.branchWidgetCursorIndex =
                        currentContent.branchWidgetCursorIndex + 1;
                    }
                  }
                  if (currentWidget.branchControlType === "switch") {
                    let condition = {
                      conditions: [
                        {
                          field: "",
                          expression: "<",
                          value: "",
                        },
                      ],
                    };
                    currentWidget.branchConditions = [
                      ...currentWidget.branchConditions,
                      condition,
                    ];
                  }
                  insertAt(
                    currentWidget.widgetList,
                    currentContent.branchWidgetCursorIndex + 1,
                    action.payload
                  );
                  // currentWidget.widgetList.push(action.payload)
                }
                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  function insertAt(array, index, ...elements) {
                    array.splice(index, 0, ...elements);
                    if (currentContent.branchWidgetCursorIndex !== undefined) {
                      currentContent.branchWidgetCursorIndex =
                        currentContent.branchWidgetCursorIndex + 1;
                    }
                  }

                  insertAt(
                    currentWidget.widgetList,
                    currentContent.branchWidgetCursorIndex + 1,
                    action.payload
                  );
                  // currentWidget.widgetList.push(action.payload)
                }
                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  currentWidget.widgetList.map((wid, idx) => {
                    if (idx === currentContent.branchWidgetCursorIndex) {
                      if (wid.widgetType === "branch") {
                        function insertAt(array, index, ...elements) {
                          array.splice(index, 0, ...elements);
                          if (
                            currentContent.nestedBranchWidgetCursorIndex !==
                            undefined
                          ) {
                            currentContent.nestedBranchWidgetCursorIndex =
                              currentContent.nestedBranchWidgetCursorIndex + 1;
                          }
                        }
                        if (wid.branchControlType === "switch") {
                          let condition = {
                            conditions: [
                              {
                                field: "",
                                expression: "<",
                                value: "",
                              },
                            ],
                          };
                          wid.branchConditions = [
                            ...wid.branchConditions,
                            condition,
                          ];
                        }
                        insertAt(
                          wid.widgetList,
                          currentContent.nestedBranchWidgetCursorIndex + 1,
                          action.payload
                        );
                      }
                    }

                    return wid;
                  });
                }
                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_NESTED_WIDGET_INSIDE_BRANCH_WIDGET_CONDITION:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  currentWidget.widgetList.map((wid, idx) => {
                    if (wid.widgetType === "branch") {
                      function insertAt(array, index, ...elements) {
                        array.splice(index, 0, ...elements);
                        if (
                          currentContent.nestedBranchWidgetCursorIndex !==
                          undefined
                        ) {
                          currentContent.nestedBranchWidgetCursorIndex =
                            currentContent.nestedBranchWidgetCursorIndex + 1;
                        }
                      }

                      insertAt(
                        wid.widgetList,
                        currentContent.nestedBranchWidgetCursorIndex + 1,
                        action.payload
                      );
                    }
                    return wid;
                  });
                }
                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((currentWidget) => {
            let activeWidgetId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "widget"
            )?.id;
            if (activeWidgetId === currentWidget.id) {
              currentWidget.widgetList.map((wid, idx) => {
                function insertAt(array, index, ...elements) {
                  array.splice(index, 0, ...elements);
                  if (
                    currentContent.nestedBranchWidgetCursorIndex !== undefined
                  ) {
                    currentContent.nestedBranchWidgetCursorIndex =
                      currentContent.nestedBranchWidgetCursorIndex + 1;
                  }
                }
                if (wid.branchControlType === "switch") {
                  let condition = {
                    conditions: [
                      {
                        field: "",
                        expression: "<",
                        value: "",
                      },
                    ],
                  };
                  wid.branchConditions = [...wid.branchConditions, condition];
                }
                insertAt(
                  wid.widgetList,
                  currentContent.nestedBranchWidgetCursorIndex + 1,
                  action.payload
                );
                return wid;
              });

              //currentWidget.widgetList.push(action.payload)
            }
            return currentWidget;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_NESTED_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((currentWidget) => {
            let activeWidgetId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "widget"
            )?.id;
            if (activeWidgetId === currentWidget.id) {
              currentWidget.widgetList.map((wid, idx) => {
                function insertAt(array, index, ...elements) {
                  array.splice(index, 0, ...elements);
                  if (
                    currentContent.nestedBranchWidgetCursorIndex !== undefined
                  ) {
                    currentContent.nestedBranchWidgetCursorIndex =
                      currentContent.nestedBranchWidgetCursorIndex + 1;
                  }
                }

                insertAt(
                  wid.widgetList,
                  currentContent.nestedBranchWidgetCursorIndex + 1,
                  action.payload
                );
                return wid;
              });

              //currentWidget.widgetList.push(action.payload)
            }
            return currentWidget;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_OUTSIDE_BRANCH_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((currentWidget) => {
            let activeWidgetId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "widget"
            )?.id;
            if (activeWidgetId === currentWidget.id) {
              function insertAt(array, index, ...elements) {
                array.splice(index, 0, ...elements);
                if (currentContent.branchWidgetCursorIndex !== undefined) {
                  currentContent.branchWidgetCursorIndex =
                    currentContent.branchWidgetCursorIndex + 1;
                }
              }
              if (
                currentWidget.branchControlType === "switch" &&
                currentContent.condition !== false
              ) {
                let condition = {
                  conditions: [
                    {
                      field: "",
                      expression: "<",
                      value: "",
                    },
                  ],
                };
                currentWidget.branchConditions = [
                  ...currentWidget.branchConditions,
                  condition,
                ];
              }
              insertAt(
                currentWidget.widgetList,
                currentContent.branchWidgetCursorIndex + 1,
                action.payload
              );
              //currentWidget.widgetList.push(action.payload)
            }
            return currentWidget;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_OUTSIDE_BRANCH_WIDGET_CONDITION:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((currentWidget) => {
            let activeWidgetId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "widget"
            )?.id;
            if (activeWidgetId === currentWidget.id) {
              function insertAt(array, index, ...elements) {
                array.splice(index, 0, ...elements);
                if (currentContent.branchWidgetCursorIndex !== undefined) {
                  currentContent.branchWidgetCursorIndex =
                    currentContent.branchWidgetCursorIndex + 1;
                }
              }

              insertAt(
                currentWidget.widgetList,
                currentContent.branchWidgetCursorIndex + 1,
                action.payload
              );
              //currentWidget.widgetList.push(action.payload)
            }
            return currentWidget;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_INSIDE_EXECUTION_FRAME:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  currentWidget.widgetList.map((wid, idx) => {
                    if (idx === currentContent.branchWidgetCursorIndex) {
                      // if (idx === currentContent.branchWidgetCursorIndex+1) {
                      console.log("execution", wid);
                      if (wid.widgetType === "execution_frame") {
                        function insertAt(array, index, ...elements) {
                          array.splice(index, 0, ...elements);
                          if (
                            currentContent.executionFrameCursorId !== undefined
                          ) {
                            currentContent.executionFrameCursorId =
                              currentContent.executionFrameCursorId + 1;
                          }
                        }
                        insertAt(
                          wid.widgetList,
                          currentContent.executionFrameCursorId + 1,
                          action.payload
                        );
                      }

                      // }
                    }

                    return wid;
                  });
                }

                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_OUTSIDE_EXECUTION_FRAME:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.widgetList.map((currentWidget) => {
            let activeWidgetId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "widget"
            )?.id;
            if (activeWidgetId === currentWidget.id) {
              currentWidget.widgetList.map((wid, idx) => {
                if (idx === currentContent.branchWidgetCursorIndex) {
                  if (wid.widgetType === "execution_frame") {
                    function insertAt(array, index, ...elements) {
                      array.splice(index, 0, ...elements);
                      if (currentContent.executionFrameCursorId !== undefined) {
                        currentContent.executionFrameCursorId =
                          currentContent.executionFrameCursorId + 1;
                      }
                    }
                    insertAt(
                      wid.widgetList,
                      currentContent.executionFrameCursorId + 1,
                      action.payload
                    );
                  }
                }

                return wid;
              });
            }
            return currentWidget;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
        recentAddedWidget: action.payload,
      };
    case ADD_WIDGET_INSIDE_NESTED_EXECUTION_FRAME:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.moduleList.map((currentModule) => {
            let activeModuleId = currentContent.modulesAndOutsideWidgetsPositions.find(
              (x, index) =>
                index === currentContent.activeCursorModuleId &&
                x.type === "module"
            )?.id;
            if (currentModule.id === activeModuleId) {
              currentModule.widgetList.map((currentWidget, i) => {
                if (i === currentContent.activeCursorWidgetId) {
                  currentWidget.widgetList.map((wid, idx) => {
                    if (idx === currentContent.branchWidgetCursorIndex) {
                      // if (idx === currentContent.branchWidgetCursorIndex+1) {
                      console.log("execution", wid);
                      if (wid.widgetType === "branch") {
                        wid.widgetList.map((x) => {});
                        function insertAt(array, index, ...elements) {
                          array.splice(index, 0, ...elements);
                          if (
                            currentContent.executionFrameCursorId !== undefined
                          ) {
                            currentContent.executionFrameCursorId =
                              currentContent.executionFrameCursorId + 1;
                          }
                        }
                        insertAt(
                          wid.widgetList,
                          currentContent.executionFrameCursorId + 1,
                          action.payload
                        );
                      }

                      // }
                    }

                    return wid;
                  });
                }

                return currentWidget;
              });
            }
            return currentModule;
          });
        }
        return currentContent;
      });

      return {
        ...state,
        contents,
      };
    case HOLD_CURSOR:
      return { ...state, isCursorFreezedOnKeyChange: action.payload };
    case SET_ACTIVE_FORMBAR_TAB:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.activeFormBarTab = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_COMMON_ACTIVE_FORMBAR_TAB:
      return {
        ...state,
        activeCommonFormBarTab: action.payload,
      };
    case SET_OUTPUT_CURSOT_POSITION:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.outputCursorPosition = action.payload;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_MODULE_WIDGET_POSITION:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.modulesAndOutsideWidgetsPositions =
            action.modulesAndOutsideWidgetsPositions;
          content.modulesWidgetsPositions = action.modulesWidgetsPositions;
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case SET_SELECTED_PROPERTIES_PROCESS:
      return {
        ...state,
        selectedPropertiesProcess: action.payload,
      };
    case SET_GLOBAL_REF_WIDGET:
      contents = state.contents.slice();
      contents.map((currentContent) => {
        if (currentContent.contentId === state.activeContentId) {
          currentContent.globalRefWidget = [];
          currentContent.globalRefWidget = action.payload;
        }
        return currentContent;
      });
      return {
        ...state,
        contents,
      };
    case CLEAR_WIDGET:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          let selectedWidgets = content.selectedWidgetsData?.widgetIds;
          if (selectedWidgets?.length > 0) {
            selectedWidgets.map((selectedWidget) => {
              if (content.moduleList?.length > 0) {
                content.moduleList.map((module) => {
                  if (module?.widgetList?.length > 0) {
                    module.widgetList.map((widget) => {
                      if (widget.id == selectedWidget) clearWidget(widget);
                      if (widget.type === "branch") {
                        if (widget.widgetList?.length > 0) {
                          widget.widgetList.map((nestedWidget) => {
                            if (nestedWidget.id == selectedWidget)
                              clearWidget(nestedWidget);
                            else {
                              if (nestedWidget.type == "execution_frame") {
                                if (nestedWidget.widgetList?.length > 0) {
                                  nestedWidget.widgetList.map(
                                    (innerNestedWidget) => {
                                      if (
                                        innerNestedWidget.id == selectedWidget
                                      )
                                        clearWidget(innerNestedWidget);
                                    }
                                  );
                                }
                              } else if (nestedWidget.type === "branch") {
                                if (nestedWidget.widgetList?.length > 0) {
                                  nestedWidget.widgetList.map(
                                    (innerNestedWidget) => {
                                      if (
                                        innerNestedWidget.id == selectedWidget
                                      )
                                        clearWidget(innerNestedWidget);
                                    }
                                  );
                                }
                              } else {
                                if (nestedWidget.id == selectedWidget)
                                  clearWidget(nestedWidget);
                              }
                            }
                          });
                        }
                      }
                    });
                  }
                });
              }
              // Outside Widgets
              if (content.widgetList?.length > 0) {
                content.widgetList.map((widget) => {
                  if (widget.id == selectedWidget) clearWidget(widget);

                  if (widget.type === "branch") {
                    if (widget.widgetList?.length > 0) {
                      widget.widgetList.map((nestedWidget) => {
                        if (nestedWidget.id == selectedWidget)
                          clearWidget(nestedWidget);
                        else {
                          if (nestedWidget.type == "execution_frame") {
                            if (nestedWidget.widgetList?.length > 0) {
                              nestedWidget.widgetList.map(
                                (innerNestedWidget) => {
                                  if (innerNestedWidget.id == selectedWidget)
                                    clearWidget(innerNestedWidget);
                                }
                              );
                            }
                          } else if (nestedWidget.type === "branch") {
                            if (nestedWidget.widgetList?.length > 0) {
                              nestedWidget.widgetList.map(
                                (innerNestedWidget) => {
                                  if (innerNestedWidget.id == selectedWidget)
                                    clearWidget(innerNestedWidget);
                                }
                              );
                            }
                          } else {
                            if (nestedWidget.id == selectedWidget)
                              clearWidget(nestedWidget);
                          }
                        }
                      });
                    }
                  }
                });
              }
            });
          }
        }
        return content;
      });
      return {
        ...state,
        contents,
      };
    case UPDATE_AUTHOR:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.authors = action.payload;
        }
      });
      return {
        ...state,
        contents,
      };
    case SET_CONTENT_AUTHOR:
      contents = state.contents.slice();
      contents.map((content) => {
        if (content.contentId === state.activeContentId) {
          content.authors = action.payload;
        }
      });
      return {
        ...state,
        contents,
      };
    case SET_TAB_CHANGE:
      return {
        ...state,
        isContentTabChange: action.payload,
      };
    default:
      return state;
  }
}

function clearWidget(widget) {
  widget.body = null;
  widget.bookmark = false;
  widget.comment = null;
  widget.export = false;
  widget.help = null;
  widget.hide = false;
  widget.required = false;
  widget.answerRequired = null;
  widget.answerRequiredValue = null;
  widget.defaultText = null;
  widget.formatValidationStatus = null;
  widget.formatValidationValue = null;
  widget.hintText = null;
  widget.hintTextValue = null;
  widget.indent = null;
  widget.note = null;
  widget.showDefaultAnswer = null;
  widget.showDefaultAnswerValue = null;
  widget.size = null;
  widget.useDefaultAnswerValue = null;
  widget.useDefaultValue = null;
  widget.layout = null;
  widget.decimalValue = null;
  widget.defaultValue = null;
  widget.maximumValue = null;
  widget.minimumValue = null;
  widget.defaultOptions = [
    { value: "", option: "", defaultStatus: false },
    { value: "", option: "", defaultStatus: false },
    { value: "", option: "", defaultStatus: false },
  ];
  widget.branchConditions = [
    {
      conditions: [{ field: "", expression: "<", value: "" }],
    },
  ];
  widget.branchControlType = "skip";
}

/// **** do not remove ****
/*
case TOGGLE_WIDGET_TYPE:
    contents = state.contents.slice();
    const { type } = action.payload;
    contents.map((currentContent) => {
      if (currentContent.contentId === state.activeContentId) {
        currentContent.moduleList.map((currentModule) => {
          currentModule.widgetList.map((widget) => {
            if (currentModule.id === widget.moduleId) {
              if (widget.id === action.payload.id) {
                if (
                  widget.toggledWidgets &&
                  Object.keys(widget.toggledWidgets).length > 0
                ) {
                  let isExist = false;
                  if (widget.toggledWidgets.hasOwnProperty(type))
                    isExist = true;
                  if (isExist) {
                    widget.toggledWidgets = { ...widget.toggledWidgets };
                    widget.toggledWidgets[widget.type] = Object.assign(
                      {},
                      widget
                    );
                    widget.body = widget.toggledWidgets[type].body || null;
                    widget.bookmark =
                      widget.toggledWidgets[type].bookmark || false;
                    widget.comment =
                      widget.toggledWidgets[type].comment || null;
                    widget.export =
                      widget.toggledWidgets[type].export || false;
                    widget.help = widget.toggledWidgets[type].help || null;
                    widget.hide = widget.toggledWidgets[type].hide || false;
                    widget.required =
                      widget.toggledWidgets[type].required || false;
                    widget.answerRequired =
                      widget.toggledWidgets[type].answerRequired || null;
                    widget.answerRequiredValue =
                      widget.toggledWidgets[type].answerRequiredValue || null;
                    widget.defaultText =
                      widget.toggledWidgets[type].defaultText || null;
                    widget.date_defaultValue =
                      widget.toggledWidgets[type].date_defaultValue || null;
                    widget.date_maxValue =
                      widget.toggledWidgets[type].date_maxValue || null;
                    widget.date_minValue =
                      widget.toggledWidgets[type].date_minValue || null;
                    widget.value = widget.toggledWidgets[type].value || null;
                    widget.time_minValue =
                      widget.toggledWidgets[type].time_minValue || null;
                    widget.time_maxValue =
                      widget.toggledWidgets[type].time_maxValue || null;
                    widget.time_defaultValue =
                      widget.toggledWidgets[type].time_defaultValue || null;
                    widget.formatValidationStatus =
                      widget.toggledWidgets[type].formatValidationStatus ||
                      null;
                    widget.formatValidationValue =
                      widget.toggledWidgets[type].formatValidationValue ||
                      null;
                    widget.hintText =
                      widget.toggledWidgets[type].hintText || null;
                    widget.hintTextValue =
                      widget.toggledWidgets[type].hintTextValue || null;
                    widget.indent =
                      widget.toggledWidgets[type].indent || null;
                    widget.note = widget.toggledWidgets[type].note || null;
                    widget.showDefaultAnswer =
                      widget.toggledWidgets[type].showDefaultAnswer || null;
                    widget.showDefaultAnswerValue =
                      widget.toggledWidgets[type].showDefaultAnswerValue ||
                      null;
                    widget.size = widget.toggledWidgets[type].size || null;
                    widget.useDefaultAnswerValue =
                      widget.toggledWidgets[type].useDefaultAnswerValue ||
                      null;
                    widget.useDefaultValue =
                      widget.toggledWidgets[type].useDefaultValue || null;
                    widget.layout =
                      widget.toggledWidgets[type].layout || null;
                    widget.decimalValue =
                      widget.toggledWidgets[type].decimalValue || null;
                    widget.defaultValue =
                      widget.toggledWidgets[type].defaultValue || null;
                    widget.maximumValue =
                      widget.toggledWidgets[type].maximumValue || null;
                    widget.minimumValue =
                      widget.toggledWidgets[type].minimumValue || null;
                    widget.defaultOptions = widget.toggledWidgets[type]
                      .defaultOptions || [
                      { value: "", option: "", defaultStatus: false },
                      { value: "", option: "", defaultStatus: false },
                      { value: "", option: "", defaultStatus: false },
                    ];
                    widget.branchConditions = [
                      {
                        conditions: [
                          { field: "", expression: "<", value: "" },
                        ],
                      },
                    ];
                    widget.branchControlType = "skip";
                    widget.widgetType = type;
                    widget.type = type;
                  } else {
                    widget.toggledWidgets[widget.type] = Object.assign(
                      {},
                      widget
                    );
                    widget.body = null;
                    widget.bookmark = false;
                    widget.comment = null;
                    widget.export = false;
                    widget.help = null;
                    widget.hide = false;
                    widget.required = false;
                    widget.answerRequired = null;
                    widget.answerRequiredValue = null;
                    widget.defaultText = null;
                    widget.formatValidationStatus = null;
                    widget.formatValidationValue = null;
                    widget.hintText = null;
                    widget.hintTextValue = null;
                    widget.indent = null;
                    widget.note = null;
                    widget.showDefaultAnswer = null;
                    widget.showDefaultAnswerValue = null;
                    widget.size = null;
                    widget.useDefaultAnswerValue = null;
                    widget.useDefaultValue = null;
                    widget.layout = null;
                    widget.decimalValue = null;
                    widget.defaultValue = null;
                    widget.maximumValue = null;
                    widget.minimumValue = null;
                    widget.defaultOptions = [
                      { value: "", option: "", defaultStatus: false },
                      { value: "", option: "", defaultStatus: false },
                      { value: "", option: "", defaultStatus: false },
                    ];
                    widget.branchConditions = [
                      {
                        conditions: [
                          { field: "", expression: "<", value: "" },
                        ],
                      },
                    ];
                    widget.branchControlType = "skip";
                    widget.widgetType = type;
                    widget.type = type;
                  }
                } else {
                  widget.toggledWidgets = {};
                  widget.toggledWidgets[widget.type] = Object.assign(
                    {},
                    widget
                  );
                  widget.body = null;
                  widget.bookmark = false;
                  widget.comment = null;
                  widget.export = false;
                  widget.help = null;
                  widget.hide = false;
                  widget.required = false;
                  widget.answerRequired = null;
                  widget.answerRequiredValue = null;
                  widget.defaultText = null;
                  widget.formatValidationStatus = null;
                  widget.formatValidationValue = null;
                  widget.hintText = null;
                  widget.hintTextValue = null;
                  widget.indent = null;
                  widget.note = null;
                  widget.showDefaultAnswer = null;
                  widget.showDefaultAnswerValue = null;
                  widget.size = null;
                  widget.useDefaultAnswerValue = null;
                  widget.useDefaultValue = null;
                  widget.layout = null;
                  widget.decimalValue = null;
                  widget.defaultValue = null;
                  widget.maximumValue = null;
                  widget.minimumValue = null;
                  widget.defaultOptions = [
                    { value: "", option: "", defaultStatus: false },
                    { value: "", option: "", defaultStatus: false },
                    { value: "", option: "", defaultStatus: false },
                  ];
                  widget.branchConditions = [
                    {
                      conditions: [{ field: "", expression: "<", value: "" }],
                    },
                  ];
                  widget.branchControlType = "skip";
                  widget.widgetType = type;
                  widget.type = type;
                }
              }
              return widget;
            }
          });
          return currentModule;
        });
        currentContent.widgetList.map((widget) => {
          if (widget.id === action.payload.id) {
            if (
              widget.toggledWidgets &&
              Object.keys(widget.toggledWidgets).length > 0 &&
              widget.toggledWidgets.hasOwnProperty(type)
            ) {
              // let respectiveWidgetProps = {};
              // ** Creating empty obj for current widget if not exist in toggledWidgets
              if (!widget.toggledWidgets.hasOwnProperty(widget.type))
                widget.toggledWidgets[widget.type] = {};
              // ** to store current modified widget in toggledWidgets
              // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
              if (
                widget.type === NUMBER_WIDGET ||
                widget.type === TIME_INPUT_WIDGET ||
                widget.type === DATE_WIDGET
              ) {
                widget.toggledWidgets[widget.type].minimumValue =
                  widget.minimumValue;
                widget.toggledWidgets[widget.type].maximumValue =
                  widget.maximumValue;
                widget.toggledWidgets[widget.type].defaultValue =
                  widget.defaultValue;
                if (widget.type === NUMBER_WIDGET) {
                  widget.toggledWidgets[widget.type].decimalValue =
                    widget.decimalValue;
                }
              } else if (
                widget.type === TEXT_INPUT_WIDGET ||
                widget.type === CALCULATION_WIDGET ||
                widget.type === NARRATIVE_WIDGET ||
                widget.type === WARNING_INPUT_WIDGET
              ) {
                widget.toggledWidgets[widget.type].defaultText =
                  widget.defaultText;
              }
              // ** single/multiple/binary/dropdown - defaultOptions
              // if (
              //   widget.type === BINARY_INPUT_WIDGET ||
              //   widget.type === SINGLE_CHOICE_WIDGET ||
              //   widget.type === MULTI_CHOICE_WIDGET ||
              //   widget.type === DROPDOWNLIST_WIDGET
              // ) {
              //   respectiveWidgetProps.defaultOptions = [
              //     { value: "", option: "", defaultStatus: false },
              //     { value: "", option: "", defaultStatus: false },
              //   ];
              //   widget.defaultOptions = setDefaultOptionsForWidget(type);
              // }

              // respectiveWidgetProps = widget.toggledWidgets[widget.type];
              // widget.toggledWidgets[widget.type] = Object.assign(
              //   {},
              //   respectiveWidgetProps
              // );

              // ** To copy toggled properties for selected widget
              // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
              if (
                type === NUMBER_WIDGET ||
                type === TIME_INPUT_WIDGET ||
                type === DATE_WIDGET
              ) {
                widget.minimumValue =
                  widget.toggledWidgets[type].minimumValue;
                widget.maximumValue =
                  widget.toggledWidgets[type].maximumValue;
                widget.defaultValue =
                  widget.toggledWidgets[type].defaultValue;
                if (type === NUMBER_WIDGET)
                  widget.decimalValue =
                    widget.toggledWidgets[type].decimalValue;
              } else if (
                type === TEXT_INPUT_WIDGET ||
                type === CALCULATION_WIDGET ||
                type === NARRATIVE_WIDGET ||
                type === WARNING_INPUT_WIDGET
              ) {
                // ** text/calc/narr/warn -  defaultText properties
                widget.defaultText = widget.toggledWidgets[type].defaultText;
              }
              // ** single/multiple/binary/dropdown - defaultOptions
              // if (
              //   type === BINARY_INPUT_WIDGET ||
              //   type === SINGLE_CHOICE_WIDGET ||
              //   type === MULTI_CHOICE_WIDGET ||
              //   type === DROPDOWNLIST_WIDGET
              // ) {
              //   widget.defaultOptions =
              //     widget.toggledWidgets[type].defaultOptions.length > 0
              //       ? widget.toggledWidgets[type].defaultOptions
              //       : setDefaultOptionsForWidget(type);
              // }
            } else {
              let respectiveWidgetProps = {};
              if (!widget.toggledWidgets) widget.toggledWidgets = {};
              // ** Num/Time/Date - minimumValue,maximumValue, defaultValue, decimalValue
              if (
                widget.type === NUMBER_WIDGET ||
                widget.type === TIME_INPUT_WIDGET ||
                widget.type === DATE_WIDGET
              ) {
                respectiveWidgetProps.minimumValue = widget.minimumValue;
                respectiveWidgetProps.maximumValue = widget.maximumValue;
                respectiveWidgetProps.defaultValue = widget.defaultValue;
                widget.minimumValue = null;
                widget.maximumValue = null;
                widget.defaultValue = null;
                if (widget.type === NUMBER_WIDGET) {
                  respectiveWidgetProps.decimalValue = widget.decimalValue;
                  widget.decimalValue = null;
                }
              } else if (
                widget.type === TEXT_INPUT_WIDGET ||
                widget.type === CALCULATION_WIDGET ||
                widget.type === NARRATIVE_WIDGET ||
                widget.type === WARNING_INPUT_WIDGET
              ) {
                respectiveWidgetProps.defaultText = widget.defaultText;
                widget.defaultText = "";
              }
              // single/multiple/binary/dropdown - defaultOptions
              // if (
              //   widget.type === BINARY_INPUT_WIDGET ||
              //   widget.type === SINGLE_CHOICE_WIDGET ||
              //   widget.type === MULTI_CHOICE_WIDGET ||
              //   widget.type === DROPDOWNLIST_WIDGET
              // ) {
              //   respectiveWidgetProps.defaultOptions = [
              //     { value: "", option: "", defaultStatus: false },
              //     { value: "", option: "", defaultStatus: false },
              //   ];
              //   widget.defaultOptions = setDefaultOptionsForWidget(type);
              // }

              widget.toggledWidgets[widget.type] = Object.assign(
                {},
                respectiveWidgetProps
              );
            }

            // ** Other default properties included when switched.
            widget.branchConditions =
              widget.branchConditions?.length > 0
                ? widget.branchConditions
                : [
                    {
                      conditions: [
                        {
                          field: "",
                          expression: "<",
                          value: "",
                        },
                      ],
                    },
                  ];
            widget.branchControlType = "skip";
            widget.widgetType = type;
            widget.type = type;
            return widget;
            if (
              widget.toggledWidgets &&
              Object.keys(widget.toggledWidgets).length > 0
            ) {
              let isExist = false;
              if (widget.toggledWidgets.hasOwnProperty(type)) isExist = true;
              if (isExist) {
                widget.toggledWidgets = { ...widget.toggledWidgets };
                widget.toggledWidgets[widget.type] = Object.assign(
                  {},
                  widget
                );
                widget.body = widget.toggledWidgets[type].body || null;
                widget.bookmark =
                  widget.toggledWidgets[type].bookmark || false;
                widget.comment = widget.toggledWidgets[type].comment || null;
                widget.export = widget.toggledWidgets[type].export || false;
                widget.help = widget.toggledWidgets[type].help || null;
                widget.hide = widget.toggledWidgets[type].hide || false;
                widget.required =
                  widget.toggledWidgets[type].required || false;
                widget.answerRequired =
                  widget.toggledWidgets[type].answerRequired || null;
                widget.answerRequiredValue =
                  widget.toggledWidgets[type].answerRequiredValue || null;
                widget.defaultText =
                  widget.toggledWidgets[type].defaultText || null;
                widget.date_defaultValue =
                  widget.toggledWidgets[type].date_defaultValue || null;
                widget.date_maxValue =
                  widget.toggledWidgets[type].date_maxValue || null;
                widget.date_minValue =
                  widget.toggledWidgets[type].date_minValue || null;
                widget.value = widget.toggledWidgets[type].value || null;
                widget.time_minValue =
                  widget.toggledWidgets[type].time_minValue || null;
                widget.time_maxValue =
                  widget.toggledWidgets[type].time_maxValue || null;
                widget.time_defaultValue =
                  widget.toggledWidgets[type].time_defaultValue || null;
                widget.formatValidationStatus =
                  widget.toggledWidgets[type].formatValidationStatus || null;
                widget.formatValidationValue =
                  widget.toggledWidgets[type].formatValidationValue || null;
                widget.hintText =
                  widget.toggledWidgets[type].hintText || null;
                widget.hintTextValue =
                  widget.toggledWidgets[type].hintTextValue || null;
                widget.indent = widget.toggledWidgets[type].indent || null;
                widget.note = widget.toggledWidgets[type].note || null;
                widget.showDefaultAnswer =
                  widget.toggledWidgets[type].showDefaultAnswer || null;
                widget.showDefaultAnswerValue =
                  widget.toggledWidgets[type].showDefaultAnswerValue || null;
                widget.size = widget.toggledWidgets[type].size || null;
                widget.useDefaultAnswerValue =
                  widget.toggledWidgets[type].useDefaultAnswerValue || null;
                widget.useDefaultValue =
                  widget.toggledWidgets[type].useDefaultValue || null;
                widget.layout = widget.toggledWidgets[type].layout || null;
                widget.decimalValue =
                  widget.toggledWidgets[type].decimalValue || null;
                widget.defaultValue =
                  widget.toggledWidgets[type].defaultValue || null;
                widget.maximumValue =
                  widget.toggledWidgets[type].maximumValue || null;
                widget.minimumValue =
                  widget.toggledWidgets[type].minimumValue || null;
                widget.defaultOptions = widget.toggledWidgets[type]
                  .defaultOptions || [
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                ];
                widget.branchConditions = [
                  {
                    conditions: [{ field: "", expression: "<", value: "" }],
                  },
                ];
                widget.branchControlType = "skip";
                widget.widgetType = type;
                widget.type = type;
              } else {
                widget.toggledWidgets[widget.type] = Object.assign(
                  {},
                  widget
                );
                widget.body = null;
                widget.bookmark = false;
                widget.comment = null;
                widget.export = false;
                widget.help = null;
                widget.hide = false;
                widget.required = false;
                widget.answerRequired = null;
                widget.answerRequiredValue = null;
                widget.defaultText = null;
                widget.formatValidationStatus = null;
                widget.formatValidationValue = null;
                widget.hintText = null;
                widget.hintTextValue = null;
                widget.indent = null;
                widget.note = null;
                widget.showDefaultAnswer = null;
                widget.showDefaultAnswerValue = null;
                widget.size = null;
                widget.useDefaultAnswerValue = null;
                widget.useDefaultValue = null;
                widget.layout = null;
                widget.decimalValue = null;
                widget.defaultValue = null;
                widget.maximumValue = null;
                widget.minimumValue = null;
                widget.defaultOptions = [
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                  { value: "", option: "", defaultStatus: false },
                ];
                widget.branchConditions = [
                  {
                    conditions: [{ field: "", expression: "<", value: "" }],
                  },
                ];
                widget.branchControlType = "skip";
                widget.widgetType = type;
                widget.type = type;
              }
            } else {
              widget.toggledWidgets = {};
              widget.toggledWidgets[widget.type] = Object.assign({}, widget);
              widget.body = null;
              widget.bookmark = false;
              widget.comment = null;
              widget.export = false;
              widget.help = null;
              widget.hide = false;
              widget.required = false;
              widget.answerRequired = null;
              widget.answerRequiredValue = null;
              widget.defaultText = null;
              widget.formatValidationStatus = null;
              widget.formatValidationValue = null;
              widget.hintText = null;
              widget.hintTextValue = null;
              widget.indent = null;
              widget.note = null;
              widget.showDefaultAnswer = null;
              widget.showDefaultAnswerValue = null;
              widget.size = null;
              widget.useDefaultAnswerValue = null;
              widget.useDefaultValue = null;
              widget.layout = null;
              widget.decimalValue = null;
              widget.defaultValue = null;
              widget.maximumValue = null;
              widget.minimumValue = null;
              widget.defaultOptions = [
                { value: "", option: "", defaultStatus: false },
                { value: "", option: "", defaultStatus: false },
                { value: "", option: "", defaultStatus: false },
              ];
              widget.branchConditions = [
                {
                  conditions: [{ field: "", expression: "<", value: "" }],
                },
              ];
              widget.branchControlType = "skip";
              widget.widgetType = type;
              widget.type = type;
            }
          }
          return widget;
        });
      }
      return currentContent;
    });
    return {
      ...state,
      contents,
    };
  */
