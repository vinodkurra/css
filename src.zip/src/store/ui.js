// Defined all imports here
import { stylesApi } from "../calls/apis";

// Defined all action_type constants here
const SAVE_STYLES = "ui/fetched_styles";

// Defined all action creators here
export const fetchStyles = () => {
  return (dispatch) => {
    stylesApi
      .get(`/uiobjects/styles`)
      .then((res) => {
        dispatch({ type: SAVE_STYLES, payload: res.data });
      })
      .catch((err) => {
        //
      });
  };
};



// Defined UI reducer here
export default function (state = {}, action) {
  switch (action.type) {
    case SAVE_STYLES:
      return { ...state, styles: action.payload };
    default:
      return state;
  }
}
