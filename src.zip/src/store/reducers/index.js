import { combineReducers } from 'redux';
import auth from '../auth';
import ui from '../ui';
import content from '../content';
import landingpage from '../LandingPage/index';
import consulationProcess from '../consultationProcess';

export default combineReducers({
  ui,
  auth,
  landingpage,
  consulationProcess,
  content
});
